EditorTools = {}

-- [Comment]
-- @param id  article.lua的id
-- @name name 名称
-- return CS.TCFramework.GameModel
function EditorTools.CreateModel(id, name)
    local gameObject = CS.UnityEngine.GameObject(name == nil and "" or name)
    local model = CS.TCFramework.GameModel("Model", gameObject.transform)
    model:Load(ModelConfig.GetModelPath(id))
    return model
end

-- [Comment]
-- 根据cfg配置文件创建模型和碰撞
-- 备注：配置文件里面需要存在字段 "model"
-- @param cfg文件名称
-- @param cfg的id
-- return CS.TCFramework.GameModel
-- return CS.GeometryCollider
function EditorTools.CreateObject(configName, id)
    local config = ConfigManager.FindConfig(configName, "id", id)
    if not config then
        logError(string.formatc("{0}.cfg 未发现 id:{1}", configName, id))
        return
    end
    local artCfg = ConfigManager.FindConfig(ConfigName.Article,"id",config.model)
    if artCfg and artCfg.model then
        local modelStr = artCfg.model[1]
        local model = EditorTools.CreateModel(modelStr)
        model.transform.position = Vector3(config.x, config.y, config.z)
        model.transform.eulerAngles = Vector3(config.direction_x, config.direction_y, config.direction_z)
        model.transform.localScale = Vector3(artCfg.scale, artCfg.scale, artCfg.scale)
        local modelCfg = ConfigManager.FindConfig(ConfigName.Model,"id", artCfg.model[1])
        local collider 
        if modelCfg then
          if modelCfg .collider == "" then
            logError(string.formatc("model.cfg中id:{0}的字段collider为空", artCfg.model[1]))
          else
            local geometry = ModelConfig.GetGeomerty(modelCfg.collider, modelCfg.collider_shifting)
            collider = CS.GeometryCollider(model.transform, geometry)
          end
        else
            logError(string.formatc("model.cfg 未发现 id:{0}", artCfg.model[1]))
        end
        return model, collider
    else
        logError(string.formatc("article.cfg 未发现 id:{0}", config.model))
    end
end

return EditorTools