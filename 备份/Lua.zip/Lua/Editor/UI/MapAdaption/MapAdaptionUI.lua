local MapAdaptionUI = require "Editor/UI/MapAdaption/MapAdaptionUIDesigner"
local MapAdaptionUICtrl = require "Editor/UI/MapAdaption/MapAdaptionUICtrl"

-- 初始化界面数据，此时UI还未创建完成
-- 只会在第一次加载时触发,需要时打开
--function MapAdaptionUI:Init()
--end

local Type = {
    RewardBox = 1,
    Collection = 2,
}

local PanelName = {
    Window_Name.AdaptionBoxUINode,
    Window_Name.AdaptionCollectionUINode,
}

-- 界面创建完成
function MapAdaptionUI:OnCreate()
    self:InitControls()
    self:InitCustomizeControls()
    self:InitUI()
    self:RegistUIEvents()
    self:RegistCustomizeUIEvents()
    self.ctrl = MapAdaptionUICtrl(self)
end

function MapAdaptionUI:InitUI()

end

-- 初始化自定义控件
function MapAdaptionUI:InitCustomizeControls()
end

-- 界面显示时调用
function MapAdaptionUI:OnShow()
    self:RegistEvents()
    --self:Refresh()
    self:JumpPageByName(Type.RewardBox,true)
    self.SelectNode.RewardBox:SetToggleIsOn(true)
end


function MapAdaptionUI:JumpPageByName(tab,isOn)
    local windName = PanelName[tab]
    if isOn then
        self:ShowWidget(windName,self.ChildNode.transform,self)
        self.atShowPanel = windName
    else
        self:HideWidget(windName)
    end
 end

-- 界面隐藏时调用
function MapAdaptionUI:OnHide()
end

-- 界面销毁时调用
function MapAdaptionUI:OnDestroy()
    if self.ctrl then
        self.ctrl:Destroy()
    end
end

function MapAdaptionUI:TabToggle_OnClick(control, isOn)
    local tabKey = control.index
    self:JumpPageByName(tabKey,isOn)
end
-- 处理键盘事件，返回true表示已处理
--function MapAdaptionUI:OnKeyInput()
--end

-- 每帧更新，需要使用时打开
--function MapAdaptionUI:Update()
--end

--function MapAdaptionUI:LateUpdate()
--end

----------------------------------------------------------------------------------------
-- 注册自定义UI事件
function MapAdaptionUI:RegistCustomizeUIEvents()
    for k, v in pairs(Type) do
        self.SelectNode[k]:SetDataIndex(nil, v)
        self.SelectNode[k]:SetToggleOnClick(self, self.TabToggle_OnClick)
    end
end

-----------------------------------------------------------------------------------------
-- UI事件
function MapAdaptionUI:Button_CloseOnClick(control)
    UIManager.Hide(self.name);
end

----------------------------------------------------------------------------------------
-- 注册Lua事件，使用self:RegistEvent，界面关闭时会自动移除
function MapAdaptionUI:RegistEvents()
end

----------------------------------------------------------------------------------------
-- 刷新界面
function MapAdaptionUI:Refresh()
end
return MapAdaptionUI
