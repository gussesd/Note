local AdaptionCollectionUINode = require "Editor/UI/MapAdaption/AdaptionCollection/AdaptionCollectionUINodeDesigner"
local AdaptionCollectionUINodeCtrl = require "Editor/UI/MapAdaption/AdaptionCollection/AdaptionCollectionUINodeCtrl"

-- 初始化界面数据，此时UI还未创建完成
-- 只会在第一次加载时触发,需要时打开
--function AdaptionCollectionUINode:Init()
--end

-- 界面创建完成
function AdaptionCollectionUINode:OnCreate()
    self:InitControls()
    self:InitCustomizeControls()
    self:InitUI()
    self:RegistUIEvents()
    self:RegistCustomizeUIEvents()
    self.ctrl = AdaptionCollectionUINodeCtrl(self)
end

-- 初始化界面
function AdaptionCollectionUINode:InitUI()
end

-- 初始化自定义控件
function AdaptionCollectionUINode:InitCustomizeControls()
end

-- 界面显示时调用
function AdaptionCollectionUINode:OnShow()
    self:RegistEvents()
    self:Refresh()
end

-- 界面隐藏时调用
function AdaptionCollectionUINode:OnHide()
end

-- 界面销毁时调用
function AdaptionCollectionUINode:OnDestroy()
   if self.ctrl then
        self.ctrl:Destroy()
    end
end

-- 处理键盘事件，返回true表示已处理
--function AdaptionCollectionUINode:OnKeyInput()
--end

-- 每帧更新，需要使用时打开
--function AdaptionCollectionUINode:Update()
--end

--function AdaptionCollectionUINode:LateUpdate()
--end

----------------------------------------------------------------------------------------
-- 注册自定义UI事件
function AdaptionCollectionUINode:RegistCustomizeUIEvents()
end

-----------------------------------------------------------------------------------------
-- UI事件
function AdaptionCollectionUINode:Button_DeleteOnClick(control)
end

function AdaptionCollectionUINode:Button_AddOnClick(control)
end

function AdaptionCollectionUINode:Button_OutPutOnClick(control)
end

function AdaptionCollectionUINode:Button_SaveOnClick(control)
end

function AdaptionCollectionUINode:Button_ShowMonsterOnClick(control)
end

----------------------------------------------------------------------------------------
-- 注册Lua事件，使用self:RegistEvent，界面关闭时会自动移除
function AdaptionCollectionUINode:RegistEvents()
end

----------------------------------------------------------------------------------------
-- 刷新界面
function AdaptionCollectionUINode:Refresh()
end
return AdaptionCollectionUINode
