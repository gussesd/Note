-- 此文件工具自动生成，不要修改
local AdaptionCollectionUINode = class(BaseUI)
AdaptionCollectionUINode.layer = UILayer.Panel
AdaptionCollectionUINode.orderInLayer = 0
AdaptionCollectionUINode.hideType = UIHideType.WaitDestroy
AdaptionCollectionUINode.hideFunc = UIHideFunc.MoveOutOfScreen
AdaptionCollectionUINode.escClose = UIEscClose.DontClose
AdaptionCollectionUINode.isFull = false
AdaptionCollectionUINode.showModel = false
-- 初始化控件，把Tag设为UIControl会在这里生成变量
function AdaptionCollectionUINode:InitControls()
	self.Operation = self:GetControl("Operation")
	self.Button_Delete = self:GetControl("Operation/Button_Delete")
	self.Button_Add = self:GetControl("Operation/Button_Add")
	self.Button_OutPut = self:GetControl("Operation/Button_OutPut")
	self.Button_Save = self:GetControl("Operation/Button_Save")
	self.InputField_ID = self:GetControl("Operation/InputField_ID")
	self.InputField_MonsterID = self:GetControl("Operation/InputField_MonsterID")
	self.InputField_Group = self:GetControl("Operation/InputField_Group")
	self.InputField_Points = self:GetControl("Operation/InputField_Points")
	self.Button_ShowMonster = self:GetControl("Operation/Button_ShowMonster")
	self.CfgList = self:GetControl("CfgList")
	self.ScrollView_BagList = self:GetControl("CfgList/ScrollView_BagList")
end

----------------------------------------------------------------------------------------
-- 注册UI事件
function AdaptionCollectionUINode:RegistUIEvents()
	self.Button_Delete:SetOnClick(self, self.Button_DeleteOnClick)
	self.Button_Add:SetOnClick(self, self.Button_AddOnClick)
	self.Button_OutPut:SetOnClick(self, self.Button_OutPutOnClick)
	self.Button_Save:SetOnClick(self, self.Button_SaveOnClick)
	self.Button_ShowMonster:SetOnClick(self, self.Button_ShowMonsterOnClick)
end

return AdaptionCollectionUINode
