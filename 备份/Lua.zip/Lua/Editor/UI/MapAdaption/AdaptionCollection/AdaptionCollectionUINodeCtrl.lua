local AdaptionCollectionUINodeCtrl = class(BaseUICtrl)

function AdaptionCollectionUINodeCtrl:ctor(view)
     BaseUICtrl.ctor(self, view)
end

return AdaptionCollectionUINodeCtrl
