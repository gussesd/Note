-- 此文件工具自动生成，不要修改
local AdaptionBoxUINode = class(UserWidgetUI)
AdaptionBoxUINode.path = "UI/MapAdaption/AdaptionBox/AdaptionBoxUINode.prefab"

-- 初始化控件，把Tag设为UIControl会在这里生成变量
function AdaptionBoxUINode:InitControls()
	self.Operation = self:GetControl("Operation")
	self.Button_Start = self:GetControl("Operation/Button_Start")
	self.InputField_ConfigID = self:GetControl("Operation/InputField_ConfigID")
	self.Text_RotationID = self:GetControl("Operation/Text_RotationID")
	self.Button_Skip_ConfigID = self:GetControl("Operation/Button_Skip_ConfigID")
	self.Button_Last = self:GetControl("Operation/Button_Last")
	self.Button_Next = self:GetControl("Operation/Button_Next")
	self.Text_Num = self:GetControl("Operation/Image_Num/Text_Num")
	self.Toggle_Save = self:GetControl("Operation/Toggle_Save")
	self.InputField_ProcessID = self:GetControl("Operation/InputField_ProcessID")
	self.Button_Skip_ProcessID = self:GetControl("Operation/Button_Skip_ProcessID")
	self.CfgList = self:GetControl("CfgList")
	self.Text_ID = self:GetControl("CfgList/Image_ID/Text_ID")
	self.Text_Position = self:GetControl("CfgList/Image_Position/Text_Position")
	self.Text_Rotation = self:GetControl("CfgList/Image_Rotation/Text_Rotation")
	self.Button_Update = self:GetControl("CfgList/Button_Update")
	self.Button_Apadtion = self:GetControl("CfgList/Button_Apadtion")
	self.ScrollView = self:GetControl("CfgList/ScrollView")
	self.Panel_Type = self:GetControl("CfgList/ScrollView/Viewport/Panel_Type")
	self.Button_Item = self:GetControl("CfgList/ScrollView/Viewport/Panel_Type/Button_Item")
	self.Button_Selection = self:GetControl("CfgList/Button_Selection")
	self.Text_Selection = self:GetControl("CfgList/Button_Selection/Text_Selection")
end

----------------------------------------------------------------------------------------
-- 注册UI事件
function AdaptionBoxUINode:RegistUIEvents()
	self.Button_Start:SetOnClick(self, self.Button_StartOnClick)
	self.Button_Skip_ConfigID:SetOnClick(self, self.Button_Skip_ConfigIDOnClick)
	self.Button_Last:SetOnClick(self, self.Button_LastOnClick)
	self.Button_Next:SetOnClick(self, self.Button_NextOnClick)
	self.Button_Skip_ProcessID:SetOnClick(self, self.Button_Skip_ProcessIDOnClick)
	self.Button_Update:SetOnClick(self, self.Button_UpdateOnClick)
	self.Button_Apadtion:SetOnClick(self, self.Button_ApadtionOnClick)
	self.Button_Item:SetOnClick(self, self.Button_ItemOnClick)
	self.Button_Selection:SetOnClick(self, self.Button_SelectionOnClick)
end

return AdaptionBoxUINode
