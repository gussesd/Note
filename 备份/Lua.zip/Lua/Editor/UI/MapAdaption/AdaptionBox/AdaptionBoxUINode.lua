local AdaptionBoxUINode = require "Editor/UI/MapAdaption/AdaptionBox/AdaptionBoxUINodeDesigner"
local AdaptionBoxUINodeCtrl = require "Editor/UI/MapAdaption/AdaptionBox/AdaptionBoxUINodeCtrl"

local addDecoID = 0
-- -- 初始化界面数据，此时UI还未创建完成
-- -- 只会在第一次加载时触发,需要时打开
-- function AdaptionBoxUINode:Init()
-- end

local EType = 
{
    "宝箱",
    "采集物",
}

local EConfigType =
{
    ConfigName.BaoXiang,
    ConfigName.CollectionSelf,
}

-- 界面创建完成
function AdaptionBoxUINode:OnLoaded(go)
    UserWidgetUI.OnLoaded(self, go)
    self:InitControls()
    self:InitCustomizeControls()
    self:InitUI()
    self:RegistUIEvents()
    self:RegistCustomizeUIEvents()
    self.ctrl = AdaptionBoxUINodeCtrl(self)
end

-- 初始化界面
function AdaptionBoxUINode:InitUI()
    self.list = {}
    local sceneSize = 8192
    self.sceneSingleSize = 512
    self.size = sceneSize / self.sceneSingleSize
    self.id = 0
    self.maxNum = 0
    self.selectType = 1
    self.isRunning = false
end

-- 初始化自定义控件
function AdaptionBoxUINode:InitCustomizeControls()
    self.contentList = UIListContainer(self.ScrollView.loopListView,
    "Button_Item",self,nil,self.UpdateScrollItemCall)
    self.contentList:SetData(EType)
end

-- 界面显示时调用
function AdaptionBoxUINode:OnShow()
    self:RegistEvents()
    self:Refresh()
end

-- 界面隐藏时调用
function AdaptionBoxUINode:OnHide()
end

-- 界面销毁时调用
function AdaptionBoxUINode:OnDestroy()
    if self.ctrl then
        self.ctrl:Destroy()
    end
    if self.model ~= nil then
        CS.UnityEngine.Object.Destroy(self.model.transform.parent.gameObject)
    end 
    self.collider = nil
end

-- 处理键盘事件，返回true表示已处理
--function AdaptionBoxUINode:OnKeyInput()
--end

-- 每帧更新，需要使用时打开
function AdaptionBoxUINode:Update()
    if self.model ~= nil then
        self.Text_Position:SetText(string.format("(%.2f,%.2f,%.2f)", self.model.transform.position.x, self.model.transform.position.y,  self.model.transform.position.z))
        self.Text_Rotation:SetText(string.format("(%.2f,%.2f,%.2f)", self.model.transform.eulerAngles.x, self.model.transform.eulerAngles.y,  self.model.transform.eulerAngles.z))
    else
        self.Text_Position:SetText("(0,0,0)")
        self.Text_Rotation:SetText("(0,0,0)")
    end
end

--function AdaptionBoxUINode:LateUpdate()
--end

----------------------------------------------------------------------------------------
-- 注册自定义UI事件
function AdaptionBoxUINode:RegistCustomizeUIEvents()
end

-----------------------------------------------------------------------------------------
-- UI事件
function AdaptionBoxUINode:Button_StartOnClick(control)
    self.maxNum = 0
    table.quickClear(self.list)
    local test = {}
    for i = 1, self.size * self.size do
        table.insert(test, {})
    end
    local config = ConfigManager.GetConfigTable(EConfigType[self.selectType])
    for key,value in pairs(config) do
        if value.mapid == 1000 then
           self.maxNum = self.maxNum + 1
           local index = math.ceil(value.x / self.sceneSingleSize) + math.ceil((value.z / self.sceneSingleSize)) * self.size
           table.insert(test[index], key)
        end
    end
    local num = 1
    for key,value in pairs(test) do
        for k,v in pairs(value) do
            self.list[num] = config[v]
            num = num + 1 
        end
    end
    self.isRunning = true
    self:ChangeShow(1)
end

function AdaptionBoxUINode:Button_Skip_ConfigIDOnClick(control)
    local str = self.InputField_ConfigID:GetInputText()
    if str ~= "" then
        local id = tonumber(str)
        for k,v in pairs(self.list) do
            if v.id == id then
                self:ChangeShow(k)
                return
            end
        end
        logError("当前配置表未找到id:"..id)
    else 
        logError("请输入id")
    end
end

function AdaptionBoxUINode:Button_Skip_ProcessIDOnClick(control)
    local str = self.InputField_ProcessID:GetInputText()
    if str ~= "" then
        local id = tonumber(str)
        if id > self.maxNum or id <= 0 then
            logError("请填写正确id!")
            return
        end
        self:ChangeShow(id)
    end
end

function AdaptionBoxUINode:Button_LastOnClick(control)
    self:ChangeShow(self.id - 1)
end

function AdaptionBoxUINode:Button_NextOnClick(control)
    self:ChangeShow(self.id + 1)
end

function AdaptionBoxUINode:Button_UpdateOnClick(control)
    self:Update()
end

function AdaptionBoxUINode:Button_ApadtionOnClick(control)
    if not Scene.IsSceneLoading() then
        if  self.collider then
            self.collider:AdaptTerrainInfo()
            self:Update()
        end
    else
        logError("地形正在加载中,请稍后")
    end
end

function AdaptionBoxUINode:UpdateScrollItemCall(obj,index)
    local data = EType[index]
    obj.Text:SetText(data)
    obj:SetOnClick(self,function()
        self.ScrollView:SetActive(false)
        if self.selectType ~= index then
           self:Reset()
           self.Text_Selection:SetText(data)
           self.selectType = index
        end
    end)
end

function AdaptionBoxUINode:Button_SelectionOnClick(control)
    self.ScrollView:SetActive(true)
end
----------------------------------------------------------------------------------------
-- 注册Lua事件，使用self:RegistEvent，界面关闭时会自动移除
function AdaptionBoxUINode:RegistEvents()
end

----------------------------------------------------------------------------------------
-- 刷新界面
function AdaptionBoxUINode:Refresh()
end

----------------------------------------------------------------------------------------
-- 自定义
function AdaptionBoxUINode:RefreshNum()
    self.Text_Num:SetText(string.formatc("{0}/{1}", self.id, self.maxNum))
end

function AdaptionBoxUINode:ChangeShow(id)
    if not isRunning then
       return
    end
    if id <= 0 or id > self.maxNum then
        return
    end
    -- 保存上一次的
    self:Save()
    self.id = id
    local config = self.list[id]
    self:MoveTo(config.x - 1,config.y,config.z - 1)
    if self.model ~= nil then
        CS.UnityEngine.Object.Destroy(self.model.transform.parent.gameObject)
        self.collider = nil
    end
    local name = EConfigType[self.selectType]
    local model, collider = EditorTools.CreateObject(name, config.id)
    self.model = model
    self.collider = collider
    self.Text_ID:SetText(config.id)
    self:RefreshNum()
    self:Update()
end

function AdaptionBoxUINode:MoveTo(x,y,z)
    local h = Scene.GetHeight(x, y == 0 and 1000 or y, z)
    UnitManager.hero:SynchPos(x,h,z)
end

function AdaptionBoxUINode:Save()
    if self.model ~= nil and self.Toggle_Save:GetToggleIsOn() then
        local name = EConfigType[self.selectType]
        local pos = self.model.transform.position
        local dir = self.model.transform.eulerAngles
        local config = self.list[self.id]
        config.x = pos.x
        config.y = pos.y
        config.z = pos.z
        config.direction_x = dir.x
        config.direction_y = dir.y
        config.direction_z = dir.z
        local id = config.id
        CS.CfgUtil.WriteAssignSignToCfg(name, id, "x", string.format("%.2f", pos.x))
        CS.CfgUtil.WriteAssignSignToCfg(name, id, "y", string.format("%.2f", pos.y))
        CS.CfgUtil.WriteAssignSignToCfg(name, id, "z", string.format("%.2f", pos.z))
        CS.CfgUtil.WriteAssignSignToCfg(name, id, "direction_x", string.format("%.2f", dir.x))
        CS.CfgUtil.WriteAssignSignToCfg(name, id, "direction_y", string.format("%.2f", dir.y))
        CS.CfgUtil.WriteAssignSignToCfg(name, id, "direction_z", string.format("%.2f", dir.z))
    end
end

function AdaptionBoxUINode:Reset()
    if self.model ~= nil then
        CS.UnityEngine.Object.Destroy(self.model.transform.parent.gameObject)
        self.model = nil
    end 
    self.collider = nil
    isRunning = false
    table.quickClear(self.list)

    self.Text_Num:SetText("0/0")
    self.Text_ID:SetText("0")
    self.Text_Position:SetText("(0,0,0)")
    self.Text_Rotation:SetText("(0,0,0)")
end

return AdaptionBoxUINode
