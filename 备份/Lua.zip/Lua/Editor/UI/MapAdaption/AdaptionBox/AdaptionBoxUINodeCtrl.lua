local AdaptionBoxUINodeCtrl = class(UserWidgetUICtrl)

function AdaptionBoxUINodeCtrl:ctor(view)
     UserWidgetUICtrl.ctor(self, view)
end

return AdaptionBoxUINodeCtrl
