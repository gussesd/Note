-- 此文件工具自动生成，不要修改
local MapAdaptionUI = class(BaseUI)
MapAdaptionUI.layer = UILayer.Panel
MapAdaptionUI.orderInLayer = 0
MapAdaptionUI.hideType = UIHideType.WaitDestroy
MapAdaptionUI.hideFunc = UIHideFunc.MoveOutOfScreen
MapAdaptionUI.escClose = UIEscClose.Close
MapAdaptionUI.isFull = false
MapAdaptionUI.showModel = false
-- 初始化控件，把Tag设为UIControl会在这里生成变量
function MapAdaptionUI:InitControls()
	self.ChildNode = self:GetControl("UIContent/ChildNode")
	self.Button_Close = self:GetControl("UIContent/CloseNode/Button_Close")
	self.Text_Tag = self:GetControl("UIContent/CloseNode/Button_Close/Text_Tag")
	self.SelectNode = self:GetControl("UIContent/SelectNode")
end

----------------------------------------------------------------------------------------
-- 注册UI事件
function MapAdaptionUI:RegistUIEvents()
	self.Button_Close:SetOnClick(self, self.Button_CloseOnClick)
end

return MapAdaptionUI
