local MapAdaptionUICtrl = class(BaseUICtrl)

function MapAdaptionUICtrl:ctor(view)
     BaseUICtrl.ctor(self, view)
end

return MapAdaptionUICtrl
