--碰撞器数据
local ColliderData = class()

function ColliderData:ctor(avatar, collider, args)
    self:PoolCtor(avatar, collider, args)
end

function ColliderData:PoolCtor(avatar, collider, args)
    self.avatar = avatar
    self.collider = collider
    self.args = args
end

function ColliderData:PoolReset()
    self.avatar = nil
    self.collider = nil
    self.args = nil
end

function ColliderData:OnTriggerEnter(targetData, colliderPos)
    --不处理两个trigger直接的交互
    if targetData.args and targetData.args.trigger and self.args and self.args.trigger then
        return 
    end
    self.avatar:OnTriggerEnter(self.collider, targetData.collider, self.args, targetData.args, colliderPos)
end

function ColliderData:OnTriggerExit(targetData)
    --不处理两个trigger直接的交互
    if targetData.args and targetData.args.trigger and self.args and self.args.trigger then
        return 
    end
    self.avatar:OnTriggerExit(self.collider, targetData.collider, self.args, targetData.args)
end

function ColliderData:OnTriggerStay(targetData)
    --不处理两个trigger直接的交互
    if targetData.args and targetData.args.trigger and self.args and self.args.trigger then
        return 
    end
    if self.avatar.OnTriggerStay then
        self.avatar:OnTriggerStay(self.collider, targetData.collider, self.args, targetData.args)
    end
end

return ColliderData