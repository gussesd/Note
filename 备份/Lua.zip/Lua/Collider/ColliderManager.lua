local CSColliderManager = CS.ColliderManager
local CSGeometryCollider = CS.GeometryCollider
local ColliderManager = {}
local this = ColliderManager

ColliderData = require "Collider/ColliderData"

function ColliderManager.Init()
    this.root = CS.UnityEngine.GameObject("ColliderManager", typeof(CSColliderManager))
    this.csColliderManager = this.root:GetComponent(typeof(CSColliderManager))
    CS.UnityEngine.Object.DontDestroyOnLoad(this.root)

    this.colliders = {}
end

-- [Comment]
-- 添加碰撞器参与碰撞
-- object 持有碰撞事件的对象
-- collider 碰撞器
-- args 自定义参数
-- return nil
function ColliderManager.AddObject(avatar, collider, args)
    --logError("AddObject")
    this.csColliderManager:AddObject(collider)
    this.colliders[collider] = PoolManager.Get("ColliderData", avatar, collider, args)
end

-- [Comment]
-- 添加碰撞器参与碰撞
-- object 持有碰撞事件的对象
-- collider 碰撞器
-- args 自定义参数
-- return nil
function ColliderManager.AddObjectImmediate(avatar, collider, args)
    --logError("AddObjectImmediate")
    this.colliders[collider] = PoolManager.Get("ColliderData", avatar, collider, args)
    this.csColliderManager:AddObjectImmediate(collider)
end

-- [Comment]
-- 将碰撞器移除参与碰撞
-- collider 碰撞器
-- return nil
function ColliderManager.RemoveObject(collider)
    --logError("RemoveObject")
    if not collider then
        return
    end
    this.csColliderManager:RemoveObject(collider)
    --this.colliders[collider] = PoolManager.Release(this.colliders[collider])
end

-- [Comment]
-- 立即删除碰撞器
-- collider 碰撞器
-- return nil
function ColliderManager.RemoveObjectImmediate(collider)
    --logError("RemoveObjectImmediate")
    this.csColliderManager:RemoveObjectImmediate(collider)
    this.colliders[collider] = PoolManager.Release(this.colliders[collider])
end

function ColliderManager.GetColliderData(collider)
    return this.colliders[collider]
end

-- [Comment]
-- 碰撞发生事件
-- collider1 碰撞器1
-- collider2 碰撞器2
-- return nil
function ColliderManager.OnTriggerEnter(collider1, collider2, colliderPos)
    local data1 = this.colliders[collider1]
    local data2 = this.colliders[collider2]
    if data1 and data2 then
        data1:OnTriggerEnter(data2, colliderPos)
        data2:OnTriggerEnter(data1, colliderPos)
        -- logError("OnTriggerEnter", data1.avatar.id, data2.avatar.id)
    end
    --logError("OnTriggerEnter")
    --data1.avatar:OnTriggerEnter(collider1, collider2, colliders1.args, colliders2.args)
    --colliders2.object:OnTriggerEnter(collider2, collider1, colliders2.args, colliders1.args)
end

-- [Comment]
-- 碰撞停留事件
-- collider1 碰撞器1
-- collider2 碰撞器2
-- return nil
function ColliderManager.OnTriggerStay(collider1, collider2)
    local data1 = this.colliders[collider1]
    local data2 = this.colliders[collider2]
    if data1 and data2 then
        data1:OnTriggerStay(data2)
        data2:OnTriggerStay(data1)
    end
    --logError("OnTriggerStay")
    --data1.avatar:OnTriggerEnter(collider1, collider2, colliders1.args, colliders2.args)
    --colliders2.object:OnTriggerEnter(collider2, collider1, colliders2.args, colliders1.args)
end

-- [Comment]
-- 碰撞离开事件
-- collider1 碰撞器1
-- collider2 碰撞器2
-- return nil
function ColliderManager.OnTriggerExit(collider1, collider2)
    local data1 = this.colliders[collider1]
    local data2 = this.colliders[collider2]
    if data1 and data2 then
        data1:OnTriggerExit(data2)
        data2:OnTriggerExit(data1)
        --logError("OnTriggerExit", data1.avatar.id, data2.avatar.id)
    end
    --logError("OnTriggerExit")
    -- local colliders1 = this.colliders[collider1]
    -- local colliders2 = this.colliders[collider2]
    -- colliders1.object:OnTriggerExit(collider1, collider2, colliders1.args, colliders2.args)
    -- colliders2.object:OnTriggerExit(collider2, collider1, colliders2.args, colliders1.args)
end

function ColliderManager.OnDestroyCollider(collider)
    this.colliders[collider] = PoolManager.Release(this.colliders[collider])
end


--- 碰撞世界射线
---@param origin any
---@param direction any
---@param maxDistance any
---@param layerMask any
function ColliderManager.RaycastAll(originX, originY, originZ, directionX, directionY, directionZ, maxDistance, layerMask)
    return this.csColliderManager:RaycastAll(originX, originY, originZ, directionX, directionY, directionZ, maxDistance, layerMask)
end

--- 设置碰撞世界中的碰撞器坐标
---@param collider 碰撞器
---@param position 坐标c
function ColliderManager.SetColliderPosition(collider, position)
    if this.colliders[collider] == nil then
        return false
    end
    collider.position = position
    return this.csColliderManager:UpdateColliderPosition(collider)
end

ColliderManager.Init()
return ColliderManager