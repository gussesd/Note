local ColliderAction = {}

function ColliderAction:Init()
    self.objectList = {}
end

function ColliderAction:AddObject(object, onTrigger)
    local id = object:GetInstanceID()
    if not self.objectList[id] then
        self.object[id] = {Object = object, OnTrigger = onTrigger}
    end
end

function ColliderAction:RemoveObject(object)
    local id = object:GetInstanceID()
    this.object[id] = nil
end

ColliderAction:Init()
return ColliderAction