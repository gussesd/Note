--[[
    管理所有需要update的lua action和action player
]]

local ActionManager = {}
local this = ActionManager
local CSActionManager = CS.TCFramework.ActionManager
local CSResourceManager = CS.TCFramework.ResourceManager
local CSPlayActionArgs = CS.TCFramework.PlayActionArgs
local CSActionDataAsset = CS.TCFramework.ActionDataAsset
local CSActionDataAssetConfig = CS.ActionDataAssetConfig

--检测时间，5秒一次
local checkTimeInterval = 5
function ActionManager.Init()
    this.actionPlayerList = {}
    this.lastActionPlayerKey = 0
    this.luaActionList = {}
    this.lastActionKey = 0
    this.checkTime = 0
    this.RegistEvents()
end

function ActionManager.RegistEvents()

end

function ActionManager.AddAction(luaAction)
    this.lastActionKey  = this.lastActionKey + 1
    this.luaActionList[this.lastActionKey] = luaAction
    return this.lastActionKey
end

function ActionManager.RemoveAction(key)
    this.luaActionList[key] = nil
end

function ActionManager.GetLuaPlayActionArgs(role, rolePos, targets, targetPoses, speed, breakType, callback)
    local args = {}
    args.self = role
    args.selfPos = rolePos
    if speed then
        args.speed = speed
    end

    if targets then
        args.targets = {}
        for k, v in pairs(targets) do
            args.targets[k] = v
        end
    end

    if targetPoses then
        args.targetPoses = {}
        for k, v in pairs(targetPoses) do
            args.targetPoses[k] = Vector3(v.x, v.y, v.z)
        end
    end

    args.breakType = breakType
    args.callback = callback
    
    return args
end

function ActionManager.AddLuaActionPlayer(id, args, immediately, bHero, bMultiple, avatar)
    --logError(id)
    this.lastActionPlayerKey = this.lastActionPlayerKey + 1
    args = args or {}
    local actionPlay = LuaActionManager.Play(id, args, bHero, bMultiple, 0, avatar)
    this.actionPlayerList[this.lastActionPlayerKey] = actionPlay
    return actionPlay
end

function ActionManager.GetPlayActionArgs(roleID, targetIDs, targetPoses)
    local role = CS.LuaActionRole(roleID)
    local args = CSPlayActionArgs.Create(role)
    if targetIDs and #targetIDs > 0 then
        local targets = {}
        for i = 1, #targetIDs do
            if targetIDs[i] > 0 then
                table.insert(targets, CS.LuaActionRole(targetIDs[i]))
            end
        end
        if #targets > 0 then
            args.targets = targets
        end
    end

    if targetPoses and #targetPoses > 0 then
        args.targetPoses = targetPoses
    end

    return args
end

function ActionManager.AddActionPlayer(id, args, immediately, bHero)
    this.lastActionPlayerKey = this.lastActionPlayerKey + 1
    args = args or {}
    local actionPlay
    if not immediately then
        --actionPlay = CSActionManager.Play(path, args)
    else
        --local data = CSResourceManager.LoadAsset(path, typeof(CSActionDataAsset))
        local config = ConfigManager.GetMultiConfig(ConfigName.SkillAction, id)
        if not config then
            return
        end
        local data = CSActionDataAssetConfig.LoadFromConfig(id, config, bHero, 0)
        if data then
            actionPlay = CSActionManager.Play(data, args)
        else
            return
        end
    end
    this.actionPlayerList[this.lastActionPlayerKey] = actionPlay
    return actionPlay
end

function ActionManager:BrokenActionPlayer(actionPlayID, brokenWay)
    local actionPlay = this.actionPlayerList[actionPlayID]
    if actionPlay then
        actionPlay:Stop(0)
        this.RemoveActionPlayer(actionPlayID)
    end
end

function ActionManager.RemoveActionPlayer(actionPlayID)
    this.actionPlayerList[actionPlayID] = nil
end

function ActionManager.Update()
    this.UpdateLuaAction()
    this.UpdateActionPlayer()
end

function ActionManager.UpdateLuaAction()
    for _,v in pairs(this.luaActionList) do
        v:Update()
    end
end

function ActionManager.UpdateActionPlayer()
    if this.checkTime + checkTimeInterval < Time.unscaledTime then
        this.checkTime = Time.unscaledTime
        if table.count(this.actionPlayerList) > 0 then
            for k,v in pairs(this.actionPlayerList) do
                if v and v.bDestroy then
                    this.actionPlayerList[k] = nil
                end
            end
        end
    end
end

function ActionManager.OnChangeScene()
    this.Clean()
end

function ActionManager.Clean()
    this.luaActionList = {}
    this.actionPlayerList = {}
end

ActionManager.Init()

return ActionManager