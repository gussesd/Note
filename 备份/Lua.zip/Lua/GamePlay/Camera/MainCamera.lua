CameraSwitch = require "GamePlay/Camera/CameraSwitch" 
CameraEffect = require "GamePlay/Camera/CameraEffect" 
CameraManager = require "GamePlay/Camera/CameraManager" 
local MainCamera = {}
local this = MainCamera

DEFAULT_CAMERA_DISTANCE = 5
FLY_CAMERA_DISTANCE = 6

function MainCamera.Init()
    this.Sensitivity= 0.2--最低0.2 最高0.3
    this.MinDistance = 1
    this.MaxDistance = 8
    this.MouseYMin = -85
    this.MouseYMax = 45
    this.StartDistance = DEFAULT_CAMERA_DISTANCE
    this.DistanceSmoothTime = 0.7
    this.CameraPivotLocalPosition = Vector3(0, 1.8, 0)
    
    this.curPos = Vector3()
    this.cullingMask = 1
    CS.TCFramework.CameraController.terrainMask = LAYER_MASK.Default
    this.initCamera = CSMainCamera
    this.cameraData = this.initCamera.gameObject:GetComponent(typeof(CS.CustomPipeline.DL.DLAdditionalCameraData))
    this.virtualCameraTrans = this.initCamera.transform:GetChild(0)
    this.virtualCamera = this.virtualCameraTrans.gameObject:GetComponent(typeof(CS.Cinemachine.CinemachineVirtualCamera))

    this.SetCamera(this.initCamera)
    this.SetMouseSensitivity(50)
    this.SetMouseScrollSensitivity(0)
    --记录摄像机初始状态
    this.initPostion = this.camera.transform.localPosition
    this.initAngles = this.camera.transform.localEulerAngles

    if SceneAreaAction then
        SceneAreaAction.AddObject(this.camera.transform, this.OnEnterSceneArea, this.OnLeaveSceneArea)
    end

    this.SetLayerCullDistance()
end

function MainCamera.ChangeVirtualPos(value)
    this.virtualCameraTrans:SetLocalPosition(value.x, value.y, value.z)
end

function MainCamera.ChangeVirtualFov(value)
    local ll =  this.virtualCamera.m_Lens
    ll.FieldOfView = value
    this.virtualCamera.m_Lens = ll
end

function MainCamera.ChangeBlendEffect(isOn)
    if this.brain then
        local CSStyle = CS.Cinemachine.CinemachineBlendDefinition.Style
        local style = CSStyle.Cut
        if isOn then
            style = CSStyle.Linear
        else
            style = CSStyle.Cut
        end
        local vv = CS.Cinemachine.CinemachineBlendDefinition(style,0.3)
        this.brain.m_DefaultBlend = vv
    end

end

function MainCamera.SetCamera(camera)
    camera = camera or this.initCamera
    if this.camera == camera then
        return
    end

    this.camera = camera
    this.cullingMask=this.camera.cullingMask
    this.initCamera.gameObject:SetActive(this.camera == this.initCamera)

    this.SetupCameraController()
end
function MainCamera.SetRoleFaceTarget(target, height)
    this.target = target
    if target and height and height > 0 then
        this.CameraPivotLocalPosition.y = height
        this.controller.CameraPivotLocalPosition = this.CameraPivotLocalPosition
    end
    this.SetupCameraController()

    --修正摄像机朝向
    if target then
        this.controller:StartAlignCameraWithCharacter(180)
    end

    local x, y = this.controller:GetMouse()
    this.controller:SetMouse(x, 1)
    this.SetDistance(0)
end
function MainCamera.SetTarget(target, yaw, pitch, height)
    if this.target == target then
        return
    end

    this.target = target
    if target and height and height > 0 then
        this.CameraPivotLocalPosition.y = height
        this.controller.CameraPivotLocalPosition = this.CameraPivotLocalPosition
    end
    this.SetupCameraController()

    --修正摄像机朝向
    if target and yaw then
        if yaw == 0 then
            --强制跟背
            this:AlignCamera(true)
        else
            this.controller:StartAlignCameraWithCharacter(yaw - target.eulerAngles.y)
        end
    end

    if pitch then
        local x, y = this.controller:GetMouse()
        if pitch > 0 then
            this.controller:SetMouse(x, pitch)
        else
            this.controller:SetMouse(x, 15)
        end
    end
end

function MainCamera.SetupCameraController()
    if not this.controller then
        this.controller = this.camera.gameObject:AddMissingComponent(typeof(CS.ViewCameraController))
        if not this.controller.uiAsset then
            --初始化控件
            this.controller.MinDistance = this.MinDistance
            this.controller.MaxDistance = this.MaxDistance
            this.controller.StartDistance = this.StartDistance
            this.controller.MouseYMin = this.MouseYMin
            this.controller.MouseYMax = this.MouseYMax
            this.controller.CameraPivotLocalPosition = this.CameraPivotLocalPosition
            this.controller.DistanceSmoothTime = this.DistanceSmoothTime
            this.controller.uiAsset = CS.Main.instance.uiRoot:GetComponent(typeof(CS.UIAsset))

            this.viewFrustum = this.camera:GetComponent(typeof(CS.ViewFrustum))
            this.viewFrustum:SetOccludingLayerMask(LAYER_MASK.Terrain | LAYER_MASK.Building)
        end
        this.controller:ResetView()
        --这里才打开CinemachineBrain
        this.brain = this.camera.gameObject:GetComponent(typeof(CS.Cinemachine.CinemachineBrain))
        if this.brain then
            this.brain.enabled = true
        end
    end

    if Main then
        this.controller.Target = this.target
        this.AlignCamera(true, true)
    end
end

function MainCamera.IsClickUI()
    if this.controller then
        return this.controller.uiAsset:IsClickUI()
    end
    return false
end

function MainCamera.LateUpdate()
    if IsObjectNil(this.camera) then
        this.SetCamera(this.initCamera)
    end
end


--function MainCamera.GetClosestDis()
--    return this.controller and this.controller.ClosestDis or -1
--end

function MainCamera.GetController()
    return this.controller
end
function MainCamera.GetYaw()
    return this.controller and this.controller.yaw or 0
end

function MainCamera.GetPitch()
    return this.controller and this.controller.pitch or 0
end

function MainCamera.GetDistance()
    return this.controller and this.controller.distanceSmooth or 10
end

--根据距离获取渐变alpha值
function MainCamera.GetTransparentAlpha()
    local dis = this.GetDistance()
    local pitch = this.GetPitch()
    local radio = 0
    if pitch > 90 and pitch < 330 then
        radio = (330 - pitch) / 60
    end

    if dis >= 1 + 1.5 * radio then
        return 0
    elseif dis >= 0.5 + 1.5 * radio then
        local val = (1 + 1.5 * radio - dis) / (0.5)
        return val * val
    end

    return 1
end

function MainCamera.Reset()
    this.camera.transform:SetLocalPosition(this.initPostion.x, this.initPostion.y, this.initPostion.z)
    this.camera.transform:SetLocalEulerAngles(this.initAngles.x, this.initAngles.y, this.initAngles.z)
    MainCamera.Enable(true)
    this.LeaveWater()
end

function MainCamera.Enable(bEnable)
    --this.camera.enabled = bEnable
    this.camera.gameObject:SetActive(bEnable)
end

function MainCamera.SetLayerCullDistance()
    local list = this.initCamera.layerCullDistances
    --list[LAYER_TYPE.Role] = 50
    --list[LAYER_TYPE.HUD] = 50
    this.initCamera.layerCullDistances = list
end

function MainCamera.StartShake(x, y, z, power, time)
    this.controller:StartShake(x or 10, y or 0, z or 10, power or 0.02, time or 0.05)
end

function MainCamera.OnEnterSceneArea(SceneAreaObj, args)
    log("MainCamera.OnEnterSceneArea", args)
end

function MainCamera.OnLeaveSceneArea(SceneAreaObj, args)
    log("MainCamera.OnLeaveSceneArea", args)
end

--跟背
function MainCamera.AlignCamera(force, fixpitch)
    --每秒最多触发依次
    if not this.AlignCameraTime or Time.unscaledTime - this.AlignCameraTime > 1 or force then
        this.AlignCameraTime = Time.unscaledTime
        if fixpitch then
            local x, y = this.controller:GetMouse()
            this.controller:SetMouse(x, 15)
        end
        --logError("---  "..Time.unscaledTime)
        this.controller:StartAlignCameraWithCharacter()
    end
end

----------------------------------------------
--瞄准镜头

function MainCamera.StartAim()
    this.aiming = true
    this.controller.MinDistance = 1.5--1.3
    this.controller.MaxDistance = 1.5--1.3
    this.curDistance = this.controller:SetDistance(2)
    this.curMouseX, this.curMouseY = this.controller:GetMouse()
    this.controller:SetMouse(this.curMouseX, this.curMouseY)
    --this.controller.StartDistance = 2--1.3
    this.aimCameraPivot = Vector3(0.5, 1.65, 0)
    this.controller.DistanceSmoothTime = 0
    this.StopAnimTimer()
    this.aimTimer = Timer.StartLoop(-1, -1, MainCamera.UpdateAim)
    this.aimStartTime = Time.time
end

function MainCamera.UpdateAim()
    local dltime = Time.time - this.aimStartTime
    if dltime >= 0.2 then
        if this.aiming then
            this.controller.CameraPivotLocalPosition = this.aimCameraPivot
        else
            this.controller.CameraPivotLocalPosition = this.CameraPivotLocalPosition
        end
        this.StopAnimTimer()
    elseif dltime > 0 then
        if this.aiming then
            this.controller.CameraPivotLocalPosition = Vector3.Lerp(this.CameraPivotLocalPosition, this.aimCameraPivot, dltime / 0.2)
        else
            this.controller.CameraPivotLocalPosition = Vector3.Lerp(this.CameraPivotLocalPosition, this.aimCameraPivot, 1 - dltime / 0.2)
        end
    end
end

function MainCamera.GetPivotPos()
    return this.controller.cameraPivotPosition

end

function MainCamera.GetPivotLocalPosition()
    return this.controller.CameraPivotLocalPosition
end
function MainCamera.SetPivotLocalPosition(pos)
    this.controller.CameraPivotLocalPosition = pos
end

function MainCamera.StopAnimTimer()
    if this.aimTimer then
        Timer.Stop(this.aimTimer)
        this.aimTimer = nil
    end
end

function MainCamera.EndAim()
    this.aiming = false
    this.controller.MinDistance = this.MinDistance
    this.controller.MaxDistance = this.MaxDistance
    this.controller:SetDistance(this.curDistance)
    --this.controller.StartDistance = this.StartDistance
    --this.controller.CameraPivotLocalPosition = this.CameraPivotLocalPosition
    this.aimCameraPivot = this.controller.CameraPivotLocalPosition
    this.controller.DistanceSmoothTime = this.DistanceSmoothTime
    --this.controller:ResetView()
    --不再还原角度
    --this.controller:SetMouse(this.curMouseX, this.curMouseY)
    --this.AlignCamera(true)

    this.StopAnimTimer()
    this.aimTimer = Timer.StartLoop(-1, -1, MainCamera.UpdateAim)
    this.aimStartTime = Time.time
end

--外部修改摄像机转向
function MainCamera.MouseSmooth(x, y)
    if x == 0 and y == 0 then
        return
    end
    --外部传入的是像素，这里跟据情况处理灵敏度
    --TODO 可能涉及平台和分辨率
    local sensitivity = this.Sensitivity--math.min(math.max(0.1 * CS.UnityEngine.Screen.dpi / 100, 0.2), 0.3)
    this.controller:UpdateMouse(x * sensitivity, -y * sensitivity)
end
--设置震屏开关
function MainCamera.SetShakeSwitch(bool)
    this.controller.ShakeSwitch = bool
end
--设置控制开关
function MainCamera.SetOffControl(bool)
    this.controller.ActivateCameraControl=not bool
    --this.controller.OffControl=bool
end
--打开/关闭快速拉近距离
function MainCamera.SetOpenFastDis(isopen)
    this.controller:SetOpenFastDis(isopen)
end
--快速拉近摄像机距离
function MainCamera.SetFastDistance(distance,speed)
    this.controller:SetFastDistance(distance,speed)
end
--外部设置摄像机距离
function MainCamera.SetDistance(distance,bImmediately)
    return this.controller:SetDistance(distance, bImmediately or false)
end
--默认15
function MainCamera.TestSetMouseScrollSensitivity(param)
    this.controller.MouseScrollSensitivity=param
end
function MainCamera.SetMouseScrollSensitivity(param)
    if param then
        -- this.controller.MouseScrollSensitivity=param
        -- min-max        0-100转化成0-(max-min)
        if StaticTool.IsAndroid() then
            local min=30
            local max = 50
            local v = min+param*(max-min)/100
            this.controller.MouseScrollSensitivity = v
        else
            local min = 3
            local max = 20
            local v = min+param*(max-min)/100
            this.controller.MouseScrollSensitivity = v
        end
    else
        logError("缩放值为空")
    end
end
function MainCamera.TestSetMouseSensitivity(param)
    this.controller.MouseXSensitivity=param
    this.controller.MouseYSensitivity=param
end
--pc默认8  非pc默认1
function MainCamera.SetMouseSensitivity(param)
    if param then
        --镜头 1-15
        -- this.controller.MouseYSensitivity=param
        -- this.controller.MouseXSensitivity=param
        -- min-max        0-100转化成0-(max-min)
        if StaticTool.IsAndroid() then
            local min=40
            local max = 60
            local v = min+param*(max-min)/100
            this.controller.MouseYSensitivity = v
            this.controller.MouseXSensitivity = v
        else
            local min= 1
            local max = 15
            local v = min+param*(max-min)/100
            this.controller.MouseYSensitivity = v
            this.controller.MouseXSensitivity = v
        end
    else
        logError("滑动系数值为空")
    end
end
--设置高度自动回正
function MainCamera.SetBackCameraY(bool)
    this.controller.BackYSwitch = bool
end
function MainCamera.SetStateBackCameraY(art)
    --actionnamelist表id
    if art == 153 then
        -- logError("---true----",art)
        this.controller:SetStateBackCameraY(true)--开始移动
    elseif (art == 154 or art == 155) or
    (art == 158 or art == 159) or
    (art == 453 or art == 454) or
    (art == 457 or art == 458) or
    art == 277 or--开始飞
    art == 164 or--开始游泳
    art == 149 or art == 151 or art == 150 or--落地 落水
    art == 161  or art == 274 then
        -- logError("---false----",art)
        this.controller:SetStateBackCameraY(false)--结束移动
    -- else
    --     logError("---zhuan----",art)
    end
end

function MainCamera.SetSensitivity(val)
    -- val --0-100转化成min到max
    --瞄准 0.05-0.3
    local min=0.05
    local max = 0.3
    local v = min+val*(max-min)/100
    this.Sensitivity = v
end
--测试值为多少合适
function MainCamera.TestSetSensitivity(val)
    this.Sensitivity = val
end
---------------------------------------------------------------------------------------
--临时支持的入水判定流程
function MainCamera.CheckInWater()
    local num = this.controller:CheckInWater()
    if num==1 then
        this.InWater()
    else
        this.LeaveWater()
    end
    -- local bHit, hitHeight = CS.MoveUtils.CheckInWater(this.camera.transform)
    -- if bHit then
    --     local w, h = this.controller:GetCameraHalfExtends()
    --     this.curPos:Set(this.camera.transform:GetPosition())
    --     --检测运动趋势
    --     if not this.lastPosY then
    --         this.lastPosY = this.curPos.y
    --     end
    --     local bUp = true
    --     if this.lastPosY > this.curPos.y then
    --         bUp = false
    --     end

    --     this.lastPosY = this.curPos.y
        
    --     --说明摄像机在触摸水平面
    --     if this.curPos.y > hitHeight - h and this.curPos.y < hitHeight + h then
    --         if bUp then
    --             this.curPos.y = hitHeight + h + 0.1
    --         else
    --             this.curPos.y = hitHeight - h - 0.1
    --         end
    --         --logError(this.camera.transform.position.y, this.curPos.y, bUp, hitHeight)
    --         this.controller:MoveToHeight(this.curPos.y)
    --     end

    --     if this.curPos.y < hitHeight then
    --         this.InWater()
    --     else
    --         this.LeaveWater()
    --     end
    -- else
    --     this.LeaveWater()
    -- end
end

function MainCamera.InWater()
    if not this.bInWater then
        --logError("InWater")
        this.bInWater = true
        CS.Main.InWater = 1
        CS.CustomPipeline.DL.UnderWaterEffectRenderer.SetUnderWaterEffectState(this.camera, true)
    end
end

function MainCamera.LeaveWater()
    if this.bInWater then
        --logError("LeaveWater")
        this.bInWater = nil
        CS.Main.InWater = 0
        CS.CustomPipeline.DL.UnderWaterEffectRenderer.SetUnderWaterEffectState(this.camera, false)
    end
end

function MainCamera.SetCullingMaskExceptNothingLayer()
    this.camera.cullingMask = this.cullingMask
end
function MainCamera.SetCullingMaskNothingLayer()
    this.camera.cullingMask = 0
end
function MainCamera.SetCameraActive(bActive)
    if this.cameraData then
        this.cameraData.renderActive = bActive
    end
end
function MainCamera.SyncMCPositionByVC()
    this.controller:SyncMCPositionByVC()
end

MainCamera.Init()

return MainCamera