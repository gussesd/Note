local CameraManager = {}
local this = CameraManager
local CSCameraManager = CS.CameraManager.instance

function CameraManager.Init()
end

--设置相机, @CamerasFunctionType
function CameraManager.SetCameraByType(_type)
    --暂停主相机渲染
    MainCamera.SetCameraActive(false)
    ---设置相机类型
    CSCameraManager:SetCameraActive(_type)
end

--开启主相机
function CameraManager.OpenMainCamera()
    CSCameraManager:SetCameraActive(CamerasFunctionType.None)
    --暂停主相机渲染
    MainCamera.SetCameraActive(true)
end

CameraManager.Init()

return CameraManager