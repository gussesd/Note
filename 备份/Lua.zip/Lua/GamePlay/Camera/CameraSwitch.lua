local CameraSwitch = {}
local this = CameraSwitch
local CSCameraSwitch = CS.CameraSwitch.instance

function CameraSwitch.Init()

end

function CameraSwitch.SwitchCamera(cameraID, args, rotateSpeed, moveSpeed, finishHandler)
    this.cameraID = cameraID
        
    if cameraID == CamerasType.ControlMainCamera then
        if args.distance and args.distance > 0 then
            this.cameraDistance = MainCamera.SetDistance(args.distance, moveSpeed and moveSpeed > 0 or false)
        else
            this.cameraDistance = nil
        end
        if finishHandler then
            finishHandler()
        end
    else
        CSCameraSwitch:SwitchCamera(cameraID, args, rotateSpeed, moveSpeed, finishHandler)
    end
end

function CameraSwitch.SwitchCamera2Join(cameraId,pos,rot,view)

    this.cameraID = cameraId
    if cameraId == CamerasType.ControlMainCamera then
        -- 瞬切相机不允许对主相机进行操作
        return
    else
        CSCameraSwitch:SwitchCamera2Join(cameraId,pos,rot,view)
    end

end


function CameraSwitch.AddCameraAct(lookType, rotateTime, moveType, moveTime, cameraTime, lookPos, midPos, movePos, lookTrans)
    --如果当前处于主镜头动作，需要先重置，然后执行C#的动作
    if this.cameraID == CamerasType.ControlMainCamera then
        if this.cameraDistance then
            MainCamera.SetDistance(this.cameraDistance)
        end
    end
    CSCameraSwitch:AddCameraAct(lookType, rotateTime, moveType, moveTime, cameraTime, lookPos, midPos, movePos, lookTrans)
end

function CameraSwitch.SwitchBack()
    if this.cameraID == CamerasType.ControlMainCamera then
        if this.cameraDistance then
            MainCamera.SetDistance(this.cameraDistance)
        end
    else
        CSCameraSwitch:SwitchBack()
    end
end

CameraSwitch.Init()

return CameraSwitch