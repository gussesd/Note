local CameraEffect = {}
local this = CameraEffect

function CameraEffect.Init()
    this.effectList = {}
    this.effectList2 = {}
    this.effectList2Cache = {}
    this.eventContainer = EventContainer(EventManager)
    this.eventContainer:Regist(Event.GamePlay_EnterMap, this.GamePlay_EnterMap)
end

function CameraEffect.GamePlay_EnterMap()
    if Scene.sceneID == 1001 then
        this.Play(10070201)

    end
end

-- 2D屏幕特效用的
function CameraEffect.Play(id, notPlay, isPlot)
    -- 根据曲线 目前写死
    if not isPlot then

        MainCamera.ChangeVirtualFov(55)
    end
    MainCamera.controller.isUpdateFov = false
    if this.effectList[id] and this.effectList[id].model then
        local ad = this.effectList[id].model.gameObject:GetComponent(typeof(CS.ParticleAdaptive))
        ad:Refresh(MainCamera.initCamera.fieldOfView)
        this.effectList[id]:Show2()
        return
    end
    this.effectList[id] = Decoration({
        id = id,
        parent = MainCamera.camera.transform,
        notPlay = notPlay,
        onHide = this.HideEvent,
        onHideTime = 4
    })
    this.effectList[id].model.gameObject:AddMissingComponent(typeof(CS.ParticleAdaptive))
end

function CameraEffect.Load(id)
    if this.effectList2[id] and this.effectList2[id].model and not IsObjectNil(this.effectList[id].model.gameObject) then
        return this.effectList2[id].model.gameObject
    end
    this.effectList2[id] = Decoration({
        id = id,
        parent = MainCamera.camera.transform,
        async = false
    })
    if this.effectList2[id].model and not IsObjectNil(this.effectList2[id].model.gameObject) then
        return this.effectList2[id].model.gameObject
    end
    logError("相机特效加载失败" .. id)
    return nil
end
function CameraEffect.HideActiveObjects()
    for k, v in pairs(this.effectList2) do
        if not IsObjectNil(v.model.gameObject) and v.model.gameObject.activeSelf then
            table.insert(this.effectList2Cache, v)
            v:Hide()
        end
    end
end
function CameraEffect.ShowCachedObjects()
    for k, v in pairs(this.effectList2Cache) do
        v:Show()
    end
    table.quickClear(this.effectList2Cache)
end

function CameraEffect.Clean()
    for k, v in pairs(this.effectList) do
        v:Destroy()
    end
    for k, v in pairs(this.effectList2) do
        v:Destroy()
    end
    table.quickClear(this.effectList)
    table.quickClear(this.effectList2)
end

function CameraEffect.Stop(id)
    local effect = this.effectList[id]
    if effect then
        effect:Destroy()
        this.effectList[id] = nil
    end
end

function CameraEffect.HideEvent()
    MainCamera.controller.isUpdateFov = true
end
function CameraEffect.ClearAll()
    for k, v in pairs(this.effectList) do
        v:Destroy()
    end
end

CameraEffect.Init()

return CameraEffect
