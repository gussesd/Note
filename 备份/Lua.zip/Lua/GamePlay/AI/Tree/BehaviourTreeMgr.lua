--[[
行为树管理器
]]
local BehaviourTreeMgr = {}
local this = BehaviourTreeMgr

function BehaviourTreeMgr.Init()
    this.rootList = {}
    this.logName = "Hero" --打印的对象id
    this.showLog = true --是否打印
end


function BehaviourTreeMgr.DefaultObjID(objid)
    objid = objid ~= nil and objid or (UnitManager.hero == nil and "Hero" or UnitManager.hero:GetName())
    return objid
end

function BehaviourTreeMgr.IsRunning(objid)
    objid = this.DefaultObjID(objid)
    objid = objid ~= nil and objid or this.heroName
    return this.rootList[objid].root ~= nil
end

function BehaviourTreeMgr.Update()
    for key, value in pairs(this.rootList) do
        if value.root and not value.pause then
            if value.root.status == BTStatus.BTS_BEGIN or value.root.status == BTStatus.NONE then
                value.root:Begin()
            elseif value.root.status == BTStatus.BTS_RUNNING then
                value.root:Update()
            end
        end
        if value.delayResume then
            if value.durationResume <= Time.unscaledTime then
                value.delayResume = false
                value.pause = false
                if value.root then
                    value.root:Resume()
                end
            end
        end
        
        if value.delayRemove then
            this.UnloadTree(value.delayRemove, nil, key)
            value.delayRemove = nil
        end
    end

end

---@ 查询行为树是否暂停
function BehaviourTreeMgr.isPause(objId)
    objId = this.DefaultObjID(objId)
    local tree = this.rootList[objId]
    if tree == nil or tree.pause then
        return true
    end
    return false
end


function BehaviourTreeMgr.Pause(objid)
    objid = this.DefaultObjID(objid)
    local tree = this.rootList[objid]
    if tree == nil or tree.pause then
        return
    end
    tree.pause = true
    if tree.root then
        tree.root:Pause()
    end
end

function BehaviourTreeMgr.Resume(duration, objid)
    objid = this.DefaultObjID(objid)
    local tree = this.rootList[objid]
    if tree == nil or not tree.pause then
        return
    end
    tree.delayResume = true
    if duration == nil then
        duration = 0
    end
    tree.durationResume = duration + Time.unscaledTime
end

function BehaviourTreeMgr.LoadTree(tree, objid)
    objid = this.DefaultObjID(objid)
    local treeRoot = this.rootList[objid]
    if not treeRoot then
        treeRoot = {}
        this.rootList[objid] = treeRoot
    end
    if treeRoot.root then
        this.UnloadTree("BehaviourTreeMgr.LoadTree(tree)", nil, objid)
        treeRoot = {}
        this.rootList[objid] = treeRoot
    end

    treeRoot.root = tree
    treeRoot.root:Reset()
    treeRoot.root.bUnload = false
    treeRoot.aiRoot = tree.name
    -- --this.showLog = true
    LPrint.log(ColorCode.Red,"开启行为树 " .. treeRoot.aiRoot)
    --tree:PrintTree()

    return treeRoot.root
end
function BehaviourTreeMgr.LaterLoadTree(tree, delay, objid)
    objid = this.DefaultObjID(objid)
    local treeRoot = this.rootList[objid]
    --LPrint.Log("延时开启行为树 " .. (delay or 0))
    if not treeRoot then
        treeRoot = {}
        this.rootList[objid] = treeRoot
    end
    local function load()
        this.LoadTree(tree, objid)
        this.DeleteTimer(objid)
    end
    if treeRoot.delayLoadTimer then
        this.DeleteTimer(objid)
    end
    treeRoot.delayLoadTimer = Timer.Start(delay or 0, load)
end

function BehaviourTreeMgr.DelayUnloadTree(prt, objid)
    objid = this.DefaultObjID(objid)
    this.rootList[objid].delayRemove = prt
end

function BehaviourTreeMgr.UnloadTree(prt, resetAnimation, objid)
    objid = this.DefaultObjID(objid)
    local tree = this.rootList[objid]
    if tree and tree.root then
        tree.root.bUnload = true
        LPrint.log("~~~~~~~~~~~~~~~~~~~~~~~~~UnloadTree行为树移除：",prt)
        if not tree.root.doNotRelease then
            tree.root:Reset()
            PoolManager.Release(tree.root)
        end

        if objid == "Hero" then
            EventManager.Dispatch(Event.UI_Game_Task_Move,false,0)
            LPrint.log(ColorCode.Red,"行为树移除 ： " ,objid)
        end
        this.rootList[objid] = nil
    end
    if resetAnimation ~= false and UnitManager.hero ~= nil then
        UnitManager.hero:RefreshAnimation()
    end
end

function BehaviourTreeMgr.DeleteTimer(objid)
    local tree = this.rootList[objid]
    if not tree or not tree.delayLoadTimer then
        return
    end
    Timer.Stop(tree.delayLoadTimer)
    tree.delayLoadTimer = nil
end

function BehaviourTreeMgr.GetRoot(objid)
    if type(objid) == "number" and objid < 0 then
        objid = this.DefaultObjID(nil)--小于0代表c#调用
    else
        objid = this.DefaultObjID(objid)
    end
    return this.rootList[objid].root
end

function BehaviourTreeMgr.Reset(resetAnimation, objid)
    objid = this.DefaultObjID(objid)
    local tree = this.rootList[objid]
    --取消延时加载
    if tree and tree.delayLoadTimer then
        this.DeleteTimer(objid)
    end
    --停止当前树
    this.UnloadTree(nil, resetAnimation, objid)
end

function BehaviourTreeMgr.ResetALL()
    for index, value in pairs(this.rootList) do
        this.UnloadTree(nil, nil, index)
        --取消延时加载
        if this.rootList[index].delayLoadTimer then
            this.DeleteTimer(index)
        end
    end
end

function BehaviourTreeMgr.StopMyFollow(reason,objid)
    local objid = this.DefaultObjID(objid)
    local tree = this.rootList[objid]
    if tree and tree.root and tree.root.name == "FollowTeamLeader" then
        this.UnloadTree(reason,false,objid)
        if UnitManager.hero then
            UnitManager.hero.moveCtrl:StopMove()
            UnitManager.hero.inputCtrl:FollowVector(0,0)
        end
        LocalData.BubbleTip("跟随已取消！")
        EventManager.Dispatch(Event.Game_FollowCap,false)
    end
end

BehaviourTreeMgr.Init()

return BehaviourTreeMgr
