local BAutoProtect = {}

function BAutoProtect.BuildTree()
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence", "BAutoProtect")
    LuaActionCreator.End()
    return root
end

return BAutoProtect