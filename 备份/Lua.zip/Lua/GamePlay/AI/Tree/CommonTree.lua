--[[
    常用行为树
]]

local CommonTree = {}



function CommonTree.MoveToNPCAndTalk(npcID, taskID, state)
    LuaActionCreator.Begin()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "MoveToNPCAndTalk"
    root:AddAction(PoolManager.Get("LuaBTAction", "SetPathToTarget", {npcID = npcID, taskID = taskID, state = state}),
                    PoolManager.Get("LuaBTAction", "MoveToPosition"),
                    PoolManager.Get("LuaBTAction", "TalkToNPC", {npcID = npcID, taskID = taskID, state = state}),
                    PoolManager.Get("LuaBTAction", "StopBT"))
    LuaActionCreator.End()
    return root
end

function CommonTree.MoveToNPC()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "MoveToNPC"
    root:AddAction(PoolManager.Get("LuaBTAction", "SetPathToNPC"), 
                    PoolManager.Get("LuaBTAction", "MoveToPosition"),
                    PoolManager.Get("LuaBTAction", "OpenQuestPanel"))
    return root
end

function CommonTree.MoveToTransfer(transferID)
    LuaActionCreator.Begin()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "MoveToTransfer"
    root:AddAction(PoolManager.Get("LuaBTAction", "SetPathToTarget", {transferID = transferID}),
                    PoolManager.Get("LuaBTAction", "MoveToPosition"),
                    PoolManager.Get("LuaBTAction", "DoTransfer", {transferID = transferID}),
                    PoolManager.Get("LuaBTAction", "StopBT"))
    LuaActionCreator.End()
    return root
end

function CommonTree.MoveToMap(mapID)
    LuaActionCreator.Begin()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "MoveToMap"
    root:AddAction(PoolManager.Get("LuaBTAction", "SetPathToTarget", {mapID = mapID}),
                    PoolManager.Get("LuaBTAction", "MoveToPosition"),
                    PoolManager.Get("LuaBTAction", "StopBT"))
    LuaActionCreator.End()
    return root
end

--function CommonTree.OpenRecyclePanel(name)
--    local root = PoolManager.Get("LuaSequence", "OpenRecyclePanel")
--    root:AddAction(PoolManager.Get("LuaBTAction", "OpenQuestPanel", {panelName = name}),
--                    PoolManager.Get("LuaBTAction", "AutoRecycle"))
--    return root
--end

--追踪放技能
function CommonTree.TraceAndAttack(target, distance, skillID)
    LuaActionCreator.Begin()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "TraceAndAttack"
    LuaActionCreator.btData.spellID = skillID
    local loop = root:AddAction(PoolManager.Get("Loop"))
    local loopseq = loop:AddAction(PoolManager.Get("LuaSequence"))
    loopseq:AddAction(PoolManager.Get("LuaBTAction", "SetPathToTarget", {target = target, distance = distance * 0.8}),
                    PoolManager.Get("LuaBTAction", "MoveToPosition"),
                    PoolManager.Get("LuaBTAction", "MoveToTargetHeight"),
                    PoolManager.Get("LuaConditon", "CheckTargetDistance", {target = target, distance = distance}),
                    PoolManager.Get("LuaBTAction", "HitTarget", {target = target}),
                    PoolManager.Get("LuaBTAction", "StopBT"))

    LuaActionCreator.End()
    return root
end

-- 移动置某区域
function CommonTree.MoveToRegion(targetPos,identifier)
    --计算当前位置与区域范围的最近位置
    LuaActionCreator.Begin()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "MoveToRegion"
    root.identifier = identifier
    root:AddAction(
            PoolManager.Get("LuaBTAction", "SetPathToTarget", {targetPosition = targetPos}),
            PoolManager.Get("LuaBTAction", "MoveToPosition"))
    LuaActionCreator.End()
    return root
end


function CommonTree.ArticleMove(id,avatar)
    LuaActionCreator.Begin()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "ArticleMove"
    local loop = root:AddAction(PoolManager.Get("Loop"))
     local loopseq = loop:AddAction(PoolManager.Get("LuaSequence"))
     loopseq:AddAction(PoolManager.Get("LuaBTAction", "SetArticlePath", {id=id,avatar=avatar}),
                    PoolManager.Get("LuaBTAction", "ArticleMove"))
    LuaActionCreator.End()         
    return root
end
function CommonTree.ArticleRandomMove(avatar)
    LuaActionCreator.Begin()
    local root =  PoolManager.Get("LuaSequence")
    root.name = "ArticleRandomMove"
    local loop = root:AddAction(PoolManager.Get("Loop"))
     local loopseq = loop:AddAction(PoolManager.Get("LuaSequence"))
     loopseq:AddAction(PoolManager.Get("LuaBTAction", "ArticleRandomPath", {avatar=avatar}),
                    PoolManager.Get("LuaBTAction", "IntermMove"))
    LuaActionCreator.End()         
    return root
end

function CommonTree.P2pMove(avatar,id)
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence")
    root.name = "P2pMove"

    root:AddAction(PoolManager.Get("LuaBTAction","P2pMove",{unit = avatar , cfgId = id}))
    LuaActionCreator.End()

    return root
end

---@ 次要npc
function CommonTree.MinorNpcP2p(avatar,pointList,isLoop,loopType,pointIndex,extraBehaviors)
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence")
    root.name = "MinorNpcP2p"

    root:AddAction(PoolManager.Get("LuaBTAction","MinorNpcP2p", {unit = avatar , pointList = pointList , loop = {isLoop,loopType} , initIndex = pointIndex,extraBehaviors = extraBehaviors}))
    LuaActionCreator.End()

    return root
end

---@ 次要多人npc
function CommonTree.MinorNpcP2pMulti(avatar,pointList,isLoop,loopType,pointIndex,extraBehaviors)
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence")
    root.name = "MinorNpcP2pMulti"

    root:AddAction(PoolManager.Get("LuaBTAction","MinorNpcP2pMulti", {unit = avatar , pointList = pointList , loop = {isLoop,loopType} , initIndex = pointIndex,extraBehaviors = extraBehaviors}))
    LuaActionCreator.End()

    return root
end



function CommonTree.FollowTeamLeader(leaderCid)
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence")
    root.name = "FollowTeamLeader"
    root:AddAction(PoolManager.Get("LuaBTAction","FollowPlayer",{cid=leaderCid}))
    LuaActionCreator.End()
    return root
end

-- 紧紧跟随
function CommonTree.NpcFollow2Hero(avatar,id)
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence")
    root.name = "NpcFollow2Hero"

    root:AddAction(PoolManager.Get("LuaBTAction","NpcFollow2Hero",{unit = avatar , cfgId = id}))
    LuaActionCreator.End()
    return root
end

-- 通过寻路跟随
function CommonTree.NpcFollow2HeroByWayFinding(avatar,id)
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence")
    root.name = "Follow2HeroByWayFinding"

    root:AddAction(PoolManager.Get("LuaBTAction","NpcFollow2HeroByWayFinding",{unit = avatar , cfgId = id}))
    LuaActionCreator.End()
    return root
end

function CommonTree.JiGuanAI(avatar,instId,id)
    LuaActionCreator.Begin()
    local root = PoolManager.Get("LuaSequence")
    root.name = "JiGuanAIAction"
    local loop = root:AddAction(PoolManager.Get("Loop"))
    local loopSeq = loop:AddAction(PoolManager.Get("LuaSequence"))
    loopSeq:AddAction(PoolManager.Get("LuaBTAction","JiGuanAIAction",{unit = avatar , cfgId = id, instId = instId}))
    LuaActionCreator.End()

    return root
end

return CommonTree