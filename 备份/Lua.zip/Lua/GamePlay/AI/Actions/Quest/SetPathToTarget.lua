local SetPathToTarget = class(LuaAction)

function SetPathToTarget:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "SetPathToTarget"
end

function SetPathToTarget:OnBegin()
    if self.params.npcID or self.btData.Quest then
        local npcData
        if self.params.npcID then
            npcData = ConfigManager.GetConfig(ConfigName.Npc, self.params.npcID, "id")
        else
            if self.btData.Quest.State == TaskState.TSTATE_CAN_SUBMIT then
                npcData = ConfigManager.GetConfig(ConfigName.Npc, self.btData.Quest.Data["end_npc"], "id")
            else
                npcData = ConfigManager.GetConfig(ConfigName.Npc, self.btData.Quest.Data["start_npc"], "id")
            end
        end


        local mapID = npcData["mapid"]
        local transfers = TransferQuerier.Query(Scene.sceneID, mapID)
        if not transfers then
            return BTStatus.BTS_FAILURE
        end

        local count = #transfers

        LPrint.log("路径节点数".."..".. count.."..".. Scene.sceneID.."..".. mapID.."======================================")
        self.btData.Path = {}
        if count == 0 then
            if Scene.sceneID ~= mapID then
                LocalData.BubbleTip("找不到前往目标地图的传送点。")
                return BTStatus.BTS_FAILURE
            end
            --print("self.btData.Path   路径2222")
            table.insert(self.btData.Path, { x = npcData["point"][1], z = npcData["point"][3], npcID = npcData["id"], range = 2})
            return BTStatus.BTS_SUCCESS
        else
            for i = 1, count do
                if (i == count) then
                    table.insert(self.btData.Path, { x = npcData["point"][1], z = npcData["point"][3], npcID = npcData["id"], range = 1})
                    --print(npcData["point"][1], npcData["point"][3], npcData["id"])
                else
                    table.insert(self.btData.Path, { x = transfers[i].x, z = transfers[i].z, transferID = transfers[i].nID, range = 1})
                    --print(transfers[i].x, transfers[i].z, transfers[i].nID)
                end
            end
        end
    elseif self.params.monsterID then

    elseif self.params.transferID then
        --local transferData = ConfigManager.GetConfig(ConfigName.MapDoor, self.params.transferID)
        --if transferData then
        --    self.btData.Path = {{x = transferData.x, z = transferData.z}}
        --end
    elseif self.params.mapID then
        local transfers = TransferQuerier.Query(Scene.sceneID, self.params.mapID)
        if not transfers then
            return BTStatus.BTS_FAILURE
        end

        local count = #transfers
        LPrint.log("路径节点数".."..".. count.."..".. Scene.sceneID.."..".. self.params.mapID)
        self.btData.Path = {}
        if count == 0 then
            if Scene.sceneID ~= self.params.mapID then
                LocalData.BubbleTip("找不到前往目标地图的传送点。")
                return BTStatus.BTS_FAILURE
            end
            return BTStatus.BTS_SUCCESS
        else
            for i = 1, count do
                --if (i == count) then
                --    table.insert(self.btData.Path, { x = npcData["teleport_point"][1][1], z = npcData["teleport_point"][1][3], id = npcData["id"]})
                --    print(npcData["teleport_point"][1][1], npcData["teleport_point"][1][3], npcData["id"])
                --else
                table.insert(self.btData.Path, { x = transfers[i].x, z = transfers[i].z, transferID = transfers[i].nID})
                --end
            end
        end
    elseif self.params.target then
        if not UnitManager.IsRoleAlive(self.params.target) or not self.params.distance then
            return BTStatus.BTS_FAILURE
        end
        local hero = UnitManager.hero
        --如果距离小于指定距离，则指定当前坐标，然后返回
        local pos = hero.pos
        local fullDistance = Vector3.Distance(hero.pos, self.params.target.pos)
        if fullDistance > self.params.distance then
            --计算直线达到指定距离的坐标点，然后开始移动
            pos = Vector3.Lerp(self.params.target.pos, hero.pos, self.params.distance / fullDistance)
        end
        self.btData.Path = {{x = pos.x, y = pos.y, z = pos.z}}
    elseif self.params.targetPosition then
        --如果距离小于指定距离
        self.btData.Path = {{x = self.params.targetPosition.x , y =self.params.targetPosition.y , z = self.params.targetPosition.z}}
    end
    return BTStatus.BTS_SUCCESS
end


return SetPathToTarget