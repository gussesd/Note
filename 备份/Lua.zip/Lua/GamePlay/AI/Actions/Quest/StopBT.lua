local StopBT = class(LuaAction)

function StopBT:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "StopBT"
end

function StopBT:OnBegin()
    BehaviourTreeMgr.DelayUnloadTree("StopBT:OnBegin")
    return BTStatus.BTS_SUCCESS
end

return StopBT