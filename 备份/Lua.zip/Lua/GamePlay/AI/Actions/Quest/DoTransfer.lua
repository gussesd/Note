local DoTransfer = class(LuaAction)

function DoTransfer:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "DoTransfer"
end

function DoTransfer:OnBegin()
    --if self.params.transferID then
    --    local transferData = ConfigManager.GetConfig(ConfigName.MapDoor, self.params.transferID)
    --    if transferData then
    --        NetManager.Send(ClientMsgMessage.CM_ENTER_DOOR, {id = transferData.id})
    --    end
    --else
    --    return BTStatus.BTS_FAILURE
    --end

    return BTStatus.BTS_SUCCESS
end

return DoTransfer