local FollowPlayer = class(LuaAction)

function FollowPlayer:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "FollowPlayer"
end

function FollowPlayer:OnBegin()
    self.myPlayer = UnitManager.hero
    if not self.myPlayer then
        return BTStatus.BTS_FAILURE
    end
    if not self.params then
        return BTStatus.BTS_FAILURE
    end
    local player = LocalData.GetPlayerByCid(self.params.cid)
    if not player then
        return BTStatus.BTS_FAILURE
    end

    self.targetPos = Vector3();
    self.moveCheckTick = 0.067;
    self.tooFar = 0

    self.followPlayer = UnitManager.GetUnit("role",LocalData.GetPlayerByCid(self.params.cid).id)
    if not self.followPlayer then
        return BTStatus.BTS_FAILURE
    end
    self.targetPos:CopyFrom(self.followPlayer.pos)
    local followRet,started = self:Following()
    if started then
        LocalData.BubbleTip("开始跟随队长！")
    end
    return followRet
end
function FollowPlayer:Following()
    local dis = self:GetDistance()
    local started = false
    if dis > 15 then
        self.myPlayer.moveCtrl:StopMove()
        self.myPlayer.inputCtrl:FollowVector(0,0)
        self.tooFar = 1
        return BTStatus.BTS_SUCCESS
    elseif dis <= 2 then
        self.myPlayer.moveCtrl:StopMove()
        self.myPlayer.inputCtrl:FollowVector(0,0)
    else
        started = true
        self.myPlayer:LookAt(self.targetPos.x, self.targetPos.z)
        self.myPlayer.inputCtrl:FollowVector(self.targetPos.x - self.myPlayer.pos.x,self.targetPos.z - self.myPlayer.pos.z)
    end
    return BTStatus.BTS_RUNNING,started
end
function FollowPlayer:GetDistance()
    return Vector3.Distance(self.targetPos,self.myPlayer.pos)
end
function FollowPlayer:OnUpdate()
    if not self.followPlayer then
        return BTStatus.BTS_FAILURE
    end
    if not self.myPlayer then
        return BTStatus.BTS_FAILURE
    end
    self.moveCheckTick = self.moveCheckTick - Time.deltaTime
    if self.moveCheckTick > 0 then
        return BTStatus.BTS_RUNNING
    end
    self.moveCheckTick = 0.067
    local toPos = self.followPlayer.pos
    if math.floor(self.targetPos.x) ~= math.floor(toPos.x)
    or math.floor(self.targetPos.y) ~= math.floor(toPos.y)
    or math.floor(self.targetPos.z) ~= math.floor(toPos.z) then
        self.targetPos:CopyFrom(toPos)
    end
    return self:Following()
end
function FollowPlayer:OnEnd()
    FromManager.EndFollow("FollowPlayer:OnEnd")
    if self.tooFar == 1 then
        LocalData.BubbleTip("距离队长太远，无法跟随！")
    end
    return BTStatus.BTS_SUCCESS
end
function FollowPlayer:OnReset()
    self.followPlayer = nil
    self.myPlayer = nil
    self.targetPos = nil
end

function FollowPlayer:PoolReset()
    self:OnReset()
end

return FollowPlayer