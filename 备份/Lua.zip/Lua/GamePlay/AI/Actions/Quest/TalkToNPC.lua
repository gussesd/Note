local TalkToNPC = class(LuaAction)

function TalkToNPC:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "TalkToNPC"
end

function TalkToNPC:OnBegin()
    if self.params.npcID then
        local cfg = ConfigManager.GetConfig(ConfigName.Npc,self.params.npcID)
        local dialogueId = 0
        if cfg then
            dialogueId = cfg.click_def_dialogue
            if dialogueId == 0 then
                local base_cfg = ConfigManager.GetConfig(ConfigName.NpcBase,cfg.base_id)
                dialogueId = base_cfg.click_def_dialogue
            end
        end



        if dialogueId ~= 0 then
            NpcUIMgr.OpenDialogUI({ 1, self.params.npcID })
        else
            -- 不存在默认对话
            local taskData = TaskManager.IsTaskForNPC(self.params.npcID)
            if #taskData > 0 then
                NpcUIMgr.OpenDialogUI({ 1, self.params.npcID })
                return
            end
            LPrint.log(ColorCode.SpTxtYellow,"npc：" , self.params.npcID , "缺少默认对话，且未挂载任务")
            return BTStatus.BTS_FAILURE
        end


        LPrint.log("talk to npc" .. ".." .. self.params.npcID)
    else
        return BTStatus.BTS_FAILURE
    end

    return BTStatus.BTS_SUCCESS
end

return TalkToNPC
