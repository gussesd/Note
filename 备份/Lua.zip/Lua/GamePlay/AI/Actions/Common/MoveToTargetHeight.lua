local MoveToTargetHeight = class(LuaAction)

function MoveToTargetHeight:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "MoveToTargetHeight"
    self.transTick = 100
end

function MoveToTargetHeight:PoolCtor(btData)
    LuaAction.PoolCtor(self, btData)
    self.transTick = 100
end

function MoveToTargetHeight:OnBegin()
    if self.btData.Path == nil then
        return BTStatus.BTS_FAILURE
    end
    self.avatar = UnitManager.hero
    if self.avatar == nil then
        return BTStatus.BTS_FAILURE
    end
    if not Global.AllowTransfer then--传送中
        LocalData.BubbleTip("正在传送中。")
        return BTStatus.BTS_FAILURE
    end
    self.count = #self.btData.Path
    self.curScene = Scene.sceneID
    
    self.btData.targetHeight = 0
    
    if self.count > 0 then
        self.index = 1
        self.btData.targetHeight = self.btData.Path[self.index].y
        if self.index == self.count then
            if self.curScene ~= Scene.sceneID or self.navStatus == NavStatus.End then
                return BTStatus.BTS_SUCCESS
            end
        end
        if (self.avatar.gravityType ~= GRAVITY_TYPE.Float and self.avatar.gravityType ~= GRAVITY_TYPE.Swim) or  self.btData.targetHeight == self.avatar.pos.y or self.btData.targetHeight == 0 then
            return BTStatus.BTS_SUCCESS
        end

        if self.btData.targetHeight > self.avatar.pos.y then
            self.btData.floatInput = 1
        else
            self.btData.floatInput = -1
        end
        self.avatar.inputCtrl.floatInput = self.btData.floatInput
        self.btData.startTime = Time.unscaledTime
    else
        return BTStatus.BTS_SUCCESS
    end
    return BTStatus.BTS_RUNNING
end

function MoveToTargetHeight:OnUpdate()
    if not self.avatar or not self.avatar.moveCtrl then
        return
    end

    if (self.avatar.gravityType ~= GRAVITY_TYPE.Float and self.avatar.gravityType ~= GRAVITY_TYPE.Swim) or self.btData.targetHeight == self.avatar.pos.y or self.btData.targetHeight == 0 then
        return BTStatus.BTS_SUCCESS
    end

    if self.btData.targetHeight > self.avatar.pos.y then
        if self.btData.floatInput < 0 then
            return BTStatus.BTS_SUCCESS
        end
    elseif self.btData.targetHeight < self.avatar.pos.y then
        if self.btData.floatInput > 0 then
            return BTStatus.BTS_SUCCESS
        end
    else
        return BTStatus.BTS_SUCCESS
    end

    --因为阻挡的原因，很多时候无法达到指定的高度，这里为了效率考虑，只判定下超时时长，不再做复杂的碰撞检测了
    if Time.unscaledTime - self.btData.startTime > 2 then
        return BTStatus.BTS_SUCCESS
    end

    return BTStatus.BTS_RUNNING
end

function MoveToTargetHeight:CheckArrive()
    if mathEx.GetSqrDistance(self.avatar.pos.x, self.avatar.pos.z, 
        self.btData.Path[self.index].x, self.btData.Path[self.index].z) > 0.25 then
            return false
    end            
    return true
end

function MoveToTargetHeight:OnEnd()
    if self.btData.floatInput ~= 0 and self.avatar then
        self.avatar.inputCtrl.floatInput = 0
    end
end

function MoveToTargetHeight:OnReset()
    self.navStatus = nil
end
function MoveToTargetHeight:OnPause()

end
function MoveToTargetHeight:OnResume()
    if self.btData.Path and self.btData.Path[self.index] and self.avatar then
        self.navStatus = self.avatar.moveCtrl:TaskMoveTo(self.btData.Path[self.index].x, self.btData.Path[self.index].z)
    else
        self:OnBegin()
    end
end

return MoveToTargetHeight