local ArticleMove = class(LuaAction)

function ArticleMove:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "ArticleMove"
    self.transTick = 100
end

function ArticleMove:PoolCtor(btData)
    LuaAction.PoolCtor(self, btData)
    self.transTick = 100
end

function ArticleMove:OnBegin()
    if self.btData.Path == nil then
        return BTStatus.BTS_FAILURE
    end
    self.avatar = self.btData.avatar
    if not self.avatar then
        self.avatar = UnitManager.hero
    end
    if self.avatar == nil then
        return BTStatus.BTS_FAILURE
    end
    
    if not Global.AllowTransfer then --传送中
        return BTStatus.BTS_FAILURE
    end
    self.count = #self.btData.Path
    self.curScene = Scene.sceneID
    if self.count > 0 then
        self.index = 1
        self.navStatus = self.avatar.moveCtrl:MoveTo(self.btData.Path[self.index])
        if self.index == self.count then
            if self.curScene ~= Scene.sceneID or self.navStatus == NavStatus.End then
                return BTStatus.BTS_SUCCESS
            end
        end
    else
        return BTStatus.BTS_SUCCESS
    end
    return BTStatus.BTS_RUNNING
end

function ArticleMove:OnUpdate()
    if not self.avatar or not self.avatar.moveCtrl then
        return
    end
    self.navStatus = self.avatar.moveCtrl:GetMoveStatus()
    if not Global.AllowTransfer then --传送中
        LPrint.log("还在传送中"..".."..self.navStatus)
        self.transTick = 0
        return BTStatus.BTS_RUNNING
    else
        if self.transTick < 60 then
            self.transTick = self.transTick + 1
            return BTStatus.BTS_RUNNING
        end
    end
    local status = self.navStatus
    if status == NavStatus.Break then
        return BTStatus.BTS_FAILURE
    end
    if status == NavStatus.End then
        if not self:CheckArrive() then
            return BTStatus.BTS_FAILURE
        end
        if self.curScene ~= Scene.sceneID then
            self.index = self.index + 1
            if self.index > self.count then
                return BTStatus.BTS_SUCCESS
            end
            self.curScene = Scene.sceneID
            self.navStatus = self.avatar.moveCtrl:MoveTo(self.btData.Path[self.index])
            return BTStatus.BTS_RUNNING
        else
            --检查是否配置了传送点
            --if self.btData.Path[self.index].transferID then
            --    local transferData = ConfigManager.GetConfig(ConfigName.MapDoor, self.btData.Path[self.index].transferID)
            --    if transferData then
            --        NetManager.Send(ClientMsgMessage.CM_ENTER_DOOR, {id = transferData.id})
            --    end
            --end
            
            if self.index >= self.count then
                LPrint.log("self.index >= self.count success"..self.navStatus)
                return BTStatus.BTS_SUCCESS
            end
        end
    end
    --print("BTS_RUNNING",self.navStatus)
    return BTStatus.BTS_RUNNING
end

function ArticleMove:CheckArrive()
    --考虑精度问题，边界适量放宽
    if mathEx.GetDistance(self.avatar.pos.x, self.avatar.pos.z,
        self.btData.Path[self.index].x, self.btData.Path[self.index].z) > (self.btData.Path[self.index].range or 0.5) * 1.05 then
        return false
    end
    return true
end

function ArticleMove:OnReset()
    self.navStatus = nil
end
function ArticleMove:OnPause()

end


return ArticleMove
