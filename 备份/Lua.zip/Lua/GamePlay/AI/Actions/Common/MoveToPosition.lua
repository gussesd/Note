local MoveToPosition = class(LuaAction)

function MoveToPosition:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "MoveToPosition"
    self.transTick = 100
end

function MoveToPosition:PoolCtor(btData)
    LuaAction.PoolCtor(self, btData)
    self.transTick = 100
end

function MoveToPosition:OnBegin()
    if self.btData.Path == nil then
        return BTStatus.BTS_FAILURE
    end
    self.avatar = self.btData.avatar
    if not self.avatar then
        self.avatar=UnitManager.hero
    end
    if self.avatar == nil then
        return BTStatus.BTS_FAILURE
    end
   
    if not Global.AllowTransfer then--传送中
        LocalData.BubbleTip("正在传送中。")
        return BTStatus.BTS_FAILURE
    end
    self.count = #self.btData.Path
    self.curScene = Scene.sceneID
    if self.btData.Item == nil then
        self.btData.Item = {x = 0,z = 0}
    else
        self.btData.Item.x = 0
        self.btData.Item.z = 0
    end
    if self.count > 0 then
        self.index = 1
        self.navStatus = self.avatar.moveCtrl:TaskMoveTo(self.btData.Path[self.index].x, self.btData.Path[self.index].z, self.btData.Path[self.index].range or 0)
        self.btData.Item.x = self.btData.Path[self.index].x
        self.btData.Item.z = self.btData.Path[self.index].z
        if self.index == self.count then
            if self.curScene ~= Scene.sceneID or self.navStatus == NavStatus.End then
                return BTStatus.BTS_SUCCESS
            end
        end
    else
        return BTStatus.BTS_SUCCESS
    end
    return BTStatus.BTS_RUNNING
end

function MoveToPosition:OnUpdate()
    if not self.avatar or not self.avatar.moveCtrl then
        return
    end
    self.navStatus = self.avatar.moveCtrl:GetMoveStatus()
    if not Global.AllowTransfer then--传送中
        LPrint.log("还在传送中"..".."..self.navStatus)
        self.transTick = 0
        return BTStatus.BTS_RUNNING
    else
        if self.transTick < 60 then
            self.transTick = self.transTick + 1
            return BTStatus.BTS_RUNNING
        end
    end
    local status = self.navStatus
    if status == NavStatus.Break then
        return BTStatus.BTS_FAILURE
    end
    if status == NavStatus.End then
        if not self:CheckArrive() then
            return BTStatus.BTS_FAILURE
        end
        if self.curScene ~= Scene.sceneID then
            self.index = self.index + 1
            if self.index > self.count then
                return BTStatus.BTS_SUCCESS
            end
            self.curScene = Scene.sceneID
            self.btData.Item.x = self.btData.Path[self.index].x
            self.btData.Item.z = self.btData.Path[self.index].z
            self.navStatus = self.avatar.moveCtrl:TaskMoveTo(self.btData.Item.x, self.btData.Item.z)
            LPrint.log("go to next point"..".."..self.navStatus..".."..self.btData.Item.x..".."..self.btData.Item.z )
            return BTStatus.BTS_RUNNING
        else
            --检查是否配置了传送点
            --if self.btData.Path[self.index].transferID then
            --    local transferData = ConfigManager.GetConfig(ConfigName.MapDoor, self.btData.Path[self.index].transferID)
            --    if transferData then
            --        NetManager.Send(ClientMsgMessage.CM_ENTER_DOOR, {id = transferData.id})
            --    end
            --end

            if self.index >= self.count then
                LPrint.log("self.index >= self.count success"..".."..self.navStatus)
                return BTStatus.BTS_SUCCESS
            end
        end
    end
    --print("BTS_RUNNING",self.navStatus)
    return BTStatus.BTS_RUNNING
end

function MoveToPosition:CheckArrive()
    --考虑精度问题，边界适量放宽
    if mathEx.GetDistance(self.avatar.pos.x, self.avatar.pos.z, 
        self.btData.Path[self.index].x, self.btData.Path[self.index].z) > (self.btData.Path[self.index].range or 0.5) * 1.05 then
            return false
    end            
    return true
end

function MoveToPosition:OnReset()
    self.navStatus = nil
end
function MoveToPosition:OnPause()

end
function MoveToPosition:OnResume()
    if self.btData.Path and self.btData.Path[self.index] and self.avatar then
        self.navStatus = self.avatar.moveCtrl:TaskMoveTo(self.btData.Path[self.index].x, self.btData.Path[self.index].z)
    else
        self:OnBegin()
    end
end

return MoveToPosition