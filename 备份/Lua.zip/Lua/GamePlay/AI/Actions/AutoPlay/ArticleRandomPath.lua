local ArticleRandomPath = class(LuaAction)

function ArticleRandomPath:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "ArticleRandomPath"
    self.Direction = {}
end
function ArticleRandomPath:PoolCtor(btData)
    LuaAction.PoolCtor(self, btData)
    self.Direction = {}
end
function ArticleRandomPath:OnBegin()
    if not UnitManager.hero.model or not self.params.avatar then
        BehaviourTreeMgr.DelayUnloadTree("MoveToPosition:OnBegin", "")
        return BTStatus.BTS_FAILURE
    end
    
    self:RandomOrDodgeMove()
    self.btData.Path = {{x = self.Direction.x, z = self.Direction.z, y = self.Direction.y}}
    self.btData.avatar = self.params.avatar
    return BTStatus.BTS_SUCCESS
end
--随机移动
function ArticleRandomPath:RandomMove()
    self.Direction.x = self.params.avatar.pos.x + math.random(-500, 500) / 100
    self.Direction.z = self.params.avatar.pos.z + math.random(-500, 500) / 100
    self.Direction.y = Scene.GetHeight(self.Direction.x, 500, self.Direction.z)
end

--躲避
function ArticleRandomPath:DodgeMove()
    local dir = self.params.avatar.pos - UnitManager.hero.pos
    local heroForward = UnitManager.hero.model:GetForward()
    local cross = Vector3.Cross(heroForward, dir)
    local dot = Vector3.Dot(Vector3.Normalize(heroForward), Vector3.Normalize(dir))
    local sign = 1
    if cross.y < 0 then
        sign = -1
    end
    
    local quat = Quaternion.Euler(0, dot * math.random(70, 110) * sign, 0)
    dir=Vector3.IsZero(dir) and self.params.avatar.model:GetForward() or dir
    local targetNormal = Vector3.Normalize(dir) * quat * math.random(5, 10)
  
    self.Direction = self.params.avatar.pos + targetNormal
end

function ArticleRandomPath:RandomOrDodgeMove()
    self.dis = Vector3.Distance(UnitManager.hero.pos, self.params.avatar.pos)
    if self.dis < 5 then
        self:DodgeMove()
    else
        self:RandomMove()
    end
end

return ArticleRandomPath
