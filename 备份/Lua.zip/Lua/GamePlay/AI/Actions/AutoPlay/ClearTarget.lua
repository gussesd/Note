local ClearTarget = class(LuaAction)

function ClearTarget:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "ClearTarget"
end

function ClearTarget:OnBegin()
    local myPlayer = UnitManager.hero
    local target = MyTarget.GetMyTarget()
    if target ~= nil and Vector3.Distance(myPlayer.pos, target.pos) > 10 then
        MyTarget.InitTarget(nil)
    end
    return BTStatus.BTS_SUCCESS
end

return ClearTarget