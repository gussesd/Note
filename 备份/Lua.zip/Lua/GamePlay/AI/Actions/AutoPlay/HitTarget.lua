local HitTarget = class(LuaAction)

function HitTarget:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "HitTarget"
end

function HitTarget:OnUpdate()
    local target = self.params.target or MyTarget.GetMyTarget()
    if target == nil then
        return BTStatus.BTS_FAILURE
    end

    if self.btData.spellIndex == 0 then
        return BTStatus.BTS_FAILURE
    end

    --简单处理下，公共cd时不准放
    if LocalData.hero.skillManager:GetPublicCoolDown() > 0 then
        return BTStatus.BTS_FAILURE
    end

    EventManager.Dispatch(Event.UI_Game_SkillBtn_Clicked, self.btData.spellID)
    return BTStatus.BTS_SUCCESS
end

return HitTarget