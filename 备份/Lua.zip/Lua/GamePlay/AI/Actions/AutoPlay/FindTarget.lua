local FindTarget = class(LuaAction)

function FindTarget:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "FindTarget"
end

function FindTarget:OnBegin()
    local target = self.btData.HasMonsterTarget
    if target == nil then
        target = SkillUtils.GetNearestMonster()
    end

    if target == nil then
        --print("can't find target")
        return BTStatus.BTS_FAILURE
    end

    self.btData.Target = target
    MyTarget.InitTarget(target)
    return BTStatus.BTS_SUCCESS
end

return FindTarget