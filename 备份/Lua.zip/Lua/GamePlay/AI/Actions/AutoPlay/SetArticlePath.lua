local SetArticlePath = class(LuaAction)

function SetArticlePath:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "SetAriclePath"
    self.index = 0
end
function SetArticlePath:PoolCtor(btData)
    LuaAction.PoolCtor(self, btData)
    self.index = 0
end
function SetArticlePath:OnBegin()
    if not self.params.id or not self.params.avatar then
        BehaviourTreeMgr.DelayUnloadTree("SetArticlePath:OnBegin", "")
        return BTStatus.BTS_FAILURE
    end
    if not self.pathData then
        self.pathData = ConfigManager.GetConfig(ConfigName.ArticlePath, self.params.id, "id")
    end
    
    if self.index >= #self.pathData.path and self.pathData.isLoop == 0 then
        BehaviourTreeMgr.DelayUnloadTree("SetArticlePath:OnBegin", self.params.avatar:GetName())
        return BTStatus.BTS_FAILURE
    elseif self.index >= #self.pathData.path and self.pathData.isLoop == 1 then
        self.index = 1
    end
    
    self.index = self.index + 1
    local point = self.pathData.path[self.index]
    self.btData.Path = {{x = point[1], z = point[2], y = point[3]}}
    self.btData.avatar = self.params.avatar
    return BTStatus.BTS_SUCCESS
end

return SetArticlePath
