local JiGuanAIAction = class(LuaAction)
local this = JiGuanAIAction

local Utils = require "GamePlay/Data/JiGuanData/JiGuanUtils"

NODETYPE = {
    BTNT_ACTION = 0, --动作
    BTNT_SELECT = 1, --选择节点
    BTNT_SEQUENCE = 2, --顺序节点
    BTNT_RAND = 3, --权重随机
    BTNT_NOT = 4, --取反节点
    BTNT_SEQ_SELECT = 5, --顺序选择	顺序直到返回失败有一个成功就算成功
    BTNT_NUM = 6, --指定成功次数
    BTNT_LOOP = 7, --循环节点
    BTNT_PARALLEL = 8, --并行执行节点
    BTNT_MUST_SEQUENCE = 9, --绝对顺序 顺序执行返回最后一个节点的结果
    BTNT_RAND_SKILL = 10, --在有可释放技能的分支间 权重随机
}

ACTIONTYPE = {
    BTAT_PLAY_ANIMATION = 21, --播放动作
    BTAT_RAND_MOVE = 22, --随机移动
    BTAT_PATROL = 23, --执行巡逻
    BTAT_GO_HOME = 24, --返回出生点

    BTAT_OVER_DISTANCE = 50, --判断是否超过N米
    BTAT_CHECK_RATE = 51, --判断概率
    BTAT_DO_SKILL = 52, --释放技能
    BTAT_HP_LESS_THAN = 53, --判断是否HP小于N%
    BTAT_CHASE_ENEMY = 54, --追敌人
    BTAT_FACE_TO_ENEMY = 55, --转向敌人
    BTAT_BETWEEN_DISTANCE = 56, --判断是否在N-M米
    BTAT_RUN_AWAY = 57, --远离敌人
    BTAT_CHECK_WEEKNESS = 58, --判断是否虚弱
    BTAT_FALL_DOWN = 59, --掉落到地上
    BTAT_MOVE_ANGLE = 60, --与目标成角度移动
    BTAT_CHECK_MASTER_DISTANCE = 61, --判断主人是否超过x米
    BTAT_FOLLOW_MASTER = 62, --跟随主人
    BTAT_CHECK_ATTACKED = 63, --判断是否受到攻击
    BTAT_TO_NORMAL = 64, --切换到脱战ai
    BTAT_HAVE_BUFF = 65, --判断是否有buff x
    BTAT_CHECK_SKILL_CD = 66, --判断技能是否在cd
    BTAT_CHECK_VIEW_ENEMY = 67, --判断视野内是否有敌人
    BTAT_ADJUST_SKILL_POS = 68, --调整释放技能的位置
    BTAT_CHOOSE_TARGET = 69, --选择目标
    BTAT_SET_SKILL_POS = 70, --设置技能释放位置
    BTAT_CHECK_CALL_MONSTER = 71, --是否可以召唤
    BTAT_CHECK_BETWEEN_HEIGHT = 72, --判断高度差是否在N-M米
    BTAT_FLY_MOVE = 73, --飞行到一定高度
    BTAT_ADD_BUFF = 74, --主动加buff
    BTAT_CURVE_MOVE = 75, --曲线移动
    BTAT_NEXT_P2P = 76, --前往下一个路点
    BTAT_IN_P2P = 77, --路点段移动中
    BTAT_SWITCH_AI = 78, --切换ai状态，目前动物专用
    BTAT_MOVE_ANGLE_3D = 79, --与目标成角度移动，3D空间
    BTAT_KILL_SELF = 80, --单位死亡
    BTAT_CHECK_TARGET_DIR = 81, --判断目标方位
    BTAT_ROTATE = 82, --旋转
    BTAT_SWITCH_BT = 83, --切换行为树

    BTAT_MAX = 100,
}

NODESTATE = {
    NS_TRUE = 1,
    NS_FALSE = 2,
    NS_RUNNING = 3,
}

function JiGuanAIAction.Init()
    this.inited = true
    local nodetab = {}
    local trees = {}

    local cfgs = ConfigManager.GetConfigTable(ConfigName.JiGuanBehavTree)
    for _, cfg in pairs(cfgs) do
        if not nodetab[cfg.id] then
            nodetab[cfg.id] = {}
        end
        nodetab[cfg.id][cfg.node_id] = cfg
    end

    for id, childs in pairs(nodetab) do
        local tab = {}
        for nid, cfg in pairs(childs) do
            tab[nid] = { cfg = cfg }
        end
        for _, node in pairs(tab) do
            if type(node.cfg.child_id) == "table" and #node.cfg.child_id > 0 then
                for _, nid in ipairs(node.cfg.child_id) do
                    if tab[nid] and tab[nid] ~= node then
                        if not node.childs then
                            node.childs = {}
                        end
                        table.insert(node.childs, tab[nid])
                    else
                        logError("ai子节点不存在或子节点指向自身" .. node.cfg.id .. ">>>>" .. node.cfg.node_id)
                    end
                end
            end
        end
        trees[id] = tab
    end
    this.trees = trees

    this.m_btActions = {}
    this.m_btActions[ACTIONTYPE.BTAT_PLAY_ANIMATION] = this.btPlayAnimation
    this.m_btActions[ACTIONTYPE.BTAT_RAND_MOVE] = this.btRandMove
    this.m_btActions[ACTIONTYPE.BTAT_PATROL] = this.btPatrol
    this.m_btActions[ACTIONTYPE.BTAT_GO_HOME] = this.btGoHome
    this.m_btActions[ACTIONTYPE.BTAT_OVER_DISTANCE] = this.btCheckOverDistance
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_RATE] = this.btCheckRate
    this.m_btActions[ACTIONTYPE.BTAT_DO_SKILL] = this.btDoSkill
    this.m_btActions[ACTIONTYPE.BTAT_HP_LESS_THAN] = this.btCheckHpLess
    this.m_btActions[ACTIONTYPE.BTAT_CHASE_ENEMY] = this.btChaseEnemy
    this.m_btActions[ACTIONTYPE.BTAT_FACE_TO_ENEMY] = this.btFaceToEnemy
    this.m_btActions[ACTIONTYPE.BTAT_BETWEEN_DISTANCE] = this.btCheckBetweenDistance
    this.m_btActions[ACTIONTYPE.BTAT_RUN_AWAY] = this.btRunaway
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_WEEKNESS] = this.btCheckWeekness
    this.m_btActions[ACTIONTYPE.BTAT_FALL_DOWN] = this.btFallDown
    this.m_btActions[ACTIONTYPE.BTAT_MOVE_ANGLE] = this.btMoveAngle
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_MASTER_DISTANCE] = this.btCheckMasterDistance
    this.m_btActions[ACTIONTYPE.BTAT_FOLLOW_MASTER] = this.btFollowMaster
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_ATTACKED] = this.btCheckAttacked
    this.m_btActions[ACTIONTYPE.BTAT_TO_NORMAL] = this.btSwitchToNormal
    this.m_btActions[ACTIONTYPE.BTAT_HAVE_BUFF] = this.btHaveBuff
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_SKILL_CD] = this.btCheckSkillCD
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_VIEW_ENEMY] = this.btCheckViewEnemy
    this.m_btActions[ACTIONTYPE.BTAT_ADJUST_SKILL_POS] = this.btAdjustSkillPos
    this.m_btActions[ACTIONTYPE.BTAT_CHOOSE_TARGET] = this.btChooseTarget
    this.m_btActions[ACTIONTYPE.BTAT_SET_SKILL_POS] = this.btSetSkillPos
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_CALL_MONSTER] = this.btCanCallMonster
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_BETWEEN_HEIGHT] = this.btCheckBetweenHeight
    this.m_btActions[ACTIONTYPE.BTAT_FLY_MOVE] = this.btFlymove
    this.m_btActions[ACTIONTYPE.BTAT_ADD_BUFF] = this.btAddBuff
    this.m_btActions[ACTIONTYPE.BTAT_CURVE_MOVE] = this.btCurveMove
    this.m_btActions[ACTIONTYPE.BTAT_NEXT_P2P] = this.btNextP2p
    this.m_btActions[ACTIONTYPE.BTAT_IN_P2P] = this.btInP2p
    this.m_btActions[ACTIONTYPE.BTAT_SWITCH_AI] = this.btSwitch_ai
    this.m_btActions[ACTIONTYPE.BTAT_MOVE_ANGLE_3D] = this.btMoveAngle3D
    this.m_btActions[ACTIONTYPE.BTAT_KILL_SELF] = this.btKillSelf
    this.m_btActions[ACTIONTYPE.BTAT_CHECK_TARGET_DIR] = this.btCheckTargetDir
    this.m_btActions[ACTIONTYPE.BTAT_ROTATE] = this.btRotate
    this.m_btActions[ACTIONTYPE.BTAT_SWITCH_BT] = this.btSwitchBT

    this.m_btlogs = {}
    this.m_btlogs[ACTIONTYPE.BTAT_PLAY_ANIMATION] = "播放动作"
    this.m_btlogs[ACTIONTYPE.BTAT_RAND_MOVE] = "随机移动"
    this.m_btlogs[ACTIONTYPE.BTAT_PATROL] = "巡逻"
    this.m_btlogs[ACTIONTYPE.BTAT_GO_HOME] = "返回出生点"
    this.m_btlogs[ACTIONTYPE.BTAT_OVER_DISTANCE] = "判断距离"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_RATE] = "判断概率"
    this.m_btlogs[ACTIONTYPE.BTAT_DO_SKILL] = "执行技能"
    this.m_btlogs[ACTIONTYPE.BTAT_HP_LESS_THAN] = "检查血量"
    this.m_btlogs[ACTIONTYPE.BTAT_CHASE_ENEMY] = "追踪敌人"
    this.m_btlogs[ACTIONTYPE.BTAT_FACE_TO_ENEMY] = "面对敌人"
    this.m_btlogs[ACTIONTYPE.BTAT_BETWEEN_DISTANCE] = "判断距离范围"
    this.m_btlogs[ACTIONTYPE.BTAT_RUN_AWAY] = "远离"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_WEEKNESS] = "是否虚弱"
    this.m_btlogs[ACTIONTYPE.BTAT_FALL_DOWN] = "是否落下"
    this.m_btlogs[ACTIONTYPE.BTAT_MOVE_ANGLE] = "成角度移动"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_MASTER_DISTANCE] = "判断主人超过距离"
    this.m_btlogs[ACTIONTYPE.BTAT_FOLLOW_MASTER] = "跟随主人"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_ATTACKED] = "是否受过攻击"
    this.m_btlogs[ACTIONTYPE.BTAT_TO_NORMAL] = "切换到脱战状态"
    this.m_btlogs[ACTIONTYPE.BTAT_HAVE_BUFF] = "是否持有buff"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_SKILL_CD] = "判断技能CD"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_VIEW_ENEMY] = "判断视野是否有敌人"
    this.m_btlogs[ACTIONTYPE.BTAT_ADJUST_SKILL_POS] = "调整技能释放位置"
    this.m_btlogs[ACTIONTYPE.BTAT_CHOOSE_TARGET] = "选择目标"
    this.m_btlogs[ACTIONTYPE.BTAT_SET_SKILL_POS] = "设置技能释放位置"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_CALL_MONSTER] = "是否可以召唤"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_BETWEEN_HEIGHT] = "判断高度差范围"
    this.m_btlogs[ACTIONTYPE.BTAT_FLY_MOVE] = "飞行到一定高度"
    this.m_btlogs[ACTIONTYPE.BTAT_ADD_BUFF] = "主动加buff"
    this.m_btlogs[ACTIONTYPE.BTAT_NEXT_P2P] = "下一个路点"
    this.m_btlogs[ACTIONTYPE.BTAT_IN_P2P] = "判断处于路点移动中"
    this.m_btlogs[ACTIONTYPE.BTAT_SWITCH_AI] = "动物切换状态"
    this.m_btlogs[ACTIONTYPE.BTAT_MOVE_ANGLE_3D] = "与目标成角度移动，3D空间"
    this.m_btlogs[ACTIONTYPE.BTAT_KILL_SELF] = "单位死亡"
    this.m_btlogs[ACTIONTYPE.BTAT_CHECK_TARGET_DIR] = "判断目标方位"
    this.m_btlogs[ACTIONTYPE.BTAT_ROTATE] = "旋转"
    this.m_btlogs[ACTIONTYPE.BTAT_SWITCH_BT] = "切换行为树"
end

function JiGuanAIAction.GetTree(id, list)
    table.quickClear(list)
    if not this.trees[id] then
        --没有对应树配置
        return
    end
    if not this.trees[id][0] then
        --没有根结点
        return
    end
    this.PushNodeData(this.trees[id][0], list)
end

function JiGuanAIAction.PushNodeData(node, list)
    local nd = {}
    nd.node = node
    nd.res = node.cfg.node_type == NODETYPE.BTNT_ACTION and NODESTATE.NS_TRUE or NODESTATE.NS_FALSE
    nd.index = #list + 1
    nd.from_wait = false
    nd.list = {}
    nd.wait_tick = 0
    table.insert(list, nd)
end

function JiGuanAIAction.DoBTAction(unit, cfg, param, nd)
    this.BTDebug(unit, "DoBtAction, action:" .. cfg.action, "desc:"..cfg.desc)
    local handler = this.m_btActions[cfg.action]
    if handler then
        --logError(unit.id..">>>>>>>"..this.m_btlogs[cfg.action]..">>>>>>"..cfg.id..">>>"..cfg.node_id)
        return handler(unit, cfg, param, nd)
    else
        return NODESTATE.NS_TRUE
    end
end

function JiGuanAIAction.btPlayAnimation(unit, cfg, param, nd)
    local waittime = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
    local facetarget = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3)
    local cd = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)

    if cd > 0 then
        local t = unit:GetAiData(cfg.id, cfg.node_id, 1)
        if t > Time.time * 1000 then
            unit:SetBTreeWait(0.1, nd)
            return NODESTATE.NS_FALSE
        end
    end

    local actid = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1)
    this.SetUnitFrameEvent(unit, actid)

    if cd > 0 then
        unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time * 1000 + cd)
    end

    unit:SetBTreeWait(waittime / 1000, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btRandMove(unit, cfg, param, nd)
    if nd.res == NODESTATE.NS_RUNNING then
        if not unit:IsMoving() then
            return NODESTATE.NS_TRUE
        else
            if Time.time > unit:GetAiData(cfg.id, cfg.node_id, 1) then
                return NODESTATE.NS_TRUE
            end
            unit:SetBTreeWait(0.1, nd)
            return NODESTATE.NS_RUNNING
        end
    end

    unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time + 10)

    local deltaPos = Vector3()
    local rMax = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) 
    local rMin = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)
    if rMin == 0 then
        rMin = 1
    end
    local r = math.random(rMin, rMax)
    deltaPos.x = (math.random(1, r * 2) - r) * 0.1 --参数单位是分米
    deltaPos.z = (math.random(1, r * 2) - r) * 0.1 --参数单位是分米
    
    local origin = this.GetUnitAIParamValue(unit, cfg, param, nd, 5)
    local tgtId = this.GetUnitAIParamValue(unit, cfg, param, nd, 6)
    local pos, _ = this.GetUnitTargetPos(unit, origin, tgtId)
    if not pos then
        -- Fallback:机关出生点
        pos = unit.back_pos
    end
    pos = pos + deltaPos
    
    local speed = this.GetUnitPromotedSpeed(unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2))
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = 1, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- unit:SetRotation(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end

    local actid = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3)
    this.SetUnitFrameEvent(unit, actid)
    unit:SetBTreeWait(0.1, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btPatrol(unit, cfg, param, nd)
    --巡逻路径配置废除了，这段逻辑暂时不用补
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btGoHome(unit, cfg, param, nd)
    if nd.res == NODESTATE.NS_RUNNING then
        local gotime = unit:GetAiData(cfg.id, cfg.node_id, 1)
        if gotime > 0 and Time.time > gotime then
            return NODESTATE.NS_TRUE
        end

        if unit:IsMoving() then
            unit:SetBTreeWait(0.1, nd)
            return NODESTATE.NS_RUNNING
        else
            return NODESTATE.NS_TRUE
        end
    end
    
    local x = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
    local y = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3)
    local z = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)
    local time = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 6)
    local len = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 7)

    if time > 0 then
        unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time + time)
    end

    local pos = Vector3(unit.back_pos.x + x * 0.1, unit.back_pos.y + y * 0.1, unit.back_pos.z + z * 0.1)
    pos = this.GetPosFromEnd(unit.pos, pos, len * 0.1)

    local speed = this.GetUnitPromotedSpeed(unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1))
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = speed, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- unit:SetRotation(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end
    local actid = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 5)
    this.SetUnitFrameEvent(unit, actid)

    return NODESTATE.NS_RUNNING
end

function JiGuanAIAction.btCheckOverDistance(unit, cfg, param, nd)
    local tar_type = this.GetUnitAIParamValue(unit, cfg, param, nd, 2)
    local trapID = this.GetUnitAIParamValue(unit, cfg, param, nd, 3)
    local tar_pos, state = this.GetUnitTargetPos(unit, tar_type, trapID)
    if not state then
        return NODESTATE.NS_FALSE
    end
    if not tar_pos then
        return NODESTATE.NS_TRUE
    end
    local l = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) * 0.1
    return Vector3.Distance(unit.pos, tar_pos) > l and NODESTATE.NS_TRUE or NODESTATE.NS_FALSE
end

function JiGuanAIAction.btCheckRate(unit, cfg, param, nd)
    --概率判断
    local rate = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1)
    if rate <= 0 then
        return NODESTATE.NS_FALSE
    elseif rate >= 100 then
        return NODESTATE.NS_TRUE
    end

    local keep = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
    if keep > 0 then
        local keeptime = unit:GetAiData(cfg.id, cfg.node_id, 1)
        local res = unit:GetAiData(cfg.id, cfg.node_id, 2)
        if Time.time > keeptime then
            res = math.random(1, 100) <= rate and NODESTATE.NS_TRUE or NODESTATE.NS_FALSE
            unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time + keeptime)
            unit:SetAiData(cfg.id, cfg.node_id, 2, res)
        end
        return res
    end
    return math.random(1, 100) <= rate and NODESTATE.NS_TRUE or NODESTATE.NS_FALSE
end

function JiGuanAIAction.btDoSkill(unit, cfg, param, nd)
    --logError("JiGuanAIAction.btCheckRate"..unit.id..">>>>尝试施法>>>")
    unit:SetAiData(cfg.id, cfg.node_id, 1, 0);
    unit:SetBTreeWait(0.1, nd);
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckHpLess(unit, cfg, param, nd)
    if unit.roleData and unit.roleData.maxHp and unit.hp then
        local rate = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1)
        local per = unit.hp / unit.roleData.maxHp
        return rate > per and NODESTATE.NS_TRUE or NODESTATE.NS_FALSE
    end
    return NODESTATE.NS_FALSE
end

function JiGuanAIAction.btChaseEnemy(unit, cfg, param, nd)
    --追人，这里一般就是追主角了，或者传参里面定义追踪目标是玩家还是某个实例npc等
    local len = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) * 0.1
    local target = unit.target
    if not target then
        return NODESTATE.NS_TRUE
    end
    if Vector3.Distance(unit.pos, target.pos) < len then
        return NODESTATE.NS_TRUE
    end

    if nd.res == NODESTATE.NS_RUNNING then
        if not unit:IsMoving() then
            return NODESTATE.NS_TRUE
        end

        local passtime = unit:GetAiData(cfg.id, cfg.node_id, 1)
        if Time.time > passtime then
            unit.mainActionMgr.ctrl.moveCtrl:ResetSpeed()
            return NODESTATE.NS_TRUE
        end
    else
        local catchtime = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
        if catchtime == 0 then
            catchtime = 5
        end
        unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time + catchtime)
    end

    local actid = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)
    local speed = this.GetUnitPromotedSpeed(unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3))
    this.FollowUnit(unit, target, len, speed, actid)
    unit:SetBTreeWait(0.2, nd)

    return NODESTATE.NS_RUNNING
end

function JiGuanAIAction.btFaceToEnemy(unit, cfg, param, nd)
    local target = unit.target
    if not target then
        return NODESTATE.NS_TRUE
    end
    unit.rotateCtrl:LookAt(target.pos.x, target.pos.z)
    unit:SetBTreeWait(0.2, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckBetweenDistance(unit, cfg, param, nd)
    --默认指向玩家自身，后续可以考虑用配置传参来指定实例目标
    local target = unit.target
    if not target then
        return NODESTATE.NS_TRUE
    end

    local l1 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) * 0.1 --最小距离
    local l2 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2) * 0.1 --最大距离
    local type = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3)     --选取目标点类型 0 目标 1 出生点 2 自身
    local x = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4) * 0.1  --目标点偏移分米x
    local y = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 5) * 0.1  --目标点偏移分米y
    local z = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 6) * 0.1  --目标点偏移分米z

    local trapID = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 7)
    local pos, state = this.GetUnitTargetPos(unit, type, trapID)
    if not state then
        return NODESTATE.NS_FALSE
    end

    pos.x = pos.x + x
    pos.y = pos.y + y
    pos.z = pos.z + z

    local len = Vector3.Distance(unit.pos, pos)

    if len > l1 and len < l2 then
        return NODESTATE.NS_TRUE
    end

    return NODESTATE.NS_FALSE
end

function JiGuanAIAction.btRunaway(unit, cfg, param, nd)
    local target = unit.target
    if not target then
        return NODESTATE.NS_TRUE
    end
    local len = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) * 0.1
    local cd = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 5)
    if nd.res ~= NODESTATE.NS_RUNNING and cd > 0 then
        if unit:GetAiData(cfg.id, cfg.node_id, 5) > Time.time then
            return NODESTATE.NS_FALSE
        end
    end

    if nd.res == NODESTATE.NS_RUNNING then
        local passtime = unit:GetAiData(cfg.id, cfg.node_id, 1)
        if Time.time > passtime then
            unit.mainActionMgr.ctrl.moveCtrl:ResetSpeed()
            return NODESTATE.NS_TRUE
        end

        if not unit:IsMoving() then
            return NODESTATE.NS_TRUE
        else
            unit:SetBTreeWait(0.2, nd)
            return NODESTATE.NS_RUNNING
        end
    else
        if mathEx.GetDistance(unit.pos.x, unit.pos.z, target.pos.x, target.pos.z) > len then
            return NODESTATE.NS_TRUE
        end

        local rtime = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
        unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time + rtime)
    end

    local runmode = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)
    local pend = unit.pos - target.pos
    pend:SetNormalize()
    if pend:IsZero() then
        pend.x = 1.0
    end
    pend = pend * len

    local pos = Vector3()
    if runmode == 0 then
        pos = target.pos + pend
    else
        pos = unit.pos + pend
    end

    --飞行矫正
    if unit.gravityType == GRAVITY_TYPE.Float then
        pos.y = unit.pos.y
    end

    if cd > 0 then
        unit:SetAiData(cfg.id, cfg.node_id, 5, Time.time + cd)
    end

    --local mtype = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 6)
    local speed = this.GetUnitPromotedSpeed(unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3))
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = 1, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- unit:SetRotation(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end
    -- unit.rotateCtrl:StartRotate(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    unit:SetBTreeWait(0.2, nd)

    local actid = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 6)
    this.SetUnitFrameEvent(unit, actid)

    return NODESTATE.NS_RUNNING
end

function JiGuanAIAction.btCheckWeekness(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btFallDown(unit, cfg, param, nd)
    if nd.res == NODESTATE.NS_RUNNING then
        return NODESTATE.NS_TRUE
    end

    local speed = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) * 0.1
    local action = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
    local height = Scene.GetHeight(unit.pos.x, unit.pos.y, unit.pos.z) --体素获取最低高度

    if height > unit.pos.y then
        return NODESTATE.NS_TRUE
    end

    local pos = Vector3()
    pos.x = unit.pos.x
    pos.y = height
    pos.z = unit.pos.z
    local t = (unit.pos.y - height) / speed
    --客户端接口暂时没有下落的，后续记得替换一下 2022-2-28
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = speed, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    unit:SetBTreeWait(t / 1000, nd)
    return NODESTATE.NS_RUNNING
end

function JiGuanAIAction.btMoveAngle(unit, cfg, param, nd)
    local tar_type = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 8)
    local trapID = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 9)
    local tar_pos, state = this.GetUnitTargetPos(unit, tar_type, trapID)
    if not state then
        return NODESTATE.NS_FALSE
    end
    if not tar_pos then
        return NODESTATE.NS_TRUE
    end
    
    if nd.res == NODESTATE.NS_RUNNING then
        if unit:IsMoving() then
            if Time.time > unit:GetAiData(cfg.id, cfg.node_id, 1) then
                unit.mainActionMgr.ctrl.moveCtrl:ResetSpeed()
                return NODESTATE.NS_TRUE
            end
            unit:SetBTreeWait(0.1, nd)
            return NODESTATE.NS_RUNNING
        end
    end

    local angle1 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1)
    local angle2 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
    local len = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3) * 0.1
    local speedper = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)
    if speedper <= 0 then
        speedper = 100
    end

    local mtime = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 6)
    if mtime <= 0 then
        mtime = 10
    end
    unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time + mtime)

    angle1 = math.random(angle1, angle2)

    local dir = Vector2(tar_pos.x, tar_pos.z) - Vector2(unit.pos.x, unit.pos.z)
    if dir:IsZero() then
        dir.x = 1.0
    end
    dir = mathEx.RotateDir(dir, angle1)
    dir:SetNormalize()
    local pos = dir * len
    local posend = Vector3(unit.pos.x, unit.pos.y, unit.pos.z)
    posend.x = posend.x + pos.x
    posend.z = posend.z + pos.y
    pos = posend

    local actid = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 5)
    this.SetUnitFrameEvent(unit, actid)
    --logError(">curpos x:"..math.floor(unit.pos.x).."  z:"..math.floor(unit.pos.z).." tarpos x:"..math.floor(posend.x).." z:"..math.floor(posend.z))


    local speed = 2 * (speedper * 0.01)
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = speed, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    -- -- unit:SetRotation(dir)
    -- unit.rotateCtrl:StartRotate(dir) 
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end

    unit:SetBTreeWait(0.1, nd)

    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckMasterDistance(unit, cfg, param, nd)
    --检查自身与主人的距离 暂时不做
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btFollowMaster(unit, cfg, param, nd)
    --召唤怪跟随主人 暂时不做
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckAttacked(unit, cfg, param, nd)
    --这里的判断是   空闲状态后是否受到过攻击 而不是瞬时的 受到攻击，暂时不用管
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btSwitchToNormal(unit, cfg, param, nd)
    --
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btHaveBuff(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckSkillCD(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckViewEnemy(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btAdjustSkillPos(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btChooseTarget(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btSetSkillPos(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCanCallMonster(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckBetweenHeight(unit, cfg, param, nd)
    --检查高度差
    local target = unit.target
    if not target then
        return NODESTATE.NSTRUE
    end
    local l1 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) * 0.1
    local l2 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2) * 0.1
    local len = math.abs(unit.pos.y - target.pos.y)
    if len >= l1 and len <= l2 then
        return NODESTATE.NS_TRUE
    end

    return NODESTATE.NS_FALSE
end

function JiGuanAIAction.btFlymove(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btAddBuff(unit, cfg, param, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCurveMove(unit, cfg, param, nd)
    local target = unit.target
    if not target then
        return NODESTATE.NS_TRUE
    end

    if not unit.curve_pos then
        unit.curve_pos = {}
    end

    local len = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) * 0.1    --离目标距离
    local angle1 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)       --角度
    local angle2 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3)
    local angle3 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)
    local action = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 5)       --动作id
    local keeptime = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 6)     --持续毫秒
    if keeptime < 1000 then
        keeptime = 1000
    end

    local starttime = unit:GetAiData(cfg.id, cfg.node_id, 1)
    if starttime <= 0 then
        starttime = Time.time * 1000
        unit:SetAiData(cfg.id, cfg.node_id, 1, starttime)   --开始时间
        unit:SetAiData(cfg.id, cfg.node_id, 2, starttime)   --当前时间
        table.quickClear(unit.curve_pos)
    end

    if nd.res == NODESTATE.NS_RUNNING then
        local tick = Time.time * 1000
        if tick > starttime + keeptime then
            unit:SetAiData(cfg.id, cfg.node_id, 1, 0)
            unit.mainActionMgr.ctrl.moveCtrl:ResetSpeed()
            return NODESTATE.NS_TRUE
        end
    end

    if #unit.curve_pos == 0 then
        --顺/逆时针选择三个控制点
        local flag = math.random(0, 1)
        if flag == 0 then
            flag = -1
        end
        local unitPos = Vector2(target.pos.x, target.pos.z)
        local dir = Vector2(unit.pos.x, unit.pos.z) - unitPos
        if dir:IsZero() then
            dir.x = 1.0
        end

        local dir1 = mathEx.RotateDir(dir, angle1 * flag)
        dir1:SetNormalize()
        local d1 = dir1 * len
        local dir2 = mathEx.RotateDir(dir, angle2 * flag)
        dir2:SetNormalize()
        local d2 = dir2 * len
        local dir3 = mathEx.RotateDir(dir, angle3 * flag)
        dir3:SetNormalize()
        local d3 = dir3 * len

        --三阶贝塞尔
        local p0 = Vector2(unit.pos.x, unit.pos.z)
        local p1 = Vector2(unitPos.x + d1.x, unitPos.z + d1.z)
        local p2 = Vector2(unitPos.x + d2.x, unitPos.z + d2.z)
        local p3 = Vector2(unitPos.x + d3.x, unitPos.z + d3.z)

        table.insert(unit.curve_pos, p0)
        table.insert(unit.curve_pos, p1)
        table.insert(unit.curve_pos, p2)
        table.insert(unit.curve_pos, p3)
    end

    local totaltime = Time.time * 1000 - starttime
    if totaltime <= 0 then
        totaltime = 0
    end
    local t = 1.0 * totaltime / keeptime
    local q0 = unit.curve_pos[1] * (1 - t) + unit.curve_pos[2] * t
    local q1 = unit.curve_pos[2] * (1 - t) + unit.curve_pos[3] * t
    local q2 = unit.curve_pos[3] * (1 - t) + unit.curve_pos[4] * t
    local r0 = q0 * (1 - t) + q1 * t
    local r1 = q1 * (1 - t) + q2 * t
    local s = r0 * (1 - t) + r1 * t

    local pos = Vector3(s.x, unit.pos.y, s.z)

    local pretick = unit:GetAiData(cfg.id, cfg.node_id, 2)
    local time = Time.time * 1000 - pretick
    if time <= 0 then
        time = 10
    end
    unit:SetAiData(cfg.id, cfg.node_id, 2, Time.time * 1000)

    local speed = Vector3.Distance(pos, unit.pos) / time * 1000

    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = speed, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- unit:SetRotation(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    -- unit.rotateCtrl:StartRotate(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end
    unit:SetBTreeWait(0.2, nd)

    return NODESTATE.NS_RUNNING
end

function JiGuanAIAction.btNextP2p(unit, cfg, param, nd)
    --路点组id
    local aiParam = unit:GetAiParam()

    local groupId = aiParam[1]
    --当前目标路点索引
    local idx = aiParam[2]
    if aiParam[3] then
        --当前正在移动中
        return NODESTATE.NS_FALSE
    end

    local p2pListCfg = ConfigManager.GetConfig(ConfigName.P2pTree_List, groupId)
    if not p2pListCfg then
        return NODESTATE.NS_FALSE
    end
    local p2pCfg = ConfigManager.GetConfig(ConfigName.P2pTree, p2pListCfg.list[idx])
    if not p2pCfg then
        return NODESTATE.NS_FALSE
    end

    aiParam[3] = true

    local speed = 5
    local pos = Vector3(p2pCfg.param[1], unit.pos.y, p2pCfg.type == 1 and p2pCfg.param[2] or p2pCfg.param[3])
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = speed, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- unit:SetRotation(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end
    unit:SetBTreeWait(0.2, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btInP2p(unit, cfg, param, nd)
    --路点组id
    local aiParam = unit:GetAiParam()
    local groupId = aiParam[1]
    --当前目标路点索引
    local idx = aiParam[2]

    unit:SetBTreeWait(0.5, nd)
    local p2pListCfg = ConfigManager.GetConfig(ConfigName.P2pTree_List, groupId)
    if not p2pListCfg then
        return NODESTATE.NS_FALSE
    end
    local p2pCfg = ConfigManager.GetConfig(ConfigName.P2pTree, p2pListCfg.list[idx])
    if not p2pCfg then
        if unit.localType == UNIT_LOCAL_TYPE.ANIMAL then
            --抵达路点终点
            unit:DelayChangeState(Animal_State.DIE)
        end
        return NODESTATE.NS_FALSE
    end
    if aiParam[3] and mathEx.GetDistance(unit.pos.x, unit.pos.z, p2pCfg.param[1], p2pCfg.type == 1 and p2pCfg.param[2] or p2pCfg.param[3]) < 0.05 then
        aiParam[2] = idx + 1
        aiParam[3] = nil
    end
    return aiParam[3] and NODESTATE.NS_TRUE or NODESTATE.NS_FALSE
end

function JiGuanAIAction.btSwitch_ai(unit, cfg, param, nd)
    local state = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1)
    if unit.localType == UNIT_LOCAL_TYPE.ANIMAL then
        if state <= Animal_State.DIE and state > 0 then
            unit:DelayChangeState(state)
        end
    elseif unit.localType == UNIT_LOCAL_TYPE.JIGUAN then
        unit:DelayChangeState(state)
    end

    unit:SetBTreeWait(0.05, nd)
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btSwitchBT(unit, cfg, param, nd)
    local newBtId = this.GetUnitAIParamValue(unit, cfg, param, nd, 1)
    if newBtId == nil then
        logError("错误:切换行为树节点, 没有填目标行为树id")
        return NODESTATE.NS_FALSE
    end
    if unit.SwitchBT then
        unit:SwitchBT(newBtId)
        return NODESTATE.NS_TRUE
    else
        return NODESTATE.NS_FALSE
    end
end

function JiGuanAIAction.btMoveAngle3D(unit, cfg, param, nd)
    local tar_type = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 10)
    local trapID = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 11)
    local tar_pos, state = this.GetUnitTargetPos(unit, tar_type, trapID)
    if not state then
        return NODESTATE.NS_FALSE
    end
    if not tar_pos then
        return NODESTATE.NS_TRUE
    end

    if nd.res == NODESTATE.NS_RUNNING then
        if unit:IsMoving() then
            if Time.time > unit:GetAiData(cfg.id, cfg.node_id, 1) then
                unit.mainActionMgr.ctrl.moveCtrl:ResetSpeed()
                return NODESTATE.NS_TRUE
            end
            unit:SetBTreeWait(0.2, nd)
            return NODESTATE.NS_RUNNING
        end
    end

    local angle1 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1)
    local angle2 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
    local yangle1 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 3)
    local yangle2 = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 4)
    local len = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 5) * 0.1
    local speedper = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 6)
    if speedper <= 0 then
        speedper = 100
    end

    local mtime = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 8)
    if mtime <= 0 then
        mtime = 10
    end
    unit:SetAiData(cfg.id, cfg.node_id, 1, Time.time + mtime)

    angle1 = math.random(angle1, angle2)
    yangle1 = math.random(yangle1, yangle2)

    local dir = Vector2(tar_pos.x, tar_pos.z) - Vector2(unit.pos.x, unit.pos.z)
    if dir:IsZero() then
        dir.x = 1.0
    end
    dir = mathEx.RotateDir(dir, angle1)
    dir:SetNormalize()
    local pos = dir * math.cos(angle1) * len
    local posend = Vector3(unit.pos.x, unit.pos.y, unit.pos.z)
    posend.x = posend.x + pos.x
    posend.y = posend.y + math.sin(yangle1) * len
    posend.z = posend.z + pos.y
    pos = posend

    local actid = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 7)
    this.SetUnitFrameEvent(unit, actid)

    unit:ChangeGravityType(GRAVITY_TYPE.None)
    local speed = 2 * speedper * 0.01
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = speed, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- unit:SetRotation(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end
    unit:SetBTreeWait(0.2, nd)

    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btKillSelf(unit, cfg, param, nd)
    unit.hp = 0
    unit:ChangeState(Animal_State.DIE)

    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.btCheckTargetDir(unit, cfg, param, nd)
    local trapID = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1)
    local target = UnitManager.GetUniqueJiGuan(trapID)
    if not target then
        -- logError("no target")
        return NODESTATE.NS_FALSE
    end
    local angle = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 2)
    local vec = unit.pos - target.pos
    local vec2 = unit.pos - UnitManager.hero.pos
    local angle2 = Vector3.SignedAngle(vec, vec2, ConstValue.Vector3.up)
    -- logError("angle2", angle2)
    if angle > 0 then
        if angle2 > 0 and angle >= angle2 then
            -- logError("succeed")
            return NODESTATE.NS_TRUE
        end
    else
        if angle2 < 0 and angle2 >= angle then
            -- logError("succeed")
            return NODESTATE.NS_TRUE
        end
    end

    -- logError("failed")
    return NODESTATE.NS_FALSE
end

function JiGuanAIAction.btRotate(unit, cfg, param, nd)

    if not unit.rotateCtrl then
        return NODESTATE.NS_FALSE
    end
    local dir = unit:GetAiParamValue(cfg.param, param, cfg.node_id, 1) + unit.rotateCtrl:GetRealDir()

    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end
    unit:SetBTreeWait(0.1, nd)
    return NODESTATE.NS_TRUE
end

--region 公用Utility函数
-- 设置单位帧事件
function JiGuanAIAction.SetUnitFrameEvent(unit, actionId)
    if unit.localType == UNIT_LOCAL_TYPE.ANIMAL or
            unit.localType == UNIT_LOCAL_TYPE.JIGUAN then
        unit:SetDelayFrameEvent(actionId)
    end
end

-- 获取提升后的速度
function JiGuanAIAction.GetUnitPromotedSpeed(speedPercent)
    if not speedPercent or speedPercent <= 0 then
        speedPercent = 100
    end

    return 2 * (speedPercent * 0.01)
end

-- 获取节点参数,如果有覆写的话,获取覆写后的参数 
function JiGuanAIAction.GetUnitAIParamValue(unit, cfg, param, nd, index)
    if unit.ai_param_override then
        local override_index = Utils.GetOverrideAIParamIndex(nd.node.cfg.id, nd.node.cfg.node_id, index)
        if unit.ai_param_override[override_index] then
            return unit.ai_param_override[override_index]
        end
    end
    return unit:GetAiParamValue(cfg.param, param, cfg.node_id, index)
end

--- 获取AI目标位置   
-- @param tgtType 0:unit.target位置; 1:unit出生点; 2:特定机关位置,需要传入tgtId   
-- @return 参数1:最终位置; 参数2:历史逻辑,用于判断机关是否存在,若不存在则在Action中返回NODESTATE.NS_FALSE
function JiGuanAIAction.GetUnitTargetPos(unit, tgtType, tgtId)
    if tgtType == 1 then
        return unit.back_pos, true
    elseif tgtType == 2 then
        local trap = UnitManager.GetUniqueJiGuan(tgtId)
        if trap then
            return trap.pos, true
        else
            return nil, false
        end
    else
        return unit.target and unit.target.pos or nil, true
    end
end
--endregion

function JiGuanAIAction.Next_node_select(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]
        if cnd.res == NODESTATE.NS_TRUE then
            nd.res = NODESTATE.NS_TRUE
            return nil
        end
        local idx = -1
        for i = #nd.node.childs, 1, -1 do
            if cnd.node == nd.node.childs[i] then
                break
            else
                idx = i
            end
        end
        return idx == -1 and nil or nd.node.childs[idx]
    else
        if #nd.node.childs == 0 then
            return nil
        end
        return nd.node.childs[1]
    end
end

function JiGuanAIAction.Next_node_sequence(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]
        if cnd.res == NODESTATE.NS_FALSE then
            return nil
        end

        local idx = -1
        for i = #nd.node.childs, 1, -1 do
            if cnd.node == nd.node.childs[i] then
                break
            else
                idx = i
            end
        end
        if idx == -1 then
            nd.res = NODESTATE.NS_TRUE
            return nil
        else
            return nd.node.childs[idx]
        end
    else
        if #nd.node.childs == 0 then
            return nil
        end
        return nd.node.childs[1]
    end
end

function JiGuanAIAction.Next_node_rand(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]
        nd.res = cnd.res
        return nil
    else
        if #nd.node.childs == 0 or #nd.node.childs ~= #nd.node.cfg.child_weight then
            return nil
        end

        local w = 0
        for i = 1, #nd.node.cfg.child_weight do
            w = w + nd.node.cfg.child_weight[i]
        end

        local rval = math.random(0, w)
        local tmp = 0
        for i = 1, #nd.node.cfg.child_weight do
            tmp = tmp + nd.node.cfg.child_weight[i]
            if rval <= tmp then
                return nd.node.childs[i]
            end
        end
    end
end

--暂时不做随机技能结点
function JiGuanAIAction.Next_node_randskill(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]
        nd.res = cnd.res
        return nil
    else
        if #nd.node.childs == 0 or #nd.node.childs ~= #nd.node.cfg.child_weight then
            return nil
        end
    end
end

function JiGuanAIAction.Next_node_not(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]
        nd.res = cnd.res == NODESTATE.NS_TRUE and NODESTATE.NS_FALSE or NODESTATE.NS_TRUE
        return nil
    else
        if #nd.node.childs == 0 then
            return nil
        end
        return nd.node.childs[1]
    end
end

function JiGuanAIAction.Next_node_sqlselect(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]
        if cnd.res == NODESTATE.NS_TRUE then
            nd.res = NODESTATE.NS_TRUE
        elseif cnd.res == NODESTATE.NS_FALSE then
            return nil
        end

        local idx = -1
        for i = #nd.node.childs, 1, -1 do
            if cnd.node == nd.node.childs[i] then
                break
            else
                idx = i
            end
        end
        return idx == -1 and nil or nd.node.childs[idx]
    else
        if #nd.node.childs == 0 then
            return nil
        end
        return nd.node.childs[1]
    end
end

function JiGuanAIAction.Next_node_num(unit, nd, list)
    --次数结点暂时无效
    if true then
        return nil
    end
    local param = unit:GetAiParam(nd.node.cfg.id)        --来自实例的参数，用于替换ai模板里的内容用，目前配置没有
    local num = unit:GetAiData(nd.node.cfg.id, nd.node.cfg.node_id, 1)
    local value = unit:GetAiParamValue(nd.node.cfg.id, nd.node.cfg.node_id, 1)
    if num >= value then
        nd.res = NODESTATE.NS_FALSE
        return nil
    end

    if #list > nd.index then
        local mode = unit:GetAiParamValue(nd.node.cfg.id, nd.node.cfg.node_id, 2)
        local cnd = list[nd.index + 1]

        if cnd.res == NODESTATE.NS_TRUE then
            nd.res = NODESTATE.NS_TRUE
        end

        if (cnd.res == NODESTATE.NS_TRUE and mode == 0) or (cnd.res == NODESTATE.NS_FALSE and mode == 1) then
            unit:SetAiData(nd.node.cfg.id, nd.node.cfg.node_id, 1, num + 1)
        end
        return nil
    else
        if #nd.node.childs == 0 then
            return nil
        end
        return nd.node.childs[1]
    end
end

function JiGuanAIAction.Next_node_loop(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]
        if cnd.res == NODESTATE.NS_TRUE then
            return nd.node.childs[1]
        elseif cnd.res == NODESTATE.NS_FALSE then
            nd.res = NODESTATE.NS_FALSE
            return nil
        end
    else
        if #nd.node.childs == 0 then
            return nil
        end
        return nd.node.childs[1]
    end
end

function JiGuanAIAction.Next_node_must_sequence(unit, nd, list)
    if #list > nd.index then
        local cnd = list[nd.index + 1]

        local idx = -1

        for i = #nd.node.childs, 1, -1 do
            if cnd.node == nd.node.childs[i] then
                break
            else
                idx = i
            end
        end
        if idx == -1 then
            nd.res = cnd.res
            return nil
        else
            return nd.node.childs[idx]
        end
    else
        if #nd.node.childs == 0 then
            return nil
        end
        return nd.node.childs[1]
    end
end

function JiGuanAIAction.FollowUnit(unit, target, len, speed, actId)
    local pos = this.GetPosFromEnd(unit.pos, target.pos, len - 0.2)
    --飞行跟踪先不管

    --包含最后移动点，体素验证，后续补充 目前采取最粗糙的跟踪
    unit.mainActionMgr.ctrl.moveCtrl:StartManager({ pos = pos, speed = speed, followspeed = speed, crossWall = 0, crossUnit = 0, countGravity = 0, autoRemove = true })
    -- unit:SetRotation(90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x)))
    local dir = 90 - math.deg(Mathf.Atan2(pos.z - unit.pos.z, pos.x - unit.pos.x))
    if unit.rotateCtrl then
        unit.rotateCtrl:StartRotate(dir)
    else
        unit:SetRotation(dir)
    end

    this.SetUnitFrameEvent(unit, actId)
end

function JiGuanAIAction.GetPosFromEnd(from, to, len)
    local vec = from - to
    vec:SetNormalize()
    if vec:IsZero() then
        vec.x = 1.0
    end
    vec = vec * len
    vec.y = 0
    return to + vec
end

function JiGuanAIAction:ctor(btData)
    LuaAction.ctor(self, btData)
    self.tableName = "JiGuanAIAction"
end

function JiGuanAIAction:OnBegin()
    if not this.inited then
        this.Init()
    end

    if not self.params.unit.mainActionMgr or not self.params.unit.mainActionMgr.ctrl or not self.params.unit.mainActionMgr.ctrl.moveCtrl then
        logError("行为树控制机关AI的unit 未注册moveCtrl")
        return BTStatus.BTS_ERROR
    end

    self.list = {}
    self.m_nextBehaviorTick = 0
    self.curCfgId = self.params.cfgId
    this.GetTree(self.params.cfgId, self.list)

    return BTStatus.BTS_RUNNING
end

function JiGuanAIAction:OnUpdate()
    if not self.params.unit.unitMotor or self.m_nextBehaviorTick > Time.time then
        return BTStatus.BTS_RUNNING
    end

    if self.params.cfgId ~= self.curCfgId then
        --行为树替换
        self.list = {}
        self.curCfgId = self.params.cfgId
        this.GetTree(self.params.cfgId, self.list)
    end

    self.m_nextBehaviorTick = Time.time + 0.5

    if #self.list == 0 then
        return BTStatus.BTS_RUNNING
    end
    local nd = self.list[#self.list]
    if nd.wait_tick > 0 and nd.wait_tick > Time.time then
        return BTStatus.BTS_RUNNING
    end
    self:Run_node(self.params.unit, self.list, self.params.unit:GetAiParam())
    return BTStatus.BTS_RUNNING
end

function JiGuanAIAction:OnReset()

end

function JiGuanAIAction:Run_ActionNode(unit, param, nd)
    local cur_time = Time.time
    if nd.wait_tick > 0 and nd.wait_tick > cur_time then
        return true
    end
    if not nd.from_wait then
        if nd.wait_tick == 0 or nd.res == NODESTATE.NS_RUNNING then
            nd.res = self:Invoke(unit, param, nd)
            this.BTDebug(unit, "ActionNode, After DoAction, nodeId:" .. nd.node.cfg.node_id .. " res:" .. nd.res)
        end
        if nd.res ~= NODESTATE.NS_RUNNING and nd.node.cfg.wait > 0 then
            nd.from_wait = true
            unit:SetBTreeWait(nd.node.cfg.wait / 1000, nd)
            return true
        end
        if nd.wait_tick > 0 and nd.wait_tick > cur_time then
            return true
        end
    end
end

function JiGuanAIAction:Run_ParallelNode(unit, param, nd)
    if #nd.list ~= #nd.node.childs then
        table.quickClear(nd.list)
        for _, node in ipairs(nd.node.childs) do
            nd.list[#nd.list + 1] = {}
            this.PushNodeData(node, nd.list[#nd.list])
        end
    end
    nd.res = NODESTATE.NS_TRUE
    for _, nodeVec in ipairs(nd.list) do
        if #nodeVec == 1 and nodeVec[1].res ~= NODESTATE.NS_RUNNING then
            nodeVec[1].res = NODESTATE.NS_FALSE
            nodeVec[1].from_wait = false
            nodeVec[1].wait_tick = 0
        end
        this.BTDebug(unit, "Check Parallel Node, Run Node, childrenList.cnt:" .. #childrenList)
        self:Run_node(unit, nodeVec, param)
        if #nodeVec == 1 then
            if nodeVec[1].res == NODESTATE.NS_FALSE then
                nd.res = NODESTATE.NS_FALSE
                break
            elseif nodeVec[1].res == NODESTATE.NS_RUNNING then
                nd.res = NODESTATE.NS_RUNNING
            end
        else
            nd.res = NODESTATE.NS_RUNNING
        end
    end
end

function JiGuanAIAction:Run_node(unit, list, param)
    if not unit or #list == 0 then
        return
    end
    local nd = list[#list]
    this.BTDebug(unit, "Run_Node, nodeId:" .. nd.node.cfg.node_id)
    while nd do
        if nd.node.cfg.node_type == NODETYPE.BTNT_ACTION then
            if self:Run_ActionNode(unit, param, nd) then
                return
            end
        elseif nd.node.cfg.node_type == NODETYPE.BTNT_PARALLEL then
            self:Run_ParallelNode(unit, param, nd)
        end

        if nd.res ~= NODESTATE.NS_RUNNING then
            if self:Next_node(unit, nd, list) and #list ~= 0 then
                nd = list[#list]
            else
                return
            end
        else
            return
        end
    end
end

function JiGuanAIAction:Next_node(unit, nd, list)
    this.BTDebug(unit, "from node:" .. nd.node.cfg.node_id .. " to find <next node>")
    while nd do
        local node = nd.node
        local isLoop = node.cfg.node_type == NODETYPE.BTNT_LOOP
        if node.cfg.node_type == NODETYPE.BTNT_ACTION then
            if nd.index == 1 or nd.index > #list then
                return false
            end
            nd = list[nd.index - 1]
            this.BTDebug(unit, "next node loop, <-1>, list_cnt:" .. #list .. ", node.idx" .. nd.index)
        else
            node = self:Get_Next_node(unit, nd, list)
            while #list > nd.index do
                table.remove(list, #list)
            end
            if not node then
                this.BTDebug(unit, "next node loop, <no next>, list_cnt:" .. #list .. " node.idx:" .. nd.index)
                if nd.index == 1 or nd.index > #list then
                    return false
                end
                nd = list[nd.index - 1]
            else
                this.BTDebug(unit, "next node loop, next node:"..node.cfg.node_id.. " list_cnt:"..#list.. " node.idx:"..nd.index, "PUSH_NODE")
                this.PushNodeData(node, list)
                return not isLoop
            end
        end
    end
    return true
end

function JiGuanAIAction:Get_Next_node(unit, nd, list)
    if nd.node.cfg.node_type == NODETYPE.BTNT_SELECT then
        return JiGuanAIAction.Next_node_select(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_SEQUENCE then
        return JiGuanAIAction.Next_node_sequence(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_RAND then
        return JiGuanAIAction.Next_node_rand(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_RAND_SKILL then
        return JiGuanAIAction.Next_node_randskill(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_NOT then
        return JiGuanAIAction.Next_node_not(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_SEQ_SELECT then
        return JiGuanAIAction.Next_node_sqlselect(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_NUM then
        return JiGuanAIAction.Next_node_num(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_LOOP then
        return JiGuanAIAction.Next_node_loop(unit, nd, list)
    elseif nd.node.cfg.node_type == NODETYPE.BTNT_MUST_SEQUENCE then
        return JiGuanAIAction.Next_node_must_sequence(unit, nd, list)
    end
end

function JiGuanAIAction:Invoke(unit, param, nd)
    if nd.node.cfg.action > 0 then
        return this.DoBTAction(unit, nd.node.cfg, param, nd)
    end
    return NODESTATE.NS_TRUE
end

function JiGuanAIAction.BTDebug(unit, ...)
    local id = "NoUnit?"
    if unit ~= nil then
        id = unit:GetRealID()
    end
    --log("bt_unit:" .. id, ...)
end

return JiGuanAIAction