local CheckTargetDistance = class(LuaAction)

function CheckTargetDistance:ctor(luaTable,params)
    LuaConditon.ctor(self, luaTable, params)
    self.tableName = "CheckTargetDistance"
end

function CheckTargetDistance:Condition()
    if self.params.target then
        if not UnitManager.IsRoleAlive(self.params.target) or not self.params.distance then
            return false
        end
        local hero = UnitManager.hero
        --local pos = hero.pos
        local fullDistance = Vector3.Distance(hero.pos, self.params.target.pos)
        --logError(fullDistance, self.params.distance)
        if fullDistance < self.params.distance then
            return true
        end
    end
    return false
end


return CheckTargetDistance