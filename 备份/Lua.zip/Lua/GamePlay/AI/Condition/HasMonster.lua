local HasMonster = class(LuaAction)


function HasMonster:ctor(luaTable,params)
    LuaConditon.ctor(self, luaTable, params)
    self.tableName = "HasMonster"
end

function HasMonster:Condition()
    local target = SkillUtils.GetNearestMonster()
    if target then
        self.btData.HasMonsterTarget = target
        return true
    else
        self.btData.HasMonsterTarget = nil
    end
    return false
end

return HasMonster