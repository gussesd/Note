local LuaActionCreator = {}
local this = LuaActionCreator

function LuaActionCreator.CreateAction(name)
    return PoolManager.Get(name, this.btData)
end

function LuaActionCreator.Begin()
    this.btData = {}
end

function LuaActionCreator.End()
    this.btData = nil
end

return LuaActionCreator