local LuaAction = class()

function LuaAction:ctor(btData)
    self:PoolCtor(btData)
    self.tableName = "LuaAction"
end

function LuaAction:PoolCtor(btData)
    self.btData = btData
end

function LuaAction:OnBegin()
    return BTStatus.BTS_RUNNING
end

function LuaAction:OnUpdate()
    return BTStatus.BTS_SUCCESS
end

function LuaAction:OnPause()

end

function LuaAction:OnResume()

end

function LuaAction:OnEnd()

end

function LuaAction:OnReset()

end

function LuaAction:OnUnload()
end

function LuaAction:SetValue(key, value)
    self[key] = value
end

function LuaAction:Log(log)
    --if BehaviourTreeMgr.showLog then
    --    if BehaviourTreeMgr.logName == nil or (self.avatar ~= nil and BehaviourTreeMgr.logName == self.avatar:GetName())
    --    or (self.btData.avatar ~= nil and BehaviourTreeMgr.logName == self.btData.avatar:GetName())
    --    or (self.params.avatar ~= nil and BehaviourTreeMgr.logName == self.params.avatar:GetName())
    --    or (self.avatar==nil and self.btData.avatar==nil and self.params.avatar==nil and (BehaviourTreeMgr.logName==nil or  BehaviourTreeMgr.logName =="Hero")) then
    --        --print(log)
    --    end
    --
    --end

end
return LuaAction
