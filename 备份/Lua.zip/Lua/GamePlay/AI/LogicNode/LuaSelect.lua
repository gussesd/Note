--[[循序节点]]
local LuaSelect = class(LuaParentAction)

function LuaSelect:ctor(luaTable, params)
    LuaParentAction.ctor(self, luaTable, params)
end

function LuaSelect:Init()
    LuaParentAction.Init(self)

    self.tableName = "LuaSelect"
end

function LuaSelect:OnUpdate()
    self.status = BTStatus.BTS_SUCCESS

    while self.status ~= BTStatus.BTS_RUNNING do

        if self.bUnload then
            self.status = BTStatus.BTS_FAILURE
            return self.status
        end

        if self.curNode > #self.children then
            return BTStatus.BTS_FAILURE
        end

        if self.children[self.curNode] == nil then--这种情况不知道怎么出现的
            logError("1行为树节点为nil ????????当前行为树：", BehaviourTreeMgr.aiRoot)
            return BTStatus.BTS_FAILURE
        end

        if self.children[self.curNode].status == BTStatus.BTS_BEGIN or self.children[self.curNode].status == BTStatus.NONE then
            self.status = self.children[self.curNode]:Begin()
        end

        if self.children[self.curNode].status == BTStatus.BTS_RUNNING then
            self.status= self.children[self.curNode]:Update()
        end

        if self.children[self.curNode].status == BTStatus.BTS_FAILURE then
            self.children[self.curNode]:End()
            self.curNode = self.curNode + 1

        elseif self.children[self.curNode].status == BTStatus.BTS_SUCCESS then
            self.children[self.curNode]:End()
            return BTStatus.BTS_SUCCESS
        end
    end

    return BTStatus.BTS_RUNNING
end


return LuaSelect