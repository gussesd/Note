--[[循序节点]]
local LuaSequence = class(LuaParentAction)

function LuaSequence:Init()
    LuaParentAction.Init(self)

    self.tableName = "LuaSequence"
end

function LuaSequence:OnUpdate()
    self.status = BTStatus.BTS_SUCCESS

    --这个代码的无限循环看着就不安全，先简单限制一下次数
    local count = 0
    while self.status ~= BTStatus.BTS_RUNNING do
        count = count + 1
        if count > 100 then
            break
        end
        if self.bUnload then
            self.status = BTStatus.BTS_FAILURE
            return self.status
        end

        if self.curNode > #self.children then
            return BTStatus.BTS_SUCCESS
        end

        if self.children[self.curNode] == nil then--这种情况不知道怎么出现的
            logError("3行为树节点为nil ????????当前行为树：", BehaviourTreeMgr.aiRoot)
            return BTStatus.BTS_FAILURE
        end
        if self.children[self.curNode].status == BTStatus.BTS_BEGIN or self.children[self.curNode].status == BTStatus.NONE then
            self.status = self.children[self.curNode]:Begin()
        end

        if self.children[self.curNode].status == BTStatus.BTS_RUNNING then
            self.status = self.children[self.curNode]:Update()
        end

        if self.curNode > #self.children then
            return BTStatus.BTS_SUCCESS
        end
        if self.children[self.curNode].status == BTStatus.BTS_SUCCESS then
            self.children[self.curNode]:End()
            self.curNode=self.curNode+1

        elseif self.children[self.curNode].status == BTStatus.BTS_FAILURE then
            self.children[self.curNode]:End()
            return BTStatus.BTS_FAILURE
        elseif self.children[self.curNode].status == BTStatus.BTS_ERROR then
            self:Reset()
            return BTStatus.BTS_SUCCESS
        end
    end

    return BTStatus.BTS_RUNNING
end


return LuaSequence