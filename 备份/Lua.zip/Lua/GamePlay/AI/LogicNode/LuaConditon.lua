local LuaConditon = class(LuaBTAction)

function LuaConditon:ctor(luaTable, params)
    LuaBTAction.ctor(self, luaTable, params)
end

function LuaConditon:Init()
    LuaBTAction.Init(self)

    self.tableName = "LuaConditon"
end

function LuaConditon:OnBegin()
    return (self:Conditon() and BTStatus.BTS_SUCCESS) or BTStatus.BTS_FAILURE
end

function LuaConditon:Conditon()
    LPrint.log(self.luaObj.tableName.."..".. "Conditon".."..".. Time.frameCount)
    return self.luaObj:Condition()
end

return LuaConditon