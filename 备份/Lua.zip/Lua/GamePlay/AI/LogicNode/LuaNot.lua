local LuaNot = class(LuaParentAction)

function LuaNot:ctor(luaTable,params)
    LuaParentAction.ctor(self, luaTable,params)
end

function LuaNot:Init()
    LuaParentAction.Init(self)

    self.tableName = "LuaNot"
end

function LuaNot:OnBegin()
    self.status = self.children[1]:Begin()

    if self.status == BTStatus.BTS_SUCCESS then
        return BTStatus.BTS_FAILURE
    elseif self.status == BTStatus.BTS_FAILURE then
        return BTStatus.BTS_SUCCESS
    end
    return self.status
end

function LuaNot:OnUpdate()

    self.status = self.children[1]:Update()
    if self.status == BTStatus.BTS_SUCCESS then
        return BTStatus.BTS_FAILURE
    elseif self.status == BTStatus.BTS_FAILURE then
        return BTStatus.BTS_SUCCESS
    end
    return self.status
end

return LuaNot