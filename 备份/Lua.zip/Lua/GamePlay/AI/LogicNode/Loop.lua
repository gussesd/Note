--[[循环节点一个一个子集 curNode=1]]
local Loop = class(LuaParentAction)

function Loop:ctor(luaTable, params)
    LuaParentAction.ctor(self, luaTable, params)
end

function Loop:Init()
    LuaParentAction.Init(self)
    self.tableName = "Loop"
    self.bReset = false
end

function Loop:OnUpdate()
    if self.bUnload then
        self.status = BTStatus.BTS_FAILURE
        return self.status
    end
    if self.bReset then
        self.bReset = false
        self.children[self.curNode]:Reset()
    end
    if self.children[self.curNode]:Update() == BTStatus.BTS_SUCCESS or self.children[self.curNode].status == BTStatus.BTS_FAILURE then
        self.bReset = true
    end
    return BTStatus.BTS_RUNNING
end


return Loop