local LoopEvaluator = class(LuaParentAction)

function LoopEvaluator:ctor(luaTable, params)
    LuaParentAction.ctor(self, luaTable, params)
end

function LoopEvaluator:Init()
    LuaParentAction.Init(self)
    self.tableName = "LoopEvaluator"
    self.bReset = false
end

function LoopEvaluator:OnUpdate()
    if self.bUnload then
        self.status = BTStatus.BTS_FAILURE
        return self.status
    end

    if self.bReset then
        self.bReset = false
        self.children[2]:Reset()
        self.children[1]:Reset()
    end

    self.status = self.children[1]:Begin()

    if self.status == BTStatus.BTS_RUNNING then
        self.status = self.children[1]:Update()
    end

    if self.status == BTStatus.BTS_FAILURE then
        return BTStatus.BTS_FAILURE
    end

    if self.children[2]:Update() == BTStatus.BTS_FAILURE or self.children[2].status == BTStatus.BTS_SUCCESS then
        self.bReset = true
    end

    return BTStatus.BTS_RUNNING
end

function LoopEvaluator:OnPause()
    return self.children[2]:Pause()
end

function LoopEvaluator:OnResume()
    self.children[2]:Resume()
end

return LoopEvaluator