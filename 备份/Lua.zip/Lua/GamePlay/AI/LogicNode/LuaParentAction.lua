local LuaParentAction = class(LuaBTAction)

function LuaParentAction:PoolReset()
    if self.children then
        table.quickClear(self.children, true)
    end
end

function LuaParentAction:Init()
    LuaBTAction.Init(self)
    self.name = "LuaParentAction"
    self.tableName = "LuaParentAction"
    if not self.children then
        self.children = {}
    else
        table.quickClear(self.children)
    end
    self.curNode = 1
end

function LuaParentAction:CurNode(v)
    return v < #self.children and v or #self.children
end

function LuaParentAction:SetUnload(v)
    for i = 1, #self.children do
        self.children[i]:SetUnload(v)
    end
end


function LuaParentAction:AddAction(...)
    local args = {...}
    if #args == 0 then
        return 
    end
    for _, v in ipairs(args) do
        table.insert(self.children, v)
    end
    return ...
end

function LuaParentAction:InsertAction(index,action)
    if not action then
        return
    end
    table.insert(self.children, index, action)
end

function LuaParentAction:OnBegin()
    self.status = BTStatus.BTS_RUNNING
    return self.status
end

function LuaParentAction:OnEnd()
    if self.bUnload then
        return
    end
    for i = 1, #self.children do
        self.children[i]:End()
    end
end

function LuaParentAction:OnReset()
    self.status = BTStatus.BTS_BEGIN
    self.curNode = self:CurNode(1)
    for i = 1, #self.children do
        self.children[i]:Reset()
    end
end

function LuaParentAction:OnPause()
    if self.curNode <= #self.children then
        self.children[self.curNode]:Pause()
    end
end

function LuaParentAction:OnResume()
    if self.curNode <= #self.children then
        self.children[self.curNode]:Resume()
    end
end

function LuaParentAction:Log(str)
    if self.curNode <= #self.children then
        self.children[self.curNode]:Log(str)
    end
end

function LuaParentAction:GetChilds()
    return self.children
end

function LuaParentAction:Length()
    return #self.children
end

return LuaParentAction