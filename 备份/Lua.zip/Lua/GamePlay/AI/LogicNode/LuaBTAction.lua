local LuaBTAction = class()

function LuaBTAction:ctor(luaTable, params)
    self:PoolCtor(luaTable, params)
end

function LuaBTAction:PoolCtor(luaTable, params)
    self:Init()
    if luaTable then
        self.luaObj = LuaActionCreator.CreateAction(luaTable)
        self.name = luaTable
        self.tableName = self.luaObj.tableName
        if not self.luaObj.params then
            self.luaObj.params = {}
        else
            table.quickClear(self.luaObj.params)
        end
        if params then
            for k, v in pairs(params) do
                self.luaObj.params[k] = v
            end
        end
    end
end

function LuaBTAction:PoolReset()
    self.name = nil
    --回收对象
    if self.luaObj then
        self.luaObj = PoolManager.Release(self.luaObj)
    end
end

function LuaBTAction:Init()
    self.bUnload = false
    self.status = BTStatus.NONE
    self.name = "LuaBTAction"
    self.tableName = "LuaBTAction"
    self.identifier = nil
end 

function LuaBTAction:SetUnload(v)
    self.bUnload = v
end

function LuaBTAction:Unload()
    return self.bUnload
end

function LuaBTAction:Begin()
    if self.bUnload then
        self.status = BTStatus.BTS_FAILURE
        return self.status
    end
   
    self.status = self:OnBegin()
    if self.luaObj then
        LPrint.log(self.tableName.."..".. "OnBegin".."..".. Time.frameCount)
    end
    return self.status
end


function LuaBTAction:Update()
    if self.bUnload then
        self.status = BTStatus.BTS_FAILURE
        return self.status
    end
    if self.status == BTStatus.BTS_BEGIN or self.status == BTStatus.NONE then
        self:Begin()
    end
    
    self.status = self:OnUpdate()
    return self.status
end

function LuaBTAction:End()
    self:OnEnd()
end

function LuaBTAction:Pause()
    self:OnPause()
end
function LuaBTAction:Resume()
    self:OnResume()
end

function LuaBTAction:Reset()
    self.status = BTStatus.BTS_BEGIN
    self:OnReset()
end

function LuaBTAction:OnBegin()
    return self.luaObj:OnBegin()
end

function LuaBTAction:OnUpdate()
    return self.luaObj:OnUpdate()
end

function LuaBTAction:OnEnd()
    self.luaObj:OnEnd()
end

function LuaBTAction:OnReset()
    self.luaObj:OnReset()
end

function LuaBTAction:OnPause()
    self.luaObj:OnPause()
end

function LuaBTAction:OnResume()
    self.luaObj:OnResume()
end

function LuaBTAction:Log(str)
    self.luaObj:Log(str)
end 
function LuaBTAction:GetChilds()
    return nil
end

--打印行为树
function LuaBTAction:GetShowName()
    if self.name == self.tableName then
        return self.name
    else
        return self.name .. "(" .. self.tableName .. ")"
    end
end

function LuaBTAction:GetShowTab()
    local tab = {}
    tab.name = self:GetShowName()
    local childs = self:GetChilds()
    if childs then
        for k, v in pairs(childs) do
            tab[k] = v:GetShowTab()
        end
    end

    return tab
end

local function treeToString(t, level)
    local str = ""
    for i=1,level do
        str = str .. "\t"
    end
    str = str .. t.name .. "\n"
    for i=1, 1000 do
        if t[i] then
            str = str .. treeToString(t[i], level + 1)
        else
            break
        end
    end
    return str
end

function LuaBTAction:PrintTree()
    logError("\n" .. treeToString(self:GetShowTab(), 0))
end



return LuaBTAction