-- File: AnQiManager.lua
-- Auth: {qzw}
-- Date: 2021-11-29 16:39:30
-- Desc:
local AnQiManager = class()
local this = AnQiManager

local SendEventType = {
    StrongLevelUp = 1,
    StrongExpUp = 2,
    OrderLevelUp = 3,
    OrderExpUp = 4,
    SkillLevelUp = 5,
    JingLianLevelUp = 6,
    StarLevelUp = 7,
    StarExpUp = 8,
    ToActive = 9,
}

function AnQiManager.Init()
    -- 暗器信息
    this.infoTableList = {}
    -- 根据品质分类
    this.anqiQualityList = {}
    -- 暗器主动技能信息
    this.activeDressInfo = {}
    -- 暗器被动技能信息
    this.passiveDressInfo = {}
    this.anqiSkills = {}
end

-- 获取同一品质暗器列表
function AnQiManager.GetAnQiSuitByQuality(quality)
    return this.anqiQualityList[quality]
end

local anqiInfoChange = {}
local firstMsg = true
function AnQiManager.SM_ANQI_INFO(msg)
    if firstMsg then
        this.InitAnQiCfgInfo()
        this.InitAnQiNetMsgInfo(msg.data)
        firstMsg = false
    else
        this.UpdateAnQiNetMsgInfo(msg.data)
        this.SendChangeEvent()
    end
    SendCJMgr.SetCJ7()
end

--初始化暗器配置信息
function AnQiManager.InitAnQiCfgInfo()
    local anqiTable = ConfigManager.GetConfigTable(ConfigName.AnQi)
    for _, v in pairs(anqiTable) do
        local anqiData = PoolManager.Get("AnQiInfo", v)
        this.infoTableList[v.id] = anqiData
        if not this.anqiQualityList[v.qulity] then
            this.anqiQualityList[v.qulity] = {}
        end
        table.insert(this.anqiQualityList[v.qulity], anqiData)
        for key,skill_id in ipairs(v.skillid) do
            this.anqiSkills[skill_id] = v.id
        end
    end
end
function AnQiManager.IsAnqiSkill(skill_id)
    return this.anqiSkills[skill_id]
end
--初始化暗器数据信息
function AnQiManager.InitAnQiNetMsgInfo(data)
    for _, v in ipairs(data) do
        local anqiInfo = this.infoTableList[v.id]
        if anqiInfo then
            anqiInfo:Update(v)
            this.HandlerAnQiInit(anqiInfo)
        end
    end
end

--暗器初始化的处理
function AnQiManager.HandlerAnQiInit(info)
    local skillType = info:GetSkillType()
    if skillType == AnQiSkillType.passive then
        local plateNum  = info:GetPlateNum()
        if  plateNum  > 0 and  not this.IsAnQiDressByIndex(skillType,plateNum) then ---被动暗器技能未穿戴的话穿戴上
            this.PassiveToDress(info)
        end
    end
end

--更新暗器数据信息
function AnQiManager.UpdateAnQiNetMsgInfo(data)
    table.quickClear(anqiInfoChange)
    for _, v in ipairs(data) do
        local anqiInfo = this.infoTableList[v.id]
        if anqiInfo then
            local sendEventType = this.SetSendEventType(anqiInfo,v)
            anqiInfo:Update(v)
            if LocalData.IsMainUIInit then 
                this.HandlerAnQiChange(sendEventType,anqiInfo)
            end
        end
    end
end

function AnQiManager.SetSendEventType(oldInfo,info)
    local sendEventType = 0
    if oldInfo.active  == 0 and info ~= nil then 
        sendEventType = SendEventType.ToActive
    elseif oldInfo.order_lv ~= info.order_lv then
        sendEventType = SendEventType.OrderLevelUp
    elseif oldInfo.star_lv ~= info.star_lv then 
        sendEventType = SendEventType.StarLevelUp
    end
    if sendEventType > 0 then 
        anqiInfoChange[sendEventType] = 1
    end
    return sendEventType
end

--处理更新暗器变化
function AnQiManager.HandlerAnQiChange(sendEventType,newInfo)
    if sendEventType == SendEventType.ToActive then 
        local skillType = newInfo:GetSkillType()
        if skillType == AnQiSkillType.active then 
            this.ActiveToDress(newInfo)
        elseif skillType == AnQiSkillType.passive then 
            this.PassiveToDress(newInfo)
        end
        local cfg = ConfigManager.GetConfig(ConfigName.AnQi,newInfo.id)
        LocalData.ReceiveCountingRewards(cfg.item_id,SlotType.ST_ANQI,1)
    end
end

---指定暗器变化 需要发送消息位置
function AnQiManager.SendChangeEvent()
    for eventType, _ in pairs(anqiInfoChange) do
        if eventType == SendEventType.OrderLevelUp then
            EventManager.Dispatch(Event.UI_AnQi_Update_Order) --更新暗器阶位
        elseif eventType == SendEventType.StarLevelUp then
            EventManager.Dispatch(Event.UI_AnQi_Update_Star) --更新暗器升星
        end
    end
    EventManager.Dispatch(Event.UI_AnQi_Refresh)
end

function AnQiManager.ActiveToDress(anqiInfo)
    local isDress = this.IsAnQiDressById(AnQiSkillType.active,anqiInfo.id)
    if  isDress then 
        return 
    end
    local loadPos = this.GetAnQiDressEmptyPos()
    if loadPos > 0 then
        local settingType = SettingType.AnQi_Skill_1 + loadPos - 1
        local dressId = anqiInfo:Getid()
        this.SendToDressAnQi(settingType, tostring(dressId))
        this.activeDressInfo[loadPos] = dressId -- 先穿上
    end
end

function AnQiManager.PassiveToDress(anqiInfo)
    local loadPos = anqiInfo:GetPlateNum()
    if loadPos > 0 then
        local settingType = SettingType.AnQi_Skill_1b + loadPos - 1
        local dressId = anqiInfo:Getid()
        this.SendToDressAnQi(settingType, tostring(dressId))
        this.passiveDressInfo[loadPos] = dressId -- 先穿上
    end
end

function AnQiManager.UpAnQiDressInfo(data)
    local pos = 0
    for _, v in ipairs(data) do
        if v.type >= SettingType.AnQi_Skill_1 and v.type <= SettingType.AnQi_Skill_9 then
            pos = v.type - SettingType.AnQi_Skill_1 + 1
            this.activeDressInfo[pos] = tonumber(v.value)
        elseif v.type >= SettingType.AnQi_Skill_1b and v.type <= SettingType.AnQi_Skill_6b then
            pos = v.type - SettingType.AnQi_Skill_1b + 1
            this.passiveDressInfo[pos] = tonumber(v.value)
        end
    end
    EventManager.Dispatch(Event.UI_AnQiSkill_Refresh)
end

-- 只获取主动技能的位置
function AnQiManager.GetAnQiDressEmptyPos()
    local pos = 0
    for k = SettingType.AnQi_Skill_1, SettingType.AnQi_Skill_9 do
        pos = k - SettingType.AnQi_Skill_1 + 1
        if this.GetSkillHoleState(AnQiSkillType.active,pos) == AnQiSkillState.UnLoad then
            return pos
        end
    end
    return pos
end

function AnQiManager.SendToDressAnQi(_type, _value)
    NetManager.Send(ClientMsgMessage.CM_CLIENT_RECORD_UPDATE, {
        info = {{
            type = _type,
            value = _value
        }}
    })
end

function AnQiManager.GetAnQiList()
    return this.infoTableList
end

function AnQiManager.GetAnQi(id)
    return this.infoTableList[id]
end

function AnQiManager.GetAllAnQiDressInfo(skillType)
    if skillType == AnQiSkillType.active then
        return this.activeDressInfo
    elseif skillType == AnQiSkillType.passive then
        return this.passiveDressInfo
    end
end

function AnQiManager.GetAnQiDressInfo(skillType,index)
    local dressInfo = this.GetAllAnQiDressInfo(skillType)
    return dressInfo[index]
end

-- 判断是否穿戴获取穿戴位置
function AnQiManager.IsAnQiDressById(skillType,id)
    local dressInfo = this.GetAllAnQiDressInfo(skillType)
    for k, v in pairs(dressInfo) do
        if id == v then
            return true, k
        end
    end
    return false
end

function AnQiManager.IsAnQiDressByIndex(skillType,index)
    local dressInfo = this.GetAllAnQiDressInfo(skillType)
    if dressInfo and dressInfo[index] then 
        return true
    end
    return false
end

-- 排序
function AnQiManager.GetSortFunc(sort, updown)
    local sortFunc
    if sort == 1 then -- id排序
        sortFunc = function(a, b)
            local aCfg = a:GetCfg()
            local bCfg = b:GetCfg()
            if updown == 0 then
                if aCfg.qulity == bCfg.qulity then
                    return aCfg.id < bCfg.id
                end
                return aCfg.qulity < bCfg.qulity
            else
                if aCfg.qulity == bCfg.qulity then
                    return aCfg.id > bCfg.id
                end
                return aCfg.qulity > bCfg.qulity
            end
        end
    elseif sort == 2 then -- 强化等级排序
        sortFunc = function(a, b)
            if updown == 0 then
                if a.strong_lv == b.strong_lv then
                    return a:GetCfg().id < b:GetCfg().id
                end
                return a.strong_lv < b.strong_lv
            else
                if a.strong_lv == b.strong_lv then
                    return a:GetCfg().id > b:GetCfg().id
                end
                return a.strong_lv > b.strong_lv
            end
        end
    elseif sort == 3 then
        sortFunc = function(a, b)
            if updown == 0 then
                if a.order_lv == b.order_lv then
                    return a:GetCfg().id < b:GetCfg().id
                end
                return a.order_lv < b.order_lv
            else
                if a.order_lv == b.order_lv then
                    return a:GetCfg().id > b:GetCfg().id
                end
                return a.order_lv > b.order_lv
            end
        end
    elseif sort == 4 then
        sortFunc = function(a, b)
            if updown == 0 then
                if a.jinglian_lv == b.jinglian_lv then
                    return a:GetCfg().id < b:GetCfg().id
                end
                return a.jinglian_lv < b.jinglian_lv
            else
                if a.jinglian_lv == b.jinglian_lv then
                    return a:GetCfg().id > b:GetCfg().id
                end
                return a.jinglian_lv > b.jinglian_lv
            end
        end
    elseif sort == 5 then
        sortFunc = function(a, b)
            if updown == 0 then
                if a.star_lv == b.star_lv then
                    return a:GetCfg().id < b:GetCfg().id
                end
                return a.star_lv < b.star_lv
            else
                if a.star_lv == b.star_lv then
                    return a:GetCfg().id > b:GetCfg().id
                end
                return a.star_lv > b.star_lv
            end
        end
    end
    return sortFunc
end

-- 暗器技能状态
function AnQiManager.GetSkillHoleState(skillType, index)
    local value = this.GetAnQiDressInfo(skillType, index)
    if value == nil or value == -1 then
        return AnQiSkillState.UnLoad
    end
    return AnQiSkillState.Load, value
end

function AnQiManager.GetAllAnQiActiveByQuality(quality)
    local AnQi = this.GetAnQiSuitByQuality(quality)
    if AnQi == nil then
        logError("不存在的暗器品质")
        return false
    end
    for i, v in pairs(AnQi) do
        if not v:IsActive() then
            return false
        end
    end
    return true
end

function AnQiManager.Reset()
    firstMsg = true
    table.quickClear(this.activeDressInfo)
    table.quickClear(this.passiveDressInfo)
    table.quickClear(this.anqiQualityList)
    table.quickClear(this.infoTableList, true)
end

AnQiManager.Init()

return AnQiManager
