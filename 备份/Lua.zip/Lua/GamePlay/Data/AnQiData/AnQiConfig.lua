local AnQiConfig = {}
local this = AnQiConfig

function AnQiConfig.Init()
    local anqiTab = ConfigManager.GetConfigTable(ConfigName.AnQi)
    local suitTab = ConfigManager.GetConfigTable(ConfigName.AnQiSuit)
    this.anqiSkillTab = {} --暗器技能信息
    this.suitTab = {} --暗器套装信息
    for _, v in pairs(anqiTab) do
        for __, vv in ipairs(v.skillid) do
            --if not this.anqiSkillTab[vv] then
            --    this.anqiSkillTab[vv] = {}
            --end
            this.anqiSkillTab[vv] = v
        end
    end
    for _, v in pairs(suitTab) do
        if not this.suitTab[v.type] then
            this.suitTab[v.type] = {}
        end
        if not this.suitTab[v.type][v.qulity] then
            this.suitTab[v.type][v.qulity] = {}
        end
        table.insert(this.suitTab[v.type][v.qulity], v)
    end
end

function AnQiConfig.GetConfigBySkillId(skillId)
    return this.anqiSkillTab[skillId]
end

function AnQiConfig.GetSuit(type)
    return this.suitTab[type]
end

function AnQiConfig.SetSortData(list, sort, updown)
    local sortFunc
    if sort == 1 then --id排序
        sortFunc = function(a, b)
            if updown == 0 then
                return a.id < b.id
            else
                return a.id > b.id
            end
        end
    end
    table.sort(list, sortFunc)
end

AnQiConfig.Init()

return AnQiConfig
