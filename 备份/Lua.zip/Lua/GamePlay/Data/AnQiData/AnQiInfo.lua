-- File: AnQiData.lua
-- Auth: {qzw}
-- Date: 2021-11-29 19:04:22
-- Desc:
local AnQiInfo = class()

function AnQiInfo:ctor(cfg)
    self:PoolCtor(cfg)
end

function AnQiInfo:PoolCtor(cfg)
    self.cfg = cfg
    self.id = cfg.id
    self.strong_lv = 0
    self.strong_exp = 0
    self.order_lv = 0
    self.order_exp = 0
    self.skill_lv = 0 --淬毒等级
    self.jinglian_lv = 0
    self.star_lv = 0
    self.star_exp = 0
    self.active = 0
end

function AnQiInfo:PoolReset()
    self.cfg = nil
    self.strong_lv = 0
    self.strong_exp = 0
    self.order_lv = 0
    self.order_exp = 0
    self.skill_lv = 0
    self.jinglian_lv = 0
    self.star_lv = 0
    self.star_exp = 0
    self.active = 0
end

function AnQiInfo:Update(v)
    self.id = v.id
    self.strong_lv = v.strong_lv
    self.strong_exp = v.strong_exp
    self.order_lv = v.order_lv
    self.order_exp = v.order_exp
    self.skill_lv = v.skill_lv
    self.jinglian_lv = v.jinglian_lv
    self.star_lv = v.star_lv
    self.star_exp = v.star_exp
    self.active = 1
    --self:UnlockIlluAnqi()
end

function AnQiInfo:Getid()
    return self.id
end

-- 与其他数据类格式统一
function AnQiInfo:GetBase()
    return self.id
end

function AnQiInfo:GetCfg()
    return self.cfg
end

function AnQiInfo:GetGrid()
    return PackageTable:GetBag(SlotType.ST_ANQI)[self.id]
end

function AnQiInfo:IsActive()
    return self.active == 1
end

function AnQiInfo:GetStrongLevel()
    return self.strong_lv
end

function AnQiInfo:GetJingLianLevel()
    return self.jinglian_lv
end

function AnQiInfo:GetStarLevel()
    return self.star_lv
end

function AnQiInfo:GetOrderLevel()
    return self.order_lv
end

--获取暗器技能总等级(包括天赋点+升星+淬毒)
function AnQiInfo:GetAllSkillLevel()
    local skill_id =  self.cfg.skillid[1]
    local skillInfo = LocalData.hero.skillManager:GetSkillInfo(skill_id)
    if skillInfo then 
        return skillInfo.level
    end
    return 0
end

--获取暗器淬毒等级
function AnQiInfo:GetSkillLevel()
end

function AnQiInfo:GetSkillType()
    if self.cfg.is_active == 1 then 
        return AnQiSkillType.active
    elseif self.cfg.is_active == 0 then 
        return AnQiSkillType.passive
    end
end

--最大等级
function AnQiInfo:GetStrongMaxLevel()
    return 150
end

function AnQiInfo:GetOrderMaxLevel()
    return 15
end

function AnQiInfo:GetJingLianMaxLevel()
    return 15
end

function AnQiInfo:GetStarMaxLevel()
    return 25
end

function AnQiInfo:GetSkillMaxLevel()
    return 15
end

function AnQiInfo:IsStrongMaxLevel(level)
    local level = level or self.strong_lv
    --版署添加等级上限
    local cfg = ConfigManager.FindConfigs2key(ConfigName.AnQiStrong, "id", self.id, "level", level + 1,true)
    if cfg and cfg.order_lv > 4 then 
        return true
    end
    return level >= 150
end

function AnQiInfo:IsOrderMaxLevel(level)
    local level = level or self.order_lv
    --版署添加等级上限
    local cfg = ConfigManager.FindConfigs2key(ConfigName.AnQiOrder, "id", self.id, "level", level + 1,true)
    if cfg and cfg.need_lv > 4 then 
        return true
    end
    return level >= 15
end

function AnQiInfo:IsJingLianMaxLevel(level)
    local level = level or self.jinglian_lv
    return level >= 15
end

function AnQiInfo:IsStarMaxLevel(level)
    local level = level or self.star_lv
    return level >= 25
end

function AnQiInfo:IsSkillMaxLevel(level)
    local level = level or self.skill_lv
    return level >= 5
end

function AnQiInfo:GetPlateNum()
    return self.cfg.plate_num
end

return AnQiInfo
