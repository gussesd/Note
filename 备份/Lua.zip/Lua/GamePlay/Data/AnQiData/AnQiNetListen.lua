AnQiManager = require "GamePlay/Data/AnQiData/AnQiManager"
AnQiInfo = require "GamePlay/Data/AnQiData/AnQiInfo"
AnQiConfig = require "GamePlay/Data/AnQiData/AnQiConfig"
local AnQiNetListen = {}
local this = AnQiNetListen

function AnQiNetListen:Regist()
    this.NetList = {"SM_ANQI_INFO"}
    --for _, v in pairs(this.NetList) do
    --    if this[v] then
    --        NetManager.Regist(ServerMsgMessage[v], this[v])
    --    end
    --end
end

function AnQiNetListen.SM_ANQI_INFO(msgid, msg)
    if not msg then
        return
    end
    AnQiManager.SM_ANQI_INFO(msg)
    PackageTable:UpdateAnqi(msg)
end

function AnQiNetListen.UnRegist()
end

return AnQiNetListen
