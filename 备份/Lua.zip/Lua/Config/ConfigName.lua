ConfigName =
{
    ---A
    ActionNameList = "actionnamelist",  --动作列表
    AnimationPetty = "animation_petty", -- 肢体动作配置
    Animal = "animal",    --动物模板
    Animation = "animation",    --动作
    AnQi = "anqi",--暗器
    AnQiSuit = "anqi_suit",--暗器大师
    AnQiStrong = "anqi_strong",--暗器强化
    AnQiOrder = "anqi_order",--暗器进阶
    AnQiJingLian = "anqi_jinglian",--暗器精炼
    AnQiStar = "anqi_star",--暗器升星
    AnQiSkill = "anqi_skill",--暗器淬毒
    Audio = "audio",    --音效
    Audio_Group = "audio_group",    --场景音效组
    Audio_Inst = "audio_inst",    --场景音效实例
    Attr = "attr",  --属性
    Article = "article",   --小物件
    ArticlePath = "articlePath",   --物件路径
    ArticleModel = "articleModel",  --小物件模型
    Achievement="achievement",
    Achievement_task="achievement_task",
    Architecture = "architecture", -- 建筑(包括传送门)
    ActivityTitle = "activity_title",--活动标题
    ActivityTime = "activity_time",--活动时间
    Advert = "advert", --广告
    Arena_Reward_2v2 = "arena_reward_2v2",--2v2奖励
    Arena_Reward_7v7= "arena_reward_7v7",--7v7奖励
    Arena_Guess_Reward_7v7 = "arena_guess_reward_7v7",--7v7竞猜奖励
    Arena_Guess_Reward_7v7S = "arena_guess_reward_7v7s",--7v7特殊竞猜奖励 
    Arena_Grade_7v7  = "arena_grade_7v7",--7v7段位限制
    Arena_Final_Time = "arena_final_time",--活动时间
    Activity_Final_Arena  = "activity_final_arena",
    Activity_Final_Arena32 = "activity_final_arena32",
    Animation_Interaction = "animation_interaction",
    Animation_Param = "animation_param",
    Auction_Mart = "auction_mart",--私有拍卖行
    Action_Behavior = "action_behavior",    --行为动作映射表
    AnimationOtherMove = "animation_other_move", -- 其他移动动作列表
    ---B
    BannedWord = "banned_word", --屏蔽字
    BaoXiang = "baoxiang", --本地机关
    Bone = "bone", --魂骨
    Bone_strong = "bone_strong",
    Bone_strong_attr = "bone_strong_attr",
    Bone_hunsui = "bone_hunsui",
    Bone_hunsui_attr = "bone_hunsui_attr",
    Bone_jinglian = "bone_jinglian",
    Bone_star = "bone_star",
    Bone_num_suit = "bone_num_suit",
    Bone_suit = "bone_suit",
    Bone_year = "bone_year",
    Bone_hunsui_unlock = "bone_hunsui_unlock",
    Bone_hunsui_job = "bone_hunsui_job",
    Bone_order_upgrade = "bone_order_upgrade",
    Bone_level = "bone_level",
    BasicSettings = "basicsettings",
    Buff = "buff", --buff
    BuffDec = "buff_decoration",    --buff效果
    NpcBubbleDialog = "npc_bubble_dialog",
    BloodAwake = "blood_awake", --血脉觉醒
    BloodAwakeAfflux = "blood_awake_afflux", --血脉觉醒重数
    BloodAwakeAffluxValue = "blood_awake_afflux_value", --血脉觉醒注入值
    BossBubbleDialog = "boss_bubble_dialog",
    
    ---C
    Collection = "collection",  --机关
    Cook = "cook",--烹饪
    Core = "core",--，魂核
    Core_level = "core_level", --魂核升级
    Common_Animation = "common_animation", --通用动作
    Cutscene = "cutscene",    --动画
    Cutscene_branch = "cutscene_branch",    --动画分支
    Cutscene_control = "cutscene_control",    --动画替换
    CollectionSelf = "collection_self", --私有机关
    ChatBigEmoji = "chat_big_emoji",
    Common_Reward="common_reward", -- 捐献奖励
    Common_Group_Drop = "common_group_drop",--怪物掉落
    Collider = "collider", -- 碰撞器
    Client_Parameter = "client_parameter", --客户端参数表
    ChronRift = "chrono_rift", -- 裂缝碎片
    ---D
    Dialogue = "dialogue",
    DialogueSimplify = "dialogue_simplify", -- 简易对话
    Decoration = "decoration",  --特效
	DanYao = "danyao",--丹药
	DanYao_Cost = "danyao_cost",--
    Domain_Open = "domain_open",
    Draw_UP_Active = "draw_up_active",--抽卡
    Draw_Pool = "draw_pool",
    Draw_Group = "draw_group",
    Draw_Rate_Func = "draw_rate_func",
    Draw_Show = "draw_show",
    Dress = "dress",--时装
    Dress_Free = "dress_free",
    DressSuite = "dress_suite",--时装套装
    DropGroup = "drop_group", -- 掉落表
    Dungeon="dungeon",--副本
    -- Dungeon_Target = "dungeon_target",--副本目标(表不用了)
    DouHun  = "douhun",--斗魂
    Dialogue_Condition = "dialogue_select_show", --选择条件显示逻辑配置
    Dialogue_Invite = "dialogue_invite", --
    ---E
    Exp_Item = "exp_item",--升级道具经验相关
    Equip = "equip",    --装备
    Equip_strong = "equip_strong",--装备强化
    Equip_strong_attr = "equip_strong_attr",--装备强化属性
    Equip_jinglian = "equip_jinglian",--装备精炼
    Equip_jinglian_suit = "equip_jinglian_suit",--装备精炼属性
    Equip_star = "equip_star",--装备升星
    Equip_star_attr = "equip_star_attr",--装备升星属性
    Equip_fuling_slot = 'equip_fuling_slot',--装备附灵
    Element = "element",--元素弓
    Element_bow = "element_bow",--元素弓
    Element_bow_suit = "element_bow_suit",--元素弓
    ---F
    FLV = "flv",
    --FunctionButton = "functionButton",--ToDo弃用
    Family_build_level = "family_build_level",
    Family_active_reward = "family_active_reward",
    Family_Donate_Item ="family_donate_item", -- 捐献物品数值
    Family_Send="family_send",
    Family_team = "family_team",
    Family_skill_level_limit = "family_skill_level_limit",
    Family_skill_level_up = "family_skill_level_up",
    Function_Button = "function_button",

    FylWayPointContact = "fly_way_point_contact",--传送连线
    FlyWayPoint = "fly_way_point", --传送点信息
    FestivalTime = "festival_time",--节日时间

    Fish_Action = "fish_action", --钓鱼动画参数
    FamilyBuildPos = "family_build_pos", --宗门驻地表
    FamilyDungeonDonate = "family_dungeon_donate", --宗门建筑升级表
    FamilyDonateItem = "family_donate_item", --宗门捐献道具表

    ---G
    Grass_Group = "grass_group",--仙草组合
    Grass_Level = "grass_level",--仙草等级
    Grass_Star = "grass_star",--仙草升星
    Glamour = "glamour",--魅力等级
    Gain_Method = "gain_method",--获取途径
    Gain_Name = "gain_name",--方法名字
    GuideClick = "guide_click", --点击引导
    RankGift = "rank_gift",--排行奖励
    ---H
    HanZi = "hanzi",  --汉字屏蔽
    Hao_Level="hao_level",
    HunYin = "hunyin",
    HunYin_LV = "hunyin_level",
    HunHuan = "hunhuan",  --魂环
    HunHuanDesc = "hunhuan_description",  --魂环展示
    HunHuanStrength = "hunhuan_strength",--魂环强化
    HunHuanBreak = "hunhuan_break",--魂环突破
    HunHuanInit = "hunhuan_init",   --魂环初始化
    HudAnimation = "hud_animation", --冒血数字动画
	HunYin_Slot = "hunyin_slot",--
    HunShiRoad = "hunshiroad",
    HunShi_Name = "hunshi_name",
    HunShi = "hunshi",
    HunQi = "hunqi",
    HunQi_Lv = "hunqi_level",
    HunQi_Base_Attr = "hunqi_base_attr",
    HunQi_God_Attr = "hunqi_god_attr",
    HunQi_Strong_Attr_Lv = "hunqi_strong_attr_level",
    HunQi_Suite = "hunqi_suit",
    HunQi_master_attr = "hunqi_master_attr",
    ---I
    --Index_Number="index_number",--购买内力相关的表
    Item_compose = "item_compose",--合成
    Item_compose_unlock = "item_compose_unlock",--合成解锁
    Item = "item",  --道具
    Item_Inst = "item_inst",--
    Item_Gift = "item_gift",--礼包
    Item_Type = "item_type",  --
    Item_XinJian = "item_xinjian",-- 信件书籍
    Item_Photo = "item_photo", -- 道具图片
    Item_Select_Type = "item_select_type",  --
    Item_Group = "item_group", -- 道具组
    Item_Sub_List = "item_submit_list", --提交道具组
    Invite_Progress_Reward = "invite_progress_reward",--邀约奖励
    ---J
    Job = "job",    --职业基础
    JobDesc = "newly_built", --门派简介
    Jiaocheng = "jiaocheng", --教程

    JiGuan = "jiguan",                      --机关模板
    JiGuanInst = "jiguan_inst",             --机关实例模板
    JiGuanState = "jiguan_state",           --机关实例 状态下的条件与行为，客户端过滤有效操作，以及服务端验证用，行为部分是服务端处理，部分是双端预演
    JiGuanStateLogic = "jiguan_state_logic",--机关模板状态逻辑，包含动作逻辑，技能逻辑等，主要用于客户端编辑的锁定表现
    JiGuanBehavTree = "jiguan_behav_tree",  --机关行为树
    JiGuanBehType = "jiguan_beh_type",      --机关对接编辑器，字段数量与顺序控制
    JiGuanGroup = "jiguan_group",           --机关组数据，负责关联表现，无关解密逻辑

    Job_Domain_Open =  "job_domain_open",

    ---L
    Level = "level", --等级
    Line_level = "line_level",
    LastName = "lastName",
    Life_skill = "life_skill",--生活技能相关
    LocalMap = "localmap",  --本地地图配置
    ---M
    MakeFace = "make_face",
    Make_face_model_load = "make_face_model_load",
    MakeFace_zr = "make_face_zr",
    Make_face_design_face = "make_face_design_face",
    Make_face_design_environment = "make_face_design_environment",
    Make_face_design_dress = "make_face_design_dress",
    Make_face_design_accessories = "make_face_design_accessories",
    Make_face_design = "make_face_design",
    Master = "master",
    --MapRegion = "map_region",   --地图区域
    Map = "map",    --地图
    MapExplore = "map_explore", --本地机关
    Monster = "monster",
    Monster_Extra = "monster_extra",
    Map_Monster = "map_monster",
    Map_Trap = "map_trap",
    Map_Force = "map_force", --地图阵营
    Missile = "newmissile", --投射物
    --MapCollection = "map_collection",   --地图机关
    Model = "model",    --模型配置
    ModelPart = "modelPart",    --模型组件
    --Medal_Task = "medal_task", -- 勋章任务
    Medal="medal",
    MapAnchorPoint = "map_anchorpoint", --地图挂点
    MapIcon = "map_icon", -- 地图标记点
    MapSprite = "map_sprite", -- ui地图像素
    -- 触发区域
    MapTriggerArea = "map_triggerarea", 
    MapFisheryArea = "map_triggerarea_fishery", -- 渔场
    FishDrop = "fish_drop",--渔场掉落
    MapLightCurtainArea = "map_triggerarea_lightcurtain", -- 光幕
    MapTaskArea = "map_triggerarea_task", -- 任务区域
    MapAudioArea = "map_triggerarea_audio", --音效区域
    -- MapXunLianArea = "map_triggerarea_xiulian", -- 训练区域
    --MapArea = "map_area",
    --MapArea_Info = "map_area_info",
    MapDomain = "map_domain", -- 任务区域标记点
    MapFog = "map_fog", --非迷雾区域
    MapTeleport = "map_teleport", --地图传送点
    MapTerrainParams = "map_terrain_params", --地图地形属性
    MapLoading = "map_loading", --地图切图显示
    MapCollectionSelf = "map_collection_self", -- 私有采集物实例表
    MapBaoX = "map_baoxiang", -- 宝箱配置实例表
    MapPostStation = "map_post_station",-- 狮鹫重置点

    MapExploreGift = "explore_gift",--探索区域奖励
    MapExploreScore = "explore_score",--探索区域分

    MarryRing="marry_ring",
    MarryWedding="marry_wedding",
    MarrySkill="marry_skill",

    MapAnimal = "map_animal", --动物实例表
    MapJiGuan = "map_jiguan", --机关实例表

    MapPosSave = "map_pos_save", -- 任务副本进度点保存

    ---N
    Npc = "npc",    --npc
    NpcBase = "npc_base",
    Name = "name",
    NewOpen = "new_open",--系统开启
    Neigong_Grade="neigong_grade",--玄天功等级
    Neigong_Level="neigong_level",--每条经脉的数据
    Notice = "notice", --公告
    Notice_Lan = "notice_lan", 
    NPCAtk = "npc_atk",--npc战力表
    ---R
    Rule = "rule",--规则
    RevivalPoint = "revival_point", -- 复活点
    ---P
    PayProduct =  "pay_product", --充值
    --(暂时弃用)Plot = "cutscene_plot", --剧情对话
    PlotAniBlack = "cutscene_subtitles",--剧情动画字幕
    PlotIntroduce = "cutscene_introduce",--剧情动画人物介绍
    PlotTalk = "cutscene_dialogue", --剧情对话
    PlotBlcakScreen = "cutscene_blackScreen", --黑屏
    Position="position",
    Position_reward="position_reward",
    Panel_open = "panel_open",--界面跳转配置
    P2pTree = "p2p_tree", -- 点对点配置
    P2pTree_List = "p2p_tree_list", -- 点对点列表配置
    PersonalSet = "personal_set", -- 个性化设置
    P2pPath = "p2p_path", -- 行为路径
    P2pPathModelGroup = "p2p_path_model_group", -- 行为路径模型组
    

    ---Q
    --QTE = "cutscene_qte", --QTE
    Quick_Buy = "quick_buy",

    ---S
    Skill = "skill2", --技能
    SkillDescribe = "skill_describe",
    SkillDescribeTag = "skill_describe_tag",
    SkillDescribeRecast = "skill_describe_recast",
    SkillLevel = "skill_level",--
    SkillEffect = "skill_effect",   --技能数据
    ServerList = "serverList",  --服务器列表
    SkillAction = "skill_action", --技能事件
    SkillBuffToggle = "skill_buff_toggle", --BUFF触发类技能（触发条件）
    SkillRecast = "skill_recast", --技能数值调整
    ShopMall = "shop_mall",--商品配置
    ShopCommon = "shop_common",--商店配置
    ShopMystery = "shop_mystery",--神秘商店配置
    Some_Reward = "some_reward",--首充
    SignUp = "sign_up",--每日登录
    Shader = "shader",--shader
    ShiLiLevel = "shili_level",--势力等级配置
    Static_Param = "static_param",
    Story = "story",
    Story_Target = "story_target",
    ---T
    Task = "task",--任务
    Task_Branch = "task_branch", --支线任务表
    Task_Guide = "task_guide", --引导任务
    Task_Group = "task_group", -- 随机任务
    Trap = "trap", --技能机关
    Task_War_Token = "task_war_token",--战令任务
    Task_Box = "task_baoxiang", -- 宝箱任务
    Task_Memoirist = "task_zhuanji", -- 传记任务
    Task_MemoiristUnlock = "task_zhuanji_unlock", -- 传记解锁条件
    Task_Decoration = "task_decoration", --任务特效
    Task_Hold2_Receive = "task_hold_2_receive", -- 持有道具解锁任务
    Task_Random = "task_random", --任务随机规则表
    Task_QingYuan="task_qingyuan", -- 情缘任务
    Task_Mixed   ="task_mixed",-- 订婚戒指
    Task_Marry_Ring ="task_marry_ring",--婚戒升级
    Task_Treasure = "task_treasure", -- 宝箱任务
    Task_Invite = "task_invite", -- 邀约任务
    TalkGift = "talk_gift", -- 对话赠礼
    TiLi = "tili",--体力
    Tianfu="tianfu",--玄天宝录树配置
    Tianfu_Point="tianfu_point",--玄天宝录星座点配置
    Tujian = "tujian", --图鉴/主页签
    Tujian_Score = "tujian_score",--图鉴分数奖励
    Tujian_Npc = "tujian_npc",--图鉴/npc
    Tujian_Jiban = "tujian_jiban",--图鉴/npc/羁绊
    Tujian_Gift = "tujian_gift",--图鉴/npc/礼物
    TujianGiftCommon = "tujian_gift_common",--图鉴/npc/礼物
    Tujian_Affinity = "tujian_affinity",--图鉴/npc/认知度
    Tujian_Monster = "tujian_monster",--图鉴/怪物
    Tujian_Cognition = "tujian_cognition",--图鉴/怪物/认知度
    Tujian_Baibao = "tujian_baibao",--图鉴/百宝
    Tujian_Map = "tujian_map",--图鉴/万里河山
    Tujian_Story = "tujian_story",--图鉴/大陆典籍
    --Tujian_StoryUnlcok = "tujian_storyunlock",--图鉴/大陆典籍
    Tujian_Story_Main = "tujian_story_main",--图鉴/大陆典籍主线
    --Tujian_Dungeon = "tujian_dungeon",--图鉴/万里河山/副本秘境
    Tujian_RegionStory = "tujian_regionstory",--图鉴/万里河山/势力内容
    TuJ_NPCTalk = "tujian_npc_talk", -- npc随机回话
    TuJian_shuji= "tujian_shuji", -- 图鉴书籍
    TuJian_zhixian= "tujian_zhixian", -- 支线
    TuJian_chuanwen= "tujian_chuanwen", -- 传闻

    Tradingbank_Type = "tradingbank_type", --拍卖行分类
    Tradingrecord_Type = "tradingrecord_type", --拍卖记录分类
    ---V
    Vit_Gift = "vit_gift",
    Vit_Task = "vit_task",
    Vit_Medal = "vit_medal",
    Vit_TotalGift = "vit_total_gift",
    Voxel_Block = "voxel_block",    --动态体素配置

    ---W
    War_Token = "war_token",--战令
    Wing = "wing",--外附魂骨
    Wing_Fuling = "wing_fuling",
    Wing_Fuling_Attr = "wing_fuling_attr",
    Wing_Order = "wing_order",
    Wing_Star = "wing_star",
    Weather = "weather",
    Weather_Setting = "weather_settings",
    --Wing_Star_Skill = "wing_star_skill",
    Wing_Strong = "wing_strong",
    WuHun = "wuhun",
    WuHun_JueXing = "wuhun_juexing",
    WuHun_JinHua = "wuhun_jinhua",
    WuHun_Strong = "wuhun_strong",
    ---X
    XiuLian = "xiulian",
    ---Z
    ZZ_Task = "zz_task", --宗门任务
    ZZ_Task_Round_Reward = "zz_task_round_reward",
    ZanZhu = "zanzhu", --学院赞助
    ZanZhu_Tequan = "zanzhu_tequan",
    Zone_Area = "zone_area", --城战地图
    Zone_Reward = "zone_reward", --城战奖励
    Zone_Achievement = "zone_achievement",--赛季成就
    Zone_Time = "zone_time",
    Zone_Building = "zone_building",
    Zone_Skill = "zone_skill",
    Zone_View = "zone_view",
    Zone_Season = "zone_season", --赛季时间
}