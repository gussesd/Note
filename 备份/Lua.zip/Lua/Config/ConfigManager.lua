require "Config/ConfigName"
local ConfigManager = {}
local this = ConfigManager
local name2Table = {}
local name2Map = {}
local name2MultiMap = {}
local reloadList = {}
--某些表经过二次处理后，如果只使用二次处理后的数据，就清楚缓存
function ConfigManager.ClearConfigTable(name)
    name2Table[name] = nil
    name2MultiMap[name] = nil
end
function ConfigManager.GetConfigTable(name)
    local tbl = name2Table[name]
    if not tbl then
        tbl = require("Config/data/" .. name)
        if not tbl then
            logWarning("Config " .. name .. "not exist!!!")
            return
        end

        name2Table[name] = tbl
        name2MultiMap[name] = {}
    end
    return tbl
end

local function BuildMap(array, key)
    local dic = {}
    for _, v in ipairs(array) do
        if dic[v[key]] == nil then
            dic[v[key]] = v
        end
    end
    return dic
end

local function BuildMultiMap(array, key)
    local dic = {}
    local len = 0
    for _, v in ipairs(array) do
        local id = v[key]
        if id then
            if not dic[id] then
                dic[id] = {}
            end
            len = #dic[id]
            dic[id][len + 1] = v
        end
    end
    return dic
end

function ConfigManager.GetConfig(name, id, key, showLog)
    if id == nil then
        return nil
    end

    --用id的配置很多，所以这里加了一个默认key
    key = key or "id"

    local namemap = name2Map[name]
    if not namemap then
        name2Map[name] = {}
        namemap = {}
    end
    if namemap then
        if not namemap[key] then
            local tbl = this.GetConfigTable(name)
            if tbl then
                namemap[key] = BuildMap(tbl, key)
                name2Map[name][key] = namemap[key]
            else
                return nil
            end
            --if name==ConfigName.Item then
            --    logError(name,key,LPrint.tablePrint(namemap[key]))
            --end
        end
        if namemap[key][id] then
            return namemap[key][id]
        end
    end
    if showLog ~= false then
        if not namemap then
            logWarning("cannot find config file ", name)
        elseif not namemap[key] then
            logWarning("cannot find config value, file ", name,  "key ", key)
        elseif not namemap[key][id] then
            logWarning("cannot find config value, file ", name, "value", id, "key ", key)
        end
    end

    --local map = name2Map[name]
    --if not map then
    --    local tbl = this.GetConfigTable(name)
    --    if tbl then
    --        map = BuildMap(tbl, key)
    --        name2Map[name] = map
    --    end
    --end
    --if map and map[id] then
    --    return map[id]
    --end
    --if showLog ~= false then
    --    if not map then
    --        logWarning("cannot find config file ", name)
    --    elseif not map[id] then
    --        logWarning("cannot find config value, file ", name, "value", id, "key ", key)
    --    end
    --end
end

--用这个函数获取，表示配置里id可能不止一个，所以返回的是一个table
--扩展这个类，允许为所有key创建multi列表
function ConfigManager.GetMultiConfig(name, id, key, showLog)
    if id == nil then
        logError("获取配置时参数有误 id == nil",name,id,key)
        return nil
    end

    --用id的配置很多，所以这里加了一个默认key
    key = key or "id"
    
    local map = name2MultiMap[name]
    if not map then
        this.GetConfigTable(name)
        map = name2MultiMap[name]
    end
    if map then
        if not map[key] then
            map[key] = BuildMultiMap(name2Table[name], key)
        end
    
        if map[key][id] then
            return map[key][id]
        end
    end
    if showLog ~= false then
        if not map then
            logWarning("cannot find config file ", name)
        elseif not map[key] or not map[key][id] then
            logWarning("cannot find config value, file ", name, "value", id, "key ", key)
        end
    end
    return {}--只有获取不存在的配置时才会走到这里，正常情况到这里比较少
end

function ConfigManager.FindConfigs(name, key, value, useMutilCache)
    if useMutilCache == true then
        return this.GetMultiConfig(name, value, key, false)
    else
        local cfgs = {}
        local tbl = this.GetConfigTable(name)
        if tbl then
            local len = 0
            for _, v in ipairs(tbl) do
                if v[key] == value then
                    len = len + 1
                    cfgs[len] = v
                    --table.insert(cfgs, v)
                end
            end
        end
        return cfgs
    end
end

function ConfigManager.FindConfigList2key(name, key, value, key2, value2, useMutilCache)
    local cfgs = {}
    local len = 0
    if useMutilCache == true then
        local tbl = this.GetMultiConfig(name, value, key, false)
        if tbl then
            for _, v in ipairs(tbl) do
                if v[key2] == value2 then
                    len = len + 1
                    cfgs[len] = v
                    --table.insert(cfgs, v)
                end
            end
        end
    else
        local tbl = this.GetConfigTable(name)
        if tbl then
            for _, v in ipairs(tbl) do
                if v[key] == value and v[key2] == value2 then
                    len = len + 1
                    cfgs[len] = v
                    --table.insert(cfgs, v)
                end
            end
        end
    end
    return cfgs
end

function ConfigManager.FindCfgList2keyWithFilter(name, key, value, key2, value2, useMutilCache, filterFunc)
    local cfgs = {}
    local len = 0
    if useMutilCache == true then
        local tbl = this.GetMultiConfig(name, value, key, false)
        if tbl then
            for _, v in ipairs(tbl) do
                if v[key2] == value2 and filterFunc(v) then
                    len = len + 1
                    cfgs[len] = v
                end
            end
        end
    else
        local tbl = this.GetConfigTable(name)
        if tbl then
            for _, v in ipairs(tbl) do
                if v[key] == value and v[key2] == value2 and filterFunc(v) then
                    len = len + 1
                    cfgs[len] = v
                end
            end
        end
    end
    return cfgs
end

function ConfigManager.FindConfig(name, key, value)
    local tbl = this.GetConfigTable(name)
    if tbl then
        for _, v in ipairs(tbl) do
            if v[key] == value then
                return v
            end
        end
    end
    return nil
end


function ConfigManager.FindConfigs2(name, key, value, key2, value2)
    local cfgs = {}
    local len = 0
    local tbl = this.GetMultiConfig(name, value, key, false)
    if tbl then
        for _, v in ipairs(tbl) do
            if v[key2] == value2 then
                len = len + 1
                cfgs[len] = v
            end
        end
    end
    return cfgs
end

function ConfigManager.FindConfigs3(name, key, value, key2, value2, key3, value3)
    local cfgs = {}
    local len = 0
    local tbl = this.GetMultiConfig(name, value, key, false)
    if tbl then
        for _, v in ipairs(tbl) do
            if v[key2] == value2 and v[key3] == value3 then
                len = len + 1
                cfgs[len] = v
            end
        end
    end
    return cfgs
end


function ConfigManager.FindConfigs2key(name, key, value, key2, value2, useMutilCache)
    if useMutilCache == true then
        local tbl = this.GetMultiConfig(name, value, key, false)
        if tbl then
            for _, v in pairs(tbl) do
                if v[key2] == value2 then
                    return v
                end
            end
        end
    else
        local tbl = this.GetConfigTable(name)
        if tbl then
            for _, v in ipairs(tbl) do
                if v[key] == value and v[key2] == value2 then
                    return v
                end
            end
        end
    end
    return nil
end

function ConfigManager.FindConfigs3key(name, key1, value1, key2, value2, key3, value3, useMutilCache)
    if useMutilCache == true then
        local tbl = this.GetMultiConfig(name, value1, key1, false)
        if tbl then
            for _, v in ipairs(tbl) do
                if v[key2] == value2 and v[key3] == value3 then
                    return v
                end
            end
        end
    else
        local tab = this.GetConfigTable(name)
        if tab then
            for _, v in pairs(tab) do
                if v[key1]==value1 and v[key2] == value2 and v[key3] == value3 then
                    return v
                end
            end
        end
    end
    return nil
end

function ConfigManager.FindConfigsN2N(name, key1, key2, value)
        local tbl = this.GetConfigTable(name)
        if tbl then
            for _, v in ipairs(tbl) do
                if v[key1] <= value and v[key2] >= value then
                    return v
                end
            end
        end
    return nil
end

function ConfigManager.FindConfigsKeyBy2Value(name,key,value1,value2)
    local tab = this.GetConfigTable(name)
    local t = {}
    local len = 0
    if tab then
        for _, v in pairs(tab) do
            if v[key] == value1 or v[key] == value2 then
                len = len + 1
                t[len] = v
            end
        end
        return t
    end
    return nil
end

function ConfigManager.FindConfigsKeyByTabValue(name,key,values)
    local tab = this.GetConfigTable(name)
    local t = {}
    if tab then
        for _, v in pairs(tab) do
            for _, value in pairs(values) do
                if v[key] == value then
                    table.insert(t,v)
                    break
                end
            end
        end
        return t
    end
    return nil
end

--文件重载
function ConfigManager.Reload(path)
    path = string.replace(path, "\\", "/")
    local list = string.split(path, "/")
    if #list >= 3 then
        local name = list[#list]
        name2MultiMap[name] = nil
        name2Table[name] = nil
        name2Map[name] = nil
        rrequire("Config/data/" .. name)
        logError("reload config", path)

        if this.IsSkillConfig(name) then
            reloadList["skill"] = true
        end
    end
end

function ConfigManager.DoReload()
    for k, v in pairs(reloadList) do
        --一些特殊文件的热重载支持
        if k == "skill" then
            if LocalData then
                local herodata = LocalData.GetHero()
                if herodata and herodata.skillManager then
                    herodata.skillManager:Reload()
                end
            end
        elseif k == "actionnamelist" then
            UnitActionManager.ClearActionName()
        elseif k == "flv" then
            FLVConfig.Init()
        end
    end

    table.quickClear(reloadList)
end

function ConfigManager.IsSkillConfig(name)
    if name == ConfigName.Skill
    or name == ConfigName.SkillEffect then
        return true
    end
end
--预先加载
function ConfigManager.PreLoadTable()
    CheckWords.InitHanziCache()
    this.GetConfigTable(ConfigName.Item_Group)
    this.GetConfigTable(ConfigName.Buff)
    this.GetConfigTable(ConfigName.Map_Monster)
    this.GetConfigTable(ConfigName.MapTriggerArea)
    this.GetConfigTable(ConfigName.Monster)
    this.GetConfigTable(ConfigName.Npc)
    this.GetConfigTable(ConfigName.NpcBase)
    this.GetConfigTable(ConfigName.P2pTree)
    this.GetConfigTable(ConfigName.ShopMall)
    this.GetConfigTable(ConfigName.SkillAction)
    this.GetConfigTable(ConfigName.SkillEffect)
    this.GetConfigTable(ConfigName.SkillRecast)
    this.GetConfigTable(ConfigName.AnQiStrong)
    this.GetConfigTable(ConfigName.Equip_strong)
    this.GetConfigTable(ConfigName.Equip_strong_attr)
    this.GetConfigTable(ConfigName.JiGuanState)
    this.GetConfigTable(ConfigName.Cutscene)
    this.GetConfigTable(ConfigName.Dialogue)
    this.GetConfigTable(ConfigName.Gain_Method)
    this.GetConfigTable(ConfigName.Gain_Name)
    --logError("=====================================preload cfg finish================================")
end

return ConfigManager