-- 临时配置表工具
local ConfigTestUtils = {}

local filePath = CS.UnityEngine.Application.dataPath.."Doc/Tools/"

function ConfigTestUtils.Init()
    filePath = string.gsub(filePath, "Assets", "")
end

-- [Comment]
-- 导出一个临时配置
-- fileName 文件名称
-- head 头配置
-- list 内容
--function ConfigTestUtils.ExportCfg(fileName, head, list)
--    local path = filePath..fileName..".cfg"
--    local buff = {}
--    local file = io.open(path, "w+")
--    for key,value in pairs(head) do
--        file:write(value)
--        file:write("\t")
--    end
--    file:write("\n")
--    for key,value in pairs(list) do
--        for k,v in pairs(value) do
--            file:write(v)
--            file:write("\t")
--        end
--        file:write("\n")
--    end
--    io.close(file)
--end

-- [Comment]
-- 导出一个临时配置
-- fileName 文件名称
-- head 头配置
-- list 内容
function ConfigTestUtils.ExportCfg(fileName, head, list)
    local path = filePath..fileName..".cfg"
    local buff = {}
    local len = 0
    local file = io.open(path, "w+")
    for key,value in pairs(head) do
        len = len + 1
        buff[len] = value
        len = len + 1
        buff[len] = "\t"
    end
    len = len + 1
    buff[len] = "\n"
    --file:write(table.concat(buff, ""))
    --table.quickClear(buff)
    --len = 0
    for key,value in pairs(list) do
        for k,v in pairs(value) do
            len = len + 1
            buff[len] = v
            len = len + 1
            buff[len] = "\t"
        end
        len = len + 1
        buff[len] = "\n"

        if len >= 100 then
            file:write(table.concat(buff, ""))
            table.quickClear(buff)
            len = 0
        end
    end
    if len > 0 then
        file:write(table.concat(buff, ""))
    end
    io.close(file)
end

ConfigTestUtils.Init()
return ConfigTestUtils