-- 此文件工具自动生成，不要修改
--id	int	11	机关id[sl:i][l]
--shape_type	int	11	机关范围类型:0无1圆2矩形(宽长高)[sl:i][l]
--shape_params	char	32	机关参数:按:分割r:h或w:l:h(单位米)[sl:i][l][DMH]
--delay	int	11	技能延迟[l]
--skill	int	11	技能[l]
--interval	int	11	循环间隔[l]
--model	char	128	模型[l]
--decoration	char	128	特效[l][d]
--voxel_block_enabled	int	11	是否开启动态体素[l]
--scale	float	11	缩放比[l]
local trap =
{
	{id = 1052,	shape_type = 1,	shape_params = {400,400},	delay = 0,	skill = 1052,	interval = 1000,	model = "",	decoration = {10540},	voxel_block_enabled = 0,	scale = 1},
	{id = 2303,	shape_type = 1,	shape_params = {200,300},	delay = 0,	skill = 2303,	interval = 1000,	model = "",	decoration = {10540},	voxel_block_enabled = 0,	scale = 1},
	{id = 2304,	shape_type = 1,	shape_params = {200,300},	delay = 0,	skill = 2304,	interval = 1000,	model = "",	decoration = {10540},	voxel_block_enabled = 0,	scale = 1},
	{id = 2603,	shape_type = 1,	shape_params = {100,200},	delay = 500,	skill = 2603,	interval = 3000,	model = "",	decoration = {26012},	voxel_block_enabled = 0,	scale = 1},
	{id = 2803,	shape_type = 1,	shape_params = {300,300},	delay = 0,	skill = 2803,	interval = 500,	model = "",	decoration = {28030},	voxel_block_enabled = 0,	scale = 1},
	{id = 5553,	shape_type = 1,	shape_params = {100,100},	delay = 0,	skill = 5553,	interval = 1000,	model = "",	decoration = {10540},	voxel_block_enabled = 0,	scale = 1},
	{id = 7202,	shape_type = 1,	shape_params = {500,500},	delay = 0,	skill = 7203,	interval = 500,	model = "",	decoration = {5003020},	voxel_block_enabled = 0,	scale = 1},
	{id = 10903,	shape_type = 1,	shape_params = {200,200},	delay = 500,	skill = 10903,	interval = 500,	model = "",	decoration = {101205},	voxel_block_enabled = 0,	scale = 1},
	{id = 14202,	shape_type = 1,	shape_params = {250,250},	delay = 0,	skill = 14202,	interval = 2500,	model = "",	decoration = {101601,101702},	voxel_block_enabled = 0,	scale = 1},
	{id = 14302,	shape_type = 1,	shape_params = {250,250},	delay = 0,	skill = 14302,	interval = 2500,	model = "",	decoration = {101601,101502},	voxel_block_enabled = 0,	scale = 1},
	{id = 20006,	shape_type = 1,	shape_params = {200,200},	delay = 500,	skill = 20006,	interval = 1000,	model = "",	decoration = {101401},	voxel_block_enabled = 0,	scale = 1},
	{id = 20211,	shape_type = 1,	shape_params = {150,150},	delay = 500,	skill = 20211,	interval = 500,	model = "",	decoration = {101205},	voxel_block_enabled = 0,	scale = 1},
	{id = 20350,	shape_type = 1,	shape_params = {1000,400},	delay = 0,	skill = 20350,	interval = 1000,	model = "",	decoration = {200013},	voxel_block_enabled = 0,	scale = 1},
	{id = 20416,	shape_type = 1,	shape_params = {300,300},	delay = 5750,	skill = 20416,	interval = 2000,	model = "",	decoration = {5003030},	voxel_block_enabled = 0,	scale = 1},
	{id = 40250,	shape_type = 1,	shape_params = {250,250},	delay = 0,	skill = 40250,	interval = 2500,	model = "",	decoration = {101601,101702},	voxel_block_enabled = 0,	scale = 1},
	{id = 40351,	shape_type = 1,	shape_params = {250,250},	delay = 0,	skill = 40351,	interval = 2500,	model = "",	decoration = {102602},	voxel_block_enabled = 0,	scale = 1},
	{id = 40551,	shape_type = 1,	shape_params = {250,250},	delay = 0,	skill = 40551,	interval = 2500,	model = "",	decoration = {101601,102414},	voxel_block_enabled = 0,	scale = 1},
	{id = 40951,	shape_type = 1,	shape_params = {250,250},	delay = 0,	skill = 40951,	interval = 2500,	model = "",	decoration = {101601,102414},	voxel_block_enabled = 0,	scale = 1},
	{id = 41050,	shape_type = 1,	shape_params = {200,200},	delay = 500,	skill = 41050,	interval = 500,	model = "",	decoration = {101205},	voxel_block_enabled = 0,	scale = 1},
	{id = 41051,	shape_type = 1,	shape_params = {200,200},	delay = 500,	skill = 41051,	interval = 500,	model = "",	decoration = {101205},	voxel_block_enabled = 0,	scale = 1},
	{id = 90001,	shape_type = 1,	shape_params = {54,10},	delay = 0,	skill = 7001,	interval = 0,	model = "",	decoration = {0},	voxel_block_enabled = 0,	scale = 1},
	{id = 90002,	shape_type = 1,	shape_params = {7,6},	delay = 0,	skill = 7041,	interval = 0,	model = "model_war_004",	decoration = {0},	voxel_block_enabled = 0,	scale = 1},
	{id = 90003,	shape_type = 1,	shape_params = {6,6},	delay = 0,	skill = 0,	interval = 0,	model = "model_war_003",	decoration = {0},	voxel_block_enabled = 0,	scale = 1},
	{id = 90004,	shape_type = 0,	shape_params = {0},	delay = 0,	skill = 0,	interval = 0,	model = "test_gm",	decoration = {0},	voxel_block_enabled = 1,	scale = 1},
	{id = 100401,	shape_type = 0,	shape_params = {0},	delay = 0,	skill = 0,	interval = 0,	model = "test_pvpgm",	decoration = {0},	voxel_block_enabled = 1,	scale = 1},
	{id = 400401,	shape_type = 1,	shape_params = {300,200},	delay = 300,	skill = 400411,	interval = 500,	model = "",	decoration = {4005110},	voxel_block_enabled = 0,	scale = 1},
	{id = 400501,	shape_type = 1,	shape_params = {300,400},	delay = 0,	skill = 400511,	interval = 300,	model = "",	decoration = {4006010},	voxel_block_enabled = 0,	scale = 1},
	{id = 500301,	shape_type = 1,	shape_params = {750,400},	delay = 0,	skill = 500311,	interval = 1000,	model = "",	decoration = {5003020},	voxel_block_enabled = 0,	scale = 1},
	{id = 500302,	shape_type = 1,	shape_params = {750,400},	delay = 0,	skill = 500312,	interval = 2000,	model = "",	decoration = {0},	voxel_block_enabled = 0,	scale = 1},
}

return trap