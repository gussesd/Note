-- 此文件工具自动生成，不要修改
--id	int	11	序号[l]
--type	int	11	类型[l]
--start_cutscene	int	11	开始剧情配置id[l]
--end_cutscene	int	11	结束剧情配置id[l]
--hint	char	265	提示信息内容[l]
local dungeon_cfg_behavior =
{
}

return dungeon_cfg_behavior