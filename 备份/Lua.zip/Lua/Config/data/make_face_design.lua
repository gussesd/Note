-- 此文件工具自动生成，不要修改
--id	int	11	预设选择(1脸2时装3配饰4动作5环境)[l]
--name	char	2048	内容(男|女)[l]
local make_face_design =
{
	{id = 1,	name = {{5,6,7,8,10},{1,2,3,4,9}}},
	{id = 2,	name = {{104,100},{107,102}}},
	{id = 3,	name = {{90,91},{92,106}}},
	{id = 4,	name = {{1000},{1000}}},
	{id = 5,	name = {{0,0},{1,1}}},
}

return make_face_design