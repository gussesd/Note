-- 此文件工具自动生成，不要修改
--id	int	11	唯一[l]
--type	int	11	几何形状(1.球体  2.圆柱体  3.胶囊体  4.棱柱体)[l]
--position	char	32	坐标[l][DMH]
--points	char	512	点集(4的顶点点集,点集需要按顺时针顺序传入)[l]
--height	float	11	高度(1不使用)[l]
--radius	float	11	半径(1、2、3使用)[l]
local geometry =
{
	{id = 1,	type = 5,	position = {0,0,0},	points = {{-20,-20},{20,-20},{20,20},{-20,20}},	height = 10,	radius = 0},
	{id = 2,	type = 1,	position = {-30.43915,109,-44.09425},	points = {{0,0}},	height = 0,	radius = 4},
	{id = 3,	type = 2,	position = {0,0,0},	points = {{30,30}},	height = 10,	radius = 5},
	{id = 4,	type = 4,	position = {-40.6706,109,-33.77875},	points = {{10,10},{10,-10},{-10,-10},{-10,10}},	height = 10,	radius = 0},
	{id = 80001,	type = 1,	position = {3371,40.1,1831},	points = {{0,0}},	height = 0,	radius = 4},
	{id = 80002,	type = 1,	position = {5379,329.9,6556},	points = {{0,0}},	height = 0,	radius = 4},
	{id = 80003,	type = 1,	position = {3885.39,99.0,4647.03},	points = {{0,0}},	height = 0,	radius = 4},
}

return geometry