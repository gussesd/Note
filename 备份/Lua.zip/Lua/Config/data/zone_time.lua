-- 此文件工具自动生成，不要修改
--id	int	11	ID[sl:i][l]
--state	int	11	类型（1竞价期；2备战期；3战斗期，除了类型1-3之外当天的时间内其他时间都算空闲期）[sl:i][l]
--week	int	11	对应周几[l][sl]
--start_time	int	11	开启时间对应static_param表id[l][sl]
--end_time	int	11	结束时间对应static_param表id[l][sl]
--desc	char	64	描述[l]
local zone_time =
{
	{id = 301,	state = 1,	week = 3,	start_time = 300,	end_time = 1140,	desc = "城战交战时间周三竞价期"},
	{id = 302,	state = 2,	week = 3,	start_time = 1140,	end_time = 1200,	desc = "城战交战时间周三备战期"},
	{id = 303,	state = 3,	week = 3,	start_time = 1200,	end_time = 1230,	desc = "城战交战时间周三第1场"},
	{id = 304,	state = 3,	week = 3,	start_time = 1230,	end_time = 1260,	desc = "城战交战时间周三第2场"},
	{id = 305,	state = 4,	week = 3,	start_time = 1260,	end_time = 1440,	desc = "城战结果展示时间周三"},
	{id = 601,	state = 1,	week = 6,	start_time = 300,	end_time = 1140,	desc = "城战交战时间周六竞价期"},
	{id = 602,	state = 2,	week = 6,	start_time = 1140,	end_time = 1200,	desc = "城战交战时间周六备战期"},
	{id = 603,	state = 3,	week = 6,	start_time = 1200,	end_time = 1230,	desc = "城战交战时间周六第1场"},
	{id = 604,	state = 3,	week = 6,	start_time = 1230,	end_time = 1260,	desc = "城战交战时间周六第2场"},
	{id = 605,	state = 4,	week = 6,	start_time = 1260,	end_time = 1440,	desc = "城战结果展示时间周六"},
}

return zone_time