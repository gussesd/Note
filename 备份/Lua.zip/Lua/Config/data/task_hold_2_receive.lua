-- 此文件工具自动生成，不要修改
--id	int	11	道具id[l]
--task	char	32	任务(类型:Id|类型:Id)[l][DMH]
--is_use	int	11	是否主动使用（0否，1是）[l]
local task_hold_2_receive =
{
	{id = 88044,	task = {2,2101060},	is_use = 0},
	{id = 88045,	task = {2,2101060},	is_use = 0},
	{id = 88046,	task = {2,2101060},	is_use = 0},
	{id = 88047,	task = {2,2101060},	is_use = 0},
}

return task_hold_2_receive