-- 此文件工具自动生成，不要修改
--id	int	11	配置id[sl][l]
--name	char	16	名字[sl][l]
--param	char	16	动作变量[l]
--value	int	11	动作改变区间值(默认1)[l]
local animation_param =
{
	{id = 1001,	name = "打坐",	param = "meditate",	value = 1},
}

return animation_param