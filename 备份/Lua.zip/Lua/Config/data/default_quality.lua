-- 此文件工具自动生成，不要修改
--level	int	11	等级[l]
--androidcpus	char	1024	安卓cpu名称[l]
--ioscpus	char	1024	ioscpu名称[l]
local default_quality =
{
	{level = 0,	androidcpus = "MSM8937,MSM8939,Exynos5410,mt6592,Kirin925,MSM8920,Kirin920,MSM8917,Exynos5260,mt6528,Kirin910,MSM8909,MSM8936,MSM8916,Exynos5250,MSM8960,MSM8208,Exynos4412,MSM8212,mt6589,MSM8260,Exynos4210,MSM8225,mt6577,MSM8255,Exynos3475,mt6515,Exynos3110,MSM7230,MSM7627,mt6573,mt6516,MSM8976,SDM660,APQ8084,MSM8994,Adreno616,Exynos7420,mt6797,MSM8956,mt6757,MSM8992,mt6795,Kirin935,mt6755T,Exynos5433,mt6755,Kirin930,Kirin655,MSM8953,Kirin650,Exynos5430,Exyons7870,Exynos7580,Exynos5432,mt6753,mt6750,mt6735,Exynos5800,Exynos5422,Kirin620,MSM8940,MSM8952,MSM8974,Exynos5420,mt6595,Kirin928",	ioscpus = "iPhone,iPhone3G,iPhone3GS,iPhone4,iPhone5,iPadMini1Gen,iPad4Gen,iPhone5C,iPhone5S,iPadAir1,iPadMini2Gen,iPhone6,iPhone6Plus"},
	{level = 1,	androidcpus = "Adreno630,MSM8998,MSM8996,Exynos8890,Kirin960,hi3660,Kirin955,Kirirn950,mt6797T,Exynos9810,Exynos8895,sdm845,sdm835,sdm855,Kirin980,Kirin970",	ioscpus = "iPadMini3Gen,iPadAir2,iPhone6S,iPhone6SPlus,iPadPro1Gen,iPadMini4Gen,iPhoneSE1Gen,iPadPro10Inch1Gen,iPhone7,iPhone7Plus,iPad5Gen,iPadPro2Gen,iPadPro10Inch2Gen,iPhone8,iPhone8Plus,iPhoneX,iPhoneXS,iPhoneXSMax,iPhoneXR"},
	{level = 2,	androidcpus = ""},
}

return default_quality