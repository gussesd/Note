-- 此文件工具自动生成，不要修改
--id	int	11	id[sl][l]
--type	int	11	引导位置区域（1.左上按钮2.右下技能）[l]
--param	int	11	功能参数(按钮为功能引导，技能为位置顺序)[l]
--size	int	11	缩放百分比[l]
--page	int	11	打开页签[l]
--item	int	11	索引道具[l]
--showIcon	int	11	附加显示Icon(0无操作，1显示加号)[l]
local guide_click =
{
	{id = 1001,	type = 1,	param = 1,	size = 60,	page = 0,	item = 0,	showIcon = 0},
	{id = 1002,	type = 1,	param = 2,	size = 60,	page = 0,	item = 0,	showIcon = 0},
	{id = 1003,	type = 1,	param = 3,	size = 60,	page = 0,	item = 0,	showIcon = 0},
	{id = 1004,	type = 1,	param = 4,	size = 60,	page = 0,	item = 0,	showIcon = 0},
	{id = 1005,	type = 1,	param = 5,	size = 60,	page = 0,	item = 0,	showIcon = 0},
	{id = 1006,	type = 1,	param = 6,	size = 60,	page = 0,	item = 0,	showIcon = 0},
	{id = 2001,	type = 2,	param = 1,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2002,	type = 2,	param = 2,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2003,	type = 2,	param = 3,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2004,	type = 2,	param = 4,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2005,	type = 2,	param = 5,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2006,	type = 2,	param = 6,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2007,	type = 2,	param = 7,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2008,	type = 2,	param = 8,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2009,	type = 2,	param = 9,	size = 100,	page = 0,	item = 0,	showIcon = 0},
	{id = 2010,	type = 2,	param = 10,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 2011,	type = 2,	param = 11,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 2012,	type = 2,	param = 12,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 2013,	type = 2,	param = 13,	size = 50,	page = 0,	item = 0,	showIcon = 1},
	{id = 2014,	type = 2,	param = 14,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 2015,	type = 2,	param = 15,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 2016,	type = 2,	param = 16,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 3001,	type = 3,	param = 1,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 4001,	type = 4,	param = 1,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 5001,	type = 5,	param = 1,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 6001,	type = 6,	param = 1,	size = 50,	page = 0,	item = 0,	showIcon = 0},
	{id = 8001,	type = 1,	param = 2,	size = 60,	page = 101,	item = 110101,	showIcon = 0},
	{id = 8002,	type = 1,	param = 2,	size = 60,	page = 101,	item = 110101,	showIcon = 0},
	{id = 8003,	type = 1,	param = 2,	size = 60,	page = 101,	item = 120101,	showIcon = 0},
	{id = 8004,	type = 1,	param = 2,	size = 60,	page = 101,	item = 130101,	showIcon = 0},
	{id = 8005,	type = 1,	param = 2,	size = 60,	page = 101,	item = 140101,	showIcon = 0},
	{id = 8006,	type = 1,	param = 2,	size = 60,	page = 102,	item = 81001,	showIcon = 0},
	{id = 8007,	type = 1,	param = 2,	size = 60,	page = 102,	item = 16108,	showIcon = 0},
	{id = 8008,	type = 1,	param = 2,	size = 60,	page = 102,	item = 16301,	showIcon = 0},
	{id = 8009,	type = 1,	param = 2,	size = 60,	page = 102,	item = 16201,	showIcon = 0},
	{id = 8011,	type = 1,	param = 2,	size = 60,	page = 102,	item = 16102,	showIcon = 0},
	{id = 10021,	type = 1,	param = 2,	size = 60,	page = 101,	item = 0,	showIcon = 0},
	{id = 10022,	type = 1,	param = 2,	size = 60,	page = 102,	item = 0,	showIcon = 0},
	{id = 10023,	type = 1,	param = 2,	size = 60,	page = 103,	item = 0,	showIcon = 0},
	{id = 10024,	type = 1,	param = 2,	size = 60,	page = 104,	item = 0,	showIcon = 0},
	{id = 10025,	type = 1,	param = 2,	size = 60,	page = 105,	item = 0,	showIcon = 0},
	{id = 10026,	type = 1,	param = 2,	size = 60,	page = 106,	item = 0,	showIcon = 0},
	{id = 10027,	type = 1,	param = 2,	size = 60,	page = 107,	item = 0,	showIcon = 0},
	{id = 10028,	type = 1,	param = 2,	size = 60,	page = 108,	item = 0,	showIcon = 0},
	{id = 10029,	type = 1,	param = 2,	size = 60,	page = 103,	item = 0,	showIcon = 0},
	{id = 10030,	type = 1,	param = 2,	size = 60,	page = 110,	item = 0,	showIcon = 0},
	{id = 10031,	type = 1,	param = 2,	size = 60,	page = 102,	item = 5571,	showIcon = 0},
}

return guide_click