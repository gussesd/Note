-- 此文件工具自动生成，不要修改
--group	int	11	组合类型(1-5)[sl:i][l]
--level	int	11	组合等级[sl:i][l]
--name	char	64	组合名称[l]
--param	char	11	组合需求(仙草类型:年限|仙草类型:年限)[sl:vv][l]
--skill	int	11	被动技能[sl:i][l]
--attr	char	128	属性[sl:ct][l]
--icon	char	16	仙草图标[l]
local grass_group =
{
	{group = 1,	level = 1,	name = "奇花三友",	param = {{1,10000},{3,10000},{5,10000}},	skill = 0,	attr = {{5,2,500},{6,2,500}},	icon = "icon_xczh"},
	{group = 1,	level = 2,	name = "奇花三友",	param = {{1,30000},{3,30000},{5,30000}},	skill = 0,	attr = {{5,2,600},{6,2,600}},	icon = "icon_xczh"},
	{group = 1,	level = 3,	name = "奇花三友",	param = {{1,50000},{3,50000},{5,50000}},	skill = 0,	attr = {{5,2,700},{6,2,700}},	icon = "icon_xczh"},
	{group = 1,	level = 4,	name = "奇花三友",	param = {{1,75000},{3,75000},{5,75000}},	skill = 0,	attr = {{5,2,800},{6,2,800}},	icon = "icon_xczh"},
	{group = 1,	level = 5,	name = "奇花三友",	param = {{1,100000},{3,100000},{5,100000}},	skill = 0,	attr = {{5,2,900},{6,2,900}},	icon = "icon_xczh"},
	{group = 1,	level = 6,	name = "奇花三友",	param = {{1,125000},{3,125000},{5,125000}},	skill = 0,	attr = {{5,2,1000},{6,2,1000}},	icon = "icon_xczh"},
	{group = 1,	level = 7,	name = "奇花三友",	param = {{1,160000},{3,160000},{5,160000}},	skill = 0,	attr = {{5,2,1200},{6,2,1200}},	icon = "icon_xczh"},
	{group = 1,	level = 8,	name = "奇花三友",	param = {{1,200000},{3,200000},{5,200000}},	skill = 0,	attr = {{5,2,1400},{6,2,1400}},	icon = "icon_xczh"},
	{group = 1,	level = 9,	name = "奇花三友",	param = {{1,250000},{3,250000},{5,250000}},	skill = 0,	attr = {{5,2,1600},{6,2,1600}},	icon = "icon_xczh"},
	{group = 1,	level = 10,	name = "奇花三友",	param = {{1,350000},{3,350000},{5,350000}},	skill = 0,	attr = {{5,2,1800},{6,2,1800}},	icon = "icon_xczh"},
	{group = 1,	level = 11,	name = "奇花三友",	param = {{1,500000},{3,500000},{5,500000}},	skill = 0,	attr = {{5,2,2000},{6,2,2000}},	icon = "icon_xczh"},
	{group = 1,	level = 12,	name = "奇花三友",	param = {{1,1000000},{3,1000000},{5,1000000}},	skill = 0,	attr = {{5,2,2500},{6,2,2500}},	icon = "icon_xczh"},
	{group = 2,	level = 1,	name = "披荆斩棘",	param = {{6,10000},{8,10000},{9,10000}},	skill = 0,	attr = {{3,2,500},{4,2,500}},	icon = "icon_xczh"},
	{group = 2,	level = 2,	name = "披荆斩棘",	param = {{6,30000},{8,30000},{9,30000}},	skill = 0,	attr = {{3,2,600},{4,2,600}},	icon = "icon_xczh"},
	{group = 2,	level = 3,	name = "披荆斩棘",	param = {{6,50000},{8,50000},{9,50000}},	skill = 0,	attr = {{3,2,700},{4,2,700}},	icon = "icon_xczh"},
	{group = 2,	level = 4,	name = "披荆斩棘",	param = {{6,75000},{8,75000},{9,75000}},	skill = 0,	attr = {{3,2,800},{4,2,800}},	icon = "icon_xczh"},
	{group = 2,	level = 5,	name = "披荆斩棘",	param = {{6,100000},{8,100000},{9,100000}},	skill = 0,	attr = {{3,2,900},{4,2,900}},	icon = "icon_xczh"},
	{group = 2,	level = 6,	name = "披荆斩棘",	param = {{6,125000},{8,125000},{9,125000}},	skill = 0,	attr = {{3,2,1000},{4,2,1000}},	icon = "icon_xczh"},
	{group = 2,	level = 7,	name = "披荆斩棘",	param = {{6,160000},{8,160000},{9,160000}},	skill = 0,	attr = {{3,2,1200},{4,2,1200}},	icon = "icon_xczh"},
	{group = 2,	level = 8,	name = "披荆斩棘",	param = {{6,200000},{8,200000},{9,200000}},	skill = 0,	attr = {{3,2,1400},{4,2,1400}},	icon = "icon_xczh"},
	{group = 2,	level = 9,	name = "披荆斩棘",	param = {{6,250000},{8,250000},{9,250000}},	skill = 0,	attr = {{3,2,1600},{4,2,1600}},	icon = "icon_xczh"},
	{group = 2,	level = 10,	name = "披荆斩棘",	param = {{6,350000},{8,350000},{9,350000}},	skill = 0,	attr = {{3,2,1800},{4,2,1800}},	icon = "icon_xczh"},
	{group = 2,	level = 11,	name = "披荆斩棘",	param = {{6,500000},{8,500000},{9,500000}},	skill = 0,	attr = {{3,2,2000},{4,2,2000}},	icon = "icon_xczh"},
	{group = 2,	level = 12,	name = "披荆斩棘",	param = {{6,1000000},{8,1000000},{9,1000000}},	skill = 0,	attr = {{3,2,2500},{4,2,2500}},	icon = "icon_xczh"},
	{group = 3,	level = 1,	name = "疏影暗香",	param = {{2,10000},{4,10000},{7,10000}},	skill = 0,	attr = {{25,2,500},{26,2,500}},	icon = "icon_xczh"},
	{group = 3,	level = 2,	name = "疏影暗香",	param = {{2,30000},{4,30000},{7,30000}},	skill = 0,	attr = {{25,2,600},{26,2,600}},	icon = "icon_xczh"},
	{group = 3,	level = 3,	name = "疏影暗香",	param = {{2,50000},{4,50000},{7,50000}},	skill = 0,	attr = {{25,2,700},{26,2,700}},	icon = "icon_xczh"},
	{group = 3,	level = 4,	name = "疏影暗香",	param = {{2,75000},{4,75000},{7,75000}},	skill = 0,	attr = {{25,2,800},{26,2,800}},	icon = "icon_xczh"},
	{group = 3,	level = 5,	name = "疏影暗香",	param = {{2,100000},{4,100000},{7,100000}},	skill = 0,	attr = {{25,2,900},{26,2,900}},	icon = "icon_xczh"},
	{group = 3,	level = 6,	name = "疏影暗香",	param = {{2,125000},{4,125000},{7,125000}},	skill = 0,	attr = {{25,2,1000},{26,2,1000}},	icon = "icon_xczh"},
	{group = 3,	level = 7,	name = "疏影暗香",	param = {{2,160000},{4,160000},{7,160000}},	skill = 0,	attr = {{25,2,1200},{26,2,1200}},	icon = "icon_xczh"},
	{group = 3,	level = 8,	name = "疏影暗香",	param = {{2,200000},{4,200000},{7,200000}},	skill = 0,	attr = {{25,2,1400},{26,2,1400}},	icon = "icon_xczh"},
	{group = 3,	level = 9,	name = "疏影暗香",	param = {{2,250000},{4,250000},{7,250000}},	skill = 0,	attr = {{25,2,1600},{26,2,1600}},	icon = "icon_xczh"},
	{group = 3,	level = 10,	name = "疏影暗香",	param = {{2,350000},{4,350000},{7,350000}},	skill = 0,	attr = {{25,2,1800},{26,2,1800}},	icon = "icon_xczh"},
	{group = 3,	level = 11,	name = "疏影暗香",	param = {{2,500000},{4,500000},{7,500000}},	skill = 0,	attr = {{25,2,2000},{26,2,2000}},	icon = "icon_xczh"},
	{group = 3,	level = 12,	name = "疏影暗香",	param = {{2,1000000},{4,1000000},{7,1000000}},	skill = 0,	attr = {{25,2,2500},{26,2,2500}},	icon = "icon_xczh"},
}

return grass_group