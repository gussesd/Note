-- 此文件工具自动生成，不要修改
--id	int	11	节日id[l]
--name	char	64	节日名字[l]
--starttime	int	11	开始时间戳[l]
--endtime	int	11	结束时间戳[l]
local festival_time =
{
	{id = 1,	name = "元旦",	starttime = 1672574400,	endtime = 1672664400},
	{id = 2,	name = "春节",	starttime = 1674302400,	endtime = 1674824400},
	{id = 3,	name = "清明",	starttime = 1680696000,	endtime = 1680699600},
	{id = 4,	name = "劳动",	starttime = 1682769600,	endtime = 1683118800},
	{id = 5,	name = "端午",	starttime = 1687435200,	endtime = 1687611600},
	{id = 6,	name = "国庆/中秋",	starttime = 1695988800,	endtime = 1696597200},
}

return festival_time