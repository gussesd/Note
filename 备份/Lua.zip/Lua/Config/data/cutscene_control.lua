-- 此文件工具自动生成，不要修改
--id	int	11	ID[l]
--cutscene	char	256	timeline内物件名称(name:name)[l]
--scene	char	256	场景物件名称(name:name)[l]
--change	int	11	是否恢复原状(0:不恢复，1:恢复）[l]
local cutscene_control =
{
	{id = 2001,	cutscene = "out",	scene = "dxyj_lei_build13_b_01",	change = 0},
	{id = 2002,	cutscene = "mid",	scene = "dxyj_lei_build13_b_02",	change = 0},
	{id = 2003,	cutscene = "in",	scene = "dxyj_lei_build13_b_03",	change = 0},
	{id = 10004,	cutscene = "door1",	scene = "QSTMSN_Build01_Door01",	change = 1},
	{id = 25010,	cutscene = "box",	scene = "HWDJGSN_Small_07e",	change = 0},
	{id = 25043,	cutscene = "door",	scene = "dwsbysf_build_02",	change = 0},
	{id = 250431,	cutscene = "door",	scene = "dwsbysf_build_02",	change = 0},
	{id = 54352,	cutscene = "stool1",	scene = "QSTMSN_Small_01g",	change = 0},
	{id = 40302,	cutscene = "ironchain1",	scene = "Common_HTZ_Small_04b_lod0",	change = 0},
	{id = 520220,	cutscene = "huaping",	scene = "HWDJGSN_Small_12b",	change = 0},
	{id = 600030,	cutscene = "qiuqian",	scene = "ty_smalll_03",	change = 1},
	{id = 650003,	cutscene = "door",	scene = "TY_FBdoorsmall_shui",	change = 1},
	{id = 660001,	cutscene = "door",	scene = "TY_FBdoor_shui",	change = 1},
	{id = 660004,	cutscene = "door",	scene = "TY_FBdoor_shui",	change = 1},
	{id = 660005,	cutscene = "door",	scene = "TY_FBdoor_lei",	change = 1},
	{id = 660008,	cutscene = "door",	scene = "TY_FBdoor_lei",	change = 1},
	{id = 660100,	cutscene = "light",	scene = "dxyj_03_guangzhu_01",	change = 0},
}

return cutscene_control