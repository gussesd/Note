-- 此文件工具自动生成，不要修改
--id	int	11	任务ID[l][sl:i]
--type	int	11	任务类型[l][sl:i]
--level	int	11	等级[l][sl:i]
--pretask	char	11	前置任务[l][sl:v]
--exp	int	11	经验奖励[l][sl:i]
--reward_items	char	64	奖励道具(道具ID：类型：数量)[l][sl:ct]
--hint_pilot	char	256	追踪点(x:y:z:r|x:y:z:r，r半径，点为0）[l][float[][]]
--stage_event	char	1024	阶段行为配置[l][NoColor]
--condition_info	char	128	任务进度描述[l][DMH]
--condition_special	char	64	任务完成特殊处理[l][sl:v]
--condition_list	char	1024	完成任务类型[l][sl:vv]
local task_mixed =
{
	{id = 10001,	type = 14,	level = 20,	pretask = "",	exp = 0,	reward_items = "",	hint_pilot = "",	stage_event = "",	condition_info = {"准备一株甘草"},	condition_special = "",	condition_list = {{2,2001,1,1}}},
	{id = 10002,	type = 14,	level = 20,	pretask = "10001",	exp = 0,	reward_items = "",	hint_pilot = "",	stage_event = "",	condition_info = {"准备一株金银花"},	condition_special = "",	condition_list = {{2,2043,1,1}}},
	{id = 10003,	type = 14,	level = 20,	pretask = "10002",	exp = 0,	reward_items = "",	hint_pilot = "",	stage_event = "",	condition_info = {"准备一株灯笼草"},	condition_special = "",	condition_list = {{2,2023,1,1}}},
	{id = 10004,	type = 14,	level = 20,	pretask = "10003",	exp = 0,	reward_items = "",	hint_pilot = "",	stage_event = "",	condition_info = {"准备一株玫瑰"},	condition_special = "",	condition_list = {{2,216,1,1}}},
	{id = 10005,	type = 14,	level = 20,	pretask = "10004",	exp = 100,	reward_items = {{240,1,1}},	hint_pilot = "",	stage_event = "",	condition_info = {"提交鲜花，打造牵缘戒指"},	condition_special = "",	condition_list = {{20,9999,10000,2600003}}},
	{id = 840005,	type = 15,	level = 0,	pretask = "",	exp = 0,	reward_items = "",	hint_pilot = "",	stage_event = "",	condition_info = "",	condition_special = "0",	condition_list = {{12,84116}}},
	{id = 840010,	type = 15,	level = 0,	pretask = "840005",	exp = 0,	reward_items = "",	hint_pilot = "",	stage_event = "",	condition_info = "",	condition_special = "0",	condition_list = {{12,84118}}},
	{id = 840015,	type = 15,	level = 0,	pretask = "840010",	exp = 0,	reward_items = "",	hint_pilot = "",	stage_event = "",	condition_info = "",	condition_special = "0",	condition_list = {{12,84120}}},
}

return task_mixed