-- 此文件工具自动生成，不要修改
--type	int	11	类型(0.连锁递减 1.分裂递减)[sl:i][l]
--value	int	11	值[sl:i][l]
--desc	char	32	说明[l]
local static_param =
{
	{type = 1,	value = 10001,	desc = "出生地图"},
	{type = 2,	value = -18908,	desc = "出生X坐标(厘米)"},
	{type = 3,	value = 15698,	desc = "出生Y坐标(厘米)"},
	{type = 4,	value = 16455,	desc = "出生Z坐标(厘米)"},
	{type = 5,	value = 300,	desc = "朝向"},
}

return static_param