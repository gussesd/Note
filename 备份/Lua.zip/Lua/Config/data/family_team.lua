-- 此文件工具自动生成，不要修改
--family_level	int	11	对应武堂等级[sl:i][l]
--team_num	int	11	战团解锁个数[sl:i][l]
--member_max	int	11	成员上限[sl:i][l]
local family_team =
{
	{family_level = 1,	team_num = 1,	member_max = 10},
	{family_level = 2,	team_num = 2,	member_max = 10},
	{family_level = 3,	team_num = 3,	member_max = 10},
	{family_level = 4,	team_num = 4,	member_max = 10},
	{family_level = 5,	team_num = 5,	member_max = 10},
	{family_level = 6,	team_num = 6,	member_max = 10},
	{family_level = 7,	team_num = 7,	member_max = 10},
	{family_level = 8,	team_num = 8,	member_max = 10},
	{family_level = 9,	team_num = 9,	member_max = 10},
	{family_level = 10,	team_num = 10,	member_max = 10},
	{family_level = 11,	team_num = 11,	member_max = 10},
	{family_level = 12,	team_num = 12,	member_max = 10},
	{family_level = 13,	team_num = 13,	member_max = 10},
	{family_level = 14,	team_num = 14,	member_max = 10},
	{family_level = 15,	team_num = 15,	member_max = 10},
}

return family_team