-- 此文件工具自动生成，不要修改
--type	int	11	类型(和奖励库对应的模板类型一致)[sl][l]
--quality	int	11	品质(魂骨(order) 魂印(quality)值,其他类型待补充)[sl][l]
--cd	int	11	cd秒[sl][l]
local auction_cd =
{
	{type = 3,	quality = 4,	cd = 3600},
	{type = 3,	quality = 5,	cd = 3600},
	{type = 3,	quality = 6,	cd = 5400},
	{type = 3,	quality = 7,	cd = 5400},
	{type = 3,	quality = 8,	cd = 7200},
	{type = 3,	quality = 9,	cd = 7200},
	{type = 3,	quality = 10,	cd = 7200},
	{type = 3,	quality = 11,	cd = 9000},
	{type = 3,	quality = 12,	cd = 9000},
	{type = 3,	quality = 13,	cd = 9000},
	{type = 3,	quality = 14,	cd = 10800},
	{type = 3,	quality = 15,	cd = 10800},
	{type = 4,	quality = 1,	cd = 3600},
	{type = 4,	quality = 2,	cd = 3600},
	{type = 4,	quality = 3,	cd = 7200},
	{type = 4,	quality = 4,	cd = 7200},
	{type = 4,	quality = 5,	cd = 7200},
	{type = 4,	quality = 6,	cd = 10800},
}

return auction_cd