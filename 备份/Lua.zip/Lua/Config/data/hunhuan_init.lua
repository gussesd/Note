-- 此文件工具自动生成，不要修改
--grade	int	11	阶段[l][#][sl:i]
--mapid	char	128	地图id[l][sl:v][DMH]（白虎、昊天、灵猫、凤凰、琉璃）
--basic_attr	char	256	职业基础属性[l][sl:ct]
--hunshi	int	11	魂师等级[l][sl:i]
--level	int	11	最大等级[l][sl:i]
--hunyin_open_attr_num	char	256	魂印解锁需要属性总和[l][sl:v]
--hunyin_open_item	char	256	魂印解锁需要道具[l][sl:vv]
--hunyin_open_year	char	256	魂印解锁需要年限[l][sl:v]
--give_exp	int	11	附加经验[l][sl:i]
--monster_info	char	256	模拟怪物[l](依次配置怪物id,x,y,z,4个参数，用冒号隔开)
local hunhuan_init =
{
	{grade = 0,	mapid = {1000},	basic_attr = "",	hunshi = 1,	level = 10,	hunyin_open_attr_num = {{800,960,1200}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{500,1000,5000}},	give_exp = 3000,	monster_info = ""},
	{grade = 1,	mapid = {80316,82005,83010,84016,85504},	basic_attr = {{50,1,180},{51,1,135},{52,1,135},{53,1,112},{54,1,112}},	hunshi = 1,	level = 20,	hunyin_open_attr_num = {{960,1200,1440}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{1000,5000,10000}},	give_exp = 6000,	monster_info = {{8300601,3478.52,191.7,1072.9},{8200201,5533.4,415.9,6892.4},{8350301,3105.41,102.36,1849.94},{8401001,4906.02,195.1,4928.63},{8550401,3372,235,6244}}},
	{grade = 2,	mapid = {84070,84070,84067,84078,84074},	basic_attr = {{50,1,236},{51,1,176},{52,1,176},{53,1,147},{54,1,147}},	hunshi = 2,	level = 30,	hunyin_open_attr_num = {{1164,1440,1760}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{4400,10000,25000}},	give_exp = 9000,	monster_info = {{8406001,-109.82,1.31,-31.3},{8406001,-109.82,1.31,-31.3},{8405501,-61.17,-0.57,-55.75},{8407001,-53.44,-16.11,5.08},{8406501,-68.36,-3.05,58.25}}},
	{grade = 3,	mapid = {83032,83032,83024,83028,83030},	basic_attr = {{50,1,268},{51,1,201},{52,1,201},{53,1,167},{54,1,167}},	hunshi = 3,	level = 40,	hunyin_open_attr_num = {{1440,1760,2160}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{10000,25000,50000}},	give_exp = 12000,	monster_info = {{8542201,47.59,70.05,117.06},{8542201,47.59,70.05,117.06},{8541901,47.59,70.05,117.06},{8542001,47.59,70.05,117.06},{8542101,47.59,70.05,117.06}}},
	{grade = 4,	mapid = {83042,83042,83046,83044,83048},	basic_attr = {{50,1,320},{51,1,240},{52,1,240},{53,1,200},{54,1,200}},	hunshi = 3,	level = 50,	hunyin_open_attr_num = {{1760,2160,2640}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{25000,50000,75000}},	give_exp = 15000,	monster_info = {{8552001,47.59,70.05,117.06},{8552001,47.59,70.05,117.06},{8552201,47.59,70.05,117.06},{8552101,47.59,70.05,117.06},{8552301,47.59,70.05,117.06}}},
	{grade = 5,	mapid = {1000},	basic_attr = {{50,1,395},{51,1,296},{52,1,296},{53,1,247},{54,1,247}},	hunshi = 5,	level = 60,	hunyin_open_attr_num = {{2160,2640,3200}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{50000,75000,100000}},	give_exp = 18000,	monster_info = ""},
	{grade = 6,	mapid = {1000},	basic_attr = {{50,1,448},{51,1,336},{52,1,336},{53,1,279},{54,1,279}},	hunshi = 5,	level = 70,	hunyin_open_attr_num = {{2752,3840,5480}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{80000,125000,200000}},	give_exp = 21000,	monster_info = ""},
	{grade = 7,	mapid = {1000},	basic_attr = {{50,1,576},{51,1,432},{52,1,432},{53,1,360},{54,1,360}},	hunshi = 6,	level = 80,	hunyin_open_attr_num = {{3840,5480,8576}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{125000,200000,350000}},	give_exp = 24000,	monster_info = ""},
	{grade = 8,	mapid = {1000},	basic_attr = {{50,1,733},{51,1,550},{52,1,550},{53,1,458},{54,1,458}},	hunshi = 8,	level = 90,	hunyin_open_attr_num = {{4560,6592,8576}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{160000,250000,350000}},	give_exp = 27000,	monster_info = ""},
	{grade = 9,	mapid = {1000},	basic_attr = {{50,1,854},{51,1,640},{52,1,640},{53,1,533},{54,1,533}},	hunshi = 8,	level = 94,	hunyin_open_attr_num = {{24000,24000,24000}},	hunyin_open_item = {{1085,1},{1085,2},{1085,3}},	hunyin_open_year = {{1000000,1000000,1000000}},	give_exp = 28200,	monster_info = ""},
}

return hunhuan_init