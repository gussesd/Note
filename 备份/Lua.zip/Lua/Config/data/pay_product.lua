-- 此文件工具自动生成，不要修改
--id	int	11	产品id[sl:i][l]
--name	char	16	产品名[l]
--type	int	11	产品类型[l]
--rmb	int	11	人民币(分)[sl:i][l]
--rate	int	11	充值比例[sl:i][l]
--gold_unbind	int	11	龙晶[sl:i][l]
--gold_bind	int	11	魂钻[sl:i][l]
--reward	char	64	道具奖励(101:1:1)[sl:vv][l]
--gold_bind_ev	int	11	每日领取魂钻(月卡)[sl:i][l]
--show	char	16	稀有度（0不显示1绝版2限定,{1|2|0|0}的意思就是对应reward字段里面填的道具顺序，没有显示需求就不用填）[l][DMH]
local pay_product =
{
	{id = 1,	name = "60枚龙晶",	type = 1,	rmb = 600,	rate = 10,	gold_unbind = 60,	gold_bind = 60,	reward = "",	gold_bind_ev = 0,	show = ""},
	{id = 2,	name = "300枚龙晶",	type = 1,	rmb = 3000,	rate = 10,	gold_unbind = 300,	gold_bind = 300,	reward = "",	gold_bind_ev = 0,	show = ""},
	{id = 3,	name = "980枚龙晶",	type = 1,	rmb = 9800,	rate = 10,	gold_unbind = 980,	gold_bind = 980,	reward = "",	gold_bind_ev = 0,	show = ""},
	{id = 4,	name = "1980枚龙晶",	type = 1,	rmb = 19800,	rate = 10,	gold_unbind = 1980,	gold_bind = 1980,	reward = "",	gold_bind_ev = 0,	show = ""},
	{id = 5,	name = "3280枚龙晶",	type = 1,	rmb = 32800,	rate = 10,	gold_unbind = 3280,	gold_bind = 3280,	reward = "",	gold_bind_ev = 0,	show = ""},
	{id = 6,	name = "6480枚龙晶",	type = 1,	rmb = 64800,	rate = 10,	gold_unbind = 6480,	gold_bind = 6480,	reward = "",	gold_bind_ev = 0,	show = ""},
	{id = 10,	name = "月卡",	type = 2,	rmb = 3000,	rate = 10,	gold_unbind = 0,	gold_bind = 300,	reward = {{6010,1,10},{6511,1,10},{6001,1,10},{6530,1,1},{202,1,1}},	gold_bind_ev = 100,	show = ""},
	{id = 11,	name = "长老令",	type = 3,	rmb = 9800,	rate = 10,	gold_unbind = 980,	gold_bind = 0,	reward = "",	gold_bind_ev = 0,	show = ""},
	{id = 12,	name = "教皇令",	type = 3,	rmb = 15800,	rate = 10,	gold_unbind = 1580,	gold_bind = 0,	reward = {{15003,1,1},{15205,1,1},{200,1,5}},	gold_bind_ev = 0,	show = {1,1,0,0}},
	{id = 13,	name = "长老升级教皇",	type = 3,	rmb = 6000,	rate = 10,	gold_unbind = 600,	gold_bind = 0,	reward = {{15003,1,1},{15205,1,1},{200,1,5}},	gold_bind_ev = 0,	show = {1,1,0,0}},
}

return pay_product