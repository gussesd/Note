-- 此文件工具自动生成，不要修改
--stage	int	11	赛段[l][sl:i]
--index	int	11	编号(1:512强...类推)[l][sl:i]
--reward	int	11	奖励[l][sl:i]
--pos_min	int	11	名次[l][sl:i]
--pos_max	int	11	名次[l][sl:i]
--name	char	16	奖励名称[l]
local arena_reward_7v7 =
{
	{stage = 1,	index = 1,	reward = 9309,	pos_min = 257,	pos_max = 512,	name = "512强"},
	{stage = 1,	index = 2,	reward = 9308,	pos_min = 129,	pos_max = 256,	name = "256强"},
	{stage = 1,	index = 3,	reward = 9307,	pos_min = 65,	pos_max = 128,	name = "128强"},
	{stage = 1,	index = 4,	reward = 9306,	pos_min = 33,	pos_max = 64,	name = "64强"},
	{stage = 1,	index = 5,	reward = 9305,	pos_min = 17,	pos_max = 32,	name = "32强"},
	{stage = 1,	index = 6,	reward = 9304,	pos_min = 9,	pos_max = 16,	name = "16强"},
	{stage = 1,	index = 7,	reward = 9303,	pos_min = 5,	pos_max = 8,	name = "八强"},
	{stage = 1,	index = 8,	reward = 9302,	pos_min = 3,	pos_max = 4,	name = "四强"},
	{stage = 1,	index = 9,	reward = 9301,	pos_min = 2,	pos_max = 2,	name = "亚军"},
	{stage = 1,	index = 10,	reward = 9300,	pos_min = 1,	pos_max = 1,	name = "冠军"},
	{stage = 1,	index = 11,	reward = 9310,	pos_min = 513,	pos_max = 1000,	name = "参与奖Ⅰ"},
	{stage = 1,	index = 12,	reward = 9311,	pos_min = 1001,	pos_max = 5000,	name = "参与奖Ⅱ"},
	{stage = 1,	index = 13,	reward = 9312,	pos_min = 5001,	pos_max = 9999999,	name = "参与奖Ⅲ"},
	{stage = 2,	index = 1,	reward = 9409,	pos_min = 257,	pos_max = 512,	name = "512强"},
	{stage = 2,	index = 2,	reward = 9408,	pos_min = 129,	pos_max = 256,	name = "256强"},
	{stage = 2,	index = 3,	reward = 9407,	pos_min = 65,	pos_max = 128,	name = "128强"},
	{stage = 2,	index = 4,	reward = 9406,	pos_min = 33,	pos_max = 64,	name = "64强"},
	{stage = 2,	index = 5,	reward = 9405,	pos_min = 17,	pos_max = 32,	name = "32强"},
	{stage = 2,	index = 6,	reward = 9404,	pos_min = 9,	pos_max = 16,	name = "16强"},
	{stage = 2,	index = 7,	reward = 9403,	pos_min = 5,	pos_max = 8,	name = "八强"},
	{stage = 2,	index = 8,	reward = 9402,	pos_min = 3,	pos_max = 4,	name = "四强"},
	{stage = 2,	index = 9,	reward = 9401,	pos_min = 2,	pos_max = 2,	name = "亚军"},
	{stage = 2,	index = 10,	reward = 9400,	pos_min = 1,	pos_max = 1,	name = "冠军"},
	{stage = 2,	index = 11,	reward = 9410,	pos_min = 513,	pos_max = 1000,	name = "参与奖Ⅰ"},
	{stage = 2,	index = 12,	reward = 9411,	pos_min = 1001,	pos_max = 5000,	name = "参与奖Ⅱ"},
	{stage = 2,	index = 13,	reward = 9412,	pos_min = 5001,	pos_max = 9999999,	name = "参与奖Ⅲ"},
	{stage = 3,	index = 1,	reward = 9509,	pos_min = 257,	pos_max = 512,	name = "512强"},
	{stage = 3,	index = 2,	reward = 9508,	pos_min = 129,	pos_max = 256,	name = "256强"},
	{stage = 3,	index = 3,	reward = 9507,	pos_min = 65,	pos_max = 128,	name = "128强"},
	{stage = 3,	index = 4,	reward = 9506,	pos_min = 33,	pos_max = 64,	name = "64强"},
	{stage = 3,	index = 5,	reward = 9505,	pos_min = 17,	pos_max = 32,	name = "32强"},
	{stage = 3,	index = 6,	reward = 9504,	pos_min = 9,	pos_max = 16,	name = "16强"},
	{stage = 3,	index = 7,	reward = 9503,	pos_min = 5,	pos_max = 8,	name = "八强"},
	{stage = 3,	index = 8,	reward = 9502,	pos_min = 3,	pos_max = 4,	name = "四强"},
	{stage = 3,	index = 9,	reward = 9501,	pos_min = 2,	pos_max = 2,	name = "亚军"},
	{stage = 3,	index = 10,	reward = 9500,	pos_min = 1,	pos_max = 1,	name = "冠军"},
	{stage = 3,	index = 11,	reward = 9510,	pos_min = 513,	pos_max = 1000,	name = "参与奖Ⅰ"},
	{stage = 3,	index = 12,	reward = 9511,	pos_min = 1001,	pos_max = 5000,	name = "参与奖Ⅱ"},
	{stage = 3,	index = 13,	reward = 9512,	pos_min = 5001,	pos_max = 9999999,	name = "参与奖Ⅲ"},
}

return arena_reward_7v7