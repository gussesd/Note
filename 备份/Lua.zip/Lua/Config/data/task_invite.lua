-- 此文件工具自动生成，不要修改
--id	int	11	序号[l][#][sl:i]
--type	int	11	类型[l][sl:i]
--job	int	11	职业[l][sl:i]
--sex	int	11	性别(0男,1女,2通用)[l][sl:i]
--chapter	int	11	章节[l][sl:i]
--index	int	11	顺序[l][sl]
--is_show_end	int	11	[l]
--reset	char	64	重置/放弃当前任务需要回到的任务id[l][sl:v][DMH]
--name	char	16	小节名[l]
--pretask	char	128	前置任务[l][sl:v][DMH]
--tujian_npc	int	11	npc图鉴对应ID[sl:i][l]
--unlock_npcjiban	char	16	激活邀约对应的npc羁绊等级(图鉴id:羁绊等级)[l][sl:v][DMH]
--desc	char	128	描述[l]
--hint_area	char	16	执行任务区域[l]
--hint_pilot	char	256	追踪点(x:y:z:r|x:y:z:r，r半径，点为0）[l][float[][]]
--stage_event	char	1024	阶段行为配置[l][NoColor]
--npc_occupy_info	char	1024	npc占用配置[l]
--condition_info	char	128	任务进度描述[l][DMH]
--condition_special	char	64	任务完成特殊处理[l][sl:v]
--stage_special	char	64	阶段完成特殊处理[l][NTB]
--condition_list	char	1024	完成任务类型[l][sl:vv]
local task_invite =
{
	{id = 900010,	type = 17,	job = 0,	sex = 2,	chapter = 1,	index = 1,	is_show_end = 0,	reset = {900010},	name = "花树遐思",	pretask = "",	tujian_npc = 8,	unlock_npcjiban = {8,3},	desc = "宁荣荣在琉璃径的花树下徘徊，也带着许多思念……",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{2,"0#600010@6#900010"}},	npc_occupy_info = {{0,90103001,2}},	condition_info = {1,"赴约宁荣荣"},	condition_special = "0",	stage_special = {},	condition_list = {{25,83020}}},
	{id = 900015,	type = 17,	job = 0,	sex = 2,	chapter = 1,	index = 2,	is_show_end = 1,	reset = {900010},	name = "花树遐思",	pretask = {900010},	tujian_npc = 8,	unlock_npcjiban = "",	desc = "宁荣荣在琉璃径的花树下徘徊，也带着许多思念……",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{1,"14#600100$1$90103001"},{2,"2#1@8#83050"}},	npc_occupy_info = {{0,90103001,1},{0,90103001,4}},	condition_info = {1,"赴约宁荣荣"},	condition_special = "0",	stage_special = {},	condition_list = {{34,600100}}},
	{id = 900020,	type = 17,	job = 0,	sex = 2,	chapter = 2,	index = 1,	is_show_end = 0,	reset = {900020},	name = "悠闲的温泉时光",	pretask = "",	tujian_npc = 5,	unlock_npcjiban = {5,3},	desc = "戴沐白泡着温泉，享受着这难得的放松时刻……",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{2,"0#600020@6#900020"}},	npc_occupy_info = {{0,10002202,2}},	condition_info = {1,"赴约戴沐白"},	condition_special = "0",	stage_special = {},	condition_list = {{25,83021}}},
	{id = 900025,	type = 17,	job = 0,	sex = 2,	chapter = 2,	index = 2,	is_show_end = 1,	reset = {900020},	name = "悠闲的温泉时光",	pretask = {900020},	tujian_npc = 5,	unlock_npcjiban = "",	desc = "戴沐白泡着温泉，享受着这难得的放松时刻……",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{1,"14#600200$1$10002202"},{2,"2#1@8#83052"}},	npc_occupy_info = {{0,10002202,1},{0,10002202,4}},	condition_info = {1,"赴约戴沐白"},	condition_special = "0",	stage_special = {},	condition_list = {{34,600200}}},
	{id = 900030,	type = 17,	job = 0,	sex = 2,	chapter = 3,	index = 1,	is_show_end = 0,	reset = {900030},	name = "梦星湖之约",	pretask = "",	tujian_npc = 3,	unlock_npcjiban = {3,3},	desc = "小舞在梦星湖边的古榕树下荡秋千，欣赏湖光山色，特地邀请你一起同游。",	hint_area = "梦星湖粉色榕树下",	hint_pilot = {{1,3642.85,51.78,1993.25,1,1000}},	stage_event = {{2,"0#600030@6#900030"}},	npc_occupy_info = {{0,10001902,2}},	condition_info = {1,"赴约小舞"},	condition_special = "0",	stage_special = {},	condition_list = {{25,83022}}},
	{id = 900035,	type = 17,	job = 0,	sex = 2,	chapter = 3,	index = 2,	is_show_end = 1,	reset = {900030},	name = "梦星湖之约",	pretask = {900030},	tujian_npc = 3,	unlock_npcjiban = "",	desc = "小舞此刻在梦星湖下的古榕树下欣赏着湖光山色，她玩心大发，荡起了秋千……",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{1,"14#600300$1$10001902"},{2,"2#1@8#83054"}},	npc_occupy_info = {{0,10001902,1},{0,10001902,4}},	condition_info = {1,"赴约小舞"},	condition_special = "0",	stage_special = {},	condition_list = {{34,600300}}},
	{id = 900040,	type = 17,	job = 0,	sex = 2,	chapter = 4,	index = 1,	is_show_end = 0,	reset = {900040},	name = "少女的心事",	pretask = "",	tujian_npc = 6,	unlock_npcjiban = {6,3},	desc = "朱竹清愁眉不展，思绪万千。不过，这世上的烦心事，没有什么是泡个温泉解决不了的。",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{2,"0#600040@6#900040"}},	npc_occupy_info = {{0,10002302,2}},	condition_info = {1,"赴约朱竹清"},	condition_special = "0",	stage_special = {},	condition_list = {{25,83023}}},
	{id = 900045,	type = 17,	job = 0,	sex = 2,	chapter = 4,	index = 2,	is_show_end = 1,	reset = {900040},	name = "少女的心事",	pretask = {900040},	tujian_npc = 3,	unlock_npcjiban = "",	desc = "朱竹清愁眉不展，思绪万千。不过，这世上的烦心事，没有什么是泡个温泉解决不了的。",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{1,"14#600400$1$10002302"},{2,"2#1@8#83056"}},	npc_occupy_info = {{0,10002302,1},{0,10002302,4}},	condition_info = {1,"赴约朱竹清"},	condition_special = "0",	stage_special = {},	condition_list = {{34,600400}}},
	{id = 900050,	type = 17,	job = 0,	sex = 2,	chapter = 5,	index = 1,	is_show_end = 0,	reset = {900050},	name = "幻想美男",	pretask = "",	tujian_npc = 9,	unlock_npcjiban = {9,3},	desc = "马红俊在河畔散步，幻想着自己变成绝世美男的样子，不由得心神荡漾……",	hint_area = "凤栖村芦苇荡",	hint_pilot = {{1,4782.305,180.623,5095.57,0,1000}},	stage_event = {{2,"0#600050@6#900050"}},	npc_occupy_info = {{0,10002603,2}},	condition_info = {1,"赴约马红俊"},	condition_special = "0",	stage_special = {},	condition_list = {{25,83024}}},
	{id = 900055,	type = 17,	job = 0,	sex = 2,	chapter = 5,	index = 2,	is_show_end = 1,	reset = {900050},	name = "幻想美男",	pretask = {900050},	tujian_npc = 9,	unlock_npcjiban = "",	desc = "马红俊在河畔散步，幻想着自己变成绝世美男的样子，不由得心神荡漾……",	hint_area = "凤栖村芦苇荡",	hint_pilot = "",	stage_event = {{1,"14#600500$1$10002603"},{2,"2#1@8#83058"}},	npc_occupy_info = {{0,10002603,1},{0,10002603,4}},	condition_info = {1,"赴约马红俊"},	condition_special = "0",	stage_special = {},	condition_list = {{34,600500}}},
	{id = 900060,	type = 17,	job = 0,	sex = 2,	chapter = 6,	index = 1,	is_show_end = 0,	reset = {900060},	name = "奇思妙想",	pretask = "",	tujian_npc = 7,	unlock_npcjiban = {7,3},	desc = "奥斯卡在欣赏着瀑布飞流，凝望着七情问心塔，若有所思……",	hint_area = "七宝城琉璃径",	hint_pilot = "",	stage_event = {{2,"0#600060@6#900060"}},	npc_occupy_info = {{0,10002402,2},{0,10002403,2}},	condition_info = {1,"赴约奥斯卡"},	condition_special = "0",	stage_special = {},	condition_list = {{25,83025}}},
	{id = 900065,	type = 17,	job = 0,	sex = 2,	chapter = 6,	index = 2,	is_show_end = 1,	reset = {900060},	name = "史莱克的假期",	pretask = {900060},	tujian_npc = 9,	unlock_npcjiban = "",	desc = "今天是史莱克学院难得的假期，奥斯卡邀你一起共度惬意的假期时光……",	hint_area = "史莱克学院",	hint_pilot = "",	stage_event = {{1,"14#600600$1$10002402"},{2,"2#1@8#83060"}},	npc_occupy_info = {{0,10002402,1},{0,10002402,4},{0,10002403,1},{0,10002403,4}},	condition_info = {1,"赴约奥斯卡"},	condition_special = "0",	stage_special = {},	condition_list = {{34,600600}}},
}

return task_invite