-- 此文件工具自动生成，不要修改
--id	int	11	任务id[l][sl:i]
--name	char	64	任务名[l]
--cycle	int	11	任务周期(1日2周3赛季)[l][sl:i]
--type	int	11	任务类型[l][sl:i]
--param	int	11	类型参数[l][sl:i]
--progress	int	11	任务进度[l][sl:i]
--exp	int	11	战令经验[l][sl:i]
--desc	char	128	描述[l]
--way	char	32	完成途径跳转（0:npcid或1:面板id）[l]
--open	int	11	是否开启（0-开启；1关闭）[l]
local task_war_token =
{
	{id = 1,	name = "每日讨伐",	cycle = 1,	type = 1,	param = 0,	progress = 200,	exp = 200,	desc = "消耗200凝华魂液",	way = "512",	open = 0},
	{id = 2,	name = "学院任务",	cycle = 1,	type = 2,	param = 0,	progress = 4,	exp = 200,	desc = "完成4个学院任务",	way = "513",	open = 0},
	{id = 3,	name = "每日打怪",	cycle = 1,	type = 3,	param = 0,	progress = 5,	exp = 150,	desc = "击败5个精英魂兽或魂师",	way = "576",	open = 0},
	{id = 4,	name = "采集",	cycle = 1,	type = 4,	param = 0,	progress = 10,	exp = 100,	desc = "采集10个果实或草药",	way = "502",	open = 0},
	{id = 5,	name = "挖矿",	cycle = 1,	type = 5,	param = 0,	progress = 10,	exp = 100,	desc = "收集10个矿石",	way = "503",	open = 0},
	{id = 6,	name = "钓鱼",	cycle = 1,	type = 6,	param = 0,	progress = 3,	exp = 100,	desc = "钓到3条鱼",	way = "501",	open = 0},
	{id = 7,	name = "每日送礼",	cycle = 1,	type = 23,	param = 0,	progress = 1,	exp = 150,	desc = "赠送玩家角色1个礼物",	way = "19",	open = 0},
	{id = 8,	name = "每周讨伐",	cycle = 2,	type = 1,	param = 0,	progress = 1600,	exp = 500,	desc = "累计消耗1600点凝华魂液",	way = "512",	open = 0},
	{id = 9,	name = "每周打怪",	cycle = 2,	type = 3,	param = 0,	progress = 50,	exp = 250,	desc = "击败50个精英魂兽或魂师",	way = "576",	open = 0},
	{id = 10,	name = "每周悬赏",	cycle = 2,	type = 8,	param = 0,	progress = 7,	exp = 500,	desc = "完成7个区域悬赏任务",	way = "527",	open = 0},
	{id = 11,	name = "狩猎活动",	cycle = 2,	type = 9,	param = 0,	progress = 1,	exp = 500,	desc = "领取武魂殿狩猎活动奖励",	way = "2022",	open = 1},
	{id = 12,	name = "每周制作",	cycle = 2,	type = 10,	param = 0,	progress = 20,	exp = 200,	desc = "制作20个料理或丹药",	way = "505",	open = 0},
	{id = 13,	name = "每周合成",	cycle = 2,	type = 11,	param = 0,	progress = 20,	exp = 200,	desc = "合成20个炼金材料",	way = "506",	open = 0},
	{id = 14,	name = "周猎魂副本",	cycle = 2,	type = 12,	param = 0,	progress = 5,	exp = 250,	desc = "挑战5次猎魂副本",	way = "530",	open = 0},
	{id = 15,	name = "周奇遇副本",	cycle = 2,	type = 13,	param = 0,	progress = 5,	exp = 200,	desc = "挑战5次器魂封地/奇花秘境副本",	way = "533",	open = 0},
	{id = 16,	name = "周元素/天赋副本",	cycle = 2,	type = 14,	param = 0,	progress = 5,	exp = 200,	desc = "挑战5次元素/天赋副本",	way = "535",	open = 0},
	{id = 17,	name = "宗门周贡献",	cycle = 2,	type = 15,	param = 0,	progress = 5000,	exp = 200,	desc = "本周宗门贡献达到5000点",	way = "2091",	open = 0},
	{id = 18,	name = "今日在线",	cycle = 1,	type = 16,	param = 0,	progress = 30,	exp = 200,	desc = "今日在线累计达到30分钟",	way = "6",	open = 0},
	{id = 19,	name = "宗门派遣",	cycle = 1,	type = 17,	param = 0,	progress = 2,	exp = 300,	desc = "完成2次宗门派遣任务",	way = "509",	open = 0},
	{id = 20,	name = "物资收集",	cycle = 1,	type = 18,	param = 0,	progress = 1,	exp = 300,	desc = "捐献金魂币/木材/矿石等宗门物资",	way = "523",	open = 0},
	{id = 21,	name = "宗门商店",	cycle = 1,	type = 19,	param = 0,	progress = 1,	exp = 200,	desc = "在宗门商店购买任意物品",	way = "521",	open = 0},
	{id = 22,	name = "铁斗魂勋章",	cycle = 3,	type = 20,	param = 0,	progress = 1500,	exp = 250,	desc = "魂师争霸赛达到铁斗魂5阶",	way = "2094",	open = 0},
	{id = 23,	name = "铜斗魂勋章",	cycle = 3,	type = 20,	param = 0,	progress = 2000,	exp = 500,	desc = "魂师争霸赛达到铜斗魂5阶",	way = "2094",	open = 0},
	{id = 24,	name = "银斗魂勋章",	cycle = 3,	type = 20,	param = 0,	progress = 3000,	exp = 750,	desc = "魂师争霸赛达到银斗魂5阶",	way = "2094",	open = 0},
	{id = 25,	name = "祈愿20次",	cycle = 3,	type = 21,	param = 0,	progress = 20,	exp = 500,	desc = "完成20次祈愿",	way = "136",	open = 0},
	{id = 26,	name = "祈愿30次",	cycle = 3,	type = 21,	param = 0,	progress = 30,	exp = 750,	desc = "完成30次祈愿",	way = "136",	open = 0},
	{id = 27,	name = "祈愿50次",	cycle = 3,	type = 21,	param = 0,	progress = 50,	exp = 1000,	desc = "完成50次祈愿",	way = "136",	open = 0},
	{id = 28,	name = "100层海神之光",	cycle = 3,	type = 22,	param = 0,	progress = 100,	exp = 250,	desc = "穿越100层海神之光",	way = "18",	open = 1},
	{id = 29,	name = "200层海神之光",	cycle = 3,	type = 22,	param = 0,	progress = 200,	exp = 500,	desc = "穿越200层海神之光",	way = "18",	open = 1},
	{id = 30,	name = "333层海神之光",	cycle = 3,	type = 22,	param = 0,	progress = 333,	exp = 750,	desc = "穿越333层海神之光",	way = "18",	open = 1},
}

return task_war_token