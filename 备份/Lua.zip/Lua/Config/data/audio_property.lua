-- 此文件工具自动生成，不要修改
--id	int	11	id[sl:i][l]
--resource_id	int	11	audio.cfg的id[sl:i][l]
--random	int	11	随机参数（万分之一，填10000就是不随机）[sl:v][l]
local audio_property =
{
}

return audio_property