-- 此文件工具自动生成，不要修改
--id	int	11	序列(1~630)[l][sl]
--name	char	16	解锁教程名[l]
--group	int	11	组[l]
--sort	int	11	组内排序[l]
--desc	char	128	教程文字说明[l]
--picture	char	32	教程图资源[l]
--type	char	32	解锁条件类型(类型（1.到达目的地2.遇见xx敌人3.接取任务后4.完成任务后):参数1:参数2）[l]
--reward	char	32	阅读教程后获得奖励[l][sl:ct]
--show	int	11	主动展示（1触发后弹出0触发后仅提示）[l]
--video	char	32	教程视频资源[l]
local jiaocheng =
{
	{id = 1,	name = "唐门暗器手法",	group = 1,	sort = 1,	desc = "<color=#e2e7f4>点击暗器进入</color><color=#f9e064>瞄准模式</color><color=#e2e7f4>，松开按钮即可发射。唐门暗器手法各异，灵活运用可发挥暗器最大威力。</color>",	picture = "",	type = {{3,1000004}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng1"},
	{id = 2,	name = "紫极魔瞳",	group = 2,	sort = 1,	desc = "<color=#e2e7f4>单击激活「紫极魔瞳」状态，该状态生效期间可探查隐藏线索。</color>",	picture = "",	type = {{3,1000032}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng3"},
	{id = 3,	name = "飞天神爪",	group = 3,	sort = 1,	desc = "<color=#f9e064>长按飞天神爪</color><color=#e2e7f4>进入瞄准模式，准星为绿色时即可释放成功。</color>",	picture = "",	type = {{3,1000033}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng4"},
	{id = 4,	name = "势力地图",	group = 4,	sort = 1,	desc = "当前世界各区域均设立据点，可通过大地图进行查看。\n各宗门通过宣战竞价获得城战宣战权后，即可占领当前选中的据点。据点所有权每赛季将重置。\n赛季中，各宗门需花费资金维持据点占领状态（若资金不足，据点将回归无主状态，等待新一轮竞价占领）。\n当宗门持续占领据点时，帮众即可领取每日据点供奉奖励。",	picture = "",	type = {{9,4300}},	reward = {{13,1,5}},	show = 0,	video = "jiaocheng2"},
	{id = 5,	name = "城战",	group = 5,	sort = 1,	desc = "城战开启后，对战双方宗门需选择对应宗门战团加入战斗。\n在城战倒计时内，双方战场建筑剩余总生命值多者为胜。若有一方提前占领敌方哨塔，则该方立刻胜利（当双方战场内建筑剩余总生命值相同时，守方优先获胜）。\n对战时两方大本营会自动派出上中下三路攻城车和士兵，沿道路行进，并攻击路上遇到的敌方士兵、攻城车和防御塔，但玩家只能攻击敌方玩家。\n占领据点可以提升对应路径上士兵/攻城车的攻击力。",	picture = "",	type = {{16,90000}},	reward = {{13,1,5}},	show = 0,	video = "jiaocheng5"},
	{id = 6,	name = "飞天神爪—连续使用",	group = 6,	sort = 1,	desc = "<color=#e2e7f4>可利用飞天神爪在多个飞行锚点间快速移动。</color>",	picture = "",	type = {{3,1000038,1000039,1000040,1000041,1000042}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng9"},
	{id = 7,	name = "控鹤擒龙",	group = 7,	sort = 1,	desc = "<color=#e2e7f4>单击使用「控鹤擒龙」可改变场景中一些物件的位置，开启新的通路。</color>",	picture = "",	type = {{3,1000035}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng10"},
	{id = 8,	name = "打坐",	group = 8,	sort = 1,	desc = "单击场景中的角色，选择「打坐」，角色将保持「冥想」状态",	picture = "",	type = {{4,1120194}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng11"},
	{id = 9,	name = "精神之海",	group = 9,	sort = 1,	desc = "<color=#e2e7f4>角色可通过</color><color=#f9e064>打坐冥想</color><color=#e2e7f4>进入「精神之海」。</color>",	picture = "",	type = {{4,1120200}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng12"},
	{id = 10,	name = "钓鱼",	group = 10,	sort = 1,	desc = "波纹水域为「渔点」，此时若背包中持有「鱼竿」即可进行钓鱼。\n点击抛竿按钮进入等待阶段，提示鱼上钩后，长按垂钓按钮控制鱼线保持在最佳区域，钓鱼进度将随之增加。进度升满后即可收获鱼，并自动放入「鱼筐」。\n不同的鱼竿和鱼饵可以在渔点中钓出各种品类的鱼。",	picture = "",	type = {{21,1}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng13"},
	{id = 11,	name = "元素灵粹",	group = 11,	sort = 1,	desc = "「元素灵粹」分布于大陆中的各个角落，蕴含灵粹特有的元素之力。",	picture = "",	type = {{5,5000,5500,6000,6500,7000,7500,8000,8500}},	reward = {{13,1,5}},	show = 0,	video = "jiaocheng6"},
	{id = 12,	name = "时空宝石",	group = 12,	sort = 1,	desc = "散落在斗罗大陆上的元素结晶，似乎蕴含强烈的空间能量，常人无法感知到它的存在。",	picture = "",	type = {{7,1001011}},	reward = {{13,1,5}},	show = 0,	video = "jiaocheng7"},
	{id = 13,	name = "狐灵秘阵",	group = 13,	sort = 1,	desc = "斗罗大陆上隐藏着神秘的奇阵，激活「狐灵秘阵」，可在大陆中实现瞬间移动。",	picture = "",	type = {{7,1001007,1001008,1001009}},	reward = {{13,1,5}},	show = 0,	video = "jiaocheng8"},
	{id = 14,	name = "打怪奖励",	group = 14,	sort = 1,	desc = "打倒元素标识点亮状态的敌方，会掉落奖励物品，元素标识灰色表示无奖励/今日已获得奖励",	picture = "",	type = {{20,1}},	reward = {{13,1,5}},	show = 0,	video = "jiaocheng14"},
	{id = 15,	name = "弓模式",	group = 15,	sort = 1,	desc = "单击切换「弓」模式，可使用灵媒藏心弓专属技能，长按可进入瞄准状态。",	picture = "",	type = {{3,1120315,1120325}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng15"},
	{id = 16,	name = "聚灵炼魂盏",	group = 16,	sort = 1,	desc = "聚灵炼魂盏可分解魂环，将其炼化为材料。\n炼魂概率获得「魂印」，装备魂印可改变魂技的效果。",	picture = "",	type = {{4,1120075}},	reward = {{13,1,5}},	show = 1,	video = "jiaocheng16"},
	{id = 17,	name = "拍卖场",	group = 17,	sort = 1,	desc = "解锁当地的拍卖场后，可购买对应的特产。\n与其他拍卖品相同，特产可选择「竞拍」方式，竞拍时间结束后价高者得，或加价至「一口价」立即获得。",	picture = "",	type = {{4,1140300,1140301,1140302,1140303,1140304}},	reward = {{13,1,5}},	show = 0,	video = "jiaocheng17"},
}

return jiaocheng