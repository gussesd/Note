-- 此文件工具自动生成，不要修改
--id	int	11	id[l]
--title	char	16	活动标题[l]
--icon	char	16	活动图[l]
--desc	char	1024	活动内容[l]
local notice =
{
	{id = 1,	title = "公告一",	icon = "test_notice",	desc = ""},
	{id = 2,	title = "公告二",	icon = "test_notice",	desc = ""},
	{id = 3,	title = "公告三",	icon = "test_notice",	desc = ""},
	{id = 4,	title = "公告四",	icon = "test_notice",	desc = ""},
	{id = 5,	title = "公告五",	icon = "test_notice",	desc = ""},
}

return notice