-- 此文件工具自动生成，不要修改
--type	int	11	类型[sl][l]
--reward	char	16	奖励[sl:vv][l]
--param	int	11	捐献参数[sl][l]
--name	char	16	捐献分类[l]
--desc	char	128	描述[l]
--condition	int	11	是否加入宗门就可以无条件捐献(0否1是)[sl][l]
local common_reward =
{
	{type = 1,	reward = {{7,1,500},{17,1,500}},	param = 500,	name = "宗门资金",	desc = "<color=#b6c0da>宗门成员捐献</color><color=#f6e2aa>金魂币、晶华魂钻、九彩龙晶</color><color=#b6c0da>皆可提供宗门资金</color>\n<color=#b6c0da>宗门资金可用于</color><color=#f6e2aa>宗门建筑物</color><color=#b6c0da>的建造与升级。</color>",	condition = 0},
	{type = 2,	reward = {{7,1,1000},{17,1,1000},{6001,1,1}},	param = 100,	name = "宗门资金",	desc = "<color=#b6c0da>宗门成员捐献</color><color=#f6e2aa>金魂币、晶华魂钻、九彩龙晶</color><color=#b6c0da>皆可提供宗门资金</color>\n<color=#b6c0da>宗门资金可用于</color><color=#f6e2aa>宗门建筑物</color><color=#b6c0da>的建造与升级。</color>",	condition = 0},
	{type = 3,	reward = {{7,1,2000},{17,1,2000},{6001,1,2}},	param = 100,	name = "宗门资金",	desc = "<color=#b6c0da>宗门成员捐献</color><color=#f6e2aa>金魂币、晶华魂钻、九彩龙晶</color><color=#b6c0da>皆可提供宗门资金</color>\n<color=#b6c0da>宗门资金可用于</color><color=#f6e2aa>宗门建筑物</color><color=#b6c0da>的建造与升级。</color>",	condition = 1},
	{type = 4,	reward = {{7,1,600},{6010,1,1}},	param = 600,	name = "矿产",	desc = "<color=#b6c0da>使用生活技能-</color><color=#f6e2aa>挖矿</color><color=#b6c0da>可在野外获取大量矿产。</color>\n<color=#b6c0da>矿产可用于</color><color=#f6e2aa>宗门建筑物</color><color=#b6c0da>的建造与升级。</color>",	condition = 0},
	{type = 5,	reward = {{7,1,600},{6010,1,1}},	param = 600,	name = "石材",	desc = "<color=#b6c0da>使用生活技能-</color><color=#f6e2aa>挖矿</color><color=#b6c0da>可在野外获取大量石材。</color>\n<color=#b6c0da>石材可用于</color><color=#f6e2aa>宗门建筑物</color><color=#b6c0da>的建造与升级。</color>",	condition = 0},
	{type = 6,	reward = {{7,1,600},{6010,1,1}},	param = 600,	name = "木材",	desc = "<color=#b6c0da>使用生活技能-</color><color=#f6e2aa>伐木</color><color=#b6c0da>可在野外获取大量木材。</color>\n<color=#b6c0da>木材可用于</color><color=#f6e2aa>宗门建筑物</color><color=#b6c0da>的建造与升级。</color>",	condition = 0},
	{type = 7,	reward = {{3,1,2000}},	param = 200,	name = "",	desc = "今日在线",	condition = 0},
	{type = 8,	reward = {{3,1,3000}},	param = 300,	name = "",	desc = "宗门派遣",	condition = 0},
	{type = 9,	reward = {{3,1,3000}},	param = 300,	name = "",	desc = "物资收集",	condition = 0},
	{type = 10,	reward = {{3,1,2000}},	param = 200,	name = "",	desc = "商店购买",	condition = 0},
	{type = 11,	reward = {{6001,1,1}},	param = 0,	name = "",	desc = "",	condition = 0},
}

return common_reward