-- 此文件工具自动生成，不要修改
--type	int	11	类型（1.锻造2.炼制3.炼金4.烹饪5.制造6.钓鱼）[sl][l]
--level	int	11	等级[sl][l]
--exp	int	11	升到本级需要经验[sl][l]
--name	char	32	称号[l]
local life_skill =
{
	{type = 1,	level = 1,	exp = 0,	name = "初级铁匠"},
	{type = 1,	level = 2,	exp = 150,	name = "中级铁匠"},
	{type = 1,	level = 3,	exp = 300,	name = "高级铁匠"},
	{type = 1,	level = 4,	exp = 1050,	name = "铁匠师"},
	{type = 1,	level = 5,	exp = 1560,	name = "铁匠大师"},
	{type = 1,	level = 6,	exp = 2100,	name = "铁匠宗师"},
	{type = 1,	level = 7,	exp = 2700,	name = "神匠"},
	{type = 2,	level = 1,	exp = 0,	name = "初级药童"},
	{type = 2,	level = 2,	exp = 200,	name = "中级药童"},
	{type = 2,	level = 3,	exp = 600,	name = "高级药童"},
	{type = 2,	level = 4,	exp = 1200,	name = "炼药师"},
	{type = 2,	level = 5,	exp = 2000,	name = "炼药大师"},
	{type = 2,	level = 6,	exp = 3600,	name = "炼药宗师"},
	{type = 2,	level = 7,	exp = 6400,	name = "药神"},
	{type = 3,	level = 1,	exp = 0,	name = "初级工匠"},
	{type = 3,	level = 2,	exp = 100,	name = "中级工匠"},
	{type = 3,	level = 3,	exp = 300,	name = "高级工匠"},
	{type = 3,	level = 4,	exp = 600,	name = "工匠师"},
	{type = 3,	level = 5,	exp = 1000,	name = "工匠大师"},
	{type = 3,	level = 6,	exp = 1800,	name = "工匠宗师"},
	{type = 3,	level = 7,	exp = 3200,	name = "器神"},
	{type = 4,	level = 1,	exp = 0,	name = "初级厨师"},
	{type = 4,	level = 2,	exp = 200,	name = "中级厨师"},
	{type = 4,	level = 3,	exp = 600,	name = "高级厨师"},
	{type = 4,	level = 4,	exp = 1200,	name = "烹调师"},
	{type = 4,	level = 5,	exp = 2000,	name = "烹饪大师"},
	{type = 4,	level = 6,	exp = 3600,	name = "烹饪圣手"},
	{type = 4,	level = 7,	exp = 6400,	name = "食神"},
	{type = 5,	level = 1,	exp = 100,	name = ""},
	{type = 5,	level = 2,	exp = 200,	name = ""},
	{type = 5,	level = 3,	exp = 300,	name = ""},
	{type = 5,	level = 4,	exp = 400,	name = ""},
	{type = 5,	level = 5,	exp = 500,	name = ""},
	{type = 5,	level = 6,	exp = 600,	name = ""},
	{type = 5,	level = 7,	exp = 700,	name = ""},
	{type = 6,	level = 1,	exp = 100,	name = ""},
	{type = 6,	level = 2,	exp = 200,	name = ""},
	{type = 6,	level = 3,	exp = 300,	name = ""},
	{type = 6,	level = 4,	exp = 400,	name = ""},
	{type = 6,	level = 5,	exp = 500,	name = ""},
	{type = 6,	level = 6,	exp = 600,	name = ""},
	{type = 6,	level = 7,	exp = 700,	name = ""},
}

return life_skill