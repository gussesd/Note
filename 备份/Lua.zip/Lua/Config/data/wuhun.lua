-- 此文件工具自动生成，不要修改
--job	int	11	职业[l][sl]
--name	char	16	名称[l]
--model	char	16	模型[l][DMH]
--icon	char	16	图标[l]
local wuhun =
{
	{job = 1,	name = "邪眸白虎",	model = {"model_soul01_00001_01","model_soul01_00001_02","model_soul01_00001_03","model_soul01_00001_04","model_soul01_00001_05","model_soul01_00001_06"},	icon = "icon_bh"},
	{job = 2,	name = "昊天锤",	model = {"model_soul01_00002_01","model_soul01_00002_02","model_soul01_00002_03","model_soul01_00002_04","model_soul01_00002_05","model_soul01_00002_06"},	icon = "icon_ht"},
	{job = 3,	name = "幽冥灵猫",	model = {"model_soul01_00003_01","model_soul01_00003_02","model_soul01_00003_03","model_soul01_00003_04","model_soul01_00003_05","model_soul01_00003_06"},	icon = "icon_lm"},
	{job = 4,	name = "浴火凤凰",	model = {"model_soul01_00004_01","model_soul01_00004_02","model_soul01_00004_03","model_soul01_00004_04","model_soul01_00004_05","model_soul01_00004_06"},	icon = "icon_fh"},
	{job = 5,	name = "七宝琉璃塔",	model = {"model_soul01_00005_01","model_soul01_00005_02","model_sou101_00005_03","model_soul01_00005_04","model_soul01_00005_05","model_soul01_00005_06"},	icon = "icon_ll"},
}

return wuhun