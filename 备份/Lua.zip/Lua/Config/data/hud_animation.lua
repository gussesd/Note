-- 此文件工具自动生成，不要修改
--id	int	11	唯一id[l]
--name	char	256	描述[l]
--time	float	11	存在总时长[l]
--scale_action	char	256	缩放脚本(时间点:数值:时间点:数值,小数点2位)[l][FULL]
--alpha_action	char	256	透明度变化脚本(时间点:透明度:时间点:透明度,1是正常显示0是完全透明小数点2位)[l][FULL]
--height_action	char	256	高度变化脚本(时间点:数值:时间点:数值,小数点2位)[l][FULL]
--random	float	11	随机偏移距离[l]
local hud_animation =
{
	{id = 1,	name = "普通冒血",	time = 1,	scale_action = "0:0.5:1:0.1",	alpha_action = "0:1:1:0.1",	height_action = "0:0:0.5:0.5",	random = 2},
	{id = 2,	name = "暴击冒血",	time = 1.5,	scale_action = "0:0.5:1:0.3:1.5:0.1",	alpha_action = "0:1:1.5:0.1",	height_action = "0:0:0.5:0.5",	random = 3},
	{id = 3,	name = "相生冒血",	time = 1,	scale_action = "0:0.5:1:0.1",	alpha_action = "0:1:1:0.1",	height_action = "0:0:0.5:0.5",	random = 2},
}

return hud_animation