-- 此文件工具自动生成，不要修改
--id	int	11	ID[l]
--name	char	256	名称[l]
--map	int	11	归属地图[l]
--articleContrl	char	256	物件控制关联(多物件用|分隔)[l]
local cutscene_branch =
{
	{id = 1009,	name = "TimelineTest111",	map = 1001,	articleContrl = ""},
	{id = 1010,	name = "TimelineTest222",	map = 1001,	articleContrl = ""},
	{id = 1011,	name = "TimelineTest333",	map = 1001,	articleContrl = ""},
	{id = 10001,	name = "fengjing_test01",	map = 1000,	articleContrl = ""},
	{id = 20001,	name = "jg_001",	map = 3105,	articleContrl = "2001|2002|2003"},
}

return cutscene_branch