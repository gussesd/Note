-- 此文件工具自动生成，不要修改
--id	int	11	序号(按顺序1开始)[l][sl:i]
--reward	char	32	奖励[l][sl:vv]
--pos_min	int	11	名次[l][sl:i]
--pos_max	int	11	名次[l][sl:i]
--name	char	11	档位名称[l]
local arena_reward_2v2 =
{
	{id = 1,	reward = {{3,1,50000},{5501,1,20},{5567,1,20}},	pos_min = 1,	pos_max = 1,	name = "唯吾独尊"},
	{id = 2,	reward = {{3,1,45000},{5501,1,18},{5567,1,18}},	pos_min = 2,	pos_max = 2,	name = "盖世无双"},
	{id = 3,	reward = {{3,1,40000},{5501,1,16},{5567,1,16}},	pos_min = 3,	pos_max = 3,	name = "所向披靡"},
	{id = 4,	reward = {{3,1,30000},{5501,1,14},{5567,1,14}},	pos_min = 4,	pos_max = 5,	name = "威震四方"},
	{id = 5,	reward = {{3,1,20000},{5501,1,12},{5567,1,12}},	pos_min = 6,	pos_max = 10,	name = "出类拔萃"},
	{id = 6,	reward = {{3,1,10000},{5501,1,10},{5567,1,10}},	pos_min = 11,	pos_max = 20,	name = "潜力新秀"},
	{id = 7,	reward = {{3,1,5000},{5501,1,9},{5567,1,9}},	pos_min = 21,	pos_max = 50,	name = "青出于蓝"},
	{id = 8,	reward = {{3,1,4000},{5501,1,8},{5567,1,8}},	pos_min = 51,	pos_max = 100,	name = "后来居上"},
	{id = 9,	reward = {{3,1,3000},{5501,1,7},{5567,1,7}},	pos_min = 101,	pos_max = 200,	name = "披荆斩棘"},
	{id = 10,	reward = {{3,1,2000},{5501,1,6},{5567,1,6}},	pos_min = 201,	pos_max = 500,	name = "百折不挠"},
}

return arena_reward_2v2