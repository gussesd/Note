-- 此文件工具自动生成，不要修改
--season	int	11	ID[sl:i][l]
--start_date	char	16	开始日期[sl:v][l][DMH]
--end_date	char	16	结束日期[sl:v][l][DMH]
local zone_season =
{
	{season = 1,	start_date = {2023,05,01},	end_date = {2023,12,30}},
	{season = 2,	start_date = {2024,01,01},	end_date = {2024,06,10}},
}

return zone_season