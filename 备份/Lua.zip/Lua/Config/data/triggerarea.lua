-- 此文件工具自动生成，不要修改
--id	int	11	唯一[l]
--name	char	64	名称[l]
--type	int	11	类型(0.普通 1.渔场 2.光幕 3.任务 4.拉回 5.音效)[l]
--material	char	512	材质[l]
--geometryType	int	11	几何形状(1.球体  2.圆柱体  3.胶囊体  4.棱柱体)[l]
local triggerarea =
{
	{id = 1000,	name = "渔场球",	type = 1,	material = "",	geometryType = 1},
	{id = 2000,	name = "光幕球",	type = 2,	material = "",	geometryType = 1},
	{id = 2100,	name = "光幕圆柱",	type = 2,	material = "",	geometryType = 2},
	{id = 2200,	name = "光幕胶囊",	type = 2,	material = "",	geometryType = 3},
	{id = 2300,	name = "光幕棱柱",	type = 2,	material = "",	geometryType = 4},
	{id = 4000,	name = "拉回传送",	type = 4,	material = "",	geometryType = 4},
	{id = 8000,	name = "任务球",	type = 3,	material = "",	geometryType = 1},
	{id = 8100,	name = "任务圆柱",	type = 3,	material = "",	geometryType = 2},
	{id = 8200,	name = "任务棱柱",	type = 3,	material = "",	geometryType = 4},
	{id = 9001,	name = "音效圆柱",	type = 5,	material = "",	geometryType = 2},
	{id = 9002,	name = "音效胶囊",	type = 5,	material = "",	geometryType = 3},
	{id = 9003,	name = "音效棱柱",	type = 5,	material = "",	geometryType = 4},
}

return triggerarea