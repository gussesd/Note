-- 此文件工具自动生成，不要修改
--itemid	int	11	丹药物品id[l][#][sl:i]
--attr	char	256	增加属性[l][sl:v][DMH]
local danyao =
{
	{itemid = 5601,	attr = {32,1,10}},
	{itemid = 5602,	attr = {32,1,30}},
	{itemid = 5603,	attr = {32,1,60}},
	{itemid = 5604,	attr = {32,1,100}},
	{itemid = 5605,	attr = {32,1,160}},
	{itemid = 5610,	attr = {33,1,10}},
	{itemid = 5611,	attr = {33,1,30}},
	{itemid = 5612,	attr = {33,1,60}},
	{itemid = 5613,	attr = {33,1,100}},
	{itemid = 5614,	attr = {33,1,160}},
	{itemid = 5620,	attr = {34,1,10}},
	{itemid = 5621,	attr = {34,1,30}},
	{itemid = 5622,	attr = {34,1,60}},
	{itemid = 5623,	attr = {34,1,100}},
	{itemid = 5624,	attr = {34,1,160}},
	{itemid = 5630,	attr = {35,1,10}},
	{itemid = 5631,	attr = {35,1,30}},
	{itemid = 5632,	attr = {35,1,60}},
	{itemid = 5633,	attr = {35,1,100}},
	{itemid = 5634,	attr = {35,1,160}},
	{itemid = 5640,	attr = {31,1,10}},
	{itemid = 5641,	attr = {31,1,30}},
	{itemid = 5642,	attr = {31,1,60}},
	{itemid = 5643,	attr = {31,1,100}},
	{itemid = 5644,	attr = {31,1,160}},
}

return danyao