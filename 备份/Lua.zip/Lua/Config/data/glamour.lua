-- 此文件工具自动生成，不要修改
--level	int	11	魅力等级[sl:i][l]
--glamours	int	11	所需魅力[sl:i][l]
--task_id	int	11	成就任务[sl:i][l]
--name	char	16	魅力称号[l]
local glamour =
{
	{level = 1,	glamours = 200,	task_id = 0,	name = ""},
	{level = 2,	glamours = 1000,	task_id = 0,	name = ""},
	{level = 3,	glamours = 2000,	task_id = 207,	name = "崭露头角"},
	{level = 4,	glamours = 5000,	task_id = 0,	name = ""},
	{level = 5,	glamours = 8000,	task_id = 0,	name = ""},
	{level = 6,	glamours = 12000,	task_id = 208,	name = "魅力达人"},
	{level = 7,	glamours = 18000,	task_id = 0,	name = ""},
	{level = 8,	glamours = 25000,	task_id = 0,	name = ""},
	{level = 9,	glamours = 36000,	task_id = 209,	name = "时尚先锋"},
	{level = 10,	glamours = 48000,	task_id = 0,	name = ""},
	{level = 11,	glamours = 60000,	task_id = 0,	name = ""},
	{level = 12,	glamours = 72000,	task_id = 210,	name = "万人迷"},
	{level = 13,	glamours = 90000,	task_id = 0,	name = ""},
	{level = 14,	glamours = 120000,	task_id = 0,	name = ""},
	{level = 15,	glamours = 150000,	task_id = 211,	name = "风华绝代"},
}

return glamour