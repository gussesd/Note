-- 此文件工具自动生成，不要修改
--id	int	11	ID[l][sl]
--group	int	11	组(-1永久,0每周,>0赛季)[l][sl]
--group_type	int	11	组类型[l]
--type	int	11	类型[l][sl]
--index	int	11	序号(同组同类型下不重复从1递增)[l][sl]
--param	int	11	进度额外参数[l][sl]
--progress	int	11	进度[l][sl]
--max_progress	int	11	最大进度[l][sl]
--gift_way	int	11	进度领奖计算方式(0表示进度等于progress时可领奖励，gift_way>0时表示从gift_way开始进度每加progress可领奖励)[l][sl]
--gift	char	64	奖励[l][sl:ct]
--icon	char	64	图标[l]
--name	char	64	名称[l]
--desc	char	128	说明[l]
--model	char	128	模型[l]
local vit_medal =
{
	{id = 1,	group = -1,	group_type = 1,	type = 1,	index = 1,	param = 100,	progress = 1,	max_progress = 1,	gift_way = 0,	gift = {{218,1,1}},	icon = "zjcj",	name = "最坚持奖",	desc = "连续1天达成必做任务目标",	model = "show_hyd_06"},
	{id = 2,	group = -1,	group_type = 1,	type = 1,	index = 2,	param = 100,	progress = 3,	max_progress = 3,	gift_way = 0,	gift = {{218,1,1}},	icon = "zjcj",	name = "最坚持奖",	desc = "连续3天达成必做任务目标",	model = "show_hyd_06"},
	{id = 3,	group = -1,	group_type = 1,	type = 1,	index = 3,	param = 100,	progress = 5,	max_progress = 5,	gift_way = 0,	gift = {{218,1,1}},	icon = "zjcj",	name = "最坚持奖",	desc = "连续5天达成必做任务目标",	model = "show_hyd_06"},
	{id = 4,	group = -1,	group_type = 1,	type = 1,	index = 4,	param = 100,	progress = 7,	max_progress = 7,	gift_way = 0,	gift = {{218,1,1}},	icon = "zjcj",	name = "最坚持奖",	desc = "连续7天达成必做任务目标",	model = "show_hyd_06"},
	{id = 5,	group = -1,	group_type = 1,	type = 1,	index = 5,	param = 100,	progress = 10,	max_progress = 10,	gift_way = 0,	gift = {{218,1,1}},	icon = "zjcj",	name = "最坚持奖",	desc = "连续10天达成必做任务目标",	model = "show_hyd_06"},
	{id = 6,	group = -1,	group_type = 1,	type = 1,	index = 6,	param = 100,	progress = 15,	max_progress = 15,	gift_way = 0,	gift = {{218,1,1}},	icon = "zjcj",	name = "最坚持奖",	desc = "连续15天达成必做任务目标",	model = "show_hyd_06"},
	{id = 7,	group = 1,	group_type = 1,	type = 4,	index = 1,	param = 100,	progress = 6,	max_progress = 30,	gift_way = 6,	gift = {{218,1,1}},	icon = "sjtz",	name = "赛季挑战",	desc = "赛季中累计30天达成必做任务目标",	model = "show_hyd_05"},
	{id = 8,	group = 0,	group_type = 1,	type = 1,	index = 1,	param = 100,	progress = 7,	max_progress = 7,	gift_way = 0,	gift = {{218,1,1}},	icon = "wmyz_bz",	name = "完美一周(必做)",	desc = "一周内每天都达成必做任务目标",	model = "show_hyd_01"},
	{id = 9,	group = 0,	group_type = 2,	type = 2,	index = 1,	param = 100,	progress = 7,	max_progress = 7,	gift_way = 0,	gift = {{218,1,1}},	icon = "wmyz_xz",	name = "完美一周(选做)",	desc = "一周内每天都达成选做任务目标",	model = "show_hyd_02"},
	{id = 10,	group = 0,	group_type = 3,	type = 3,	index = 1,	param = 100,	progress = 7,	max_progress = 7,	gift_way = 0,	gift = {{218,1,1}},	icon = "wmyz_tz",	name = "完美一周(挑战)",	desc = "一周内每天都达成挑战任务目标",	model = "show_hyd_03"},
	{id = 13,	group = -1,	group_type = 2,	type = 4,	index = 1,	param = 100,	progress = 3,	max_progress = 30,	gift_way = 3,	gift = {{218,1,1}},	icon = "wmyz_bz",	name = "必做专家",	desc = "累计30天达成必做任务目标",	model = "show_hyd_01"},
	{id = 11,	group = -1,	group_type = 3,	type = 5,	index = 1,	param = 100,	progress = 3,	max_progress = 30,	gift_way = 3,	gift = {{218,1,1}},	icon = "wmyz_xz",	name = "选做专家",	desc = "累计30天达成选做任务目标",	model = "show_hyd_02"},
	{id = 12,	group = -1,	group_type = 4,	type = 6,	index = 1,	param = 100,	progress = 3,	max_progress = 30,	gift_way = 3,	gift = {{218,1,1}},	icon = "wmyz_tz",	name = "挑战专家",	desc = "累计30天达成挑战任务目标",	model = "show_hyd_03"},
}

return vit_medal