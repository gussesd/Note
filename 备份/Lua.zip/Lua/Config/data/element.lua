-- 此文件工具自动生成，不要修改
--id	int	11	id[l]
--name	char	16	名字[l]
local element =
{
	{id = 1,	name = "风元素"},
	{id = 2,	name = "雷元素"},
	{id = 3,	name = "毒元素"},
	{id = 4,	name = "水元素"},
	{id = 5,	name = "火元素"},
	{id = 6,	name = "土元素"},
	{id = 7,	name = "圣元素"},
	{id = 8,	name = "暗元素"},
	{id = 9,	name = "飞天神爪"},
	{id = 10,	name = "龙须针"},
	{id = 11,	name = "诸葛神弩"},
	{id = 12,	name = "蝠翼轮回"},
	{id = 13,	name = "凤引九雏"},
}

return element