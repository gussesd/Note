-- 此文件工具自动生成，不要修改
--id	int	11	索引[l]
--map_zoom	int	11	实际地图与ui显示比例[l]
--max_ui_zoom	float	11	最大ui缩放值[l]
--min_ui_zoom	float	11	最小ui缩放值[l]
--pixel_number	int	11	像素数量[l]
--pixel_size	char	64	当个像素大小[l][DMH]
--global_size	char	64	真实场景尺寸大小[l][DMH]
--pixel_all_size	char	64	地图资源尺寸大小[l][DMH]
--offset	char	64	场景坐标与视图原点坐标偏差[l][DMH]
--res_path	char	128	资源路径[l]
local map_sprite =
{
	{id = 100101,	map_zoom = 2,	max_ui_zoom = 2,	min_ui_zoom = 0.2,	pixel_number = 256,	pixel_size = {1024,1024},	global_size = {8192,8192},	pixel_all_size = {16384,16384},	offset = {0,0},	res_path = "scene_bigworld"},
}

return map_sprite