-- 此文件工具自动生成，不要修改
--id	int	11	福利id[sl:i][l]
--type	int	11	福利类型[sl:i][l]
--name	char	64	福利名称[l]
--condition	char	256	福利具体条件(id:type(1值，2百分比):value 例如1:1:2)[sl:vv][l]
--level	char	64	福利对应赞助等级（赞助等级:是否新福利:是否升级:是否为热福利）[sl:v][d][l]
--title	char	64	标题[l]
--show_num	char	64	显示数值[l]
--show_icon	char	64	显示图标[l]
--little_title	char	64	小标题[l]
--describe	char	64	描述[l][FULL]
local zanzhu_tequan =
{
	{id = 1,	type = 1,	name = "玄天功经脉修炼提升<color=#F9ED64>{0}%</color>成功率",	condition = {{1,2,5}},	level = {2,1,0,0},	title = "经脉修炼",	show_num = "{0}%↑",	show_icon = "",	little_title = "成功率",	describe = "赞助福利:提升玄天功经脉修炼成功率"},
	{id = 2,	type = 1,	name = "玄天功经脉修炼提升<color=#F9ED64>{0}%</color>成功率",	condition = {{2,2,8}},	level = {4,0,1,0},	title = "经脉修炼",	show_num = "{0}%↑",	show_icon = "",	little_title = "成功率",	describe = "赞助福利:提升玄天功经脉修炼成功率"},
	{id = 3,	type = 1,	name = "玄天功经脉修炼提升<color=#F9ED64>{0}%</color>成功率",	condition = {{3,2,10}},	level = {6,0,1,0},	title = "经脉修炼",	show_num = "{0}%↑",	show_icon = "",	little_title = "成功率",	describe = "赞助福利:提升玄天功经脉修炼成功率"},
	{id = 4,	type = 2,	name = "挖矿特技-魂力爆破",	condition = {{4,1,16}},	level = {1,0,0,1},	title = "特技",	show_num = "挖矿特技",	show_icon = "",	little_title = "特技解锁",	describe = "赞助福利:解锁挖矿特技-魂力爆破"},
	{id = 5,	type = 3,	name = "[炼能星砂]存储数量从<color=#F9ED64>{0}</color>提升至<color=#F9ED64>{1}</color>",	condition = {{5,1,6},{5,1,12}},	level = {1,0,0,0},	title = "存储数量",	show_num = "{0}",	show_icon = "",	little_title = "存储量",	describe = "赞助福利:提升[炼能星砂]存储数量"},
	{id = 6,	type = 4,	name = "开启宝箱时必定获得<color=#F9ED64>{0}</color>个随机buff并额外获得<color=#F9ED64>{1}%</color>铜魂币",	condition = {{6,1,1},{6,2,10},{901,902,903,906,907,908,941,942,943},{120000,120000,120000,180000,180000,180000,300000,300000,300000}},	level = {1,0,0,1},	title = "宝箱奖励",	show_num = "{0}%",	show_icon = "",	little_title = "额外获得",	describe = "赞助福利:开启宝箱时必定获得个随机BUFF并额外获得铜魂币"},
	{id = 7,	type = 5,	name = "击败怪物后掉落图录的概率提升为<color=#F9ED64>{0}%</color>",	condition = {{7,2,125}},	level = {1,0,0,0},	title = "图录掉落",	show_num = "{0}%",	show_icon = "",	little_title = "概率提升至",	describe = "赞助福利:提升击败怪物后掉落图录的概率"},
	{id = 8,	type = 6,	name = "锻造时灵锻概率增加<color=#F9ED64>{0}%</color>",	condition = {{8,2,5}},	level = {1,0,0,0},	title = "锻造灵锻装备",	show_num = "{0}%",	show_icon = "",	little_title = "增加概率",	describe = "赞助福利:锻造时提升灵锻概率"},
	{id = 9,	type = 7,	name = "烹饪时有<color=#F9ED64>{0}%</color>概率额外获得一个料理",	condition = {{9,2,10}},	level = {1,0,0,0},	title = "烹饪获得",	show_num = "{0}%",	show_icon = "",	little_title = "额外获得",	describe = "赞助福利:烹饪时有概率额外获得一个料理"},
	{id = 10,	type = 8,	name = "升级魂环有<color=#F9ED64>{0}%</color>概率暴击获双倍年限提升",	condition = {{10,2,10}},	level = {2,1,0,0},	title = "暴击提升双倍年限",	show_num = "{0}%",	show_icon = "",	little_title = "暴击概率",	describe = "赞助福利:升级魂环有概率暴击获双倍年限提升"},
	{id = 11,	type = 9,	name = "挑战副本可选择<color=#F9ED64>{0}</color>倍消耗领取<color=#F9ED64>{1}</color>倍奖励",	condition = {{11,1,2},{11,1,2}},	level = {2,1,0,0},	title = "副本挑战",	show_num = "{0}倍",	show_icon = "",	little_title = "奖励倍数",	describe = "赞助福利:挑战副本可选择多倍消耗领取多倍奖励"},
	{id = 12,	type = 9,	name = "挑战副本可选择<color=#F9ED64>{0}</color>倍消耗领取<color=#F9ED64>{1}</color>倍奖励",	condition = {{12,1,3},{12,1,3}},	level = {4,0,1,0},	title = "副本挑战",	show_num = "{0}倍",	show_icon = "",	little_title = "奖励倍数",	describe = "赞助福利:挑战副本可选择多倍消耗领取多倍奖励"},
	{id = 13,	type = 9,	name = "挑战副本可选择<color=#F9ED64>{0}</color>倍消耗领取<color=#F9ED64>{1}</color>倍奖励",	condition = {{13,1,4},{13,1,4}},	level = {6,0,1,0},	title = "副本挑战",	show_num = "{0}倍",	show_icon = "",	little_title = "奖励倍数",	describe = "赞助福利:挑战副本可选择多倍消耗领取多倍奖励"},
	{id = 14,	type = 10,	name = "采集时获得混沌魂果概率提升为<color=#F9ED64>{0}%</color>",	condition = {{14,2,125}},	level = {2,1,0,0},	title = "采集获得",	show_num = "{0}%",	show_icon = "",	little_title = "混沌魂果",	describe = "赞助福利:提升采集时获得混沌魂果概率"},
	{id = 15,	type = 10,	name = "采集时获得混沌魂果概率提升为<color=#F9ED64>{0}%</color>",	condition = {{15,2,150}},	level = {4,0,1,0},	title = "采集获得",	show_num = "{0}%",	show_icon = "",	little_title = "混沌魂果",	describe = "赞助福利:提升采集时获得混沌魂果概率"},
	{id = 16,	type = 10,	name = "采集时获得混沌魂果概率提升为<color=#F9ED64>{0}%</color>",	condition = {{16,2,200}},	level = {6,0,1,0},	title = "采集获得",	show_num = "{0}%",	show_icon = "",	little_title = "混沌魂果",	describe = "赞助福利:提升采集时获得混沌魂果概率"},
	{id = 17,	type = 11,	name = "采矿时获得觉醒魂玉概率提升为<color=#F9ED64>{0}%</color>",	condition = {{17,2,125}},	level = {2,1,0,0},	title = "采集获得",	show_num = "{0}%",	show_icon = "",	little_title = "觉醒魂玉",	describe = "赞助福利:提升采矿时获得觉醒魂玉概率"},
	{id = 18,	type = 11,	name = "采矿时获得觉醒魂玉概率提升为<color=#F9ED64>{0}%</color>",	condition = {{18,2,150}},	level = {4,0,1,0},	title = "采集获得",	show_num = "{0}%",	show_icon = "",	little_title = "觉醒魂玉",	describe = "赞助福利:提升采矿时获得觉醒魂玉概率"},
	{id = 19,	type = 11,	name = "采矿时获得觉醒魂玉概率提升为<color=#F9ED64>{0}%</color>",	condition = {{19,2,200}},	level = {6,0,1,0},	title = "采集获得",	show_num = "{0}%",	show_icon = "",	little_title = "觉醒魂玉",	describe = "赞助福利:提升采矿时获得觉醒魂玉概率"},
	{id = 20,	type = 12,	name = "获得元宝精灵-会自动吸取掉落物品",	condition = "",	level = {2,0,0,1},	title = "特技",	show_num = "拾取特技",	show_icon = "",	little_title = "特技解锁",	describe = "赞助福利:解锁拾取特技-掉落物品自动吸取(批量拾取)"},
	{id = 21,	type = 13,	name = "每日首次学院任务获<color=#F9ED64>{0}</color>倍奖励",	condition = {{21,1,2}},	level = {3,1,0,0},	title = "学院任务",	show_num = "{0}倍",	show_icon = "",	little_title = "多倍奖励",	describe = "赞助福利:每日首次学院任务获倍奖励"},
	{id = 22,	type = 14,	name = "每日首次天赋/元素副本获额外<color=#F9ED64>{0}</color>次奖励",	condition = {{22,1,1}},	level = {4,1,0,0},	title = "副本获取",	show_num = "{0}次",	show_icon = "",	little_title = "多倍奖励",	describe = "赞助福利:每日首次天赋/元素副本获额外次奖励"},
	{id = 23,	type = 15,	name = "每日首次奇遇副本获额外<color=#F9ED64>{0}</color>次奖励",	condition = {{23,1,1}},	level = {5,1,0,0},	title = "副本获取",	show_num = "{0}次",	show_icon = "",	little_title = "多倍奖励",	describe = "赞助福利:每日首次奇遇副本获额外次奖励"},
	{id = 24,	type = 16,	name = "每日首次主线猎魂副本获额外<color=#F9ED64>{0}</color>次奖励",	condition = {{24,1,1}},	level = {6,1,0,0},	title = "副本获取",	show_num = "{0}次",	show_icon = "",	little_title = "多倍奖励",	describe = "赞助福利:每日首次主线猎魂副本获额外次奖励"},
	{id = 25,	type = 17,	name = "永久增加<color=#F9ED64>{0}</color>个伙伴派遣队列",	condition = {{25,1,1}},	level = {3,1,0,0},	title = "伙伴队列",	show_num = "+{0}",	show_icon = "",	little_title = "派遣队列",	describe = "赞助福利:永久增加伙伴派遣队列"},
	{id = 26,	type = 17,	name = "永久增加<color=#F9ED64>{0}</color>个伙伴派遣队列",	condition = {{26,1,2}},	level = {5,0,1,0},	title = "伙伴队列",	show_num = "+{0}",	show_icon = "",	little_title = "派遣队列",	describe = "赞助福利:永久增加伙伴派遣队列"},
	{id = 27,	type = 18,	name = "解锁<color=#F9ED64>中级</color>拟态修炼",	condition = {{27,1,2}},	level = {3,1,0,0},	title = "修炼模式",	show_num = "",	show_icon = "nitai_zhong",	little_title = "模式解锁",	describe = "赞助福利:解锁更高级的拟态修炼模式"},
	{id = 28,	type = 18,	name = "解锁<color=#F9ED64>高级</color>拟态修炼",	condition = {{28,1,3}},	level = {5,1,0,0},	title = "修炼模式",	show_num = "",	show_icon = "nitai_gao",	little_title = "模式解锁",	describe = "赞助福利:解锁更高级的拟态修炼模式"},
	{id = 29,	type = 19,	name = "锻造装备时出现孔装概率提升<color=#F9ED64>{0}%</color>",	condition = {{29,2,5}},	level = {3,1,0,0},	title = "孔装锻造",	show_num = "{0}%↑",	show_icon = "",	little_title = "孔装概率",	describe = "赞助福利:提升锻造装备时出现孔装概率"},
	{id = 30,	type = 19,	name = "锻造装备时出现孔装概率提升<color=#F9ED64>{0}%</color>",	condition = {{30,2,10}},	level = {5,0,1,0},	title = "孔装锻造",	show_num = "{0}%↑",	show_icon = "",	little_title = "孔装概率",	describe = "赞助福利:提升锻造装备时出现孔装概率"},
	{id = 31,	type = 20,	name = "分解装备时获得升星石提升至<color=#F9ED64>{0}%</color>",	condition = {{31,2,120}},	level = {3,1,0,0},	title = "分解获得",	show_num = "{0}%",	show_icon = "",	little_title = "获得数量",	describe = "赞助福利:提升分解装备时获得升星石的数量"},
	{id = 32,	type = 21,	name = "拍卖场手续费享受<color=#F9ED64>{0}</color>折优惠",	condition = {{32,1,9}},	level = {3,1,0,0},	title = "拍卖手续费",	show_num = "{0}折",	show_icon = "",	little_title = "手续费",	describe = "赞助福利:拍卖场手续费享受折优惠"},
	{id = 33,	type = 21,	name = "拍卖场手续费享受<color=#F9ED64>{0}</color>折优惠",	condition = {{33,1,8}},	level = {4,0,1,0},	title = "拍卖手续费",	show_num = "{0}折",	show_icon = "",	little_title = "手续费",	describe = "赞助福利:拍卖场手续费享受折优惠"},
	{id = 34,	type = 21,	name = "拍卖场手续费享受<color=#F9ED64>{0}</color>折优惠",	condition = {{34,1,7}},	level = {5,0,1,0},	title = "拍卖手续费",	show_num = "{0}折",	show_icon = "",	little_title = "手续费",	describe = "赞助福利:拍卖场手续费享受折优惠"},
	{id = 35,	type = 21,	name = "拍卖场手续费享受<color=#F9ED64>{0}</color>折优惠",	condition = {{35,1,5}},	level = {6,0,1,0},	title = "拍卖手续费",	show_num = "{0}折",	show_icon = "",	little_title = "手续费",	describe = "赞助福利:拍卖场手续费享受折优惠"},
	{id = 36,	type = 22,	name = "钓鱼获得高级鱼类的概率提升至<color=#F9ED64>{0}%</color>",	condition = {{36,2,130}},	level = {5,1,0,0},	title = "钓鱼获取",	show_num = "{0}%",	show_icon = "",	little_title = "高级鱼类率",	describe = "赞助福利:提升钓鱼获得高级鱼类的概率"},
	{id = 37,	type = 23,	name = "炼金时有<color=#F9ED64>{0}%</color>概率返还部分材料",	condition = {{37,2,20}},	level = {2,1,0,0},	title = "炼金返还",	show_num = "{0}%",	show_icon = "",	little_title = "返还材料率",	describe = "赞助福利:炼金时有概率返还部分材料"},
	{id = 38,	type = 24,	name = "每日可额外购买<color=#F9ED64>{0}</color>次凝华魂液",	condition = {{38,1,4}},	level = {4,1,0,0},	title = "凝华魂液购买",	show_num = "{0}次",	show_icon = "",	little_title = "额外购买",	describe = "赞助福利:每日可额外购买凝华魂液"},
	{id = 39,	type = 24,	name = "每日可额外购买<color=#F9ED64>{0}</color>次凝华魂液",	condition = {{39,1,8}},	level = {5,0,1,0},	title = "凝华魂液购买",	show_num = "{0}次",	show_icon = "",	little_title = "额外购买",	describe = "赞助福利:每日可额外购买凝华魂液"},
	{id = 40,	type = 24,	name = "每日可额外购买<color=#F9ED64>{0}</color>次凝华魂液",	condition = {{40,1,12}},	level = {6,0,1,0},	title = "凝华魂液购买",	show_num = "{0}次",	show_icon = "",	little_title = "额外购买",	describe = "赞助福利:每日可额外购买凝华魂液"},
}

return zanzhu_tequan