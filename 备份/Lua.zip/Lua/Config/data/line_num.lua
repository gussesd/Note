-- 此文件工具自动生成，不要修改
--world_level	int	11	世界等级[l][sl]
--level	int	11	难度[l][sl]
--num	int	11	线路数量[l][sl]
local line_num =
{
	{world_level = 1,	level = 1,	num = 3},
	{world_level = 1,	level = 2,	num = 2},
	{world_level = 30,	level = 1,	num = 2},
	{world_level = 30,	level = 2,	num = 3},
}

return line_num