-- 此文件工具自动生成，不要修改
--branch	int	11	分支(1-玄天宝录,2-暗器百解,3-天材地宝)[sl:i][l]
--page	int	11	分页(1-15)[sl:i][l]
--name	char	64	分页名称[l]
--unlock	int	11	解锁下一页需已激活当前页天赋点数量[sl:i][l]
--reset	char	64	重置当前页消耗道具数量(id:type:count)[sl:ct][l][DMH]
--icon	char	16	道具图标[l]
local tianfu =
{
	{branch = 1,	page = 1,	name = "玄天心法Ⅰ",	unlock = 10,	reset = {234,1,3},	icon = "1-1"},
	{branch = 1,	page = 2,	name = "玄玉手Ⅰ",	unlock = 20,	reset = {234,1,3},	icon = "1-2"},
	{branch = 1,	page = 3,	name = "控鹤擒龙Ⅰ",	unlock = 30,	reset = {234,1,3},	icon = "1-3"},
	{branch = 1,	page = 4,	name = "鬼影迷踪Ⅰ",	unlock = 40,	reset = {234,1,3},	icon = "1-4"},
	{branch = 1,	page = 5,	name = "紫极魔瞳Ⅰ",	unlock = 50,	reset = {234,1,3},	icon = "1-5"},
	{branch = 1,	page = 6,	name = "玄天心法Ⅱ",	unlock = 60,	reset = {234,1,3},	icon = "1-6"},
	{branch = 1,	page = 7,	name = "玄玉手Ⅱ",	unlock = 70,	reset = {234,1,3},	icon = "1-7"},
	{branch = 1,	page = 8,	name = "控鹤擒龙Ⅱ",	unlock = 80,	reset = {234,1,3},	icon = "1-8"},
	{branch = 1,	page = 9,	name = "鬼影迷踪Ⅱ",	unlock = 90,	reset = {234,1,3},	icon = "1-9"},
	{branch = 1,	page = 10,	name = "紫极魔瞳Ⅱ",	unlock = 100,	reset = {234,1,3},	icon = "1-10"},
	{branch = 1,	page = 11,	name = "玄天心法Ⅲ",	unlock = 110,	reset = {234,1,3},	icon = "1-11"},
	{branch = 1,	page = 12,	name = "玄玉手Ⅲ",	unlock = 120,	reset = {234,1,3},	icon = "1-12"},
	{branch = 1,	page = 13,	name = "控鹤擒龙Ⅲ",	unlock = 130,	reset = {234,1,3},	icon = "1-13"},
	{branch = 1,	page = 14,	name = "鬼影迷踪Ⅲ",	unlock = 140,	reset = {234,1,3},	icon = "1-14"},
	{branch = 1,	page = 15,	name = "紫极魔瞳Ⅲ",	unlock = 0,	reset = {234,1,3},	icon = "1-15"},
	{branch = 2,	page = 1,	name = "无声袖箭",	unlock = 10,	reset = {234,1,3},	icon = "2-1"},
	{branch = 2,	page = 2,	name = "飞天神爪",	unlock = 20,	reset = {234,1,3},	icon = "2-2"},
	{branch = 2,	page = 3,	name = "靴间飞刃",	unlock = 30,	reset = {234,1,3},	icon = "2-3"},
	{branch = 2,	page = 4,	name = "龙须针",	unlock = 40,	reset = {234,1,3},	icon = "2-4"},
	{branch = 2,	page = 5,	name = "蝠翼轮回",	unlock = 50,	reset = {234,1,3},	icon = "2-5"},
	{branch = 2,	page = 6,	name = "追魂夺命胆",	unlock = 60,	reset = {234,1,3},	icon = "2-6"},
	{branch = 2,	page = 7,	name = "诸葛神弩",	unlock = 70,	reset = {234,1,3},	icon = "2-7"},
	{branch = 2,	page = 8,	name = "含沙射影",	unlock = 80,	reset = {234,1,3},	icon = "2-8"},
	{branch = 2,	page = 9,	name = "凤引九雏",	unlock = 90,	reset = {234,1,3},	icon = "2-9"},
	{branch = 2,	page = 10,	name = "孔雀翎",	unlock = 100,	reset = {234,1,3},	icon = "2-10"},
	{branch = 2,	page = 11,	name = "阎王帖",	unlock = 110,	reset = {234,1,3},	icon = "2-11"},
	{branch = 2,	page = 12,	name = "暴雨梨花针",	unlock = 120,	reset = {234,1,3},	icon = "2-12"},
	{branch = 2,	page = 13,	name = "菩提血",	unlock = 130,	reset = {234,1,3},	icon = "2-13"},
	{branch = 2,	page = 14,	name = "佛怒唐莲",	unlock = 140,	reset = {234,1,3},	icon = "2-14"},
	{branch = 2,	page = 15,	name = "观音泪",	unlock = 0,	reset = {234,1,3},	icon = "2-15"},
	{branch = 3,	page = 1,	name = "雪蚕",	unlock = 10,	reset = {234,1,3},	icon = "3-1"},
	{branch = 3,	page = 2,	name = "朱砂莲",	unlock = 20,	reset = {234,1,3},	icon = "3-2"},
	{branch = 3,	page = 3,	name = "奇茸通天菊",	unlock = 30,	reset = {234,1,3},	icon = "3-3"},
	{branch = 3,	page = 4,	name = "九品紫芝",	unlock = 40,	reset = {234,1,3},	icon = "3-7"},
	{branch = 3,	page = 5,	name = "水仙玉肌骨",	unlock = 50,	reset = {234,1,3},	icon = "3-5"},
	{branch = 3,	page = 6,	name = "鸡冠凤凰葵",	unlock = 60,	reset = {234,1,3},	icon = "3-6"},
	{branch = 3,	page = 7,	name = "水晶血龙参",	unlock = 70,	reset = {234,1,3},	icon = "3-4"},
	{branch = 3,	page = 8,	name = "绮罗郁金香",	unlock = 80,	reset = {234,1,3},	icon = "3-8"},
	{branch = 3,	page = 9,	name = "八瓣仙兰",	unlock = 90,	reset = {234,1,3},	icon = "3-9"},
	{branch = 3,	page = 10,	name = "万年九品参王",	unlock = 100,	reset = {234,1,3},	icon = "3-10"},
	{branch = 3,	page = 11,	name = "幽香绮罗仙品",	unlock = 110,	reset = {234,1,3},	icon = "3-11"},
	{branch = 3,	page = 12,	name = "相思断肠红",	unlock = 120,	reset = {234,1,3},	icon = "3-12"},
	{branch = 3,	page = 13,	name = "八角玄冰草",	unlock = 130,	reset = {234,1,3},	icon = "3-13"},
	{branch = 3,	page = 14,	name = "烈火杏娇疏",	unlock = 140,	reset = {234,1,3},	icon = "3-14"},
	{branch = 3,	page = 15,	name = "圣魂草",	unlock = 0,	reset = {234,1,3},	icon = "3-15"},
}

return tianfu