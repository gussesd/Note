-- 此文件工具自动生成，不要修改
--id	int	11	唯一[l]
--mapid	int	11	地图id[l]
--type	int	11	区域类型[l]
--points	char	512	区域点集[l]
--miny	float	11	最小y[l]
--maxy	float	11	最大y[l]
--radius	float	11	区域半径[l]
--selfTag	char	128	自身标签[l]
--triggerTags	char	128	触发Tag标记[l][DMH]
--luas	char	128	lua事件名称[l][DMH]
--decoration	char	128	区域特效[l][DMH](decorationId:位置)
local scenearea =
{
	{id = 1000,	mapid = 1000,	type = 1,	points = {{-4000,-4000},{-4000,4000},{4000,4000},{4000,-4000}},	miny = -100,	maxy = 0,	radius = 0,	selfTag = "water",	triggerTags = {"Hero","Npc"},	luas = {"SceneAreaAction"},	decoration = ""},
	{id = 1001,	mapid = 1000,	type = 1,	points = {{-10,-10},{-10,10},{10,10},{10,-10}},	miny = 0,	maxy = 10,	radius = 0,	selfTag = "water",	triggerTags = {"Hdero","Npc"},	luas = {"SceneAreaAction"},	decoration = ""},
	{id = 1003,	mapid = 1000,	type = 1,	points = {{-10,-9.999939},{-10,6.317688},{-43.27661,26.4505},{10.00024,1.786316},{10.00024,-26.85779}},	miny = 0,	maxy = 80,	radius = 0,	selfTag = "1",	triggerTags = {"Hero"},	luas = {321321},	decoration = ""},
	{id = 1004,	mapid = 1000,	type = 1,	points = {{-10,-9.999939},{-10,6.317688},{-43.27661,26.4505},{10.00024,1.786316},{10.00024,-26.85779}},	miny = 0,	maxy = 80,	radius = 0,	selfTag = "1",	triggerTags = {"Hero"},	luas = "",	decoration = ""},
	{id = 1005,	mapid = 1000,	type = 1,	points = {{5073.315,2010.901},{4368.685,2010.901},{4368.685,1283.099},{5073.315,1283.099}},	miny = 512,	maxy = 553.2,	radius = 0,	selfTag = "water",	triggerTags = {"Hero"},	luas = {"SceneAreaAction"},	decoration = ""},
	{id = 1006,	mapid = 10010,	type = 1,	points = {{-29.22671,-46.94019},{-22.48146,-53.68544},{-25.29913,-56.50311},{-32.04438,-49.75787}},	miny = 106.5,	maxy = 107.8081,	radius = 0,	selfTag = "water",	triggerTags = {"Hero","Player"},	luas = {"SceneAreaAction"},	decoration = ""},
	{id = 1007,	mapid = 1000,	type = 2,	points = {{2500,2500}},	miny = 10,	maxy = 30,	radius = 50,	selfTag = "water",	triggerTags = {"Hdero","Npc"},	luas = {"SceneAreaAction"},	decoration = ""},
	{id = 1008,	mapid = 1000,	type = 3,	points = {{3000,3000}},	miny = 10,	maxy = 30,	radius = 30,	selfTag = "water",	triggerTags = {"Hdero","Npc"},	luas = {"SceneAreaAction"},	decoration = ""},
	{id = 80001,	mapid = 1000,	type = 2,	points = {{3370,1827}},	miny = 20,	maxy = 70,	radius = 10,	selfTag = "pescar",	triggerTags = {"Hero"},	luas = {"SceneAreaAction"},	decoration = {10060201,3371,40.1,1831}},
	{id = 80003,	mapid = 1000,	type = 2,	points = {{3885.39,4647.7}},	miny = 80,	maxy = 130,	radius = 10,	selfTag = "pescar",	triggerTags = {"Hero"},	luas = {"SceneAreaAction"},	decoration = {10060201,3885.39,98.3,4646.2}},
	{id = 80201,	mapid = 1000,	type = 2,	points = {{5381,6558}},	miny = 300,	maxy = 350,	radius = 10,	selfTag = "pescar",	triggerTags = {"Hero"},	luas = {"SceneAreaAction"},	decoration = {10060201,5381,329.7,6558}},
}

return scenearea