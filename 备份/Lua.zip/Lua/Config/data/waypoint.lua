-- 此文件工具自动生成，不要修改
--id	int	11	路点组id[l][sl]
--points	char	512	起始坐标[l][Vector3[]]
--type	int	11	循环形式，0为单向不循环，1为首尾结点循环，2为反向循环[l]
local waypoint =
{
}

return waypoint