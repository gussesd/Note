-- 此文件工具自动生成，不要修改
--id	int	11	map_scenearea对应id[l][sl]
--task_index	char	64	光幕解锁任务index（1.单条为完成后永久解锁；2.两条为区间关闭光幕）[l][DMH]
--isTrggerEffect	int	11	是否触发碰撞波纹特效[l]
local map_triggerarea_lightcurtain =
{
	{id = 100,	task_index = {1070,1120},	isTrggerEffect = 1},
	{id = 101,	task_index = "",	isTrggerEffect = 1},
	{id = 102,	task_index = "",	isTrggerEffect = 1},
	{id = 103,	task_index = "",	isTrggerEffect = 1},
	{id = 900,	task_index = "",	isTrggerEffect = 0},
	{id = 901,	task_index = "",	isTrggerEffect = 0},
	{id = 903,	task_index = "",	isTrggerEffect = 0},
	{id = 1000,	task_index = "",	isTrggerEffect = 0},
	{id = 83082,	task_index = {1060},	isTrggerEffect = 1},
	{id = 83634,	task_index = {5660},	isTrggerEffect = 1},
	{id = 84122,	task_index = "",	isTrggerEffect = 1},
	{id = 84350,	task_index = "",	isTrggerEffect = 1},
	{id = 84351,	task_index = "",	isTrggerEffect = 1},
	{id = 84352,	task_index = "",	isTrggerEffect = 1},
	{id = 84353,	task_index = "",	isTrggerEffect = 1},
	{id = 84354,	task_index = "",	isTrggerEffect = 1},
	{id = 84355,	task_index = "",	isTrggerEffect = 1},
	{id = 84356,	task_index = "",	isTrggerEffect = 1},
	{id = 84357,	task_index = "",	isTrggerEffect = 1},
	{id = 84383,	task_index = "",	isTrggerEffect = 1},
	{id = 84384,	task_index = "",	isTrggerEffect = 1},
	{id = 85149,	task_index = "",	isTrggerEffect = 0},
	{id = 85501,	task_index = "",	isTrggerEffect = 1},
	{id = 185407,	task_index = "",	isTrggerEffect = 0},
	{id = 185416,	task_index = "",	isTrggerEffect = 0},
	{id = 185418,	task_index = "",	isTrggerEffect = 0},
	{id = 185421,	task_index = "",	isTrggerEffect = 0},
	{id = 185424,	task_index = "",	isTrggerEffect = 0},
	{id = 185425,	task_index = "",	isTrggerEffect = 0},
	{id = 185426,	task_index = "",	isTrggerEffect = 0},
}

return map_triggerarea_lightcurtain