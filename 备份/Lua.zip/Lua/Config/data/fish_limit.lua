-- 此文件工具自动生成，不要修改
--index	int	11	索引[sl][l]
--item_id	int	11	鱼id[sl][l]
--num	int	11	每日条数[sl][l]
--type	char	32	使用对应鱼饵可不受限制[sl:v][l]
local fish_limit =
{
	{index = 1,	item_id = 2801,	num = 5,	type = "4"},
	{index = 2,	item_id = 2802,	num = 5,	type = "4"},
	{index = 3,	item_id = 2803,	num = 5,	type = "4"},
	{index = 4,	item_id = 2805,	num = 5,	type = "4"},
	{index = 5,	item_id = 2806,	num = 5,	type = "14"},
	{index = 6,	item_id = 2807,	num = 5,	type = "14"},
	{index = 7,	item_id = 2804,	num = 5,	type = "14"},
	{index = 8,	item_id = 2808,	num = 5,	type = "14"},
	{index = 9,	item_id = 2810,	num = 4,	type = "24"},
	{index = 10,	item_id = 2813,	num = 4,	type = "24"},
	{index = 11,	item_id = 2811,	num = 4,	type = "24"},
	{index = 12,	item_id = 2812,	num = 4,	type = "24"},
	{index = 13,	item_id = 2809,	num = 4,	type = "24"},
	{index = 14,	item_id = 2815,	num = 4,	type = "34"},
	{index = 15,	item_id = 2814,	num = 4,	type = "34"},
	{index = 16,	item_id = 2818,	num = 3,	type = "44"},
	{index = 17,	item_id = 2819,	num = 3,	type = "44"},
	{index = 18,	item_id = 2817,	num = 3,	type = "54"},
	{index = 19,	item_id = 2816,	num = 3,	type = "54"},
}

return fish_limit