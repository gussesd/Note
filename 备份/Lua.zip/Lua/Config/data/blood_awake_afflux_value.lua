-- 此文件工具自动生成，不要修改
--level	int	11	角色等级[sl][l]
--exp	int	11	魂力注入值[sl][l]
--value	int	11	血脉增加值[sl][l]
local blood_awake_afflux_value =
{
	{level = 30,	exp = 300,	value = 300},
	{level = 31,	exp = 330,	value = 330},
	{level = 32,	exp = 360,	value = 360},
	{level = 33,	exp = 390,	value = 390},
	{level = 34,	exp = 420,	value = 420},
	{level = 35,	exp = 450,	value = 450},
	{level = 36,	exp = 480,	value = 480},
	{level = 37,	exp = 510,	value = 510},
	{level = 38,	exp = 540,	value = 540},
	{level = 39,	exp = 570,	value = 570},
	{level = 40,	exp = 600,	value = 600},
	{level = 41,	exp = 600,	value = 600},
	{level = 42,	exp = 600,	value = 600},
	{level = 43,	exp = 600,	value = 600},
	{level = 44,	exp = 600,	value = 600},
	{level = 45,	exp = 600,	value = 600},
	{level = 46,	exp = 600,	value = 600},
	{level = 47,	exp = 600,	value = 600},
	{level = 48,	exp = 600,	value = 600},
	{level = 49,	exp = 600,	value = 600},
	{level = 50,	exp = 600,	value = 600},
}

return blood_awake_afflux_value