-- 此文件工具自动生成，不要修改
--id	int	11	序号[l][#][sl:i]
--name	char	16	名称[l]
--desc	char	128	描述[l]
--job	int	11	职业[l][sl:i]
--level	int	11	可接取任务等级[l][sl:i]
--exp	int	11	经验奖励[l][sl:i]
--reward_items	char	64	奖励道具(道具ID：类型：数量：快捷栏)[l][sl:ct]
--condition_special	char	64	任务完成特殊处理[l][sl:v]
--condition_list	char	1024	完成任务类型表[l][sl:vv]
--baoxiang	int	11	宝箱id[l][sl:i]
local task_baoxiang =
{
	{id = 1001,	name = "消灭牛马",	desc = "消灭梦星湖左岸宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6001,1},{4,6002,1},{4,6003,1}},	baoxiang = 30000},
	{id = 1002,	name = "消灭牛马",	desc = "消灭废弃监狱南边宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6004,1},{4,6005,1},{4,6006,1}},	baoxiang = 30001},
	{id = 1003,	name = "消灭牛马",	desc = "消灭虎王峰东岳宝1箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6007,1},{4,6008,1},{4,6009,1}},	baoxiang = 30002},
	{id = 1004,	name = "消灭牛马",	desc = "消灭虎王峰东岳宝2箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6010,1},{4,6011,1},{4,6012,1}},	baoxiang = 30003},
	{id = 1005,	name = "消灭牛马",	desc = "消灭虎王峰东岳宝3箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6013,1},{4,6014,1},{4,6015,1}},	baoxiang = 30004},
	{id = 1006,	name = "消灭牛马",	desc = "消灭虎王峰东岳宝4箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6016,1},{4,6017,1},{4,6018,1}},	baoxiang = 30005},
	{id = 1007,	name = "消灭牛马",	desc = "消灭虎王峰东岳宝5箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6019,1},{4,6020,1},{4,6021,1}},	baoxiang = 30006},
	{id = 1008,	name = "消灭牛马",	desc = "消灭星罗近郊1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6022,1},{4,6023,1},{4,6024,1}},	baoxiang = 30007},
	{id = 1009,	name = "消灭牛马",	desc = "消灭星罗近郊2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6025,1},{4,6026,1},{4,6027,1}},	baoxiang = 30008},
	{id = 1010,	name = "消灭牛马",	desc = "消灭星罗近郊3宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6028,1},{4,6029,1},{4,6030,1}},	baoxiang = 30010},
	{id = 1011,	name = "消灭牛马",	desc = "消灭星罗近郊4宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6031,1},{4,6032,1},{4,6033,1}},	baoxiang = 30011},
	{id = 1012,	name = "消灭牛马",	desc = "消灭星罗近郊5宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6034,1},{4,6035,1},{4,6036,1}},	baoxiang = 30012},
	{id = 1013,	name = "消灭牛马",	desc = "消灭星罗西军营宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6037,1},{4,6038,1},{4,6039,1}},	baoxiang = 30013},
	{id = 1014,	name = "消灭牛马",	desc = "消灭星罗近郊6宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6040,1},{4,6041,1},{4,6042,1}},	baoxiang = 30015},
	{id = 1015,	name = "消灭牛马",	desc = "消灭尚武原1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6043,1},{4,6044,1},{4,6045,1}},	baoxiang = 30018},
	{id = 1016,	name = "消灭牛马",	desc = "消灭尚武原2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6046,1},{4,6047,1},{4,6048,1}},	baoxiang = 30019},
	{id = 1017,	name = "消灭牛马",	desc = "消灭虎王峰东岳宝6箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6049,1},{4,6050,1},{4,6051,1}},	baoxiang = 30021},
	{id = 1018,	name = "消灭牛马",	desc = "消灭尚武原3箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6052,1},{4,6053,1},{4,6054,1}},	baoxiang = 30022},
	{id = 1019,	name = "消灭牛马",	desc = "消灭尚武原4箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6055,1},{4,6056,1},{4,6057,1}},	baoxiang = 30023},
	{id = 1020,	name = "消灭牛马",	desc = "消灭梦星湖2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6058,1},{4,6059,1},{4,6060,1}},	baoxiang = 30024},
	{id = 1021,	name = "消灭牛马",	desc = "消灭尚武原5宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6061,1},{4,6062,1},{4,6063,1}},	baoxiang = 30025},
	{id = 1022,	name = "消灭牛马",	desc = "消灭梦星湖3宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6064,1},{4,6065,1},{4,6066,1}},	baoxiang = 30026},
	{id = 1023,	name = "消灭牛马",	desc = "消灭梦星湖4宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6067,1},{4,6068,1},{4,6069,1}},	baoxiang = 30028},
	{id = 1024,	name = "消灭牛马",	desc = "消灭尚武原6宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6070,1},{4,6071,1},{4,6072,1}},	baoxiang = 30029},
	{id = 1025,	name = "消灭牛马",	desc = "消灭星罗近郊7宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6073,1},{4,6074,1},{4,6075,1}},	baoxiang = 30030},
	{id = 1026,	name = "消灭牛马",	desc = "消灭星罗近郊8宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6076,1},{4,6077,1},{4,6078,1}},	baoxiang = 30031},
	{id = 1027,	name = "消灭牛马",	desc = "消灭星罗近郊9宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6079,1},{4,6080,1},{4,6081,1}},	baoxiang = 30032},
	{id = 1028,	name = "消灭牛马",	desc = "消灭星罗官道1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6082,1},{4,6083,1},{4,6084,1}},	baoxiang = 30033},
	{id = 1029,	name = "消灭牛马",	desc = "消灭星罗官道2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6085,1},{4,6086,1},{4,6087,1}},	baoxiang = 30034},
	{id = 1030,	name = "消灭牛马",	desc = "消灭星罗官道3宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6088,1},{4,6089,1},{4,6090,1}},	baoxiang = 30035},
	{id = 1031,	name = "消灭牛马",	desc = "消灭星斗大森林1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6091,1},{4,6092,1},{4,6093,1}},	baoxiang = 30036},
	{id = 1032,	name = "消灭牛马",	desc = "消灭星斗大森林2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6094,1},{4,6095,1},{4,6096,1}},	baoxiang = 30037},
	{id = 1033,	name = "消灭牛马",	desc = "消灭灵罗之路1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6097,1},{4,6098,1},{4,6099,1}},	baoxiang = 30038},
	{id = 1034,	name = "消灭牛马",	desc = "消灭灵罗之路2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6100,1},{4,6101,1},{4,6102,1}},	baoxiang = 30039},
	{id = 1035,	name = "消灭牛马",	desc = "消灭星斗大森林3宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6103,1},{4,6104,1},{4,6105,1}},	baoxiang = 30040},
	{id = 1036,	name = "消灭牛马",	desc = "消灭星斗大森林4宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6106,1},{4,6107,1},{4,6108,1}},	baoxiang = 30041},
	{id = 1037,	name = "消灭牛马",	desc = "消灭星斗大森林5宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6109,1},{4,6110,1},{4,6111,1}},	baoxiang = 30043},
	{id = 1038,	name = "消灭牛马",	desc = "消灭星斗大森林6宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6112,1},{4,6113,1},{4,6114,1}},	baoxiang = 30044},
	{id = 1039,	name = "消灭牛马",	desc = "消灭星斗大森林7宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6115,1},{4,6116,1},{4,6117,1}},	baoxiang = 30045},
	{id = 1040,	name = "消灭牛马",	desc = "消灭星斗大森林8宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6118,1},{4,6119,1},{4,6120,1}},	baoxiang = 30046},
	{id = 1041,	name = "消灭牛马",	desc = "消灭星斗大森林9宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6121,1},{4,6122,1},{4,6123,1}},	baoxiang = 30047},
	{id = 1042,	name = "消灭牛马",	desc = "消灭星斗大森林10宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6124,1},{4,6125,1},{4,6126,1}},	baoxiang = 30048},
	{id = 1043,	name = "消灭牛马",	desc = "消灭星斗大森林11宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6127,1},{4,6128,1},{4,6129,1}},	baoxiang = 30050},
	{id = 1044,	name = "消灭牛马",	desc = "消灭星斗大森林12宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6130,1},{4,6131,1},{4,6132,1}},	baoxiang = 30051},
	{id = 1045,	name = "消灭牛马",	desc = "消灭星斗大森林13宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6133,1},{4,6134,1},{4,6135,1}},	baoxiang = 30052},
	{id = 1046,	name = "消灭牛马",	desc = "消灭星斗大森林14宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6136,1},{4,6137,1},{4,6138,1}},	baoxiang = 30053},
	{id = 1047,	name = "消灭牛马",	desc = "消灭芒斯特之野1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6139,1},{4,6140,1},{4,6141,1}},	baoxiang = 30054},
	{id = 1048,	name = "消灭牛马",	desc = "消灭芒斯特之野2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6142,1},{4,6143,1},{4,6144,1}},	baoxiang = 30055},
	{id = 1049,	name = "消灭牛马",	desc = "消灭归墟崖1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6145,1},{4,6146,1},{4,6147,1}},	baoxiang = 30057},
	{id = 1050,	name = "消灭牛马",	desc = "消灭归墟崖2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6148,1},{4,6149,1},{4,6150,1}},	baoxiang = 30058},
	{id = 1051,	name = "消灭牛马",	desc = "消灭归墟崖3宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6151,1},{4,6152,1},{4,6153,1}},	baoxiang = 30059},
	{id = 1052,	name = "消灭牛马",	desc = "消灭归墟崖4宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6154,1},{4,6155,1},{4,6156,1}},	baoxiang = 30060},
	{id = 1053,	name = "消灭牛马",	desc = "消灭芒斯特之野3宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6157,1},{4,6158,1},{4,6159,1}},	baoxiang = 30062},
	{id = 1054,	name = "消灭牛马",	desc = "消灭西尔维斯郊野1宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6160,1},{4,6161,1},{4,6162,1}},	baoxiang = 30063},
	{id = 1055,	name = "消灭牛马",	desc = "消灭西尔维斯郊野2宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6163,1},{4,6164,1},{4,6165,1}},	baoxiang = 30064},
	{id = 1056,	name = "消灭牛马",	desc = "消灭西尔维斯郊野3宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6166,1},{4,6167,1},{4,6168,1}},	baoxiang = 30065},
	{id = 1057,	name = "消灭牛马",	desc = "消灭西尔维斯郊野4宝箱附近的三只牛马",	job = 0,	level = 1,	exp = 20,	reward_items = "",	condition_special = "0",	condition_list = {{4,6169,1},{4,6170,1},{4,6171,1}},	baoxiang = 30066},
}

return task_baoxiang