-- 此文件工具自动生成，不要修改
--id	int	11	解锁迷雾id[l]
--fog_open	char	256	对应开放区域，冒号分割[l][DMH]
local domain_open =
{
	{id = 11,	fog_open = {1}},
	{id = 12,	fog_open = {2,15}},
	{id = 13,	fog_open = {3,12}},
	{id = 14,	fog_open = {4,14}},
	{id = 15,	fog_open = {6}},
	{id = 16,	fog_open = {7}},
	{id = 17,	fog_open = {16}},
	{id = 18,	fog_open = {17}},
	{id = 21,	fog_open = {9,13}},
	{id = 22,	fog_open = {10,11}},
	{id = 23,	fog_open = {8}},
	{id = 31,	fog_open = {5}},
}

return domain_open