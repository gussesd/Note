-- 此文件工具自动生成，不要修改
--star	int	11	所有暗器达到星级[sl][l]
--level	int	11	技能等级[sl][l]
local anqi_suit_star =
{
	{star = 1,	level = 0},
	{star = 2,	level = 0},
	{star = 3,	level = 0},
	{star = 4,	level = 0},
	{star = 5,	level = 1},
	{star = 6,	level = 1},
	{star = 7,	level = 1},
	{star = 8,	level = 1},
	{star = 9,	level = 1},
	{star = 10,	level = 1},
	{star = 11,	level = 1},
	{star = 12,	level = 1},
	{star = 13,	level = 1},
	{star = 14,	level = 1},
	{star = 15,	level = 2},
	{star = 16,	level = 2},
	{star = 17,	level = 2},
	{star = 18,	level = 2},
	{star = 19,	level = 2},
	{star = 20,	level = 2},
	{star = 21,	level = 2},
	{star = 22,	level = 2},
	{star = 23,	level = 2},
	{star = 24,	level = 2},
	{star = 25,	level = 3},
}

return anqi_suit_star