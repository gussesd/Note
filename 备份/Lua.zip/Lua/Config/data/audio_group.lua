-- 此文件工具自动生成，不要修改
--id	int	11	id[l][sl]
--inst_ids	char	128	audio_inst.cfg id数组[l][DMH][int[]]
--random	int	11	随机参数(万分之一,填10000就是不随机)[l][sl]
--interval	int	11	音效播放间隔(秒,进入范围后x秒开始播放或者进行随机判断,如果填0则循环播放/判断）[l][sl]
local audio_group =
{
	{id = 10001,	inst_ids = {1000101},	random = 10000,	interval = 0},
	{id = 10002,	inst_ids = {1000201,1000202,1000203,1000204,1000205,1000206},	random = 5000,	interval = 5},
	{id = 10003,	inst_ids = {1000301},	random = 10000,	interval = 0},
	{id = 10004,	inst_ids = {1000401},	random = 10000,	interval = 0},
}

return audio_group