-- 此文件工具自动生成，不要修改
--id	int	11	id[sl][l]
--num_min	int	11	最小次数[sl][l]
--num_max	int	11	最大次数[sl][l]
local draw_rate_func =
{
	{id = 1,	num_min = 1,	num_max = 79},
	{id = 1,	num_min = 80,	num_max = 100},
	{id = 2,	num_min = 1,	num_max = 45},
	{id = 2,	num_min = 46,	num_max = 60},
	{id = 3,	num_min = 1,	num_max = 7},
	{id = 3,	num_min = 8,	num_max = 10},
	{id = 4,	num_min = 0,	num_max = 0},
	{id = 5,	num_min = 0,	num_max = 0},
}

return draw_rate_func