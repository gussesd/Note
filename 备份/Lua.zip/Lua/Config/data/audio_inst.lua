-- 此文件工具自动生成，不要修改
--id	int	11	id[l][sl]
--resource_id	int	11	audio.cfg的id[l][sl]
--cover	int	11	是否覆盖背景音(0不覆盖,1覆盖)[l][sl]
--position	char	32	坐标[l][sl:v][DMH][Vector3]
local audio_inst =
{
	{id = 1000101,	resource_id = 14008,	cover = 0,	position = {3283.95,243.05,6280.56}},
	{id = 1000201,	resource_id = 14011,	cover = 0,	position = {3253.29,243.66,6304.20}},
	{id = 1000202,	resource_id = 14001,	cover = 0,	position = {3256.28,243.80,6268.33}},
	{id = 1000203,	resource_id = 14011,	cover = 0,	position = {3270.07,251.77,6290.69}},
	{id = 1000204,	resource_id = 14007,	cover = 0,	position = {3297.30,243.84,6282.36}},
	{id = 1000205,	resource_id = 14007,	cover = 0,	position = {3288.29,260.01,6258.00}},
	{id = 1000206,	resource_id = 14001,	cover = 0,	position = {3231.19,244.65,6282.26}},
	{id = 1000207,	resource_id = 14003,	cover = 0,	position = {3253.29,243.66,6304.20}},
	{id = 1000301,	resource_id = 14003,	cover = 0,	position = {3868.26,284.50,6912.29}},
	{id = 1000302,	resource_id = 0,	cover = 0,	position = {3867.99,285.33,6912.29}},
	{id = 1000401,	resource_id = 14008,	cover = 0,	position = {3258.23,243.05,6286.21}},
}

return audio_inst