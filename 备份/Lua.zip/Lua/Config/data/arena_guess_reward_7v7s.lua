-- 此文件工具自动生成，不要修改
--stage	int	11	赛段[l][sl:i]
--name	char	11	轮次[l][sl]
--num	int	11	默认奖励数量[l][sl:i]
local arena_guess_reward_7v7s =
{
	{stage = 1,	name = "32进16强晋级赛",	num = 50000},
	{stage = 2,	name = "4进2强晋级赛",	num = 1000000},
}

return arena_guess_reward_7v7s