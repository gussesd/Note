-- 此文件工具自动生成，不要修改
--id	int	11	表现行为类型[l]
--keys	char	256	字段顺序[DMH][l]
--keysDesc	char	256	字段注释，工具读取用[l]
local jiguan_beh_type =
{
	{id = 1,	keys = {"rotatetime","angle_y","angle_speed","angle_accspeed","add_angle_y","angle_loop","angle_speedadd"},	keysDesc = {{"开始旋转延迟时间ms","附加角度值*10","角速度*10","角加速度*10","角度值改变*10（基于当前值）","是否循环","是否累加速度"}}},
	{id = 2,	keys = {"statechangetime","prestate","tarstate"},	keysDesc = {{"状态变化事件延迟派发时间ms","来源状态没有填-1","目标状态"}}},
	{id = 3,	keys = {"locktime"},	keysDesc = "锁定延迟时间ms"},
	{id = 4,	keys = {"unlocktime"},	keysDesc = "解锁延迟时间ms"},
	{id = 5,	keys = {"tarflytime","tarId","flytime","mid_xz_ratio","mid_y"},	keysDesc = {{"延时执行ms","目标机关id","飞行时间ms","bezier曲线参考点横向比例","曲线参考点纵向偏移"}}},
	{id = 6,	keys = {"fromId","px","py","pz","movetime","tarId","cameratotaltime"},	keysDesc = {{"镜头起始坐标来源0为当前主摄像机","偏移x","偏移y","偏移z","镜头移动时长","朝向机关id","镜头总时长"}}},
	{id = 7,	keys = {"adddecotime","decoId"},	keysDesc = {{"添加特效延时ms","特效id"}}},
	{id = 8,	keys = {"removedecotime","decoId"},	keysDesc = {{"移除特效延时ms","特效id"}}},
	{id = 9,	keys = {"soundtime","soundId"},	keysDesc = {{"播放音效延时ms","音效id"}}},
	{id = 10,	keys = {"movesttime","tarX","tarY","tarZ","speed","chgdir","moveMode"},	keysDesc = {{"移动开始延时ms","目标坐标x*100","目标坐标y*100","目标坐标z*100","速度","修改朝向","移动模式(0默认,1自由)"}}},
	{id = 11,	keys = {"aroundtime","tarId","radius","offset_y","monsterId"},	keysDesc = {{"环绕开始延时ms","目标id 0玩家 否则机关","半径","偏移y*100","怪物id"}}},
	{id = 12,	keys = {"followtime","tarId","offset_x","offset_y","offset_z","monsterId"},	keysDesc = {{"跟随开始延时ms","目标id 0玩家 否则机关","偏移x*100","偏移y*100","偏移z*100","怪物id"}}},
	{id = 13,	keys = {"outtime","skipreset"},	keysDesc = {{"脱离延迟ms","跳过坐标重置"}}},
}

return jiguan_beh_type