-- 此文件工具自动生成，不要修改
--type	int	11	类型[l]
--desc	char	128	描述[l][FULL]
--start_time	int	11	开始时间[l]
--end_time	int	11	结束事件[l]
--stage	int	11	阶段[l]
local arena_final_time =
{
	{type = 1,	desc = "512强抽签：3/9 12:00 - 3/10 00:00",	start_time = 1709956800,	end_time = 1710000000,	stage = 1},
	{type = 2,	desc = "512进256强投票：3/9 12:00 - 3/10 21:05",	start_time = 1709956800,	end_time = 1710075900,	stage = 1},
	{type = 3,	desc = "512强抽签结束：3/10 00:00",	start_time = 1710000000,	end_time = 1710000000,	stage = 1},
	{type = 4,	desc = "256进128投票：3/10 21:31 - 3/11 21:05",	start_time = 1710077460,	end_time = 1710162300,	stage = 2},
	{type = 5,	desc = "128进64投票：3/11 21:31 - 3/12 21:05",	start_time = 1710163860,	end_time = 1710248700,	stage = 3},
	{type = 6,	desc = "64进32投票：3/12 21:31 - 3/13 21:05",	start_time = 1710250260,	end_time = 1710335100,	stage = 4},
	{type = 7,	desc = "32强抽签：3/14 12:00 - 3/15 00:00",	start_time = 1710388800,	end_time = 1710432000,	stage = 5},
	{type = 8,	desc = "32进16强投票：3/14 12:00 - 3/15 21:05",	start_time = 1710388800,	end_time = 1710507900,	stage = 5},
	{type = 9,	desc = "32强抽签结束：3/15 00:00",	start_time = 1710432000,	end_time = 1710432000,	stage = 5},
	{type = 10,	desc = "16进8投票：3/16 00:00 - 3/16 21:05",	start_time = 1710518400,	end_time = 1710594300,	stage = 6},
	{type = 11,	desc = "8进4投票：3/16 21:31 - 3/17 21:05",	start_time = 1710595860,	end_time = 1710680700,	stage = 7},
	{type = 12,	desc = "4进2投票：3/17 21:31 - 3/18 21:05",	start_time = 1710682260,	end_time = 1710767100,	stage = 8},
	{type = 13,	desc = "总决赛投票：3/18 21:31 - 3/19 21:05",	start_time = 1710768660,	end_time = 1710853500,	stage = 9},
	{type = 14,	desc = "领奖时间：3/19 22:00 - 3/27 00:00",	start_time = 1710856800,	end_time = 1711468800,	stage = 10},
}

return arena_final_time