-- 此文件工具自动生成，不要修改
--id	int	11	保存点[l]
--map	int	11	地图[l]
--point	char	32	拉回点坐标(x:y:z:朝向)[l][DMH]
--trigger	int	11	触发类型(1位置2接到任务3完成任务)[l]
--param	char	64	触发类型参数(区域ID,任务id)[l]
local map_pos_save =
{
	{id = 1,	map = 1000,	point = {1,1,1,1},	trigger = 1,	param = {{2,2,2,10}}},
	{id = 2,	map = 1000,	point = {1,1,1,1},	trigger = 2,	param = "100010"},
	{id = 80002,	map = 10005,	point = {172.22,115.22,89.72,130},	trigger = 1,	param = "80013"},
	{id = 80003,	map = 10005,	point = {218.18,145.41,15.89,143},	trigger = 1,	param = "80014"},
	{id = 83022,	map = 83022,	point = {-109.52,10.57,-20.84},	trigger = 2,	param = "1259015"},
	{id = 83023,	map = 83022,	point = {-40.03,22.93,4.81},	trigger = 2,	param = "1259040"},
	{id = 83024,	map = 83022,	point = {95.95,47.07,-33.26},	trigger = 2,	param = "1259055"},
	{id = 83040,	map = 83040,	point = {31.26,12.17,-5.29},	trigger = 2,	param = "1230280"},
	{id = 83041,	map = 83040,	point = {55.01,14.94,20.01},	trigger = 2,	param = "1230295"},
	{id = 83042,	map = 83040,	point = {-90.81,9.27,-31.48},	trigger = 2,	param = "1230325"},
	{id = 84101,	map = 84060,	point = {-159.38,-0.99,-174.48,62},	trigger = 3,	param = "1041010"},
	{id = 84102,	map = 84060,	point = {-125.35,-2.19,-130.41,331},	trigger = 3,	param = "1041035"},
	{id = 84103,	map = 84060,	point = {-96.83,-2.43,-88.37,90},	trigger = 3,	param = "1041040"},
	{id = 84104,	map = 84060,	point = {-152.71,1.35,-23.95,0},	trigger = 3,	param = "1041050"},
	{id = 84105,	map = 84060,	point = {-75.49,-7.43,-17.71,0},	trigger = 3,	param = "1041055"},
	{id = 84106,	map = 84060,	point = {-106.77,-5.35,54.85,40},	trigger = 3,	param = "1041080"},
	{id = 84107,	map = 84060,	point = {-160.86,-2.33,106.6,264},	trigger = 3,	param = "1041090"},
	{id = 84108,	map = 84060,	point = {-110.07,-1.97,119.6,62},	trigger = 3,	param = "1041100"},
	{id = 85100,	map = 85418,	point = {-213,4,-68,105},	trigger = 1,	param = "85200"},
	{id = 85101,	map = 85418,	point = {-70.22,20,15.74,46},	trigger = 1,	param = "85201"},
	{id = 85102,	map = 85418,	point = {-10.23,33.5,-63.1,168},	trigger = 1,	param = "85202"},
	{id = 85103,	map = 85418,	point = {86.27,69.5,100.66,337},	trigger = 1,	param = "85203"},
	{id = 85425,	map = 85425,	point = {68.13,18.97,-100.70,0},	trigger = 1,	param = "85425"},
	{id = 85426,	map = 85425,	point = {38.16,13.91,2.33,0},	trigger = 1,	param = "85426"},
	{id = 85427,	map = 85425,	point = {4.30,15.18,44.76,0},	trigger = 1,	param = "85427"},
	{id = 85428,	map = 85425,	point = {-86.53,9.59,-43.18,0},	trigger = 1,	param = "85428"},
	{id = 90001,	map = 3105,	point = {6453.33,-0.09,6489.26,0},	trigger = 1,	param = "190001"},
	{id = 90002,	map = 3105,	point = {6472.57,3.74,6623.18,90},	trigger = 1,	param = "190002"},
	{id = 90003,	map = 3105,	point = {6580.81,3.11,6718.90,270},	trigger = 1,	param = "190003"},
	{id = 90004,	map = 3105,	point = {6433.61,0.50,6662.00,240},	trigger = 1,	param = "190004"},
	{id = 90005,	map = 3105,	point = {6377.85,0.50,6793.97,330},	trigger = 1,	param = "190005"},
	{id = 90006,	map = 3105,	point = {6328.05,0,6829.29,315},	trigger = 1,	param = "190006"},
	{id = 90101,	map = 3405,	point = {3920.85,162.48,2562.36,140},	trigger = 1,	param = "190101"},
	{id = 90102,	map = 3405,	point = {3994.12,171.42,2368.63,300},	trigger = 1,	param = "190102"},
	{id = 90103,	map = 3405,	point = {3949.24,195.26,1904.79,90},	trigger = 1,	param = "190103"},
	{id = 90104,	map = 3405,	point = {4100.54,211.89,1697.56,90},	trigger = 1,	param = "190104"},
	{id = 90105,	map = 3405,	point = {4212.91,230.79,1764.00,100},	trigger = 1,	param = "190105"},
	{id = 90106,	map = 3405,	point = {4140.82,216.73,1763.84,320},	trigger = 1,	param = "190106"},
}

return map_pos_save