-- 此文件工具自动生成，不要修改
--id	int	11	道具id[l][sl]
--type	int	11	功能（1.魂骨强化 2.魂髓升阶 3.外附魂骨强化 4.外附魂骨赋灵 5.暗器强化 6.暗器进阶 7.暗器升星 8.武魂强化 9.爵位升级 10.魂环强化）[l][sl]
--exp	int	11	经验[l][sl]
local exp_item =
{
	{id = 6701,	type = 1,	exp = 100},
	{id = 6702,	type = 1,	exp = 200},
	{id = 6703,	type = 1,	exp = 500},
	{id = 6730,	type = 2,	exp = 100},
	{id = 6731,	type = 2,	exp = 200},
	{id = 6732,	type = 2,	exp = 500},
	{id = 6511,	type = 8,	exp = 100},
	{id = 6512,	type = 8,	exp = 200},
	{id = 6513,	type = 8,	exp = 500},
	{id = 8501,	type = 5,	exp = 20},
	{id = 8502,	type = 5,	exp = 100},
	{id = 8503,	type = 5,	exp = 200},
	{id = 8521,	type = 6,	exp = 300},
	{id = 8522,	type = 6,	exp = 600},
	{id = 8523,	type = 6,	exp = 1500},
	{id = 8571,	type = 7,	exp = 20},
	{id = 8572,	type = 7,	exp = 20},
	{id = 8573,	type = 7,	exp = 20},
	{id = 8574,	type = 7,	exp = 20},
	{id = 8575,	type = 7,	exp = 20},
	{id = 8576,	type = 7,	exp = 20},
	{id = 8577,	type = 7,	exp = 20},
	{id = 8578,	type = 7,	exp = 20},
	{id = 8579,	type = 7,	exp = 20},
	{id = 8580,	type = 7,	exp = 20},
	{id = 8581,	type = 7,	exp = 20},
	{id = 8582,	type = 7,	exp = 20},
	{id = 8583,	type = 7,	exp = 20},
	{id = 8584,	type = 7,	exp = 20},
	{id = 8585,	type = 7,	exp = 20},
	{id = 6811,	type = 3,	exp = 100},
	{id = 6812,	type = 3,	exp = 200},
	{id = 6813,	type = 3,	exp = 500},
	{id = 8851,	type = 9,	exp = 100},
	{id = 8852,	type = 9,	exp = 200},
	{id = 8853,	type = 9,	exp = 500},
	{id = 6010,	type = 10,	exp = 100},
	{id = 6011,	type = 10,	exp = 200},
	{id = 6012,	type = 10,	exp = 500},
}

return exp_item