-- 此文件工具自动生成，不要修改
--id	int	11	序号[l]
--name	char	32	名称[l]
--unlock_type	int	11	解锁方式0默认解锁1客户端解锁2技能3事件[l]
--unlock_param	int	11	解锁参数,如元素等[l]
--touch_type	int	11	触发方式[l]
--touch_param	int	11	触发参数(0无动作1采集2挖矿)[l]
--touch_delay	int	11	触发延时[l]
--touch_remove	int	11	触发后是否移除[l]
--imm_reward	char	32	固定奖励(道具id:道具类型:道具数量,道具类型1为道具,2为装备)[l][DMH]
--common_drop	char	32	掉落组[l]
--model	int	11	模型[l]
--type	int	11	采集物类型(0未定义1草药2矿石3机关4前尘忆念5调查6挖掘7元素灵粹8食材9木材10星辰碎石)[l]
local collection =
{
	{id = 10001,	name = "铁矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4001,	type = 2},
	{id = 10002,	name = "铜矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4002,	type = 2},
	{id = 10003,	name = "银矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4003,	type = 2},
	{id = 10004,	name = "金矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4004,	type = 2},
	{id = 10005,	name = "金刚石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4005,	type = 2},
	{id = 10006,	name = "板晶",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4006,	type = 2},
	{id = 10007,	name = "黑铁矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4007,	type = 2},
	{id = 10008,	name = "紫铜矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4008,	type = 2},
	{id = 10009,	name = "秘银矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4009,	type = 2},
	{id = 10010,	name = "精金矿",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4010,	type = 2},
	{id = 10011,	name = "深海沉银",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4011,	type = 2},
	{id = 10012,	name = "落日赤金",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4012,	type = 2},
	{id = 10013,	name = "寒心铁精",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4013,	type = 2},
	{id = 10014,	name = "神佑晶精石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4014,	type = 2},
	{id = 10015,	name = "雨花石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4015,	type = 2},
	{id = 10016,	name = "彩水晶",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4016,	type = 2},
	{id = 10017,	name = "岫玉",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4017,	type = 2},
	{id = 10018,	name = "紫金宝石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4018,	type = 2},
	{id = 10019,	name = "上品血珀",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4019,	type = 2},
	{id = 10020,	name = "夜华猫眼",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4020,	type = 2},
	{id = 10021,	name = "帝玺翡翠",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4021,	type = 2},
	{id = 10022,	name = "天清和田玉",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4022,	type = 2},
	{id = 10023,	name = "赤瞳金皇玉",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4023,	type = 2},
	{id = 10024,	name = "火魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4024,	type = 2},
	{id = 10025,	name = "雷魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4025,	type = 2},
	{id = 10026,	name = "风魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4026,	type = 2},
	{id = 10027,	name = "水魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4027,	type = 2},
	{id = 10028,	name = "土魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4028,	type = 2},
	{id = 10029,	name = "毒魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4029,	type = 2},
	{id = 10030,	name = "圣魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4030,	type = 2},
	{id = 10031,	name = "暗魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4031,	type = 2},
	{id = 10032,	name = "强魂晶石",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 2,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 4032,	type = 2},
	{id = 10033,	name = "甘草",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3008,	type = 1},
	{id = 10034,	name = "鸡冠凤凰葵",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3009,	type = 1},
	{id = 10035,	name = "绮罗郁金香",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3010,	type = 1},
	{id = 10036,	name = "相思断肠红",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3011,	type = 1},
	{id = 10037,	name = "烈火杏娇疏",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3012,	type = 1},
	{id = 10038,	name = "奇茸通天菊",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3013,	type = 1},
	{id = 10039,	name = "八瓣仙兰",	unlock_type = 0,	unlock_param = 1,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3014,	type = 1},
	{id = 10040,	name = "水仙玉肌骨",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3015,	type = 1},
	{id = 10041,	name = "九品紫芝",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3016,	type = 1},
	{id = 10042,	name = "水晶血龙参",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3017,	type = 1},
	{id = 10043,	name = "血色天鹅吻",	unlock_type = 0,	unlock_param = 0,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3018,	type = 1},
	{id = 10044,	name = "半夏",	unlock_type = 0,	unlock_param = 1,	touch_type = 0,	touch_param = 1,	touch_delay = 1000,	touch_remove = 0,	imm_reward = {1000,1,1},	common_drop = "2",	model = 3019,	type = 1},
}

return collection