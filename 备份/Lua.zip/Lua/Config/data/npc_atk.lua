-- 此文件工具自动生成，不要修改
--id	int	11	ID[l][sl]
--npc	int	11	NPC表id[l]
--atk	int	11	魂力比拼时战力百分比[l][sl]
local npc_atk =
{
	{id = 1,	npc = 22022,	atk = 40},
	{id = 2,	npc = 22023,	atk = 30},
	{id = 3,	npc = 20006201,	atk = 50},
}

return npc_atk