-- 此文件工具自动生成，不要修改
--id	int	11	id[sl][l]
--name	char	16	名称[l]
--area	int	11	视野范围按米记[sl][l]
--show	int	11	小地图战斗范围判定[sl][l]
local zone_view =
{
	{id = 1,	name = "玩家",	area = 10,	show = 10},
	{id = 2,	name = "防御塔",	area = 10,	show = 10},
	{id = 3,	name = "据点",	area = 10,	show = 10},
	{id = 4,	name = "小兵",	area = 10,	show = 10},
	{id = 5,	name = "兵营",	area = 10,	show = 10},
}

return zone_view