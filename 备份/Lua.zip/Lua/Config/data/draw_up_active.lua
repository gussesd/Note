-- 此文件工具自动生成，不要修改
--id	int	11	活动id[sl][l]
--pool_id	int	11	池id[sl][l]
--group_up	char	16	up组id(gid:upid|...)[sl:t][l]
--time_start	int	11	开始时间戳[sl][l]
--time_end	int	11	结束时间戳[sl][l]
--draw_item	int	11	活动抽奖道具[sl][l]
--name	char	16	祈愿类型[l]
local draw_up_active =
{
	{id = 1,	pool_id = 1,	group_up = {{11,101}},	time_start = 1678809600,	time_end = 1679414399,	draw_item = 202,	name = "限时祈愿"},
	{id = 2,	pool_id = 2,	group_up = {{11,102}},	time_start = 1680537600,	time_end = 1681142399,	draw_item = 202,	name = "限时祈愿"},
	{id = 3,	pool_id = 3,	group_up = {{11,103}},	time_start = 1682265600,	time_end = 1682870399,	draw_item = 202,	name = "限时祈愿"},
	{id = 4,	pool_id = 4,	group_up = {{11,104}},	time_start = 1683993600,	time_end = 1684598399,	draw_item = 202,	name = "限时祈愿"},
	{id = 5,	pool_id = 5,	group_up = {{11,105}},	time_start = 1685721600,	time_end = 1686326399,	draw_item = 202,	name = "限时祈愿"},
	{id = 6,	pool_id = 6,	group_up = {{11,106}},	time_start = 1687449600,	time_end = 1688054399,	draw_item = 202,	name = "限时祈愿"},
	{id = 7,	pool_id = 7,	group_up = {{11,107}},	time_start = 1702396800,	time_end = 1733932800,	draw_item = 202,	name = "限时祈愿"},
	{id = 8,	pool_id = 8,	group_up = {{11,108}},	time_start = 1690905600,	time_end = 1691510399,	draw_item = 202,	name = "限时祈愿"},
	{id = 9,	pool_id = 9,	group_up = {{11,109}},	time_start = 1692633600,	time_end = 1693238399,	draw_item = 202,	name = "限时祈愿"},
	{id = 10,	pool_id = 10,	group_up = {{11,110}},	time_start = 1694361600,	time_end = 1694966399,	draw_item = 202,	name = "限时祈愿"},
	{id = 11,	pool_id = 11,	group_up = {{11,111}},	time_start = 1696089600,	time_end = 1696694399,	draw_item = 202,	name = "限时祈愿"},
	{id = 12,	pool_id = 12,	group_up = {{11,112}},	time_start = 1697817600,	time_end = 1698422399,	draw_item = 202,	name = "限时祈愿"},
}

return draw_up_active