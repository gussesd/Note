-- 此文件工具自动生成，不要修改
--id	char	256	id[l]
--model	char	128	模型[l]
--modelPath	char	128	模型路径[l]
--animation	char	1024	动作(动作名称:帧数  帧数最后一帧可用-1代替)[l][string[][]]
--position	char	1024	坐标[l][Vector3][DMH]
--rotation	char	1024	旋转[l][Vector3][DMH]
--scale	char	1024	缩放[l][Vector3][DMH]
--collidername	char	1024	碰撞名称[l]
local voxel_block =
{
	{id = "1",	model = "model_plot_chain",	modelPath = "",	animation = {{"link",-1}},	position = {0,0,0},	rotation = {0,0,0},	scale = {1,1,1},	collidername = ""},
	{id = "2",	model = "",	modelPath = "ArtScene/SceneRes/fb_dwsbysf/prefabs/dwsbysf_build_02",	animation = "",	position = {0,0,0},	rotation = {0,0,0},	scale = {1,1,1},	collidername = ""},
	{id = "3",	model = "",	modelPath = "ArtScene/SceneRes/fb_dwsbysf/prefabs/dwsbysf_build_02",	animation = {{"ArtScene/SceneRes/fb_dwsbysf/timeline/dwsbysf_build_02Timeline","dwsbysf_build_02_open",-1}},	position = {0,0,0},	rotation = {0,0,0},	scale = {1,1,1},	collidername = ""},
	{id = "4",	model = "model_mechanism_sudokuslate",	modelPath = "",	animation = "",	position = {0,0,0},	rotation = {0,0,0},	scale = {1,1,1},	collidername = "model_mechanism_sudokuslate 1"},
	{id = "5",	model = "model_mechanism_foxtransportarray_01",	modelPath = "",	animation = "",	position = {0,0,0},	rotation = {0,0,0},	scale = {1,1,1},	collidername = "model_mechanism_FoxTransportArray_01"},
}

return voxel_block