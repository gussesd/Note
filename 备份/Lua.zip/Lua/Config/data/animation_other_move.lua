-- 此文件工具自动生成，不要修改
--id	int	11	配置id（id从4开始）[sl][l]
--name	char	16	名字[sl][l]
local animation_other_move =
{
	{id = 4,	name = "plot_fleeing_loop"},
}

return animation_other_move