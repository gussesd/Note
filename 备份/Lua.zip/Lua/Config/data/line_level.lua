-- 此文件工具自动生成，不要修改
--line_level	int	11	线路等级[l][sl]
--name	char	16	名字[l]
local line_level =
{
	{line_level = 1,	name = "魂师"},
	{line_level = 2,	name = "魂尊"},
	{line_level = 3,	name = "魂帝"},
	{line_level = 4,	name = "封号斗罗"},
	{line_level = 5,	name = "巅峰斗罗Ⅲ"},
}

return line_level