-- 此文件工具自动生成，不要修改
--order	int	11	魂骨等阶[l]
--year	int	11	魂骨年限[l]
--year_zh	char	32	魂骨年限(中文)[l]
local bone_year =
{
	{order = 1,	year = 1000,	year_zh = "千年"},
	{order = 2,	year = 3000,	year_zh = "三千年"},
	{order = 3,	year = 5000,	year_zh = "五千年"},
	{order = 4,	year = 10000,	year_zh = "一万年"},
	{order = 5,	year = 20000,	year_zh = "两万年"},
	{order = 6,	year = 30000,	year_zh = "三万年"},
	{order = 7,	year = 40000,	year_zh = "四万年"},
	{order = 8,	year = 50000,	year_zh = "五万年"},
	{order = 9,	year = 70000,	year_zh = "七万年"},
	{order = 10,	year = 100000,	year_zh = "十万年"},
	{order = 11,	year = 150000,	year_zh = "十五万"},
	{order = 12,	year = 200000,	year_zh = "三十万"},
	{order = 13,	year = 300000,	year_zh = "五十万"},
	{order = 14,	year = 500000,	year_zh = "七十万"},
	{order = 15,	year = 1000000,	year_zh = "百万年"},
}

return bone_year