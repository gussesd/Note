-- 此文件工具自动生成，不要修改
--id	int	11	序列[l]
--map	int	11	所在场景[l]
local map_fog =
{
	{id = 1,	map = 1000},
	{id = 2,	map = 1000},
	{id = 3,	map = 1000},
	{id = 4,	map = 1000},
	{id = 5,	map = 1000},
	{id = 6,	map = 1000},
	{id = 7,	map = 1000},
	{id = 8,	map = 1000},
	{id = 9,	map = 1000},
	{id = 10,	map = 1000},
	{id = 11,	map = 1000},
	{id = 12,	map = 1000},
	{id = 13,	map = 1000},
	{id = 14,	map = 1000},
	{id = 15,	map = 1000},
	{id = 16,	map = 1000},
	{id = 17,	map = 1000},
	{id = 18,	map = 1000},
}

return map_fog