-- 此文件工具自动生成，不要修改
--id	int	11	任务ID[l][sl:i]
--name	char	64	任务名[l]
--type	int	11	任务类型[l][sl:i]
--level	int	11	等级[l][sl:i]
--pretask	char	128	前置任务[l][sl:v]
--last	int	11	单个任务或链任务的最后一个(1是0否)[l][sl:i]
--like	int	11	情缘值[l][sl:i]
--exp	int	11	经验奖励[l][sl:i]
--reward_items	char	64	奖励道具(道具ID：类型：数量)[l][sl:ct]
--condition_info	char	128	任务进度描述[l][DMH]
--condition_special	char	64	任务完成特殊处理[l][sl:v]
--condition_list	char	1024	完成任务类型[l][sl:vv]
local task_qingyuan =
{
}

return task_qingyuan