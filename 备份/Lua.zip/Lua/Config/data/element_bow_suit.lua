-- 此文件工具自动生成，不要修改
--index	int	11	索引[sl:i][l]
--level	int	11	全元素等级[sl:i][l]
--attr	char	64	属性[sl:vv][l]
local element_bow_suit =
{
	{index = 1,	level = 1,	attr = {{97,1,100},{64,1,100}}},
	{index = 2,	level = 2,	attr = {{97,1,200},{64,1,200}}},
	{index = 3,	level = 3,	attr = {{97,1,300},{64,1,300}}},
	{index = 4,	level = 4,	attr = {{97,1,400},{64,1,400}}},
	{index = 5,	level = 5,	attr = {{97,1,500},{64,1,500}}},
	{index = 6,	level = 6,	attr = {{97,1,600},{64,1,600}}},
	{index = 7,	level = 7,	attr = {{97,1,700},{64,1,700}}},
	{index = 8,	level = 8,	attr = {{97,1,800},{64,1,800}}},
	{index = 9,	level = 9,	attr = {{97,1,1000},{64,1,1000}}},
	{index = 10,	level = 10,	attr = {{97,1,1200},{64,1,1200}}},
	{index = 11,	level = 11,	attr = {{97,1,1400},{64,1,1400}}},
	{index = 12,	level = 12,	attr = {{97,1,1600},{64,1,1600}}},
	{index = 13,	level = 13,	attr = {{97,1,1800},{64,1,1800}}},
	{index = 14,	level = 14,	attr = {{97,1,2000},{64,1,2000}}},
	{index = 15,	level = 15,	attr = {{97,1,2250},{64,1,2250}}},
	{index = 16,	level = 16,	attr = {{97,1,2500},{64,1,2500}}},
}

return element_bow_suit