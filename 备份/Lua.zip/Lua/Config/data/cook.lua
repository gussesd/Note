-- 此文件工具自动生成，不要修改
--id	int	11	合成id[sl][l]
--group_id	int	11	合成组id[l]
--reward	char	16	合成道具[sl:vv][l]
--cost_id	char	16	食材id(x:x|...)[SXMH][l][sl:vv]
--cost_num	char	16	食材数量(x:x...)[sl:v][DMH][l]
--make_level	int	11	打造等级[sl][l]
--make_num	int	11	打造次数[sl][l]
--make_cost	int	11	打造消耗精力[sl][l]
local cook =
{
	{id = 2000,	group_id = 2000,	reward = {{2601,1,1}},	cost_id = {{2559,2560,2561,2562},{2653}},	cost_num = {3,2},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2001,	group_id = 2001,	reward = {{2602,1,1}},	cost_id = {{2658},{2652,2653}},	cost_num = {3,1},	make_level = 3,	make_num = 0,	make_cost = 0},
	{id = 2002,	group_id = 2002,	reward = {{2603,1,1}},	cost_id = {{2504},{2652},{2660}},	cost_num = {2,1,1},	make_level = 2,	make_num = 0,	make_cost = 0},
	{id = 2003,	group_id = 2003,	reward = {{2604,1,1}},	cost_id = {{2504},{2652}},	cost_num = {3,1},	make_level = 2,	make_num = 0,	make_cost = 0},
	{id = 2004,	group_id = 2004,	reward = {{2605,1,1}},	cost_id = {{2503,2504},{2652},{2651}},	cost_num = {2,1,1},	make_level = 3,	make_num = 0,	make_cost = 0},
	{id = 2005,	group_id = 2005,	reward = {{2606,1,1}},	cost_id = {{2556}},	cost_num = {5},	make_level = 3,	make_num = 0,	make_cost = 0},
	{id = 2006,	group_id = 2006,	reward = {{2607,1,1}},	cost_id = {{2565}},	cost_num = {3},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2007,	group_id = 2007,	reward = {{2608,1,1}},	cost_id = {{2503,2504,2505,2506}},	cost_num = {4},	make_level = 2,	make_num = 0,	make_cost = 0},
	{id = 2008,	group_id = 2008,	reward = {{2609,1,1}},	cost_id = {{2564}},	cost_num = {3},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2009,	group_id = 2009,	reward = {{2505,1,1}},	cost_id = {{2701,2702,2703,2704,2705,2707,2708,2709,2710}},	cost_num = {1},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2010,	group_id = 2009,	reward = {{2505,1,2}},	cost_id = {{2711,2712,2713,2714,2715,2716,2717}},	cost_num = {1},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2011,	group_id = 2009,	reward = {{2505,1,3}},	cost_id = {{2718,2719,2720,2721,2722,2723}},	cost_num = {1},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2012,	group_id = 2009,	reward = {{2505,1,4}},	cost_id = {{2724,2725,2726,2727}},	cost_num = {1},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2013,	group_id = 2009,	reward = {{2505,1,5}},	cost_id = {{2728,2729,2730,2731}},	cost_num = {1},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2014,	group_id = 2009,	reward = {{2505,1,6}},	cost_id = {{2732,2733}},	cost_num = {1},	make_level = 1,	make_num = 0,	make_cost = 0},
	{id = 2015,	group_id = 2015,	reward = {{2502,1,1}},	cost_id = {{2706}},	cost_num = {1},	make_level = 1,	make_num = 0,	make_cost = 0},
}

return cook