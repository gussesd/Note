-- 此文件工具自动生成，不要修改
--id	int	11	序列[l][#][sl:i]
--name	char	12	名称[l]
--model	char	256	模型[l]
--bind0	char	1024	绑定点0参数[l]
--bind1	char	1024	绑定点0参数[l]
--bind2	char	1024	绑定点0参数[l]
--bind3	char	1024	绑定点0参数[l]
local mount =
{
}

return mount