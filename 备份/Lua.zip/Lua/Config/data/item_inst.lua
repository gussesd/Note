-- 此文件工具自动生成，不要修改
--id	int	11	对应itemId[sl][l]
--time	char	16	限时(0无限时,1:day:hour=第day天hour点过期,2:sec=sec秒过期)[sl:v][l][DMH]
local item_inst =
{
	{id = 1025,	time = {0}},
	{id = 246,	time = {0}},
	{id = 259,	time = {1,2,5}},
	{id = 301,	time = {1,2,5}},
	{id = 302,	time = {1,2,5}},
	{id = 303,	time = {1,2,5}},
	{id = 304,	time = {1,2,5}},
	{id = 305,	time = {1,2,5}},
}

return item_inst