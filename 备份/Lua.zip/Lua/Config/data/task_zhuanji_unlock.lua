-- 此文件工具自动生成，不要修改
--id	int	11	传记任务id[l][#][sl:i]
--chapter	char	16	每小节第一个任务id[l][DMH]
--name	char	16	名称[l]
--icon_type	char	16	立绘资源名[l]
--cost	char	64	解锁任务需要道具[l][sl:ct]
--need_task_id	int	11	解锁前置的主线任务id[l][sl:v][DMH]
--start_desc	char	128	接取前的描述[l]
--desc	char	128	描述[l]
--reward	char	256	奖励预览[l]
--endtask_id	int	11	最后一个任务id[l][#][sl:i]
--hint_area	char	16	执行任务区域[l]
--unlock_npcjiban	char	32	解锁需要NPC羁绊(图鉴id:羁绊等级)[sl:v][l][DMH]
local task_zhuanji_unlock =
{
	{id = 520005,	chapter = {520005,520065,520170,520225},	name = "天斗美食传奇",	icon_type = "350401",	cost = {{218,1,3}},	need_task_id = 1230130,	start_desc = "一向懒散的马红俊，突然约你一起游历大陆，究竟是什么让他突然勤快起来？是美食的诱惑，还是……",	desc = "马红俊传记",	reward = {{13,1,5},{3,1,3000},{2504,1,3},{2002,1,3},{9180,1,1},{9181,1,1}},	endtask_id = 520240,	hint_area = "天斗帝国",	unlock_npcjiban = {9,2}},
	{id = 520300,	chapter = {520300,520350,520415},	name = "尘颜序曲",	icon_type = "350301",	cost = {{218,1,3}},	need_task_id = 1140355,	start_desc = "朱竹清神神秘秘邀请你前往星罗城下城区与她会面，不知何事，去看看吧。",	desc = "朱竹清传记",	reward = {{13,1,5},{3,1,3000},{2504,1,3},{2002,1,3},{9180,1,1},{9181,1,1}},	endtask_id = 520480,	hint_area = "星罗帝国",	unlock_npcjiban = {6,2}},
	{id = 540005,	chapter = {540005,540055,540150,540190},	name = "虎王之魇",	icon_type = "350201",	cost = {{218,1,3}},	need_task_id = 1253060,	start_desc = "最近戴沐白心神不宁，状态奇差，原来是因为对他二哥戴文特的死心生愧疚导致的，思量再三，你决定陪同戴沐白共赴星罗，祭奠文特。",	desc = "戴沐白传记",	reward = {{13,1,5},{3,1,3000},{2504,1,3},{2002,1,3},{9180,1,1},{9181,1,1}},	endtask_id = 540210,	hint_area = "史莱克学院",	unlock_npcjiban = {5,2}},
}

return task_zhuanji_unlock