-- 此文件工具自动生成，不要修改
--id	int	11	序号[l]
--name	char	16	名字[l]
local dungeon_cfg_npc =
{
}

return dungeon_cfg_npc