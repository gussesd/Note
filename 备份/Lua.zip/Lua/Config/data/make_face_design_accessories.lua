-- 此文件工具自动生成，不要修改
--id	int	11	预设选择[l]
--name	char	512	配饰名(男|女)[l]
local make_face_design_accessories =
{
	{id = 1,	name = {{0,14,0,0,0}}},
}

return make_face_design_accessories