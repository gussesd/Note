-- 此文件工具自动生成，不要修改
--id	int	11	唯一标识[l]
--annotation	char	16	注释[l]
--type	int	11	行为类型 (1、移动；2、常驻位置固定)[l]
local p2p_path_base =
{
	{id = 1000,	annotation = "移动",	type = 1},
	{id = 2000,	annotation = "常驻交谈",	type = 2},
	{id = 3000,	annotation = "多人交互",	type = 3},
}

return p2p_path_base