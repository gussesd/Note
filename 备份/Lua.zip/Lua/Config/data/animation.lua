-- 此文件工具自动生成，不要修改
--id	int	11	唯一id[l]
--groupid	char	1024	归属id[l][d]
--name	char	32	名称[l]
--realname	char	32	真实动作名称[l]
--simplename	char	32	对应简单动作名[l]
--layer	int	11	层级[l]
--speed	int	11	播放速度[l]
--wrapmode	int	11	播放模式[l]
--fadelength	float	11	混合百分比[l]
--nextanimation	char	128	下一个动作[l]
--ignoreAvatarSpeed	int	11	是否受攻击速度影响[l]
--sound	int	128	动作音效[l]
--frameEvent	char	256	帧事件[l]
--decoration	char	256	特效[l]
--breakType	int	11	打断类型[l]1移动打断2着路打断
--forbidType	int	11	禁止输入类型[l]
local animation =
{
	{id = 1,	groupid = {"101_male","201_boy"},	name = "plot42_loop",	realname = "plot42_loop",	simplename = "stand",	layer = 1,	speed = 1,	wrapmode = 2,	fadelength = 0.1,	nextanimation = "",	ignoreAvatarSpeed = 0,	sound = 0,	frameEvent = "",	decoration = "10010201",	breakType = 1,	forbidType = 0},
	{id = 1,	groupid = {"102_male","202_female","202_boy","202_girl"},	name = "plot42_loop",	realname = "plot42_loop",	simplename = "stand",	layer = 1,	speed = 1,	wrapmode = 2,	fadelength = 0.1,	nextanimation = "",	ignoreAvatarSpeed = 0,	sound = 0,	frameEvent = "",	decoration = "10020201",	breakType = 1,	forbidType = 0},
	{id = 1,	groupid = {"103_female","203_girl"},	name = "plot42_loop",	realname = "plot42_loop",	simplename = "stand",	layer = 1,	speed = 1,	wrapmode = 2,	fadelength = 0.1,	nextanimation = "",	ignoreAvatarSpeed = 0,	sound = 0,	frameEvent = "",	decoration = "10030201",	breakType = 1,	forbidType = 0},
	{id = 1,	groupid = {"104_male","104_female","204_boy","204_girl"},	name = "plot42_loop",	realname = "plot42_loop",	simplename = "stand",	layer = 1,	speed = 1,	wrapmode = 2,	fadelength = 0.1,	nextanimation = "",	ignoreAvatarSpeed = 0,	sound = 0,	frameEvent = "",	decoration = "10040201",	breakType = 1,	forbidType = 0},
	{id = 1,	groupid = {"105_male","105_female","205_boy","205_girl"},	name = "plot42_loop",	realname = "plot42_loop",	simplename = "stand",	layer = 1,	speed = 1,	wrapmode = 2,	fadelength = 0.1,	nextanimation = "",	ignoreAvatarSpeed = 0,	sound = 0,	frameEvent = "",	decoration = "10050201",	breakType = 1,	forbidType = 0},
}

return animation