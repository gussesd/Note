-- 此文件工具自动生成，不要修改
--id	int	256	id[l]
--name	char	256	描述[l]
--type	int	11	shader类型[l]1溶解2高亮3抖动裁切4元素视野5石化6冰冻7灼烧9自发光颜色
--numParams	char	256	数字参数[l][d]
--stringParams	char	256	字符串参数[l][d]
local shader =
{
	{id = 1000,	name = "溶解示例",	type = 1,	numParams = "",	stringParams = ""},
	{id = 2000,	name = "高亮示例",	type = 2,	numParams = {1,5,255,255,255,255},	stringParams = ""},
	{id = 2001,	name = "采集物边缘光",	type = 2,	numParams = {1,5,191,166,93,255},	stringParams = ""},
	{id = 3000,	name = "抖动裁切示例",	type = 3,	numParams = {0.7},	stringParams = ""},
	{id = 4001,	name = "元素视野(风)",	type = 4,	numParams = {0.5,0x55,0xed,0xc8,0},	stringParams = ""},
	{id = 4002,	name = "元素视野(雷)",	type = 4,	numParams = {0.5,0x66,0xa9,0xff,0},	stringParams = ""},
	{id = 4003,	name = "元素视野(毒)",	type = 4,	numParams = {0.5,0xed,0x67,0xeb,0},	stringParams = ""},
	{id = 4004,	name = "元素视野(水)",	type = 4,	numParams = {0.5,0x5a,0xd7,0xf2,0},	stringParams = ""},
	{id = 4005,	name = "元素视野(火)",	type = 4,	numParams = {0.5,0xfa,0x86,0x6e,0},	stringParams = ""},
	{id = 4006,	name = "元素视野(土)",	type = 4,	numParams = {0.5,0xf1,0xbd,0x4e,0},	stringParams = ""},
	{id = 4007,	name = "元素视野(圣)",	type = 4,	numParams = {0.5,0xf1,0xef,0x4e,0},	stringParams = ""},
	{id = 4008,	name = "元素视野(暗)",	type = 4,	numParams = {0.5,0xb2,0x79,0xf9,0},	stringParams = ""},
	{id = 5000,	name = "石化示例",	type = 5,	numParams = {1},	stringParams = ""},
	{id = 6000,	name = "冰冻示例",	type = 6,	numParams = {1},	stringParams = ""},
	{id = 7000,	name = "灼烧示例",	type = 7,	numParams = {1,100},	stringParams = ""},
	{id = 8000,	name = "半透明示例",	type = 8,	numParams = {0.7},	stringParams = ""},
	{id = 9000,	name = "佛怒唐莲",	type = 4,	numParams = {1,251,245,107,0},	stringParams = ""},
	{id = 10000,	name = "瓢虫草不发光",	type = 9,	numParams = {2,0,1,0},	stringParams = ""},
	{id = 10001,	name = "瓢虫草一阶发光",	type = 9,	numParams = {18,0.667,1,0},	stringParams = ""},
	{id = 10002,	name = "瓢虫草二阶发光",	type = 9,	numParams = {19,0.667,1,0},	stringParams = ""},
	{id = 10003,	name = "两仪生莲太光转暗",	type = 9,	numParams = {5,1.167,3,1.167},	stringParams = ""},
	{id = 10004,	name = "两仪生莲太暗转光",	type = 9,	numParams = {6,1.167,4,1.167},	stringParams = ""},
	{id = 10005,	name = "两仪生莲太光循环",	type = 9,	numParams = {25,0,24,0},	stringParams = ""},
	{id = 10006,	name = "两仪生莲太暗循环",	type = 9,	numParams = {7,0,8,0},	stringParams = ""},
	{id = 10007,	name = "元素龟不发光",	type = 9,	numParams = {17,2,0,0},	stringParams = ""},
	{id = 10008,	name = "暗元素龟纹路",	type = 9,	numParams = {9,2,0,0},	stringParams = ""},
	{id = 10009,	name = "火元素龟纹路",	type = 9,	numParams = {10,2,0,0},	stringParams = ""},
	{id = 10010,	name = "光元素龟纹路",	type = 9,	numParams = {11,2,0,0},	stringParams = ""},
	{id = 10011,	name = "毒元素龟纹路",	type = 9,	numParams = {12,2,0,0},	stringParams = ""},
	{id = 10012,	name = "土元素龟纹路",	type = 9,	numParams = {13,2,0,0},	stringParams = ""},
	{id = 10013,	name = "雷元素龟纹路",	type = 9,	numParams = {14,2,0,0},	stringParams = ""},
	{id = 10014,	name = "水元素龟纹路",	type = 9,	numParams = {15,2,0,0},	stringParams = ""},
	{id = 10015,	name = "风元素龟纹路",	type = 9,	numParams = {16,2,0,0},	stringParams = ""},
	{id = 10016,	name = "瓢虫草二转一",	type = 9,	numParams = {21,1,0,0},	stringParams = ""},
	{id = 10017,	name = "瓢虫草一转二",	type = 9,	numParams = {20,1,0,0},	stringParams = ""},
	{id = 10018,	name = "瓢虫草一转常",	type = 9,	numParams = {22,1,0,0},	stringParams = ""},
	{id = 10019,	name = "瓢虫草常转一",	type = 9,	numParams = {23,1,0,0},	stringParams = ""},
	{id = 21200,	name = "踏雷飞豹逐渐透明",	type = 8,	numParams = {1,0.1,0},	stringParams = ""},
	{id = 21201,	name = "踏雷飞豹逐渐实体",	type = 8,	numParams = {0,0.1,1},	stringParams = ""},
	{id = 22101,	name = "迅疾螳螂逐渐透明",	type = 8,	numParams = {1,0.2,0.1},	stringParams = ""},
	{id = 22102,	name = "迅疾螳螂逐渐实体",	type = 8,	numParams = {0.1,0.2,1},	stringParams = ""},
}

return shader