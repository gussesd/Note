-- 此文件工具自动生成，不要修改
--id	int	11	道具类型id，对应道具表select_type[l]
--name	char	16	类型名[l]
--bag_tab	int	11	背包物品分类（0不显示、1装备、2消耗品、3材料、5镶嵌、6魂骨、7任务、8工具）[l]
local item_select_type =
{
	{id = 1,	name = "金魂币",	bag_tab = 0},
	{id = 2,	name = "银魂币",	bag_tab = 0},
	{id = 3,	name = "铜魂币",	bag_tab = 0},
	{id = 4,	name = "星宇辉印",	bag_tab = 0},
	{id = 5,	name = "神耀辉印",	bag_tab = 0},
	{id = 6,	name = "战令代币",	bag_tab = 0},
	{id = 7,	name = "宗门贡献",	bag_tab = 0},
	{id = 8,	name = "战令经验",	bag_tab = 0},
	{id = 9,	name = "魂力修为",	bag_tab = 0},
	{id = 10,	name = "赛季资金",	bag_tab = 0},
	{id = 11,	name = "生产点数",	bag_tab = 0},
	{id = 12,	name = "九彩龙晶",	bag_tab = 0},
	{id = 13,	name = "晶华魂钻",	bag_tab = 0},
	{id = 14,	name = "赛季个人积分",	bag_tab = 0},
	{id = 22,	name = "体力",	bag_tab = 0},
	{id = 31,	name = "前尘忆念·玄天",	bag_tab = 0},
	{id = 32,	name = "前尘忆念·御宝",	bag_tab = 0},
	{id = 33,	name = "前尘忆念·百解",	bag_tab = 0},
	{id = 103,	name = "丹药",	bag_tab = 2},
	{id = 104,	name = "药品",	bag_tab = 2},
	{id = 105,	name = "烹饪",	bag_tab = 2},
	{id = 112,	name = "修炼卡",	bag_tab = 2},
	{id = 113,	name = "藏宝图",	bag_tab = 2},
	{id = 1002,	name = "时装券",	bag_tab = 3},
	{id = 1003,	name = "材料",	bag_tab = 3},
	{id = 1004,	name = "激活卡",	bag_tab = 2},
	{id = 1007,	name = "任务",	bag_tab = 7},
	{id = 1008,	name = "魂导器",	bag_tab = 8},
	{id = 1010,	name = "仙草",	bag_tab = 3},
	{id = 1011,	name = "魂环养成",	bag_tab = 3},
	{id = 1012,	name = "配方",	bag_tab = 2},
	{id = 1100,	name = "养成道具",	bag_tab = 2},
	{id = 3000,	name = "元素果实",	bag_tab = 2},
	{id = 13001,	name = "镐",	bag_tab = 8},
	{id = 13101,	name = "斧",	bag_tab = 8},
	{id = 13201,	name = "鱼竿",	bag_tab = 8},
	{id = 13301,	name = "鱼饵",	bag_tab = 8},
	{id = 14550,	name = "宝箱",	bag_tab = 2},
	{id = 14571,	name = "礼物",	bag_tab = 2},
	{id = 14576,	name = "魂兽内丹",	bag_tab = 0},
}

return item_select_type