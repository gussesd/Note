-- 此文件工具自动生成，不要修改
--id	int	11	材质类型值(约定值，不可修改)[l]
--name	char	16	名称[l]
--minspeed	float	16	最小受伤速度[l]
--maxspeed	float	16	最大受伤速度[l]
--param	float	16	材质系数[l]
local map_terrain_params =
{
	{id = 256,	name = "金属",	minspeed = 30,	maxspeed = 80,	param = 1},
	{id = 512,	name = "木头",	minspeed = 30,	maxspeed = 80,	param = 0.95},
	{id = 513,	name = "草地",	minspeed = 30,	maxspeed = 80,	param = 0.9},
	{id = 1024,	name = "水",	minspeed = 30,	maxspeed = 80,	param = 0.618},
	{id = 1025,	name = "雪",	minspeed = 30,	maxspeed = 80,	param = 0.7},
	{id = 2048,	name = "土地",	minspeed = 30,	maxspeed = 80,	param = 1},
	{id = 2049,	name = "沙地",	minspeed = 30,	maxspeed = 80,	param = 0.95},
	{id = 2050,	name = "石头",	minspeed = 30,	maxspeed = 80,	param = 1},
	{id = 2051,	name = "粘土",	minspeed = 30,	maxspeed = 80,	param = 0.95},
}

return map_terrain_params