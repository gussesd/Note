-- 此文件工具自动生成，不要修改
--id	int	11	id[l]
--type	int	11	天气（天气类型 0.无天气 1.雨 2.雪 3.雾)[l]
--audio	int	11	音频资源id[l]
local weather_settings =
{
	{id = 1,	type = 1,	audio = 14012},
	{id = 2,	type = 2,	audio = 14006},
}

return weather_settings