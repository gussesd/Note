-- 此文件工具自动生成，不要修改
--type	int	11	类型（64进1，淘汰赛）[l]
--state	int	11	1筛选并分组2第一场比赛3第二场比赛4第三场比赛[l]
--time	int	11	时间戳[l]
local activity_final_arena =
{
	{type = 1,	state = 1,	time = 1709956800},
	{type = 1,	state = 2,	time = 1710075600},
	{type = 1,	state = 3,	time = 1710076200},
	{type = 1,	state = 4,	time = 1710076800},
	{type = 2,	state = 1,	time = 1710077460},
	{type = 2,	state = 2,	time = 1710162000},
	{type = 2,	state = 3,	time = 1710162600},
	{type = 2,	state = 4,	time = 1710163200},
	{type = 3,	state = 1,	time = 1710163860},
	{type = 3,	state = 2,	time = 1710248400},
	{type = 3,	state = 3,	time = 1710249000},
	{type = 3,	state = 4,	time = 1710249600},
	{type = 4,	state = 1,	time = 1710250260},
	{type = 4,	state = 2,	time = 1710334800},
	{type = 4,	state = 3,	time = 1710335400},
	{type = 4,	state = 4,	time = 1710336000},
	{type = 5,	state = 1,	time = 1710336660},
	{type = 5,	state = 2,	time = 1710507600},
	{type = 5,	state = 3,	time = 1710509400},
	{type = 5,	state = 4,	time = 1710511200},
	{type = 6,	state = 1,	time = 1710513060},
	{type = 6,	state = 2,	time = 1710594000},
	{type = 6,	state = 3,	time = 1710594600},
	{type = 6,	state = 4,	time = 1710595200},
	{type = 7,	state = 1,	time = 1710595860},
	{type = 7,	state = 2,	time = 1710680400},
	{type = 7,	state = 3,	time = 1710681000},
	{type = 7,	state = 4,	time = 1710681600},
	{type = 8,	state = 1,	time = 1710682260},
	{type = 8,	state = 2,	time = 1710766800},
	{type = 8,	state = 3,	time = 1710767400},
	{type = 8,	state = 4,	time = 1710768000},
	{type = 9,	state = 1,	time = 1710768660},
	{type = 9,	state = 2,	time = 1710853200},
	{type = 9,	state = 3,	time = 1710853800},
	{type = 9,	state = 4,	time = 1710854400},
	{type = 10,	state = 1,	time = 1710855060},
}

return activity_final_arena