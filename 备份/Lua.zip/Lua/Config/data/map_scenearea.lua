-- 此文件工具自动生成，不要修改
--id	int	11	唯一[l]
--mapid	int	11	地图id[l]
--type	int	11	类型(1.普通 2.渔场 3.光幕)[l]
--geometry	int	11	geometry.cfg对应id[l]
--tag	char	128	自身标签[l]
--triggerTags	char	128	触发Tag标记(对应Enum.lua中的ColliderMask)[l][DMH]
local map_scenearea =
{
	{id = 1000,	mapid = 1001,	type = 2,	geometry = 2,	tag = "water",	triggerTags = {1}},
	{id = 80001,	mapid = 1000,	type = 2,	geometry = 80001,	tag = "water",	triggerTags = {1}},
	{id = 80002,	mapid = 1000,	type = 2,	geometry = 80002,	tag = "water",	triggerTags = {1}},
	{id = 80003,	mapid = 1000,	type = 2,	geometry = 80003,	tag = "water",	triggerTags = {1}},
}

return map_scenearea