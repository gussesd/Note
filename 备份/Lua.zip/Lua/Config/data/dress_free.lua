-- 此文件工具自动生成，不要修改
--index	int	11	序号[sl:i][l]
--step	int	11	阶段(1-创角送2-长大后)[sl:i][l]
--type	int	11	部位[sl:i][l]
--dress_id	int	11	id[sl:i][l]
--job	int	11	限定宗族（0不限1白虎2昊天3灵猫4凤凰5琉璃）[sl:i][l]
--sex	int	11	性别（0男1女2不限）[sl:i][l]
local dress_free =
{
	{index = 1,	step = 1,	type = 2,	dress_id = 1,	job = 1,	sex = 0},
	{index = 2,	step = 1,	type = 2,	dress_id = 2,	job = 2,	sex = 0},
	{index = 3,	step = 1,	type = 2,	dress_id = 3,	job = 2,	sex = 1},
	{index = 4,	step = 1,	type = 2,	dress_id = 4,	job = 4,	sex = 0},
	{index = 5,	step = 1,	type = 2,	dress_id = 5,	job = 4,	sex = 1},
	{index = 6,	step = 1,	type = 2,	dress_id = 6,	job = 3,	sex = 1},
	{index = 7,	step = 1,	type = 2,	dress_id = 7,	job = 5,	sex = 0},
	{index = 8,	step = 1,	type = 2,	dress_id = 8,	job = 5,	sex = 1},
}

return dress_free