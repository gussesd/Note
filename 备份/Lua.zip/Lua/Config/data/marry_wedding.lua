-- 此文件工具自动生成，不要修改
--id	int	11	编号[sl][l]
--name	char	16	名字[sl][l]
--ring	int	11	戒指id[sl][l]
--cost	char	16	消耗[sl:vv][l][DMH]
--reward_items	char	64	奖励道具(道具ID：类型：数量)[l][sl:ct]
--limit	int	11	同一时段限制场次[sl][l]
--time	char	32	时间信息start(小时),end(小时),持续时间(分)[sl:v][l]
--returngift	char	16	随礼金额选项(itemid:tp:num|itemid:tp:num)[sl:vv][l]
--redpacket	char	16	红包金额选项(itemid:tp:num:limit|itemid:tp:num:limit)[sl:vv][l]
--rednum	char	16	红包人数范围[sl:v][l][DMH]
--candies	int	11	喜糖邮件[sl][l]
--invitation	int	11	请柬邮件[sl][l]
--map	char	11	庆典场地[sl][l]
--desc	char	256	描述[l]
--story	int	11	故事ID[sl][l]
local marry_wedding =
{
	{id = 1,	name = "私定终身",	ring = 3,	cost = {1,1,800000},	reward_items = {{14703,1,1},{9205,1,5},{231,1,5}},	limit = 0,	time = "",	returngift = "",	redpacket = "",	rednum = {0},	candies = 0,	invitation = 0,	map = "",	desc = "结伴时装{7}天\n私定终身戒指\n私定终生结伴礼包\n全服公告",	story = 0},
	{id = 2,	name = "梦幻庆典",	ring = 4,	cost = {12,1,520},	reward_items = {{14704,1,1},{9205,1,15},{245,1,15},{231,1,15}},	limit = 10,	time = {{10,22,30}},	returngift = {{1,1,10000},{13,1,250},{12,1,1}},	redpacket = {{1,1,10000,1},{13,1,250,1},{12,1,1,-1}},	rednum = {10,20},	candies = 43,	invitation = 42,	map = "冰火两仪眼",	desc = "结伴时装{30}天\n相濡以沫戒指\n冰火两仪眼梦幻主题庆典\n相濡以沫结伴礼包\n全服公告\n喜糖、请柬*15/人",	story = 90000},
	{id = 3,	name = "皇家庆典",	ring = 5,	cost = {12,1,1314},	reward_items = {{14705,1,1},{9205,1,30},{245,1,30},{231,1,30}},	limit = 1,	time = {{10,22,30}},	returngift = {{1,1,10000},{13,1,250},{12,1,1}},	redpacket = {{1,1,10000,1},{13,1,250,1},{12,1,1,-1}},	rednum = {10,40},	candies = 43,	invitation = 42,	map = "天斗皇宫",	desc = "结伴时装{永久}\n天长地久戒指\n皇家马车主城巡游\n天斗皇家主题庆典\n天长地久结伴礼包\n全服公告\n喜糖、请柬*30/人",	story = 90001},
}

return marry_wedding