-- 此文件工具自动生成，不要修改
--id	int	11	唯一编号[sl][l]
--type	int	11	1表示天数,2表示周年[sl][l]
--val	int	11	type对应数值[sl][l]
local marry_day =
{
	{id = 1,	type = 1,	val = 30},
	{id = 2,	type = 1,	val = 60},
	{id = 3,	type = 2,	val = 1},
}

return marry_day