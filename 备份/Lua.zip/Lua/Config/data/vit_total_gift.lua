-- 此文件工具自动生成，不要修改
--id	int	11	活跃度累计奖励ID[sl][l]
--min	int	11	最小次数[sl][l]
--max	int	11	最大次数[sl][l]
--vit	int	11	活跃度[sl][l]
--gift	char	128	礼包[sl:ct][l]
local vit_total_gift =
{
	{id = 1,	min = 1,	max = 1,	vit = 300,	gift = {{218,1,1}}},
	{id = 2,	min = 2,	max = 2,	vit = 300,	gift = {{13,1,50}}},
	{id = 3,	min = 3,	max = 3,	vit = 300,	gift = {{13,1,200}}},
	{id = 4,	min = 4,	max = 4,	vit = 300,	gift = {{13,1,400}}},
	{id = 5,	min = 5,	max = 999,	vit = 300,	gift = {{13,1,600}}},
}

return vit_total_gift