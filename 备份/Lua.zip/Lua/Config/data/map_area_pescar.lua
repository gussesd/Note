-- 此文件工具自动生成，不要修改
--id	int	11	map_scenearea关联id[l]
--forward	int	11	朝向[l]
--group	int	11	掉落组[sl][l]
local map_area_pescar =
{
	{id = 1,	forward = 0,	group = 1},
	{id = 2,	forward = 251,	group = 1},
	{id = 10001,	forward = 0,	group = 1},
	{id = 80001,	forward = 353,	group = 1},
	{id = 80003,	forward = 25,	group = 801},
	{id = 80201,	forward = 222,	group = 2},
	{id = 100009,	forward = 0,	group = 2},
}

return map_area_pescar