-- 此文件工具自动生成，不要修改
--id	int	11	任务ID[l][sl:i]
--name	char	64	任务名[l]
--type	int	11	任务类型[l][sl:i]
--level	int	11	等级[l][sl:i]
--pretask	char	128	前置任务[l][sl:v]
--exp	int	11	经验奖励[l][sl:i]
--oldring	int	11	当前戒指id(marry_ring表id)[l][sl:i]
--ringid	int	11	新戒指id(marry_ring表id)[l][sl:i]
--del_items	char	64	删除道具(道具ID：类型：数量)[l][sl:ct]
--reward_items	char	64	奖励道具(道具ID：类型：数量)[l][sl:ct]
--condition_info	char	128	任务进度描述[l][DMH]
--condition_special	char	64	任务完成特殊处理[l][sl:v]
--condition_list	char	1024	完成任务类型[l][sl:vv]
local task_marry_ring =
{
	{id = 10101,	name = "升级为梦幻戒指",	type = 13,	level = 1,	pretask = "",	exp = 10,	oldring = 3,	ringid = 4,	del_items = {{242,1,1}},	reward_items = {{243,1,1}},	condition_info = {"获得水纹蓝鳐*5"},	condition_special = "",	condition_list = {{16,2714,5,10000,2600004}}},
	{id = 10102,	name = "升级为梦幻戒指",	type = 13,	level = 1,	pretask = "",	exp = 10,	oldring = 4,	ringid = 5,	del_items = {{243,1,1}},	reward_items = {{244,1,1}},	condition_info = {"获得水纹蓝鳐*10"},	condition_special = "",	condition_list = {{16,2714,10,10000,2600004}}},
	{id = 10103,	name = "升级为梦幻戒指",	type = 13,	level = 1,	pretask = "",	exp = 10,	oldring = 3,	ringid = 5,	del_items = {{242,1,1}},	reward_items = {{244,1,1}},	condition_info = {"获得水纹蓝鳐*15"},	condition_special = "",	condition_list = {{16,2714,15,10000,2600004}}},
}

return task_marry_ring