-- 此文件工具自动生成，不要修改
--id	int	11	购买次数[l][#][sl:i]
--cost	int	11	花费充值货币[l][#][sl:i]
--gain	int	11	获得体力[l][#][sl:i]
--use_bind	int	11	能否使用绑定货币购买[l][#][sl:i]
--zanzhu_level	int	11	赞助等级[l][#][sl:i]
local tili =
{
	{id = 1,	cost = 50,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 2,	cost = 50,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 3,	cost = 100,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 4,	cost = 100,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 5,	cost = 150,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 6,	cost = 150,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 7,	cost = 200,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 8,	cost = 200,	gain = 60,	use_bind = 1,	zanzhu_level = 0},
	{id = 9,	cost = 250,	gain = 60,	use_bind = 1,	zanzhu_level = 4},
	{id = 10,	cost = 250,	gain = 60,	use_bind = 1,	zanzhu_level = 4},
	{id = 11,	cost = 250,	gain = 60,	use_bind = 1,	zanzhu_level = 4},
	{id = 12,	cost = 250,	gain = 60,	use_bind = 1,	zanzhu_level = 4},
	{id = 13,	cost = 300,	gain = 60,	use_bind = 1,	zanzhu_level = 5},
	{id = 14,	cost = 300,	gain = 60,	use_bind = 1,	zanzhu_level = 5},
	{id = 15,	cost = 300,	gain = 60,	use_bind = 1,	zanzhu_level = 5},
	{id = 16,	cost = 300,	gain = 60,	use_bind = 1,	zanzhu_level = 5},
	{id = 17,	cost = 350,	gain = 60,	use_bind = 1,	zanzhu_level = 6},
	{id = 18,	cost = 350,	gain = 60,	use_bind = 1,	zanzhu_level = 6},
	{id = 19,	cost = 350,	gain = 60,	use_bind = 1,	zanzhu_level = 6},
	{id = 20,	cost = 350,	gain = 60,	use_bind = 1,	zanzhu_level = 6},
}

return tili