-- 此文件工具自动生成，不要修改
--id	int	11	活动id[l]
--name	char	16	活动名[l]
--index	int	11	序列[l]
--start_time	int	11	开始时间(时间戳)[l]
--end_time	int	11	结束时间(时间戳)[l]
--title	char	1024	标题[l]
--desc	char	1024	描述[l]
local activity_time =
{
	{id = 101,	name = "参赛报名",	index = 1,	start_time = 1690128000,	end_time = 1709913599,	title = "报名阶段",	desc = "组建7人战队报名参赛"},
	{id = 101,	name = "预选赛",	index = 2,	start_time = 1690300800,	end_time = 1709913599,	title = "预选阶段",	desc = "跻身前512强进入争霸"},
	{id = 101,	name = "晋级赛",	index = 3,	start_time = 1709913600,	end_time = 1711468800,	title = "决赛阶段",	desc = "晋级赛决出冠军"},
}

return activity_time