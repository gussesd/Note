-- 此文件工具自动生成，不要修改
--id	int	11	ID[sl:i][l]
--type	int	11	类型1参战次数 2个人积分达到 3占领1次不同等级的据点[l][sl]
--index	int	11	档位[l][sl]
--num	int	11	数量[l][sl]
--reward	char	64	奖励[l][sl:vv]
--desc	char	64	描述[l]
local zone_achievement =
{
	{id = 101,	type = 1,	index = 1,	num = 2,	reward = {{13,1,10},{222,1,1}},	desc = "参与2场城战"},
	{id = 102,	type = 1,	index = 2,	num = 4,	reward = {{13,1,15},{222,1,1}},	desc = "参与4场城战"},
	{id = 103,	type = 1,	index = 3,	num = 6,	reward = {{13,1,20},{222,1,2}},	desc = "参与6场城战"},
	{id = 104,	type = 1,	index = 4,	num = 8,	reward = {{13,1,25},{223,1,2}},	desc = "参与8场城战"},
	{id = 105,	type = 1,	index = 5,	num = 10,	reward = {{13,1,30},{223,1,3}},	desc = "参与10场城战"},
	{id = 201,	type = 2,	index = 1,	num = 100,	reward = {{13,1,20},{8851,1,2}},	desc = "赛季个人积分达100"},
	{id = 202,	type = 2,	index = 2,	num = 400,	reward = {{13,1,40},{8851,1,4}},	desc = "赛季个人积分达400"},
	{id = 203,	type = 2,	index = 3,	num = 1000,	reward = {{13,1,60},{8851,1,6}},	desc = "赛季个人积分达1000"},
	{id = 204,	type = 2,	index = 4,	num = 2000,	reward = {{13,1,80},{8851,1,8}},	desc = "赛季个人积分达2000"},
	{id = 301,	type = 3,	index = 1,	num = 1,	reward = {{13,1,20},{211,1,2}},	desc = "占领1次1级据点"},
	{id = 302,	type = 3,	index = 2,	num = 2,	reward = {{13,1,40},{211,1,4}},	desc = "占领1次2级据点"},
	{id = 303,	type = 3,	index = 3,	num = 3,	reward = {{13,1,60},{211,1,6}},	desc = "占领1次3级据点"},
	{id = 304,	type = 3,	index = 4,	num = 4,	reward = {{13,1,80},{211,1,8}},	desc = "占领1次4级据点"},
}

return zone_achievement