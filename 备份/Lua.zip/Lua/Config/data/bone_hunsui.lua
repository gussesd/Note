-- 此文件工具自动生成，不要修改
--level	int	11	魂髓等级[sl][l]
--exp	int	11	升到本级需要经验[sl][l]
--need_order	int	11	需要等阶[sl][l]
--master_level	int	11	需要大师等级[sl][l]
--recycle_exp	int	11	本级返还总经验[sl][l]
local bone_hunsui =
{
	{level = 1,	exp = 1000,	need_order = 1,	master_level = 1,	recycle_exp = 0},
	{level = 2,	exp = 250,	need_order = 2,	master_level = 1,	recycle_exp = 250},
	{level = 3,	exp = 250,	need_order = 3,	master_level = 1,	recycle_exp = 500},
	{level = 4,	exp = 375,	need_order = 4,	master_level = 3,	recycle_exp = 875},
	{level = 5,	exp = 375,	need_order = 5,	master_level = 3,	recycle_exp = 1250},
	{level = 6,	exp = 500,	need_order = 6,	master_level = 3,	recycle_exp = 1750},
	{level = 7,	exp = 625,	need_order = 7,	master_level = 6,	recycle_exp = 2375},
	{level = 8,	exp = 625,	need_order = 8,	master_level = 6,	recycle_exp = 3000},
	{level = 9,	exp = 1000,	need_order = 9,	master_level = 6,	recycle_exp = 4000},
	{level = 10,	exp = 1000,	need_order = 10,	master_level = 10,	recycle_exp = 5000},
	{level = 11,	exp = 1000,	need_order = 11,	master_level = 10,	recycle_exp = 6000},
	{level = 12,	exp = 1750,	need_order = 12,	master_level = 10,	recycle_exp = 7750},
	{level = 13,	exp = 2500,	need_order = 13,	master_level = 15,	recycle_exp = 10250},
	{level = 14,	exp = 5000,	need_order = 14,	master_level = 15,	recycle_exp = 15250},
	{level = 15,	exp = 15000,	need_order = 15,	master_level = 15,	recycle_exp = 30250},
}

return bone_hunsui