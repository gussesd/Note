-- 此文件工具自动生成，不要修改
--id	int	11	序号[l][#][sl:i]
--name	char	16	名称[l]
--type	int	11	类型[l][sl:i]
local dialogue_camera =
{
}

return dialogue_camera