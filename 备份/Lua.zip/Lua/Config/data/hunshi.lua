-- 此文件工具自动生成，不要修改
--grade	int	11	魂师级别[l][#][sl:i]
--level	int	11	最大等级[l][sl:i]
--hunhuannum	int	11	拥有魂环数量[l][sl:i]
--hunhuanyear	int	11	魂环年限上限[l][sl:i]
--yearratio	int	11	魂环年限换算系数[l][sl:i]
local hunshi =
{
	{grade = 0,	level = 10,	hunhuannum = 0,	hunhuanyear = 0,	yearratio = 0},
	{grade = 1,	level = 20,	hunhuannum = 1,	hunhuanyear = 500,	yearratio = 6300},
	{grade = 2,	level = 30,	hunhuannum = 2,	hunhuanyear = 1000,	yearratio = 31300},
	{grade = 3,	level = 40,	hunhuannum = 3,	hunhuanyear = 5000,	yearratio = 166700},
	{grade = 4,	level = 50,	hunhuannum = 4,	hunhuanyear = 10000,	yearratio = 208300},
	{grade = 5,	level = 60,	hunhuannum = 5,	hunhuanyear = 25000,	yearratio = 468800},
	{grade = 6,	level = 70,	hunhuannum = 6,	hunhuanyear = 50000,	yearratio = 625000},
	{grade = 7,	level = 80,	hunhuannum = 7,	hunhuanyear = 75000,	yearratio = 520800},
	{grade = 8,	level = 90,	hunhuannum = 8,	hunhuanyear = 100000,	yearratio = 446400},
	{grade = 9,	level = 95,	hunhuannum = 9,	hunhuanyear = 125000,	yearratio = 390600},
}

return hunshi