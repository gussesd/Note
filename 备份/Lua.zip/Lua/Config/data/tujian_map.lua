-- 此文件工具自动生成，不要修改
--id	int	11	地图图鉴id[sl:i][l]
--type	int	11	图鉴类型(1-势力 2-世界 3-风景 4-探索 5-副本)[sl:i][l]
--page	int	11	图鉴子页(5:id_group)[sl:i][l]
--title	char	64	标题[l]
--content	char	64	内容介绍[l]
--score	int	11	图鉴积分[sl:i][l]
--reward	char	64	奖励[sl:vv][l]
--mapimg	char	64	配图()[l]
--unlockjiguanid	int	11	解锁机关实例id[l]
local tujian_map =
{
	{id = 1,	type = 3,	page = 1,	title = "曦光映夕",	content = "非常美",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_1",	unlockjiguanid = 5000001},
	{id = 2,	type = 3,	page = 2,	title = "木野一溪谣",	content = "非常美1",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_2",	unlockjiguanid = 5000002},
	{id = 3,	type = 3,	page = 3,	title = "斗魂霓彩",	content = "非常2",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_3",	unlockjiguanid = 5000003},
	{id = 4,	type = 3,	page = 4,	title = "华宇青垣",	content = "非常美3",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_4",	unlockjiguanid = 0},
	{id = 5,	type = 3,	page = 5,	title = "孤崖翠影",	content = "非常4",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_5",	unlockjiguanid = 0},
	{id = 6,	type = 3,	page = 6,	title = "夜华琉璃阁",	content = "非常美5",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_6",	unlockjiguanid = 0},
	{id = 7,	type = 3,	page = 7,	title = "苍峦轻云",	content = "非常美6",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_7",	unlockjiguanid = 0},
	{id = 8,	type = 3,	page = 8,	title = "金盏流光",	content = "非常美",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_8",	unlockjiguanid = 0},
	{id = 9,	type = 3,	page = 9,	title = "人间道",	content = "非常美",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_9",	unlockjiguanid = 0},
	{id = 10,	type = 3,	page = 10,	title = "学树无涯",	content = "非常美",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_10",	unlockjiguanid = 0},
	{id = 11,	type = 3,	page = 11,	title = "三十三天外",	content = "非常美",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_11",	unlockjiguanid = 0},
	{id = 12,	type = 3,	page = 12,	title = "仙泉蕴灵",	content = "非常美",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "scene_12",	unlockjiguanid = 0},
	{id = 13,	type = 5,	page = 201,	title = "猎魂森林",	content = "帝国圈养魂兽的森林，由帝国士兵和武魂殿执法团共同负责看管。想要进入需获得武魂殿颁发的手令，里面多为一些中低级魂兽。",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 14,	type = 5,	page = 82509,	title = "神坛遗迹",	content = "恢弘却坍塌过的神殿，空旷幽长的步道，无声诉说着某段不为人知的上古故事。这里曾供奉过一位神明，但难知其身份，只有大殿内巨型的浮雕，沉默的塑像，在寂然中注视着彼此……",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 15,	type = 5,	page = 502,	title = "器魂封地",	content = "矿石和故土也有故事，只有岁月在无声见证。残存的上古器之魂心有不甘，满腹都是意难平，堕落的矿岩领主，让其在反复的偏执下疯狂成魔。",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 16,	type = 5,	page = 402,	title = "疾螂之麓",	content = "原本是林间一只普通魂兽，却意外吸食散落的龙王泪滴，拥有了龙王血脉而能力倍增，超乎寻常。\n 速度惊人的螳螂宛若疾风窜行与山林间，是自由的，却又是被禁锢的。\n 它只能在这一方山麓林间随意行动，但永远无法离开。",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 17,	type = 5,	page = 403,	title = "法龙之原",	content = "原本是平原上一只魂兽魂灵，却意外沾染了散落的龙王泪滴，拥有了龙王血脉得以幻化成灵力非凡的法龙。\n 长久徘徊于一方天地间，它忍不住开始思考一些高深莫测的东西。也许是关于魂力，也许是关于存亡，或是关于它自己。",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 18,	type = 5,	page = 405,	title = "巨熊之森",	content = "原本是林中一只普通魂兽，却意外吸食散落的龙王泪滴，拥有了龙王血脉而能力倍增，力大无穷。\n 据经过附近森林的猎户说，偶尔能听见自林间深处传来的兽吼，竟像是龙的悲鸣。可他们记得，那深处只有一只巨熊啊……",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 19,	type = 5,	page = 404,	title = "蛇女之楣",	content = "原本是山间一只普通魂兽，却意外吸食散落的龙王泪滴，化身为了拥有龙王血脉的美杜莎。\n 传说她守在这里迟迟不离，是有执念。有人说，她是希望能再见一面心爱之人，也有人说，她是在等待负心之人。\n 真相如何，只有天知地知山知水知，她心知……",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 20,	type = 5,	page = 304,	title = "水之神殿",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「万物之水，水渡万物。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 21,	type = 5,	page = 303,	title = "火之神殿",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「天地之火，火燎天地。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 22,	type = 5,	page = 302,	title = "风之神殿",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「长空之风，风卷长空。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 23,	type = 5,	page = 301,	title = "雷之神殿",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「深云之雷，雷破深云。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 24,	type = 5,	page = 306,	title = "大地神殿",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「大地沉眠，终将苏醒。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 25,	type = 5,	page = 305,	title = "毒神祭坛",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「轮回之苦，无穷无尽。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 26,	type = 5,	page = 308,	title = "光明神殿",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「世间光明，永生不灭。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 27,	type = 5,	page = 307,	title = "黑暗神殿",	content = "封印着某位神明元灵之力的殿宇，有神使的遗魂在此镇守。\n 「世间黑暗，不灭永生。」",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
	{id = 28,	type = 5,	page = 501,	title = "奇花秘境",	content = "万年前由神女栽种在此地的花，受天地精华久久滋养，渐生灵气。\n靠近时能闻到千变万化的香气，所以除了魂师外，调香师亦心向往之。不过其巨毒无比，难以碰触，乃奇花中的仙品。",	score = 1250,	reward = {{13,1,20},{3,1,20000},{221,1,5}},	mapimg = "123",	unlockjiguanid = 0},
}

return tujian_map