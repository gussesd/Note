-- 此文件工具自动生成，不要修改
--id	int	11	配置id[sl][l]
--type	int	11	位置区分（0肢体动作，1轮盘交互）[l]
--index	int	11	位置顺序[l]
--name	char	16	名字[sl][l]
--icon	char	16	资源icon[sl][l]
--animation	char	11	动作名称[sl][l]
local animation_petty =
{
	{id = 1001,	type = 0,	index = 1,	name = "打招呼",	icon = "101",	animation = "DEM_greet"},
	{id = 2001,	type = 1,	index = 4,	name = "展示武魂",	icon = "201",	animation = ""},
	{id = 2002,	type = 1,	index = 1,	name = "打坐",	icon = "202",	animation = "DEM_meditate_start"},
	{id = 2003,	type = 1,	index = 2,	name = "乘骑交互",	icon = "203",	animation = ""},
	{id = 2005,	type = 1,	index = 5,	name = "查看玩家",	icon = "205",	animation = ""},
	{id = 2006,	type = 1,	index = 6,	name = "魂力比拼",	icon = "206",	animation = ""},
	{id = 2007,	type = 1,	index = 7,	name = "传送",	icon = "207",	animation = ""},
}

return animation_petty