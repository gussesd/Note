-- 此文件工具自动生成，不要修改
--id	int	11	map_triggerarea对应id[l][sl]
local map_triggerarea_xiulian =
{
	{id = 8000001},
}

return map_triggerarea_xiulian