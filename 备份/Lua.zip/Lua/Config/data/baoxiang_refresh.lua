-- 此文件工具自动生成，不要修改
--groupid	int	11	组id[l][#][sl:i]
--refresh_limit	int	11	最多补齐到数量[l][sl:i]
--refresh_time	int	11	每次刷新间隔（秒）[l][sl:i]
local baoxiang_refresh =
{
	{groupid = 1,	refresh_limit = 2,	refresh_time = 60},
	{groupid = 2,	refresh_limit = 1,	refresh_time = 30},
	{groupid = 3,	refresh_limit = 100,	refresh_time = 10},
	{groupid = 4,	refresh_limit = 4,	refresh_time = 20},
	{groupid = 5,	refresh_limit = 0,	refresh_time = 315360000},
	{groupid = 6,	refresh_limit = 0,	refresh_time = 315360000},
	{groupid = 100001,	refresh_limit = 0,	refresh_time = 315360000},
}

return baoxiang_refresh