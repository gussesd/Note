-- 此文件工具自动生成，不要修改
--level	int	11	装备星级[sl][l]
--ratio	int	11	天赋属性加成[sl][l]
local equip_star_attr =
{
	{level = 0,	ratio = 0},
	{level = 1,	ratio = 400},
	{level = 2,	ratio = 800},
	{level = 3,	ratio = 1200},
	{level = 4,	ratio = 1600},
	{level = 5,	ratio = 2000},
	{level = 6,	ratio = 2800},
	{level = 7,	ratio = 3600},
	{level = 8,	ratio = 4400},
	{level = 9,	ratio = 5200},
	{level = 10,	ratio = 6000},
	{level = 11,	ratio = 7200},
	{level = 12,	ratio = 8400},
	{level = 13,	ratio = 9600},
	{level = 14,	ratio = 10800},
	{level = 15,	ratio = 12000},
	{level = 16,	ratio = 13600},
	{level = 17,	ratio = 15200},
	{level = 18,	ratio = 16800},
	{level = 19,	ratio = 18400},
	{level = 20,	ratio = 20000},
	{level = 21,	ratio = 22000},
	{level = 22,	ratio = 24000},
	{level = 23,	ratio = 26000},
	{level = 24,	ratio = 28000},
	{level = 25,	ratio = 30000},
}

return equip_star_attr