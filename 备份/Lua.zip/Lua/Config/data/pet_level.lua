-- 此文件工具自动生成，不要修改
--level	int	11	等级[l][#][sl:i]
--flv	int	11	flv值[l][sl:i]
local pet_level =
{
}

return pet_level