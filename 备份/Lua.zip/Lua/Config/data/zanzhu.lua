-- 此文件工具自动生成，不要修改
--level	int	11	赞助等级[sl:i][l]
--gold_unbind	int	11	充值货币[sl:i][l]
--reward	char	64	特权奖励(101:1:1)[sl:vv][l]
--tequan	char	32	特权id(1:2:3)[sl:v][l][DMH]
--name	char	11	赞助名称[l]
--medal_name	char	11	勋章名称[l]
--quality	int	4	道具品质[l]
--btnname	char	11	标签页名称[l]
--diwencard_name	char	11	底纹激活卡名称[l]
local zanzhu =
{
	{level = 1,	gold_unbind = 300,	reward = {{202,1,2},{211,1,10},{200,1,2},{3,1,100000}},	tequan = {4,5,6,7,8,9},	name = "白银赞助商",	medal_name = "baiyin_zzhz",	quality = 1,	btnname = "白银",	diwencard_name = "zanzhu_01"},
	{level = 2,	gold_unbind = 980,	reward = {{202,1,4},{7201,1,2},{200,1,3},{7511,1,15},{3,1,150000}},	tequan = {1,11,14,20,37,10,17},	name = "黄金赞助商",	medal_name = "huangjin_zzhz",	quality = 2,	btnname = "黄金",	diwencard_name = "zanzhu_02"},
	{level = 3,	gold_unbind = 1980,	reward = {{202,1,8},{7503,1,10},{200,1,4},{7502,1,30},{3,1,250000}},	tequan = {21,25,27,29,31,32},	name = "紫金赞助商",	medal_name = "zijin_zzhz",	quality = 3,	btnname = "紫金",	diwencard_name = "zanzhu_03"},
	{level = 4,	gold_unbind = 6480,	reward = {{202,1,20},{211,1,60},{200,1,6},{6530,1,8},{7010,1,8},{3,1,500000}},	tequan = {2,12,15,18,22,33,38},	name = "蓝宝石赞助商",	medal_name = "lanbaoshi_zzhz",	quality = 4,	btnname = "蓝宝石",	diwencard_name = "zanzhu_04"},
	{level = 5,	gold_unbind = 10000,	reward = {{202,1,30},{6712,1,100},{200,1,10},{8851,1,100},{6711,1,600},{3,1,1000000}},	tequan = {23,26,28,30,34,36,39},	name = "红宝石赞助商",	medal_name = "hongbaoshi_zzhz",	quality = 5,	btnname = "红宝石",	diwencard_name = "zanzhu_05"},
	{level = 6,	gold_unbind = 30000,	reward = {{202,1,100},{211,1,300},{200,1,30},{8851,1,200},{6001,1,300},{3,1,5000000}},	tequan = {3,13,16,19,24,35,40},	name = "钻石赞助商",	medal_name = "zuanshi_zzhz",	quality = 6,	btnname = "钻石",	diwencard_name = "zanzhu_06"},
}

return zanzhu