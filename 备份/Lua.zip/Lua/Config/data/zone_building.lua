-- 此文件工具自动生成，不要修改
--id	int	11	编号[l]
--side	int	11	0无主1攻方2守方[l]
--building_type	int	11	建筑类型( 1水晶 2泉水 3防御塔 4据点 5传送点 6出生阻挡)[l]
--road	int	11	路线(0不分路1上路2中路3下路)[l]
--entity_type	int	11	实体类型(填map_monster=2:map_trap=16)[l]
--map_entity	int	11	地图实例id[l]
--map_teleport	char	256	传送点id[l][DMH]
local zone_building =
{
	{id = 100,	side = 1,	building_type = 1,	road = 0,	entity_type = 2,	map_entity = 900113001,	map_teleport = ""},
	{id = 101,	side = 1,	building_type = 2,	road = 0,	entity_type = 2,	map_entity = 900111001,	map_teleport = ""},
	{id = 102,	side = 1,	building_type = 5,	road = 0,	entity_type = 16,	map_entity = 9000103,	map_teleport = ""},
	{id = 103,	side = 1,	building_type = 6,	road = 0,	entity_type = 16,	map_entity = 9000102,	map_teleport = ""},
	{id = 111,	side = 1,	building_type = 3,	road = 2,	entity_type = 2,	map_entity = 900112011,	map_teleport = {90111}},
	{id = 112,	side = 1,	building_type = 3,	road = 3,	entity_type = 2,	map_entity = 900112012,	map_teleport = {90121}},
	{id = 113,	side = 1,	building_type = 3,	road = 1,	entity_type = 2,	map_entity = 900112013,	map_teleport = {90131}},
	{id = 121,	side = 1,	building_type = 3,	road = 2,	entity_type = 2,	map_entity = 900112021,	map_teleport = {90141}},
	{id = 122,	side = 1,	building_type = 3,	road = 3,	entity_type = 2,	map_entity = 900112022,	map_teleport = {90151}},
	{id = 123,	side = 1,	building_type = 3,	road = 1,	entity_type = 2,	map_entity = 900112023,	map_teleport = {90161}},
	{id = 131,	side = 1,	building_type = 3,	road = 2,	entity_type = 2,	map_entity = 900112031,	map_teleport = {90171}},
	{id = 132,	side = 1,	building_type = 3,	road = 3,	entity_type = 2,	map_entity = 900112032,	map_teleport = {90181}},
	{id = 133,	side = 1,	building_type = 3,	road = 1,	entity_type = 2,	map_entity = 900112033,	map_teleport = {90191}},
	{id = 200,	side = 2,	building_type = 1,	road = 0,	entity_type = 2,	map_entity = 900213001,	map_teleport = ""},
	{id = 201,	side = 2,	building_type = 2,	road = 0,	entity_type = 2,	map_entity = 900211001,	map_teleport = ""},
	{id = 202,	side = 2,	building_type = 5,	road = 0,	entity_type = 16,	map_entity = 9000203,	map_teleport = ""},
	{id = 203,	side = 2,	building_type = 6,	road = 0,	entity_type = 16,	map_entity = 9000202,	map_teleport = ""},
	{id = 211,	side = 2,	building_type = 3,	road = 2,	entity_type = 2,	map_entity = 900212011,	map_teleport = {90211}},
	{id = 212,	side = 2,	building_type = 3,	road = 3,	entity_type = 2,	map_entity = 900212012,	map_teleport = {90221}},
	{id = 213,	side = 2,	building_type = 3,	road = 1,	entity_type = 2,	map_entity = 900212013,	map_teleport = {90231}},
	{id = 221,	side = 2,	building_type = 3,	road = 2,	entity_type = 2,	map_entity = 900212021,	map_teleport = {90241}},
	{id = 222,	side = 2,	building_type = 3,	road = 3,	entity_type = 2,	map_entity = 900212022,	map_teleport = {90251}},
	{id = 223,	side = 2,	building_type = 3,	road = 1,	entity_type = 2,	map_entity = 900212023,	map_teleport = {90261}},
	{id = 231,	side = 2,	building_type = 3,	road = 2,	entity_type = 2,	map_entity = 900212031,	map_teleport = {90271}},
	{id = 232,	side = 2,	building_type = 3,	road = 3,	entity_type = 2,	map_entity = 900212032,	map_teleport = {90281}},
	{id = 233,	side = 2,	building_type = 3,	road = 1,	entity_type = 2,	map_entity = 900212033,	map_teleport = {90391}},
	{id = 311,	side = 0,	building_type = 4,	road = 1,	entity_type = 16,	map_entity = 9000311,	map_teleport = ""},
	{id = 312,	side = 0,	building_type = 4,	road = 1,	entity_type = 16,	map_entity = 9000312,	map_teleport = ""},
	{id = 313,	side = 0,	building_type = 4,	road = 1,	entity_type = 16,	map_entity = 9000313,	map_teleport = ""},
	{id = 314,	side = 0,	building_type = 4,	road = 1,	entity_type = 16,	map_entity = 9000314,	map_teleport = ""},
	{id = 315,	side = 0,	building_type = 4,	road = 1,	entity_type = 16,	map_entity = 9000315,	map_teleport = ""},
	{id = 321,	side = 0,	building_type = 4,	road = 2,	entity_type = 16,	map_entity = 9000321,	map_teleport = ""},
	{id = 322,	side = 0,	building_type = 4,	road = 2,	entity_type = 16,	map_entity = 9000322,	map_teleport = ""},
	{id = 323,	side = 0,	building_type = 4,	road = 2,	entity_type = 16,	map_entity = 9000323,	map_teleport = ""},
	{id = 324,	side = 0,	building_type = 4,	road = 2,	entity_type = 16,	map_entity = 9000324,	map_teleport = ""},
	{id = 325,	side = 0,	building_type = 4,	road = 2,	entity_type = 16,	map_entity = 9000325,	map_teleport = ""},
	{id = 331,	side = 0,	building_type = 4,	road = 3,	entity_type = 16,	map_entity = 9000331,	map_teleport = ""},
	{id = 332,	side = 0,	building_type = 4,	road = 3,	entity_type = 16,	map_entity = 9000332,	map_teleport = ""},
	{id = 333,	side = 0,	building_type = 4,	road = 3,	entity_type = 16,	map_entity = 9000333,	map_teleport = ""},
	{id = 334,	side = 0,	building_type = 4,	road = 3,	entity_type = 16,	map_entity = 9000334,	map_teleport = ""},
	{id = 335,	side = 0,	building_type = 4,	road = 3,	entity_type = 16,	map_entity = 9000335,	map_teleport = ""},
}

return zone_building