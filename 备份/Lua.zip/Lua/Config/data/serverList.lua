-- 此文件工具自动生成，不要修改
--id	int	11	唯一，对应服务器组[l]
--sid	int	11	服务器id[l]
--name	char	256	服务器名称[l]
--ip	char	64	服务器ip[l]
--port	int	11	服务器端口[l]
--http	char	512	http服务器[l][FULL]
--face	char	512	捏脸服务器[l][FULL]
local serverList =
{
	{id = 1,	sid = 1,	name = "187",	ip = "192.168.10.187",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 2,	sid = 1,	name = "khx",	ip = "10.40.2.82",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 3,	sid = 1,	name = "fhb",	ip = "10.41.2.58",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 4,	sid = 1,	name = "lj",	ip = "10.42.0.175",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 5,	sid = 1,	name = "cgb",	ip = "10.41.2.10",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 6,	sid = 1,	name = "pqs",	ip = "10.41.1.99",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 7,	sid = 1,	name = "90001",	ip = "s90001-ad-tanwan.dldl-zxcs.zhifeii.com",	port = 8153,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 8,	sid = 1,	name = "本地",	ip = "127.0.0.1",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 9,	sid = 1,	name = "hd",	ip = "10.41.2.68",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 10,	sid = 1,	name = "xh",	ip = "10.41.2.64",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 11,	sid = 1,	name = "cxx",	ip = "10.40.2.50",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 12,	sid = 1,	name = "mzx",	ip = "10.41.3.160",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 13,	sid = 1,	name = "zkj",	ip = "10.43.0.57",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 14,	sid = 1,	name = "lc",	ip = "10.41.2.70",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 15,	sid = 1,	name = "ljx",	ip = "10.43.2.188",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 16,	sid = 1,	name = "lcq",	ip = "10.43.0.114",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 17,	sid = 1,	name = "yzf",	ip = "10.41.3.34",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 18,	sid = 1,	name = "wxt",	ip = "10.42.3.17",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 19,	sid = 1,	name = "qzw",	ip = "10.41.3.28",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 20,	sid = 1,	name = "zmy",	ip = "10.43.0.141",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 21,	sid = 1,	name = "wsj",	ip = "10.41.2.73",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 22,	sid = 1,	name = "lp",	ip = "10.40.2.236",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 23,	sid = 1,	name = "ym",	ip = "10.41.1.63",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 24,	sid = 1,	name = "qh",	ip = "10.43.0.60",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
	{id = 25,	sid = 1,	name = "ccq",	ip = "10.42.4.145",	port = 8002,	http = "http://192.168.10.187/server/server/",	face = "http://192.168.10.187/server/face/"},
}

return serverList