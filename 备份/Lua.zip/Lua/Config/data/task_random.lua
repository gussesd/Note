-- 此文件工具自动生成，不要修改
--id	int	11	ID[l][sl:i]
--type	int	11	任务类型(3学院任务5天斗悬赏6星罗悬赏)[sl:i][l]
--level	char	64	魂师等级范围(min:max)[l][sl:v][DMH]
--gift_task	int	11	领奖励任务id[l][sl]
local task_random =
{
	{id = 1,	type = 3,	level = {15,20},	gift_task = 300000},
	{id = 2,	type = 3,	level = {21,30},	gift_task = 300001},
	{id = 3,	type = 3,	level = {31,40},	gift_task = 300002},
	{id = 4,	type = 3,	level = {41,50},	gift_task = 300003},
	{id = 5,	type = 3,	level = {51,60},	gift_task = 300004},
	{id = 6,	type = 5,	level = {15,20},	gift_task = 0},
	{id = 7,	type = 5,	level = {21,30},	gift_task = 0},
	{id = 8,	type = 5,	level = {31,40},	gift_task = 0},
	{id = 9,	type = 5,	level = {41,50},	gift_task = 0},
	{id = 10,	type = 5,	level = {51,60},	gift_task = 0},
	{id = 11,	type = 6,	level = {15,20},	gift_task = 0},
	{id = 12,	type = 6,	level = {21,30},	gift_task = 0},
	{id = 13,	type = 6,	level = {31,40},	gift_task = 0},
	{id = 14,	type = 6,	level = {41,50},	gift_task = 0},
	{id = 15,	type = 6,	level = {51,60},	gift_task = 0},
}

return task_random