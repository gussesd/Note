-- 此文件工具自动生成，不要修改
--index	int	11	建筑id[l]
--name	char	16	名字[l]
--type	int	11	建筑类型[l]
--pos	char	16	位置[l][d]
--icon	char	16	图标[l]
local family_build_pos =
{
	{index = 1,	name = "力堂",	type = 3,	pos = {128,300},	icon = "li"},
	{index = 2,	name = "武堂",	type = 4,	pos = {256,200},	icon = "wu"},
	{index = 3,	name = "御堂",	type = 5,	pos = {256,450},	icon = "yu"},
	{index = 4,	name = "敏堂",	type = 6,	pos = {526,300},	icon = "min"},
	{index = 5,	name = "药堂",	type = 7,	pos = {700,325},	icon = "yao"},
}

return family_build_pos