-- 此文件工具自动生成，不要修改
--grade	int	11	阶段[l][#][sl:i]
--max_attr	char	256	该阶段职业基础属性上限[l][sl:ct]
--max_attr_num	int	11	该阶段职业基础属性总和[l][sl:i]
--cost_item	char	256	每次升级年限消耗物品[l][sl:ct](物品id:物品类型:物品数量)[DMH]
--num	int	11	每次随机次数(随机区间现在固定是3-5)[l][sl:i]
--level	int	11	最大等级[l][sl:i]
--hunhuannum	int	11	拥有魂环数量[l][sl:i]
--hunhuanyear	int	11	魂环年限上限[l][sl:i]
--yearratio	int	11	魂环年限换算系数[l][sl:i]
local hunhuan =
{
	{grade = 0,	max_attr = "",	max_attr_num = 0,	cost_item = "",	num = 0,	level = 10,	hunhuannum = 0,	hunhuanyear = 0,	yearratio = 0},
	{grade = 1,	max_attr = {{50,1,214},{51,1,160},{52,1,160},{53,1,133},{54,1,133}},	max_attr_num = 800,	cost_item = {6001,1,2},	num = 2,	level = 20,	hunhuannum = 1,	hunhuanyear = 500,	yearratio = 6250},
	{grade = 2,	max_attr = {{50,1,256},{51,1,192},{52,1,192},{53,1,160},{54,1,160}},	max_attr_num = 960,	cost_item = {6001,1,2},	num = 2,	level = 30,	hunhuannum = 2,	hunhuanyear = 1000,	yearratio = 31250},
	{grade = 3,	max_attr = {{50,1,320},{51,1,240},{52,1,240},{53,1,200},{54,1,200}},	max_attr_num = 1200,	cost_item = {6001,1,3},	num = 3,	level = 40,	hunhuannum = 3,	hunhuanyear = 5000,	yearratio = 166667},
	{grade = 4,	max_attr = {{50,1,384},{51,1,288},{52,1,288},{53,1,240},{54,1,240}},	max_attr_num = 1440,	cost_item = {6001,1,3},	num = 3,	level = 50,	hunhuannum = 4,	hunhuanyear = 10000,	yearratio = 208334},
	{grade = 5,	max_attr = {{50,1,470},{51,1,352},{52,1,352},{53,1,293},{54,1,293}},	max_attr_num = 1760,	cost_item = {6001,1,4},	num = 4,	level = 60,	hunhuannum = 5,	hunhuanyear = 25000,	yearratio = 468750},
	{grade = 6,	max_attr = {{50,1,576},{51,1,432},{52,1,432},{53,1,360},{54,1,360}},	max_attr_num = 2160,	cost_item = {6001,1,5},	num = 5,	level = 70,	hunhuannum = 6,	hunhuanyear = 50000,	yearratio = 625000},
	{grade = 7,	max_attr = {{50,1,704},{51,1,528},{52,1,528},{53,1,440},{54,1,440}},	max_attr_num = 2640,	cost_item = {6001,1,6},	num = 6,	level = 80,	hunhuannum = 7,	hunhuanyear = 75000,	yearratio = 520834},
	{grade = 8,	max_attr = {{50,1,854},{51,1,640},{52,1,640},{53,1,533},{54,1,533}},	max_attr_num = 3200,	cost_item = {6001,1,7},	num = 7,	level = 90,	hunhuannum = 8,	hunhuanyear = 100000,	yearratio = 446429},
	{grade = 9,	max_attr = {{50,1,1024},{51,1,768},{52,1,768},{53,1,640},{54,1,640}},	max_attr_num = 3840,	cost_item = {6001,1,8},	num = 8,	level = 99,	hunhuannum = 9,	hunhuanyear = 125000,	yearratio = 390625},
	{grade = 10,	max_attr = {{50,1,1216},{51,1,912},{52,1,912},{53,1,760},{54,1,760}},	max_attr_num = 4560,	cost_item = {6001,1,9},	num = 9,	level = 109,	hunhuannum = 9,	hunhuanyear = 160000,	yearratio = 486112},
	{grade = 11,	max_attr = {{50,1,1462},{51,1,1096},{52,1,1096},{53,1,913},{54,1,913}},	max_attr_num = 5480,	cost_item = {6001,1,12},	num = 12,	level = 119,	hunhuannum = 9,	hunhuanyear = 200000,	yearratio = 434783},
	{grade = 12,	max_attr = {{50,1,1758},{51,1,1318},{52,1,1318},{53,1,1099},{54,1,1099}},	max_attr_num = 6592,	cost_item = {6001,1,15},	num = 15,	level = 129,	hunhuannum = 9,	hunhuanyear = 250000,	yearratio = 449641},
	{grade = 13,	max_attr = {{50,1,2286},{51,1,1715},{52,1,1715},{53,1,1430},{54,1,1430}},	max_attr_num = 8576,	cost_item = {6001,1,25},	num = 25,	level = 139,	hunhuannum = 9,	hunhuanyear = 350000,	yearratio = 504033},
	{grade = 14,	max_attr = {{50,1,3200},{51,1,2400},{52,1,2400},{53,1,2000},{54,1,2000}},	max_attr_num = 12000,	cost_item = {6001,1,50},	num = 50,	level = 149,	hunhuannum = 9,	hunhuanyear = 500000,	yearratio = 438085},
	{grade = 15,	max_attr = {{50,1,6400},{51,1,4800},{52,1,4800},{53,1,4000},{54,1,4000}},	max_attr_num = 24000,	cost_item = {6001,1,150},	num = 150,	level = 150,	hunhuannum = 9,	hunhuanyear = 1000000,	yearratio = 416667},
}

return hunhuan