-- 此文件工具自动生成，不要修改
--id	int	11	魂髓部位[sl][l]
--item	char	16	解锁消耗[sl:vv][l][DMH]
--need_id	int	11	前置id[sl][l]
--need_lv	int	11	前置等级[sl][l]
local bone_hunsui_unlock =
{
	{id = 1,	item = {6721,1,1},	need_id = 0,	need_lv = 0},
	{id = 2,	item = {6721,1,2},	need_id = 1,	need_lv = 5},
	{id = 3,	item = {6721,1,3},	need_id = 2,	need_lv = 5},
	{id = 4,	item = {6721,1,4},	need_id = 3,	need_lv = 5},
	{id = 5,	item = {6721,1,5},	need_id = 4,	need_lv = 5},
}

return bone_hunsui_unlock