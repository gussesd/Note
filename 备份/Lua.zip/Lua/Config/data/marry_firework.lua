-- 此文件工具自动生成，不要修改
--id	int	11	序号[sl][l]
--type	int	11	类型(1付费烟花2系统烟花)[sl][l]
--icon	char	32	图标[l]
--decoration	char	64	特效[l]
--cost_type	int	11	货币类型(1金魂币51充值钻石52绑定钻石)[sl][l]
--cost_value	int	11	价格[sl][l]
local marry_firework =
{
	{id = 1,	type = 1,	icon = "1",	decoration = "1",	cost_type = 1,	cost_value = 1},
	{id = 2,	type = 1,	icon = "2",	decoration = "2",	cost_type = 51,	cost_value = 2},
	{id = 3,	type = 1,	icon = "3",	decoration = "3",	cost_type = 51,	cost_value = 3},
	{id = 4,	type = 1,	icon = "4",	decoration = "4",	cost_type = 51,	cost_value = 4},
	{id = 5,	type = 1,	icon = "5",	decoration = "5",	cost_type = 51,	cost_value = 5},
	{id = 6,	type = 1,	icon = "6",	decoration = "6",	cost_type = 51,	cost_value = 6},
	{id = 7,	type = 2,	icon = "7",	decoration = "7",	cost_type = 0,	cost_value = 0},
	{id = 8,	type = 2,	icon = "6",	decoration = "6",	cost_type = 0,	cost_value = 0},
}

return marry_firework