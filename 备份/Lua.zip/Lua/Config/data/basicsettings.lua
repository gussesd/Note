-- 此文件工具自动生成，不要修改
--id	int	11	设置id上线后不能改[l]
--swtype	int	11	显示组件类型(1滑块2开关3二选一4四选一5三选一6下拉框7按钮8输入框加按钮9图像设置10标签11分割线12下拉框(大一点))[l]
--defvalue	int	11	默认值(-1无需值按钮类,开关1关2开.二选1,2.三选1,2,3.四选1234)[l]
--tgname	char	11	几选一的名字(1低,2中,3高,4关闭,630,760,8流畅,9标准,10高清,11常规模式,12协助模式,13自定义)[l][DMH]
--name	char	11	设置的名字[l]
--buttonname	char	11	按钮的名字[l][DMH]
--dropdownname	char	11	下拉框列表[l][DMH]
--immediately	int	11	立即生效(0否1是)[l]
--tipname	char	11	[l][DMH]
local basicsettings =
{
	{id = 1,	swtype = 1,	defvalue = 50,	tgname = "",	name = "镜头灵敏度",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 2,	swtype = 1,	defvalue = 50,	tgname = "",	name = "长按瞄准灵敏度",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 3,	swtype = 2,	defvalue = 1,	tgname = "",	name = "镜头高度自动回正",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 4,	swtype = 1,	defvalue = 50,	tgname = "",	name = "镜头默认距离",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 5,	swtype = 2,	defvalue = 1,	tgname = "",	name = "镜头振动",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 6,	swtype = 9,	defvalue = 3,	tgname = {8,9,10,13},	name = "图像质量",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 7,	swtype = 3,	defvalue = 2,	tgname = {6,7},	name = "帧率",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 8,	swtype = 4,	defvalue = 3,	tgname = {4,1,2,3},	name = "阴影质量",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 9,	swtype = 5,	defvalue = 3,	tgname = {1,2,3},	name = "贴图质量",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 10,	swtype = 5,	defvalue = 3,	tgname = {1,2,3},	name = "渲染精度",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 11,	swtype = 5,	defvalue = 3,	tgname = {1,2,3},	name = "植被细节",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 12,	swtype = 12,	defvalue = 1,	tgname = "",	name = "分辨率",	buttonname = "",	dropdownname = {"全屏幕","1600x900","1440x900","1280x1024","1280x800","1024x768","800x600"},	immediately = 1,	tipname = ""},
	{id = 13,	swtype = 4,	defvalue = 3,	tgname = {4,1,2,3},	name = "抗锯齿",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 14,	swtype = 5,	defvalue = 3,	tgname = {1,2,3},	name = "水面质量",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 15,	swtype = 5,	defvalue = 3,	tgname = {1,2,3},	name = "着色质量",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 16,	swtype = 5,	defvalue = 3,	tgname = {1,2,3},	name = "后处理质量",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 20,	swtype = 1,	defvalue = 50,	tgname = "",	name = "音量",	buttonname = "",	dropdownname = "",	immediately = 1,	tipname = ""},
	{id = 21,	swtype = 1,	defvalue = 50,	tgname = "",	name = "音乐音量",	buttonname = "",	dropdownname = "",	immediately = 1,	tipname = ""},
	{id = 22,	swtype = 1,	defvalue = 50,	tgname = "",	name = "音效音量",	buttonname = "",	dropdownname = "",	immediately = 1,	tipname = ""},
	{id = 23,	swtype = 6,	defvalue = 1,	tgname = "",	name = "游戏语言",	buttonname = "",	dropdownname = {"简体中文"},	immediately = 0,	tipname = ""},
	{id = 24,	swtype = 6,	defvalue = 1,	tgname = "",	name = "游戏语音",	buttonname = "",	dropdownname = {"汉语"},	immediately = 0,	tipname = ""},
	{id = 25,	swtype = 2,	defvalue = 1,	tgname = "",	name = "显示玩家血条",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 26,	swtype = 2,	defvalue = 2,	tgname = "",	name = "显示其他玩家特效",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 27,	swtype = 2,	defvalue = 1,	tgname = "",	name = "降低人群密度",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 28,	swtype = 2,	defvalue = 2,	tgname = "",	name = "显示魂环",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 29,	swtype = 2,	defvalue = 2,	tgname = "",	name = "显示其他玩家姓名",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 30,	swtype = 2,	defvalue = 2,	tgname = "",	name = "显示自己姓名",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 31,	swtype = 7,	defvalue = -1,	tgname = "",	name = "用户中心",	buttonname = {"用户中心"},	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 32,	swtype = 7,	defvalue = -1,	tgname = "",	name = "隐私策略",	buttonname = {"隐私策略"},	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 33,	swtype = 3,	defvalue = 1,	tgname = {11,12},	name = "掉落模式",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = {"怪物有掉落，被击败怪物当天不再掉落","怪物无掉落，不消耗怪物的当天掉落权限"}},
	{id = 34,	swtype = 8,	defvalue = -1,	tgname = "",	name = "兑换码",	buttonname = {"兑换"},	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 35,	swtype = 2,	defvalue = 2,	tgname = "",	name = "自动播放剧情",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
	{id = 36,	swtype = 2,	defvalue = 2,	tgname = "",	name = "开启天气效果",	buttonname = "",	dropdownname = "",	immediately = 0,	tipname = ""},
}

return basicsettings