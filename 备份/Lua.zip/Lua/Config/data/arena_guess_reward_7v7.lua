-- 此文件工具自动生成，不要修改
--stage	int	11	赛段[l][sl:i]
--name	char	11	轮次[l][sl]
--num	int	11	默认奖励数量[l][sl:i]
local arena_guess_reward_7v7 =
{
	{stage = 2,	name = "512进256强晋级赛",	num = 2000},
	{stage = 3,	name = "256进128强晋级赛",	num = 5000},
	{stage = 4,	name = "128进64强晋级赛",	num = 10000},
	{stage = 5,	name = "64进32强晋级赛",	num = 20000},
	{stage = 6,	name = "32进16强晋级赛",	num = 50000},
	{stage = 7,	name = "16进8强晋级赛",	num = 100000},
	{stage = 8,	name = "8进4强晋级赛",	num = 200000},
	{stage = 9,	name = "4进2强晋级赛",	num = 500000},
	{stage = 10,	name = "冠军争夺赛",	num = 1000000},
}

return arena_guess_reward_7v7