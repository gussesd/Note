-- 此文件工具自动生成，不要修改
--hunhuan_id	int	11	魂环编号[l][#][sl:i]
--num	int	11	魂印孔编号[l][sl:i]
--year	int	11	需要年限[l][sl:i]
--cost	char	128	解锁消耗[l][sl:vv][DMH]
--attr_num	int	11	属性总和[l][sl:i]
local hunyin_slot =
{
	{hunhuan_id = 1,	num = 0,	year = 500,	cost = {7201,1,1},	attr_num = 800},
	{hunhuan_id = 1,	num = 1,	year = 1000,	cost = {7201,1,2},	attr_num = 960},
	{hunhuan_id = 1,	num = 2,	year = 5000,	cost = {7201,1,3},	attr_num = 1200},
	{hunhuan_id = 2,	num = 0,	year = 1000,	cost = {7201,1,1},	attr_num = 960},
	{hunhuan_id = 2,	num = 1,	year = 5000,	cost = {7201,1,2},	attr_num = 1200},
	{hunhuan_id = 2,	num = 2,	year = 10000,	cost = {7201,1,3},	attr_num = 1440},
	{hunhuan_id = 3,	num = 0,	year = 5000,	cost = {7201,1,1},	attr_num = 1200},
	{hunhuan_id = 3,	num = 1,	year = 10000,	cost = {7201,1,2},	attr_num = 1440},
	{hunhuan_id = 3,	num = 2,	year = 25000,	cost = {7201,1,3},	attr_num = 1760},
	{hunhuan_id = 4,	num = 0,	year = 10000,	cost = {7201,1,1},	attr_num = 1440},
	{hunhuan_id = 4,	num = 1,	year = 25000,	cost = {7201,1,2},	attr_num = 1760},
	{hunhuan_id = 4,	num = 2,	year = 50000,	cost = {7201,1,3},	attr_num = 2160},
	{hunhuan_id = 5,	num = 0,	year = 25000,	cost = {7201,1,1},	attr_num = 1760},
	{hunhuan_id = 5,	num = 1,	year = 50000,	cost = {7201,1,2},	attr_num = 2160},
	{hunhuan_id = 5,	num = 2,	year = 75000,	cost = {7201,1,3},	attr_num = 2640},
	{hunhuan_id = 6,	num = 0,	year = 50000,	cost = {7201,1,1},	attr_num = 2160},
	{hunhuan_id = 6,	num = 1,	year = 75000,	cost = {7201,1,2},	attr_num = 2640},
	{hunhuan_id = 6,	num = 2,	year = 100000,	cost = {7201,1,3},	attr_num = 3200},
	{hunhuan_id = 7,	num = 0,	year = 75000,	cost = {7201,1,1},	attr_num = 2640},
	{hunhuan_id = 7,	num = 1,	year = 125000,	cost = {7201,1,2},	attr_num = 3840},
	{hunhuan_id = 7,	num = 2,	year = 200000,	cost = {7201,1,3},	attr_num = 5480},
	{hunhuan_id = 8,	num = 0,	year = 125000,	cost = {7201,1,1},	attr_num = 3840},
	{hunhuan_id = 8,	num = 1,	year = 200000,	cost = {7201,1,2},	attr_num = 5480},
	{hunhuan_id = 8,	num = 2,	year = 350000,	cost = {7201,1,3},	attr_num = 8576},
	{hunhuan_id = 9,	num = 0,	year = 160000,	cost = {7201,1,1},	attr_num = 4560},
	{hunhuan_id = 9,	num = 1,	year = 250000,	cost = {7201,1,2},	attr_num = 6592},
	{hunhuan_id = 9,	num = 2,	year = 500000,	cost = {7201,1,3},	attr_num = 12000},
}

return hunyin_slot