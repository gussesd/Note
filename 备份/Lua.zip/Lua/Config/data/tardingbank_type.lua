-- 此文件工具自动生成，不要修改
--order	int	11	排序[l]
--name	char	64	名字[l]
--nodelv	int	11	页签等级(1：父页签，2：子页签)[l]
--slot_type	int	11	道具类型[l]
--type	int	11	细分类型(魂骨：0无1头部2躯干3左臂4右臂5左腿6右腿)[l]
local tardingbank_type =
{
	{order = 1,	name = "魂骨",	nodelv = 1,	slot_type = 3,	type = 0},
	{order = 2,	name = "头部",	nodelv = 2,	slot_type = 3,	type = 1},
	{order = 3,	name = "躯干",	nodelv = 2,	slot_type = 3,	type = 2},
	{order = 4,	name = "左臂",	nodelv = 2,	slot_type = 3,	type = 3},
	{order = 5,	name = "右臂",	nodelv = 2,	slot_type = 3,	type = 4},
	{order = 6,	name = "左腿",	nodelv = 2,	slot_type = 3,	type = 5},
	{order = 7,	name = "右腿",	nodelv = 2,	slot_type = 3,	type = 6},
	{order = 8,	name = "魂印",	nodelv = 1,	slot_type = 4,	type = 0},
}

return tardingbank_type