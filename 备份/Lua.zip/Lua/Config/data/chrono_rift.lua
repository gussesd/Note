-- 此文件工具自动生成，不要修改
--id	int	11	id[sl][l]
--name	char	128	名字[l]
--unlock	char	128	解锁条件（1.任务:任务类型:任务id 2玄天功:玄天功等级  支持多条配置）[sl:vv][l]
--prepoint	int	11	前置裂缝id[sl][l]
--model	int	11	裂缝模型[l]
--mapid	int	11	地图id（通常为前世唐门）[l]
--x	float	11	x坐标[l]
--y	float	11	y坐标[l]
--z	float	11	z坐标[l]
--event	int	11	触发事件类型（1.剧情 2.副本）[sl][l]
--param 	char	128	事件id（剧情或副本的id）[sl:v][l][DMH]
--reward	char	128	奖励[sl:vv][l]
local chrono_rift =
{
	{id = 1,	name = "记忆裂隙1",	unlock = {{1,1,1000001},{2,1}},	prepoint = 0,	model = 100001,	mapid = 1001,	x = -211.15,	y = 128.98,	z = -209.78,	event = 1,	param  = {1000},	reward = {{14,1,1}}},
	{id = 2,	name = "记忆裂隙2",	unlock = {{2,2}},	prepoint = 1,	model = 100002,	mapid = 1001,	x = -180.28,	y = 128.94,	z = -232.73,	event = 2,	param  = {4401},	reward = {{14,1,1}}},
}

return chrono_rift