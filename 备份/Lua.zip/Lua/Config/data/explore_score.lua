-- 此文件工具自动生成，不要修改
--group	int	11	大类(1宝箱2传送阵3复活点4草药5元素灵粹6魂器)[sl][l]
--type	int	11	小类(宝箱quality 草药、魂器和元素灵粹取collection_self表中的type)[sl][l]
--addon	int	11	增加探索度[sl][l]
local explore_score =
{
	{group = 1,	type = 1,	addon = 10},
	{group = 1,	type = 2,	addon = 20},
	{group = 1,	type = 3,	addon = 30},
	{group = 2,	type = 1,	addon = 10},
	{group = 3,	type = 1,	addon = 10},
	{group = 4,	type = 1,	addon = 10},
	{group = 5,	type = 7,	addon = 10},
	{group = 6,	type = 11,	addon = 10},
}

return explore_score