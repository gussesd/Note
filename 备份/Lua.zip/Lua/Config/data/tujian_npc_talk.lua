-- 此文件工具自动生成，不要修改
--id	int	11	id[l]
--desc	char	128	对话内容[l]
--tujian_id	int	11	npc图鉴的id[l]
local tujian_npc_talk =
{
	{id = 1,	desc = "有事在身，稍后联系。",	tujian_id = 1},
	{id = 2,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 2},
	{id = 3,	desc = "我现在有事在忙，忙完回复你~",	tujian_id = 3},
	{id = 4,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 4},
	{id = 5,	desc = "在忙，稍后回复。",	tujian_id = 5},
	{id = 6,	desc = "在忙，勿扰。",	tujian_id = 6},
	{id = 7,	desc = "奥斯卡特制香肠正在热卖中，想买多少直接留言！其他事等我忙完回复！",	tujian_id = 7},
	{id = 8,	desc = "正和剑爷爷下棋，等一会儿再联系。",	tujian_id = 8},
	{id = 9,	desc = "有事呢，不在！（请我吃饭的直接留言时间地点，小爷会准时去的）",	tujian_id = 9},
	{id = 10,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 10},
	{id = 11,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 11},
	{id = 12,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 12},
	{id = 13,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 13},
	{id = 14,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 14},
	{id = 15,	desc = "你好，我现在不在，稍后联系你。",	tujian_id = 15},
	{id = 16,	desc = "正在忙，一会儿回复。",	tujian_id = 2},
	{id = 17,	desc = "正在忙，一会儿回复。",	tujian_id = 4},
	{id = 18,	desc = "正在忙，一会儿回复。",	tujian_id = 10},
	{id = 19,	desc = "正在忙，一会儿回复。",	tujian_id = 11},
	{id = 20,	desc = "正在忙，一会儿回复。",	tujian_id = 12},
	{id = 21,	desc = "正在忙，一会儿回复。",	tujian_id = 13},
	{id = 22,	desc = "正在忙，一会儿回复。",	tujian_id = 14},
	{id = 23,	desc = "正在忙，一会儿回复。",	tujian_id = 15},
}

return tujian_npc_talk