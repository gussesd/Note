-- 此文件工具自动生成，不要修改
--id	int	11	序号[sl][l]
--map	int	11	所在场景[l]
--arch_id	int	11	关联五象阵实例id[l][sl]
--x	float	11	x坐标[sl][l]
--y	float	11	y坐标[sl][l]
--z	float	11	z坐标[sl][l]
--dir	int	11	朝向[sl][l]
--job	int	11	宗门专用点，默认开启（job表ID）[sl][l]
--domain	int	11	地图区域[l][sl]
local revival_point =
{
	{id = 1,	map = 1000,	arch_id = 0,	x = 3785,	y = 180,	z = 1010,	dir = 0,	job = 1,	domain = 22102},
	{id = 2,	map = 1000,	arch_id = 0,	x = 5543,	y = 337,	z = 6577,	dir = 280,	job = 2,	domain = 13101},
	{id = 3,	map = 1000,	arch_id = 0,	x = 2052,	y = 215,	z = 1336,	dir = 86,	job = 3,	domain = 21000},
	{id = 4,	map = 1000,	arch_id = 0,	x = 4632,	y = 183,	z = 4898,	dir = 0,	job = 4,	domain = 14202},
	{id = 5,	map = 1000,	arch_id = 0,	x = 3492,	y = 229,	z = 6135,	dir = 192,	job = 5,	domain = 12000},
	{id = 6,	map = 1000,	arch_id = 70001,	x = 3924.45,	y = 250.49,	z = 6042.41,	dir = 269,	job = 0,	domain = 14000},
	{id = 7,	map = 1000,	arch_id = 70002,	x = 3549.16,	y = 233.31,	z = 6057.90,	dir = 38,	job = 0,	domain = 12000},
	{id = 8,	map = 1000,	arch_id = 70003,	x = 5544.65,	y = 378.37,	z = 6738.19,	dir = 286,	job = 0,	domain = 13101},
	{id = 9,	map = 1000,	arch_id = 70004,	x = 4653.26,	y = 195.05,	z = 4874.89,	dir = 354,	job = 0,	domain = 14202},
	{id = 10,	map = 1000,	arch_id = 70005,	x = 4113.62,	y = 177.83,	z = 4505.72,	dir = 331,	job = 0,	domain = 15000},
	{id = 11,	map = 1000,	arch_id = 70006,	x = 4978.53,	y = 161.37,	z = 4372.03,	dir = 96,	job = 0,	domain = 16000},
	{id = 12,	map = 1000,	arch_id = 70007,	x = 2943.48,	y = 109.39,	z = 1814.04,	dir = 175,	job = 0,	domain = 21102},
	{id = 13,	map = 1000,	arch_id = 70008,	x = 3370.7,	y = 72.29,	z = 1702.66,	dir = 223,	job = 0,	domain = 23000},
	{id = 14,	map = 1000,	arch_id = 70009,	x = 2897.2,	y = 73.83,	z = 2617.8,	dir = 36,	job = 0,	domain = 23101},
	{id = 15,	map = 1000,	arch_id = 70010,	x = 3023.95,	y = 208.87,	z = 4350.46,	dir = 322,	job = 0,	domain = 31103},
	{id = 16,	map = 1000,	arch_id = 70011,	x = 3832.44,	y = 178.33,	z = 5118.15,	dir = 343,	job = 0,	domain = 14000},
	{id = 17,	map = 1000,	arch_id = 70012,	x = 4545.96,	y = 219.73,	z = 5436.37,	dir = 167,	job = 0,	domain = 14000},
}

return revival_point