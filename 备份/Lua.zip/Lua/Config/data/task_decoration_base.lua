-- 此文件工具自动生成，不要修改
--id	int	11	ID[l]
--name	char	256	注释[l]
local task_decoration_base =
{
	{id = 1,	name = "坐标集"},
}

return task_decoration_base