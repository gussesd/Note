-- 此文件工具自动生成，不要修改
--level	int	11	精炼等级[sl][l]
--attr_def	char	16	防具4部位加成[sl:vv][l]
--attr_atk	char	16	饰品4部位加成[sl:vv][l]
local equip_jinglian_suit =
{
	{level = 1,	attr_def = "",	attr_atk = ""},
	{level = 2,	attr_def = "",	attr_atk = ""},
	{level = 3,	attr_def = {{1,2,200}},	attr_atk = {{67,2,200}}},
	{level = 4,	attr_def = {{1,2,200}},	attr_atk = {{67,2,200}}},
	{level = 5,	attr_def = {{1,2,200}},	attr_atk = {{67,2,200}}},
	{level = 6,	attr_def = {{1,2,400}},	attr_atk = {{67,2,400}}},
	{level = 7,	attr_def = {{1,2,400}},	attr_atk = {{67,2,400}}},
	{level = 8,	attr_def = {{1,2,400}},	attr_atk = {{67,2,400}}},
	{level = 9,	attr_def = {{1,2,600}},	attr_atk = {{67,2,600}}},
	{level = 10,	attr_def = {{1,2,600}},	attr_atk = {{67,2,600}}},
	{level = 11,	attr_def = {{1,2,600}},	attr_atk = {{67,2,600}}},
	{level = 12,	attr_def = {{1,2,1000}},	attr_atk = {{67,2,1000}}},
	{level = 13,	attr_def = {{1,2,1000}},	attr_atk = {{67,2,1000}}},
	{level = 14,	attr_def = {{1,2,1000}},	attr_atk = {{67,2,1000}}},
	{level = 15,	attr_def = {{1,2,1500}},	attr_atk = {{67,2,1500}}},
}

return equip_jinglian_suit