-- 此文件工具自动生成，不要修改
--id	int	11	预设选择[l]
--name	char	512	时装[l]
local make_face_design_dress =
{
	{id = 1,	name = {{0,14,0,0,0}}},
	{id = 2,	name = {{0,29,0,0,0}}},
	{id = 3,	name = {{0,21,0,0,0}}},
	{id = 4,	name = {{0,24,0,0,0}}},
	{id = 5,	name = {{0,13,0,0,0}}},
	{id = 6,	name = {{0,16,0,0,0}}},
	{id = 7,	name = {{0,32,0,0,0}}},
	{id = 8,	name = {{0,1,0,0,0}}},
	{id = 9,	name = {{0,2,0,0,0}}},
}

return make_face_design_dress