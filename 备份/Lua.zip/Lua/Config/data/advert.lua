-- 此文件工具自动生成，不要修改
--id	int	11	配置id[sl][l]
--gain_id	int	11	跳转的id[l]
--icon	char	16	广告图[l]
--time	int	11	广告时长[l]
--sort	int	11	排序[l]
--enabled	int	11	是否启用(0不启用1启用)[l]
local advert =
{
	{id = 1,	gain_id = 111,	icon = "img_test1",	time = 10,	sort = 1,	enabled = 1},
	{id = 2,	gain_id = 2095,	icon = "img_test2",	time = 10,	sort = 2,	enabled = 1},
}

return advert