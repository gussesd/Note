-- 此文件工具自动生成，不要修改
--task_id	int	11	id[sl:i][l]
--unlock_type	int	11	解锁类型（1-翅膀 2-装扮）[sl:i][l]
--param	char	32	对应解锁的参数[sl:vv][l]
local task_unlock =
{
	{task_id = 1259062,	unlock_type = 1,	param = "1"},
	{task_id = 1259063,	unlock_type = 1,	param = "2"},
	{task_id = 1259064,	unlock_type = 1,	param = "3"},
	{task_id = 1259065,	unlock_type = 1,	param = "4"},
	{task_id = 1259066,	unlock_type = 1,	param = "5"},
	{task_id = 205175,	unlock_type = 2,	param = {{11,49}}},
}

return task_unlock