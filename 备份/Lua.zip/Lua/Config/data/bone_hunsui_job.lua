-- 此文件工具自动生成，不要修改
--job	int	11	职业[l]
--attr_order	char	11	属性排序[l][DMH]
--attr_name	char	11	属性名称[l][DMH]
local bone_hunsui_job =
{
	{job = 1,	attr_order = {31,34,33,35,32},	attr_name = {"体质","智慧","敏捷","精神","力量"}},
	{job = 2,	attr_order = {31,34,33,35,32},	attr_name = {"体质","智慧","敏捷","精神","力量"}},
	{job = 3,	attr_order = {31,34,32,35,33},	attr_name = {"体质","智慧","力量","精神","敏捷"}},
	{job = 4,	attr_order = {31,32,35,33,34},	attr_name = {"体质","力量","精神","敏捷","智慧"}},
	{job = 5,	attr_order = {31,32,34,33,35},	attr_name = {"体质","力量","智慧","敏捷","精神"}},
}

return bone_hunsui_job