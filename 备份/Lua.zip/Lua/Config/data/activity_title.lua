-- 此文件工具自动生成，不要修改
--id	int	11	序列[l]
--name	char	16	活动名[l]
--type	int	11	活动类型1:日常活动2:非日常活动[l]
--level	int	11	玩家等级[l]
--hunshi_lv	int	11	魂师等级[l]
--start_time	int	11	起始日期(时间戳)[l]
--end_time	int	11	结束日期(时间戳)[l]
--icon	char	1024	活动图标[l]
local activity_title =
{
	{id = 101,	name = "全大陆魂师争霸赛",	type = 1,	level = 0,	hunshi_lv = 0,	start_time = 1690128000,	end_time = 1711468800,	icon = ""},
}

return activity_title