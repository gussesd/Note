-- 此文件工具自动生成，不要修改
--grade	int	11	等阶[l][#][sl:i]
--max_attr	char	256	该阶段最大等阶[l][sl:ct]
--zizhi_num	int	11	总资质点[l][sl:i]
local pet_zizhi =
{
}

return pet_zizhi