-- 此文件工具自动生成，不要修改
--id	int	11	序号[sl:i][l]
--name	char	16	分包名称[l]
--order	int	11	优先级[l]
--desc	char	1024	描述[l]
--gift	char	64	奖励[l]
local download =
{
	{id = 1,	name = "语音包1",	order = 1,	desc = "语音包1的内容",	gift = {{3,1,50000}}},
	{id = 2,	name = "语音包2",	order = 2,	desc = "语音包2的内容",	gift = {{3,1,50000}}},
	{id = 3,	name = "语音包3",	order = 3,	desc = "语音包3的内容",	gift = {{3,1,50000}}},
	{id = 4,	name = "语音包4",	order = 4,	desc = "语音包4的内容",	gift = {{3,1,50000}}},
	{id = 5,	name = "语音包5",	order = 5,	desc = "语音包5的内容",	gift = {{3,1,50000}}},
}

return download