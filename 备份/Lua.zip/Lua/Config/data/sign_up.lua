-- 此文件工具自动生成，不要修改
--day	int	11	第几天[sl:i][l]
--reward	char	64	奖励(101:1:1)[sl:vv][l][DMH]
local sign_up =
{
	{day = 1,	reward = {3,1,50000}},
	{day = 2,	reward = {203,1,2}},
	{day = 3,	reward = {7201,1,1}},
	{day = 4,	reward = {203,1,3}},
	{day = 5,	reward = {6530,1,1}},
	{day = 6,	reward = {203,1,5}},
	{day = 7,	reward = {13,1,1000}},
}

return sign_up