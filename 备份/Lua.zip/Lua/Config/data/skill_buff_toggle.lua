-- 此文件工具自动生成，不要修改
--skillid	int	11	buff存在时可触发技能的id[l]
--buffid	int	11	buff的id[l]
--buff_layer	int	11	触发技能所需的buff层数[l]
local skill_buff_toggle =
{
	{skillid = 7215,	buffid = 59001,	buff_layer = 1},
	{skillid = 7216,	buffid = 59003,	buff_layer = 1},
	{skillid = 7217,	buffid = 59005,	buff_layer = 1},
	{skillid = 7218,	buffid = 59007,	buff_layer = 1},
	{skillid = 7220,	buffid = 55201,	buff_layer = 1},
	{skillid = 7221,	buffid = 55201,	buff_layer = 2},
	{skillid = 7222,	buffid = 55201,	buff_layer = 3},
	{skillid = 7223,	buffid = 55201,	buff_layer = 4},
	{skillid = 7224,	buffid = 55201,	buff_layer = 5},
	{skillid = 7225,	buffid = 55201,	buff_layer = 6},
	{skillid = 7230,	buffid = 55221,	buff_layer = 1},
	{skillid = 7231,	buffid = 55221,	buff_layer = 2},
	{skillid = 7232,	buffid = 55221,	buff_layer = 3},
	{skillid = 7233,	buffid = 55221,	buff_layer = 4},
	{skillid = 7234,	buffid = 55221,	buff_layer = 5},
}

return skill_buff_toggle