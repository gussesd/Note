-- 此文件工具自动生成，不要修改
--id	int	11	map_scenearea对应id[l]
--material	char	512	材质[l] 
--stopIn	int	11	阻止进入[l]
--stopOut	int	11	阻止出来[l]
local map_area_lightcurtain =
{
	{id = 1001,	material = "Effect/LightCurtain/ef_common_lightcurtain.mat",	stopIn = 1,	stopOut = 1},
}

return map_area_lightcurtain