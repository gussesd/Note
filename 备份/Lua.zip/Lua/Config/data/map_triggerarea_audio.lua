-- 此文件工具自动生成，不要修改
--id	int	11	map_scenearea对应id[l][sl]
--group_ids	char	128	audio_group.cfg id数组[l][DMH][int[]]
local map_triggerarea_audio =
{
	{id = 900005,	group_ids = {10001,10002}},
}

return map_triggerarea_audio