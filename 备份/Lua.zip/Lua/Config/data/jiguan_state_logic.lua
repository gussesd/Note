-- 此文件工具自动生成，不要修改
--id	int	11	机关模板id[sl:i][l]
--state	int	11	状态[sl:i][l]
--delay	int	11	延时开始逻辑，单位毫秒[sl:i][l][recast]
--interval	int	11	逻辑循环间隔，单位毫秒，不填则代码默认为1000，防止空跑[sl:i][l][recast]
--times	int	11	生效次数，0为不限制[sl:i][l]
--type	int	11	生效类型(1、以机关范围内的目标为目标，分别释放技能 多为单体技能2、以机关为目标，释放技能 多为群体技能)[sl:i][l]
--type_pm	char	128	生效参数，目前暂定有技能id[int[]][sl:v][DMH][l][recast]
--shape	int	11	生效范围类型 0无1圆2矩形（宽长高），选取目标用[sl:i][l]
--shape_pm	char	64	范围参数,r:h或w:l:h,单位厘米[int[]][sl:v][DMH][l][recast]
--decorations	char	64	生效时特效[int[][]][SXMH][l]
--effect_add	int	11	真实生效才加生效次数[sl:i][l]
--voxel_id	int	11	体素id[sl:i][l]
local jiguan_state_logic =
{
	{id = 1,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 1,	type_pm = {1052},	shape = 1,	shape_pm = {400,400},	decorations = {{10540,0,0}},	effect_add = 0,	voxel_id = 0},
	{id = 2,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 1,	type_pm = {2303},	shape = 1,	shape_pm = {200,300},	decorations = {{23030,0}},	effect_add = 0,	voxel_id = 0},
	{id = 3,	state = 1,	delay = 500,	interval = 3000,	times = 1,	type = 1,	type_pm = {2603},	shape = 1,	shape_pm = {100,200},	decorations = {{26012,0}},	effect_add = 1,	voxel_id = 0},
	{id = 4,	state = 1,	delay = 0,	interval = 500,	times = 0,	type = 1,	type_pm = {2803},	shape = 1,	shape_pm = {300,300},	decorations = {{28030,0}},	effect_add = 0,	voxel_id = 0},
	{id = 5,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 1,	type_pm = {5553},	shape = 1,	shape_pm = {100,100},	decorations = {{10540,0}},	effect_add = 0,	voxel_id = 0},
	{id = 6,	state = 1,	delay = 0,	interval = 500,	times = 0,	type = 1,	type_pm = {7203},	shape = 1,	shape_pm = {500,500},	decorations = {{5003020,0}},	effect_add = 0,	voxel_id = 0},
	{id = 7,	state = 1,	delay = 500,	interval = 500,	times = 0,	type = 1,	type_pm = {10903},	shape = 1,	shape_pm = {200,200},	decorations = {{101205,0,0}},	effect_add = 0,	voxel_id = 0},
	{id = 8,	state = 1,	delay = 100,	interval = 3000,	times = 0,	type = 2,	type_pm = {14202},	shape = 0,	shape_pm = "",	decorations = {{101702,1000,0}},	effect_add = 0,	voxel_id = 0},
	{id = 9,	state = 1,	delay = 100,	interval = 4000,	times = 0,	type = 2,	type_pm = {14302},	shape = 0,	shape_pm = "",	decorations = {{101502,1000,0}},	effect_add = 0,	voxel_id = 0},
	{id = 10,	state = 1,	delay = 0,	interval = 5000,	times = 0,	type = 2,	type_pm = {20050},	shape = 0,	shape_pm = "",	decorations = {{200213,1800}},	effect_add = 0,	voxel_id = 0},
	{id = 12,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 2,	type_pm = {20350},	shape = 0,	shape_pm = "",	decorations = {{200013,2000,0}},	effect_add = 0,	voxel_id = 0},
	{id = 13,	state = 1,	delay = 1500,	interval = 1500,	times = 0,	type = 1,	type_pm = {20357},	shape = 1,	shape_pm = {250,250},	decorations = {{200003,1500}},	effect_add = 0,	voxel_id = 0},
	{id = 15,	state = 1,	delay = 0,	interval = 2500,	times = 0,	type = 1,	type_pm = {40250},	shape = 1,	shape_pm = {250,250},	decorations = {{101601,0},{101702,0}},	effect_add = 0,	voxel_id = 0},
	{id = 17,	state = 1,	delay = 0,	interval = 2500,	times = 0,	type = 1,	type_pm = {40551},	shape = 1,	shape_pm = {250,250},	decorations = {{101601,0},{102414,0}},	effect_add = 0,	voxel_id = 0},
	{id = 18,	state = 1,	delay = 0,	interval = 2500,	times = 0,	type = 1,	type_pm = {40951},	shape = 1,	shape_pm = {250,250},	decorations = {{101601,0,0},{102414,0,0}},	effect_add = 0,	voxel_id = 0},
	{id = 21,	state = 1,	delay = 300,	interval = 500,	times = 0,	type = 1,	type_pm = {400411},	shape = 1,	shape_pm = {300,200},	decorations = {{4005110,0}},	effect_add = 0,	voxel_id = 0},
	{id = 22,	state = 1,	delay = 0,	interval = 300,	times = 0,	type = 1,	type_pm = {400511},	shape = 1,	shape_pm = {300,400},	decorations = {{4006010,0}},	effect_add = 0,	voxel_id = 0},
	{id = 23,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 1,	type_pm = {500311},	shape = 1,	shape_pm = {750,400},	decorations = "",	effect_add = 0,	voxel_id = 0},
	{id = 24,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 2,	type_pm = {500312},	shape = 1,	shape_pm = {750,400},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 0},
	{id = 25,	state = 1,	delay = 0,	interval = 10000,	times = 0,	type = 2,	type_pm = {400311},	shape = 0,	shape_pm = "",	decorations = "",	effect_add = 0,	voxel_id = 0},
	{id = 26,	state = 1,	delay = 0,	interval = 10000,	times = 0,	type = 1,	type_pm = {100121},	shape = 2,	shape_pm = {200,350,300},	decorations = "",	effect_add = 0,	voxel_id = 0},
	{id = 2303,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 1,	type_pm = {2303},	shape = 1,	shape_pm = {500,500},	decorations = {{10540,0}},	effect_add = 0,	voxel_id = 0},
	{id = 2304,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 1,	type_pm = {2304},	shape = 1,	shape_pm = {500,500},	decorations = {{10540,0}},	effect_add = 0,	voxel_id = 0},
	{id = 20001,	state = 1,	delay = 0,	interval = 5000,	times = 1,	type = 2,	type_pm = {2219901},	shape = 0,	shape_pm = "",	decorations = "",	effect_add = 0,	voxel_id = 0},
	{id = 20101,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 1,	type_pm = {21999},	shape = 1,	shape_pm = {200,200},	decorations = {{200936,0,8000},{200937,0,2000},{200937,1000,2000},{200937,2000,2000},{200937,3000,2000},{200937,4000,2000},{200937,5000,2000}},	effect_add = 0,	voxel_id = 0},
	{id = 20102,	state = 1,	delay = 1000,	interval = 0,	times = 1,	type = 1,	type_pm = {21999},	shape = 1,	shape_pm = {200,200},	decorations = {{200210,1000}},	effect_add = 0,	voxel_id = 0},
	{id = 20108,	state = 1,	delay = 0,	interval = 20000,	times = 0,	type = 2,	type_pm = {20150},	shape = 0,	shape_pm = "",	decorations = {{201530,1600,17000}},	effect_add = 0,	voxel_id = 0},
	{id = 20150,	state = 1,	delay = 0,	interval = 4000,	times = 0,	type = 1,	type_pm = {20150},	shape = 1,	shape_pm = {250,250},	decorations = {{101502,0}},	effect_add = 0,	voxel_id = 0},
	{id = 20250,	state = 1,	delay = 1600,	interval = 3000,	times = 0,	type = 1,	type_pm = {20211},	shape = 1,	shape_pm = {150,150},	decorations = {{200108,0}},	effect_add = 0,	voxel_id = 0},
	{id = 20320,	state = 1,	delay = 3550,	interval = 4000,	times = 0,	type = 1,	type_pm = {20354},	shape = 1,	shape_pm = {300,300},	decorations = "",	effect_add = 0,	voxel_id = 0},
	{id = 20410,	state = 1,	delay = 1000,	interval = 5000,	times = 0,	type = 1,	type_pm = {0},	shape = 1,	shape_pm = {0,0},	decorations = {{201729,0,2370},{201730,2370,0}},	effect_add = 0,	voxel_id = 0},
	{id = 20450,	state = 1,	delay = 500,	interval = 10000,	times = 0,	type = 2,	type_pm = {20450},	shape = 0,	shape_pm = "",	decorations = {{201720,0,10000}},	effect_add = 0,	voxel_id = 0},
	{id = 20451,	state = 1,	delay = 0,	interval = 4000,	times = 0,	type = 1,	type_pm = {20451},	shape = 1,	shape_pm = {300,300},	decorations = {{101502,0}},	effect_add = 0,	voxel_id = 0},
	{id = 20552,	state = 1,	delay = 0,	interval = 5000,	times = 1,	type = 1,	type_pm = {20552},	shape = 1,	shape_pm = {200,200},	decorations = {{101502,2000}},	effect_add = 0,	voxel_id = 0},
	{id = 20606,	state = 1,	delay = 0,	interval = 2000,	times = 0,	type = 1,	type_pm = {20650},	shape = 1,	shape_pm = {1000,500},	decorations = {{200013,0}},	effect_add = 0,	voxel_id = 0},
	{id = 21250,	state = 1,	delay = 0,	interval = 2500,	times = 1,	type = 1,	type_pm = {21250},	shape = 2,	shape_pm = {200,600,240},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 0},
	{id = 21251,	state = 1,	delay = 0,	interval = 2500,	times = 0,	type = 1,	type_pm = {21251},	shape = 1,	shape_pm = {200,300},	decorations = {{101401,0}},	effect_add = 0,	voxel_id = 0},
	{id = 21252,	state = 1,	delay = 100,	interval = 4000,	times = 0,	type = 2,	type_pm = {21252},	shape = 0,	shape_pm = "",	decorations = {{202417,0,2800}},	effect_add = 0,	voxel_id = 0},
	{id = 21403,	state = 1,	delay = 100,	interval = 5000,	times = 0,	type = 2,	type_pm = {21450},	shape = 0,	shape_pm = "",	decorations = {{202304,500,1500},{202305,1260,3300}},	effect_add = 0,	voxel_id = 0},
	{id = 21451,	state = 1,	delay = 0,	interval = 5000,	times = 0,	type = 1,	type_pm = {21451},	shape = 1,	shape_pm = {250,300},	decorations = {{4005110,1300}},	effect_add = 0,	voxel_id = 0},
	{id = 21452,	state = 1,	delay = 0,	interval = 5000,	times = 0,	type = 1,	type_pm = {21452},	shape = 1,	shape_pm = {250,300},	decorations = {{4006010,1000}},	effect_add = 0,	voxel_id = 0},
	{id = 21606,	state = 1,	delay = 0,	interval = 2000,	times = 0,	type = 1,	type_pm = {21650},	shape = 1,	shape_pm = {500,400},	decorations = {{101401,0}},	effect_add = 0,	voxel_id = 0},
	{id = 21707,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 1,	type_pm = {21799},	shape = 1,	shape_pm = {750,100},	decorations = {{201921,0,9999999}},	effect_add = 0,	voxel_id = 0},
	{id = 22050,	state = 1,	delay = 0,	interval = 2500,	times = 0,	type = 1,	type_pm = {22050},	shape = 1,	shape_pm = {200,200},	decorations = {{101601,0},{101502,1600}},	effect_add = 0,	voxel_id = 0},
	{id = 22450,	state = 1,	delay = 0,	interval = 3000,	times = 0,	type = 1,	type_pm = {22450},	shape = 1,	shape_pm = {200,200},	decorations = {{101502,0}},	effect_add = 0,	voxel_id = 0},
	{id = 22451,	state = 1,	delay = 0,	interval = 3000,	times = 0,	type = 1,	type_pm = {22451},	shape = 1,	shape_pm = {200,200},	decorations = {{101401,0}},	effect_add = 0,	voxel_id = 0},
	{id = 22452,	state = 1,	delay = 0,	interval = 3000,	times = 0,	type = 1,	type_pm = {22452},	shape = 1,	shape_pm = {600,200},	decorations = {{200013,0}},	effect_add = 0,	voxel_id = 0},
	{id = 22453,	state = 1,	delay = 4000,	interval = 0,	times = 1,	type = 1,	type_pm = {15806},	shape = 1,	shape_pm = {300,300},	decorations = {{101501,700,0},{400002,2700,0}},	effect_add = 0,	voxel_id = 0},
	{id = 23001,	state = 1,	delay = 0,	interval = 500,	times = 0,	type = 1,	type_pm = {2189901},	shape = 1,	shape_pm = {300,200},	decorations = {{200812,0,10000}},	effect_add = 0,	voxel_id = 0},
	{id = 30101,	state = 1,	delay = 0,	interval = 1000,	times = 6,	type = 1,	type_pm = {15999},	shape = 1,	shape_pm = {200,200},	decorations = "",	effect_add = 0,	voxel_id = 0},
	{id = 30102,	state = 1,	delay = 0,	interval = 1000,	times = 0,	type = 1,	type_pm = {10002},	shape = 1,	shape_pm = {400,300},	decorations = {{200013,0,600000}},	effect_add = 0,	voxel_id = 0},
	{id = 40301,	state = 1,	delay = 100,	interval = 4000,	times = 0,	type = 2,	type_pm = {40351},	shape = 0,	shape_pm = "",	decorations = {{102602,0,0}},	effect_add = 0,	voxel_id = 0},
	{id = 41002,	state = 1,	delay = 250,	interval = 5000,	times = 0,	type = 2,	type_pm = {41050},	shape = 0,	shape_pm = "",	decorations = {{104204,0,2200}},	effect_add = 0,	voxel_id = 0},
	{id = 41006,	state = 1,	delay = 250,	interval = 5000,	times = 0,	type = 2,	type_pm = {41052},	shape = 0,	shape_pm = "",	decorations = {{104210,0,2200}},	effect_add = 0,	voxel_id = 0},
	{id = 41008,	state = 1,	delay = 0,	interval = 5000,	times = 0,	type = 2,	type_pm = {41051},	shape = 0,	shape_pm = "",	decorations = {{0,0,0}},	effect_add = 0,	voxel_id = 0},
	{id = 1001007,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001007,	state = 2,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001007,	state = 3,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001008,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001008,	state = 2,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001008,	state = 3,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001009,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001009,	state = 2,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001009,	state = 3,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001022,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001022,	state = 2,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001022,	state = 3,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 5},
	{id = 1001023,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{1200,0}},	effect_add = 0,	voxel_id = 0},
	{id = 1001024,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 4},
	{id = 1001024,	state = 2,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 4},
	{id = 1001024,	state = 3,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 4},
	{id = 1009000,	state = 2,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 1},
	{id = 1010001,	state = 1,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 2},
	{id = 1010001,	state = 2,	delay = 0,	interval = 0,	times = 0,	type = 0,	type_pm = {0},	shape = 0,	shape_pm = {0},	decorations = {{0,0}},	effect_add = 0,	voxel_id = 0},
}

return jiguan_state_logic