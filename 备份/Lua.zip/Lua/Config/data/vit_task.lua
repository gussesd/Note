-- 此文件工具自动生成，不要修改
--id	int	11	任务ID[sl:i][l]
--group	int	11	大类(1每日必做2每日选做3挑战)[sl:i][l]
--type	int	11	类型(1登录活动2宝藏图3占卜)[sl:i][l]
--index	int	11	子类型[sl:i][l]
--param	int	11	目标参数[sl:i][l]
--progress	int	11	目标次数[sl:i][l]
--count	int	11	每日可完成次数[sl:i][l]
--auto	int	11	自动发奖励[sl:i][l]
--condition	char	128	开启条件(tp:v_1:...:v_n|,tp:1等级2星期(1-7按位读写)3时间段(begin_min:sec:end_min:sec))[sl:ct][l]
--vit	int	11	服务端奖励活跃度值[sl:i][l]
--gift	char	64	服务端只发放活跃度值以外的道具奖励[sl:ct][l]
--desc	char	256	任务描述[l]
--name	char	64	名字[l]
--tiaozhuan	char	64	跳转(类型:ID)[l][DMH]
--consume	int	11	消耗体力[l]
local vit_task =
{
	{id = 1,	group = 1,	type = 1,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "进行一次学院历练",	name = "学院历练",	tiaozhuan = {1,3402},	consume = 0},
	{id = 2,	group = 1,	type = 2,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 10,	gift = {{30,1,10},{3,1,2000}},	desc = "收取一次玄天功内力",	name = "玄天修炼",	tiaozhuan = {1,2300},	consume = 0},
	{id = 3,	group = 1,	type = 3,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 10,	gift = {{30,1,10},{3,1,2000}},	desc = "进行一次宗门捐献",	name = "宗门捐献",	tiaozhuan = {2,5051540},	consume = 0},
	{id = 4,	group = 1,	type = 4,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 10,	gift = {{30,1,10},{3,1,2000}},	desc = "进行一次伙伴赠礼",	name = "伙伴赠礼",	tiaozhuan = {1,301},	consume = 0},
	{id = 5,	group = 1,	type = 5,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 20,	gift = {{30,1,20},{3,1,4000}},	desc = "进行一次神赐祈愿",	name = "神赐祈愿",	tiaozhuan = {1,2700},	consume = 0},
	{id = 6,	group = 1,	type = 6,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "进行一次宗门派遣",	name = "宗门派遣",	tiaozhuan = {2,5051540},	consume = 0},
	{id = 7,	group = 2,	type = 7,	index = 1,	param = 0,	progress = 1,	count = 0,	auto = 0,	condition = "",	vit = 0,	gift = {{30,1,15}},	desc = "获得猎魂副本奖励",	name = "秘境讨伐",	tiaozhuan = {2,5001},	consume = 30},
	{id = 8,	group = 2,	type = 8,	index = 1,	param = 0,	progress = 1,	count = 0,	auto = 0,	condition = "",	vit = 0,	gift = {{30,1,10}},	desc = "获得元素副本奖励",	name = "元素聚灵",	tiaozhuan = {2,5022},	consume = 20},
	{id = 9,	group = 2,	type = 9,	index = 1,	param = 0,	progress = 1,	count = 0,	auto = 0,	condition = "",	vit = 0,	gift = {{30,1,10}},	desc = "获得天赋副本奖励",	name = "天赋试炼",	tiaozhuan = {2,5013},	consume = 20},
	{id = 10,	group = 2,	type = 10,	index = 1,	param = 0,	progress = 1,	count = 0,	auto = 0,	condition = "",	vit = 0,	gift = {{30,1,10}},	desc = "获得器魂封地奖励",	name = "器魂封地",	tiaozhuan = {2,5018},	consume = 20},
	{id = 11,	group = 2,	type = 11,	index = 1,	param = 0,	progress = 1,	count = 0,	auto = 0,	condition = "",	vit = 0,	gift = {{30,1,10}},	desc = "获得奇遇副本奖励",	name = "奇花秘境",	tiaozhuan = {2,5017},	consume = 20},
	{id = 12,	group = 3,	type = 12,	index = 1,	param = 1,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只风系魂兽",	name = "小试身手",	tiaozhuan = {3,1},	consume = 0},
	{id = 13,	group = 3,	type = 12,	index = 2,	param = 2,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只雷系魂兽",	name = "小试身手",	tiaozhuan = {3,2},	consume = 0},
	{id = 14,	group = 3,	type = 12,	index = 3,	param = 3,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只毒系魂兽",	name = "小试身手",	tiaozhuan = {3,3},	consume = 0},
	{id = 15,	group = 3,	type = 12,	index = 4,	param = 4,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只水系魂兽",	name = "小试身手",	tiaozhuan = {3,4},	consume = 0},
	{id = 16,	group = 3,	type = 12,	index = 5,	param = 5,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只火系魂兽",	name = "小试身手",	tiaozhuan = {3,5},	consume = 0},
	{id = 17,	group = 3,	type = 12,	index = 6,	param = 6,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只土系魂兽",	name = "小试身手",	tiaozhuan = {3,6},	consume = 0},
	{id = 18,	group = 3,	type = 12,	index = 7,	param = 7,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只圣系魂兽",	name = "小试身手",	tiaozhuan = {3,7},	consume = 0},
	{id = 19,	group = 3,	type = 12,	index = 8,	param = 8,	progress = 5,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "消灭5只暗系魂兽",	name = "小试身手",	tiaozhuan = {3,8},	consume = 0},
	{id = 20,	group = 3,	type = 13,	index = 1,	param = 2001,	progress = 10,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "采集10个甘草",	name = "搜集素材",	tiaozhuan = {4,10100001},	consume = 0},
	{id = 21,	group = 3,	type = 13,	index = 2,	param = 2021,	progress = 10,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "采集10个半夏",	name = "搜集素材",	tiaozhuan = {4,11200001},	consume = 0},
	{id = 22,	group = 3,	type = 13,	index = 3,	param = 2041,	progress = 10,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "采集10个紫苏",	name = "搜集素材",	tiaozhuan = {4,15700001},	consume = 0},
	{id = 23,	group = 3,	type = 13,	index = 4,	param = 2042,	progress = 10,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "采集10个黄连",	name = "搜集素材",	tiaozhuan = {4,12600001},	consume = 0},
	{id = 24,	group = 3,	type = 13,	index = 5,	param = 2002,	progress = 10,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "采集10个当归",	name = "搜集素材",	tiaozhuan = {4,12900001},	consume = 0},
	{id = 25,	group = 3,	type = 13,	index = 6,	param = 2043,	progress = 10,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "采集10个金银花",	name = "搜集素材",	tiaozhuan = {4,12100001},	consume = 0},
	{id = 26,	group = 3,	type = 13,	index = 7,	param = 2044,	progress = 10,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "采集10个桃仁",	name = "搜集素材",	tiaozhuan = {4,11600001},	consume = 0},
	{id = 27,	group = 3,	type = 14,	index = 1,	param = 0,	progress = 2,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "烹饪获得2个料理",	name = "烹饪修习",	tiaozhuan = {2,20104},	consume = 0},
	{id = 28,	group = 3,	type = 15,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 25,	gift = {{30,1,25},{3,1,5000}},	desc = "斗魂场2v2活动",	name = "斗魂挑战",	tiaozhuan = {2,5080002},	consume = 0},
	{id = 29,	group = 2,	type = 18,	index = 1,	param = 0,	progress = 20,	count = -1,	auto = 1,	condition = "",	vit = 10,	gift = "",	desc = "消耗体力获得活跃度",	name = "消耗体力获得活跃度",	tiaozhuan = "",	consume = 20},
	{id = 30,	group = 3,	type = 19,	index = 1,	param = 0,	progress = 1,	count = 1,	auto = 0,	condition = "",	vit = 20,	gift = {{30,1,20},{3,1,5000}},	desc = "与玩家进行一次魂力比拼",	name = "魂力比拼",	tiaozhuan = {1,5800},	consume = 0},
}

return vit_task