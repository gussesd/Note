-- 此文件工具自动生成，不要修改
--id	int	11	id[sl][l]
--buff_id	int	11	buff表的id[sl][l]
--name	char	16	名称[l]
--buff_time	int	11	buff持续时间按毫秒秒记[sl][l]
--cd	int	11	冷却时间按秒记[l]
--count	int	11	次数[sl][l]
--desc	char	1024	描述[l]
local zone_skill =
{
	{id = 1,	buff_id = 7042,	name = "坚盾",	buff_time = 5000,	cd = 60,	count = 5,	desc = "己方所有单位获得无敌5秒buff"},
	{id = 2,	buff_id = 7043,	name = "强攻",	buff_time = 10000,	cd = 60,	count = 5,	desc = "己方所有单位获得10秒伤害提升buff"},
	{id = 3,	buff_id = 7044,	name = "急行",	buff_time = 10000,	cd = 60,	count = 5,	desc = "己方所有单位获得10秒移动加速buff"},
}

return zone_skill