-- 此文件工具自动生成，不要修改
--id	int	11	模板id[sl:i][l]
--name	char	12	名称[l]
--model	char	64	模型名字[l]
--hp	int	11	生命值，目前暂定是受击次数[l]
--rest_ai	int	11	休息状态ai[l]
--walk_ai	int	11	行走状态ai[l]
--fright_ai	int	11	受惊ai[l]
--view_range	char	128	视野角度:视野范围[l][DMH]
--hear_range	char	128	休息警戒范围:行走警戒范围:受惊警戒范围[l][DMH]
--fright_cd	int	11	范围内无对象持续n秒恢复行走ai[l]
--action	int	11	交互类型 1靠近交互 2击败掉落奖励到地上 3不接受距离外交互[sl:i][l]
--home_range	int	11	服务器验证用 在出生点范围内击败有效[sl:i][l]
--drop	int	11	奖励[sl:i][l]
--cd_type	int	11	-1 永久 0 cd为绝对时间 >0 隔x天，cd代表与凌晨时间的偏差[sl:i][l]
--cd	int	11	绝对时间或与凌晨时间的偏差，秒[sl:i][l]
--gravityType	int	11	重力类型[l](1无重力,2有重力)
local animal =
{
	{id = 1,	name = "鸡",	model = "model_animal_00011",	hp = 2,	rest_ai = 1,	walk_ai = 2,	fright_ai = 4,	view_range = {100,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 20,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2,	name = "鹿",	model = "model_animal_00011",	hp = 3,	rest_ai = 5,	walk_ai = 5,	fright_ai = 6,	view_range = {360,5},	hear_range = {5,5,5},	fright_cd = 5,	action = 3,	home_range = 9999,	drop = 141,	cd_type = -1,	cd = 20,	gravityType = 2},
	{id = 3,	name = "鸡",	model = "model_animal_00011",	hp = 2,	rest_ai = 1,	walk_ai = 2,	fright_ai = 4,	view_range = {100,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 20,	drop = 140,	cd_type = 1,	cd = 20,	gravityType = 2},
	{id = 4,	name = "母鸡",	model = "model_mechanism_firepig",	hp = 1,	rest_ai = 999,	walk_ai = 999,	fright_ai = 999,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1000,	name = "----攻击交互----",	model = "model_animal_00011",	hp = 2,	rest_ai = 1,	walk_ai = 2,	fright_ai = 4,	view_range = {100,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 20,	drop = 4,	cd_type = 1,	cd = 18000,	gravityType = 2},
	{id = 1001,	name = "猫a",	model = "model_plot_00070a",	hp = 999,	rest_ai = 100101,	walk_ai = 100102,	fright_ai = 100103,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 50,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1002,	name = "猫b",	model = "model_plot_00070b",	hp = 999,	rest_ai = 100101,	walk_ai = 100102,	fright_ai = 100103,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 50,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1003,	name = "猫c",	model = "model_plot_00070c",	hp = 999,	rest_ai = 100101,	walk_ai = 100102,	fright_ai = 100103,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 50,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1004,	name = "狗a",	model = "model_plot_00076a",	hp = 999,	rest_ai = 100401,	walk_ai = 100402,	fright_ai = 100403,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 50,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1005,	name = "狗b",	model = "model_plot_00076b",	hp = 999,	rest_ai = 100401,	walk_ai = 100402,	fright_ai = 100403,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 50,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1006,	name = "狗c",	model = "model_plot_00076c",	hp = 999,	rest_ai = 100401,	walk_ai = 100402,	fright_ai = 100403,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 50,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1007,	name = "母鸡",	model = "model_animal_00011",	hp = 1,	rest_ai = 100701,	walk_ai = 100702,	fright_ai = 100703,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1008,	name = "公鸡",	model = "model_animal_00007",	hp = 1,	rest_ai = 100801,	walk_ai = 100802,	fright_ai = 100803,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1009,	name = "野猪",	model = "model_animal_00002",	hp = 2,	rest_ai = 100901,	walk_ai = 100902,	fright_ai = 100903,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1010,	name = "蛇",	model = "model_animal_00003",	hp = 1,	rest_ai = 101001,	walk_ai = 101002,	fright_ai = 101003,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1011,	name = "牛",	model = "model_animal_00004",	hp = 2,	rest_ai = 101101,	walk_ai = 101102,	fright_ai = 101103,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1012,	name = "蜘蛛",	model = "model_animal_00005",	hp = 1,	rest_ai = 101201,	walk_ai = 101202,	fright_ai = 101203,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 142,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1013,	name = "章鱼-暂时搁置",	model = "model_animal_00006",	hp = 1,	rest_ai = 101301,	walk_ai = 101302,	fright_ai = 101303,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1014,	name = "羊",	model = "model_animal_00008",	hp = 2,	rest_ai = 101401,	walk_ai = 101402,	fright_ai = 101403,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1015,	name = "鸭子",	model = "model_animal_00009",	hp = 1,	rest_ai = 101501,	walk_ai = 101502,	fright_ai = 101503,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1016,	name = "雄鹿",	model = "model_animal_00012",	hp = 2,	rest_ai = 101601,	walk_ai = 101602,	fright_ai = 101603,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1017,	name = "角马",	model = "model_monster01_0012",	hp = 2,	rest_ai = 101701,	walk_ai = 101702,	fright_ai = 101703,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1018,	name = "绒兔",	model = "model_monster01_0016",	hp = 1,	rest_ai = 101801,	walk_ai = 101802,	fright_ai = 101803,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 1019,	name = "八脚蜥",	model = "model_monster01_0030",	hp = 1,	rest_ai = 101901,	walk_ai = 101902,	fright_ai = 101903,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 2,	home_range = 9999,	drop = 142,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2000,	name = "----按钮交互----",	model = "model_animal_00011",	hp = 2,	rest_ai = 1,	walk_ai = 2,	fright_ai = 4,	view_range = {100,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 20,	drop = 4,	cd_type = 1,	cd = 18000,	gravityType = 2},
	{id = 2007,	name = "母鸡",	model = "model_animal_00011",	hp = 1,	rest_ai = 100701,	walk_ai = 100702,	fright_ai = 100703,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2008,	name = "公鸡",	model = "model_animal_00007",	hp = 1,	rest_ai = 100801,	walk_ai = 100802,	fright_ai = 100803,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2009,	name = "野猪",	model = "model_animal_00002",	hp = 1,	rest_ai = 100901,	walk_ai = 100902,	fright_ai = 100903,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2010,	name = "蛇",	model = "model_animal_00003",	hp = 1,	rest_ai = 101001,	walk_ai = 101002,	fright_ai = 101003,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2011,	name = "牛",	model = "model_animal_00004",	hp = 1,	rest_ai = 101101,	walk_ai = 101102,	fright_ai = 101103,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2012,	name = "蜘蛛",	model = "model_animal_00005",	hp = 1,	rest_ai = 101201,	walk_ai = 101202,	fright_ai = 101203,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 142,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2013,	name = "章鱼-暂时搁置",	model = "model_animal_00006",	hp = 1,	rest_ai = 101301,	walk_ai = 101302,	fright_ai = 101303,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2014,	name = "羊",	model = "model_animal_00008",	hp = 1,	rest_ai = 101401,	walk_ai = 101402,	fright_ai = 101403,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2015,	name = "鸭子",	model = "model_animal_00009",	hp = 1,	rest_ai = 101501,	walk_ai = 101502,	fright_ai = 101503,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 140,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2016,	name = "雄鹿",	model = "model_animal_00012",	hp = 2,	rest_ai = 101601,	walk_ai = 101602,	fright_ai = 101603,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2017,	name = "角马",	model = "model_monster01_0012",	hp = 2,	rest_ai = 101701,	walk_ai = 101702,	fright_ai = 101703,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2018,	name = "绒兔",	model = "model_monster01_0016",	hp = 1,	rest_ai = 101801,	walk_ai = 101802,	fright_ai = 101803,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 141,	cd_type = 0,	cd = 20,	gravityType = 2},
	{id = 2019,	name = "八脚蜥",	model = "model_monster01_0030",	hp = 1,	rest_ai = 101901,	walk_ai = 101902,	fright_ai = 101903,	view_range = {120,5},	hear_range = {2,3,5},	fright_cd = 5,	action = 1,	home_range = 9999,	drop = 142,	cd_type = 0,	cd = 20,	gravityType = 2},
}

return animal