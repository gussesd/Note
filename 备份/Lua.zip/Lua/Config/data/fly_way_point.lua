-- 此文件工具自动生成，不要修改
--id	int	11	id从1开始连续 超过64和技术核对[sl][l]
--name	char	16	传送点名称[l]
--teleport	int	11	map_teleport 表id[sl][l]
--icon	char	16	icon,air飞行，change换乘，air马车，water水上[l]
--condition	char	32	开启条件(类型(1npc 2完成任务 3接取任务):参数1:参数2...)[sl:vv][l]
--npc	int	11	驿站npc起飞检测位置[sl][l]
--pos	char	16	位置[l][d]
local fly_way_point =
{
	{id = 1,	name = "天恒谷·神扉",	teleport = 60001,	icon = "transfer_air",	condition = {{1,6001}},	npc = 6001,	pos = {986.27,942.3}},
	{id = 2,	name = "登云路",	teleport = 60002,	icon = "transfer_land",	condition = {{1,6002},{2,202070}},	npc = 6002,	pos = {904,881.5}},
	{id = 3,	name = "天斗城东",	teleport = 60003,	icon = "transfer_air",	condition = {{1,6003}},	npc = 6003,	pos = {1025.9,866.3}},
	{id = 4,	name = "天斗城西",	teleport = 60004,	icon = "transfer_change",	condition = {{1,6004},{2,1052015}},	npc = 6004,	pos = {953.9,845.26}},
	{id = 5,	name = "昊天谷",	teleport = 60005,	icon = "transfer_air",	condition = {{1,6005},{3,1020340},{2,204070}},	npc = 6005,	pos = {1189,793.69}},
	{id = 6,	name = "七宝城",	teleport = 60006,	icon = "transfer_land",	condition = {{1,6006},{2,1052015},{3,1056014},{2,202070}},	npc = 6006,	pos = {897.49,805.26}},
	{id = 7,	name = "天斗原",	teleport = 60007,	icon = "transfer_land",	condition = {{1,6007}},	npc = 6007,	pos = {972,760.69}},
	{id = 8,	name = "天斗皇家学院",	teleport = 60008,	icon = "transfer_air",	condition = {{1,6008}},	npc = 6008,	pos = {1052,770}},
	{id = 9,	name = "天斗远郊",	teleport = 60009,	icon = "transfer_air",	condition = {{1,6009}},	npc = 6009,	pos = {1122,760.69}},
	{id = 10,	name = "小唐村",	teleport = 60010,	icon = "transfer_air",	condition = {{1,6010}},	npc = 6010,	pos = {1241,735}},
	{id = 11,	name = "天宝旅馆",	teleport = 60011,	icon = "transfer_land",	condition = {{1,6011}},	npc = 6011,	pos = {893.91,738.6}},
	{id = 12,	name = "天斗军营",	teleport = 60012,	icon = "transfer_change",	condition = {{1,6012}},	npc = 6012,	pos = {1043.2,690}},
	{id = 13,	name = "华金道",	teleport = 60013,	icon = "transfer_land",	condition = {{1,6013},{2,203070}},	npc = 6013,	pos = {1161,680.69}},
	{id = 14,	name = "西尔维斯城",	teleport = 60014,	icon = "transfer_change",	condition = {{1,6014},{1,6038}},	npc = 6014,	pos = {958.57,669.73}},
	{id = 15,	name = "魂龙间",	teleport = 60015,	icon = "transfer_land",	condition = {{1,6015}},	npc = 6015,	pos = {900.91,647.88}},
	{id = 16,	name = "凤栖村",	teleport = 60016,	icon = "transfer_land",	condition = {{1,6016},{3,1040325},{2,203070}},	npc = 6016,	pos = {1048,628}},
	{id = 17,	name = "索托城",	teleport = 60017,	icon = "transfer_change",	condition = {{1,6017}},	npc = 6017,	pos = {927.45,571.24}},
	{id = 18,	name = "史莱克学院",	teleport = 60018,	icon = "transfer_land",	condition = {{1,6018},{3,2100675}},	npc = 6018,	pos = {984,610}},
	{id = 19,	name = "圣魂村",	teleport = 60019,	icon = "transfer_land",	condition = {{1,6019}},	npc = 6019,	pos = {1105.9,589.73}},
	{id = 20,	name = "诺丁城",	teleport = 60020,	icon = "transfer_land",	condition = {{1,6020}},	npc = 6020,	pos = {1092,540}},
	{id = 21,	name = "断罪峡",	teleport = 60021,	icon = "transfer_change",	condition = {{1,6021},{1,6039}},	npc = 6021,	pos = {801.8,578.8}},
	{id = 22,	name = "入海流",	teleport = 60022,	icon = "transfer_land",	condition = {{1,6022}},	npc = 6022,	pos = {852.56,558.1}},
	{id = 23,	name = "星斗大森林·外围",	teleport = 60023,	icon = "transfer_air",	condition = {{1,6023}},	npc = 6023,	pos = {973.91,509.73}},
	{id = 24,	name = "猎魂森林",	teleport = 60024,	icon = "transfer_change",	condition = {{1,6024},{3,1056014},{3,1030615},{3,1040325},{3,1020340},{3,1035390}},	npc = 6024,	pos = {1043.2,504.51}},
	{id = 25,	name = "都灵村",	teleport = 60025,	icon = "transfer_land",	condition = {{1,6025}},	npc = 6025,	pos = {754.7,478.1}},
	{id = 26,	name = "木棉山庄",	teleport = 60026,	icon = "transfer_air",	condition = {{1,6026}},	npc = 6026,	pos = {702,432.3}},
	{id = 27,	name = "星斗大森林·迷踪",	teleport = 60027,	icon = "transfer_air",	condition = {{1,6027}},	npc = 6027,	pos = {820.91,415.45}},
	{id = 28,	name = "星罗官道",	teleport = 60028,	icon = "transfer_change",	condition = {{1,6028},{3,200080},{2,204070}},	npc = 6028,	pos = {766.21,380.9}},
	{id = 29,	name = "星斗村",	teleport = 60029,	icon = "transfer_land",	condition = {{1,6029}},	npc = 6029,	pos = {801.8,347.15}},
	{id = 30,	name = "星罗西军营",	teleport = 60030,	icon = "transfer_air",	condition = {{1,6030}},	npc = 6030,	pos = {600.9,352.3}},
	{id = 31,	name = "星罗城下城区",	teleport = 60031,	icon = "transfer_air",	condition = {{1,6031},{2,1035115},{3,2100675}},	npc = 6031,	pos = {726.38,280.84}},
	{id = 32,	name = "星罗城上城区",	teleport = 60032,	icon = "transfer_air",	condition = {{1,6032},{2,1035115},{3,1035390},{3,1030615},{3,200080},{2,201075}},	npc = 6032,	pos = {622,256}},
	{id = 33,	name = "虎王峰·南岳",	teleport = 60033,	icon = "transfer_air",	condition = {{1,6033},{2,201075}},	npc = 6033,	pos = {678,192}},
	{id = 34,	name = "星罗东军营",	teleport = 60034,	icon = "transfer_air",	condition = {{1,6034}},	npc = 6034,	pos = {766.21,205}},
	{id = 35,	name = "废弃监狱",	teleport = 60035,	icon = "transfer_air",	condition = {{1,6035}},	npc = 6035,	pos = {824,185}},
	{id = 36,	name = "禁忌之地",	teleport = 60036,	icon = "transfer_air",	condition = {{1,6036}},	npc = 6036,	pos = {1098,717}},
}

return fly_way_point