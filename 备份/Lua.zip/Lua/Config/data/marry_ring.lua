-- 此文件工具自动生成，不要修改
--ringid	int	11	唯一编号[sl][l]
--type	int	11	0表示草戒 1表示订婚戒指 2表示结婚戒指[sl][l]
--base	int	11	item表id[sl][l]
--level	int	11	戒指等级[sl][l]
--attr	char	16	属性[sl:vv][l]
--attr_buff	int	11	属性buff[sl][l]
--qy_buff	int	11	情缘buff[sl][l]
--love_effect	char	16	多少秒:加多少恩爱值:每天能增加次数[sl:v][l]
local marry_ring =
{
	{ringid = 1,	type = 0,	base = 240,	level = 0,	attr = {{31,1,99},{32,1,99},{33,1,99},{34,1,99},{35,1,99}},	attr_buff = 0,	qy_buff = 221,	love_effect = {{20,10,90}}},
	{ringid = 2,	type = 1,	base = 241,	level = 1,	attr = {{31,1,99},{32,1,99},{33,1,99},{34,1,99},{35,1,99}},	attr_buff = 0,	qy_buff = 221,	love_effect = {{20,10,90}}},
	{ringid = 3,	type = 2,	base = 242,	level = 2,	attr = {{31,1,366},{32,1,366},{33,1,366},{34,1,366},{35,1,366}},	attr_buff = 225,	qy_buff = 222,	love_effect = {{20,20,90}}},
	{ringid = 4,	type = 2,	base = 243,	level = 3,	attr = {{31,1,666},{32,1,666},{33,1,666},{34,1,666},{35,1,666}},	attr_buff = 226,	qy_buff = 223,	love_effect = {{20,30,90}}},
	{ringid = 5,	type = 2,	base = 244,	level = 4,	attr = {{31,1,999},{32,1,999},{33,1,999},{34,1,999},{35,1,999}},	attr_buff = 227,	qy_buff = 224,	love_effect = {{20,40,90}}},
}

return marry_ring