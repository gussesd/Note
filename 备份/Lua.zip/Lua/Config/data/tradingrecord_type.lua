-- 此文件工具自动生成，不要修改
--index	int	11	排序[l]
--name	char	64	名字[l]
--nodelv	int	11	页签等级(1：父页签，2：子页签)[l]
--nodetype	int	11	页签类型[l]
--recordtype	int	11	记录大类(1,个人记录，2宗门记录，3世界记录)[l]
local tradingrecord_type =
{
	{index = 1,	name = "个人记录",	nodelv = 1,	nodetype = 0,	recordtype = 1},
	{index = 2,	name = "购买",	nodelv = 2,	nodetype = 1,	recordtype = 1},
	{index = 3,	name = "出售",	nodelv = 2,	nodetype = 2,	recordtype = 1},
	{index = 4,	name = "宗门记录",	nodelv = 1,	nodetype = 0,	recordtype = 2},
	{index = 5,	name = "出售",	nodelv = 2,	nodetype = 1,	recordtype = 2},
	{index = 6,	name = "流拍",	nodelv = 2,	nodetype = 2,	recordtype = 2},
	{index = 7,	name = "世界记录",	nodelv = 1,	nodetype = 0,	recordtype = 3},
}

return tradingrecord_type