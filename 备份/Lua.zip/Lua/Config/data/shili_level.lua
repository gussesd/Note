-- 此文件工具自动生成，不要修改
--level	int	11	等级[sl][l]
--value	int	11	总友好度[sl][l]
--discount	int	11	折扣百分比[sl][l]
--desc	char	16	描述[l]
local shili_level =
{
	{level = 1,	value = 200,	discount = 95,	desc = "友善"},
	{level = 2,	value = 600,	discount = 95,	desc = "友善"},
	{level = 3,	value = 1200,	discount = 90,	desc = "尊敬"},
	{level = 4,	value = 2000,	discount = 90,	desc = "尊敬"},
	{level = 5,	value = 3000,	discount = 90,	desc = "尊敬"},
	{level = 6,	value = 4200,	discount = 85,	desc = "崇敬"},
	{level = 7,	value = 5600,	discount = 85,	desc = "崇敬"},
	{level = 8,	value = 7200,	discount = 85,	desc = "崇敬"},
	{level = 9,	value = 9000,	discount = 85,	desc = "崇敬"},
	{level = 10,	value = 11000,	discount = 80,	desc = "崇拜"},
	{level = 11,	value = 13200,	discount = 80,	desc = "崇拜"},
	{level = 12,	value = 15600,	discount = 80,	desc = "崇拜"},
	{level = 13,	value = 18400,	discount = 80,	desc = "崇拜"},
	{level = 14,	value = 22000,	discount = 80,	desc = "崇拜"},
	{level = 15,	value = 26000,	discount = 75,	desc = "信仰"},
}

return shili_level