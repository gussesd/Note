-- 此文件工具自动生成，不要修改
--grade	int	11	玄天功等级[sl:i][l]
--pool	int	11	内力池上限[sl:i][l]
--attr	char	128	属性[sl:vv][l][DMH]
--param	int	11	魂师称号限制[sl:i][l]
--point	int	11	玄天宝录点数[sl:i][l]
--level	char	16	显示玄天功等级[l]
--state	char	16	显示玄天功小境界等级[l]
--name	char	16	境界名称[l]
--unlock	char	16	解锁内丹格子[l]
local neigong_grade =
{
	{grade = 1,	pool = 102400,	attr = {95,1,800},	param = 1,	point = 5,	level = "1",	state = "",	name = "一重",	unlock = "1"},
	{grade = 2,	pool = 128000,	attr = {95,1,1000},	param = 1,	point = 5,	level = "2",	state = "",	name = "二重",	unlock = "2"},
	{grade = 3,	pool = 288000,	attr = {95,1,1200},	param = 1,	point = 5,	level = "3",	state = "",	name = "三重",	unlock = "3"},
	{grade = 4,	pool = 480000,	attr = {95,1,1500},	param = 1,	point = 5,	level = "4",	state = "",	name = "四重",	unlock = "4"},
	{grade = 5,	pool = 748000,	attr = {95,1,1800},	param = 1,	point = 5,	level = "5",	state = "",	name = "五重",	unlock = "4"},
	{grade = 6,	pool = 1056000,	attr = {95,1,2200},	param = 1,	point = 5,	level = "6",	state = "",	name = "六重",	unlock = "4"},
	{grade = 7,	pool = 1296000,	attr = {95,1,2700},	param = 1,	point = 5,	level = "7",	state = "",	name = "七重",	unlock = "4"},
	{grade = 8,	pool = 1584000,	attr = {95,1,3300},	param = 1,	point = 5,	level = "8",	state = "",	name = "八重",	unlock = "4"},
	{grade = 9,	pool = 1920000,	attr = {95,1,4000},	param = 1,	point = 5,	level = "8",	state = "8002",	name = "八重·蜕凡",	unlock = "4"},
	{grade = 10,	pool = 2304000,	attr = {95,1,4800},	param = 1,	point = 5,	level = "9",	state = "",	name = "九重",	unlock = "4"},
	{grade = 11,	pool = 2736000,	attr = {95,1,5700},	param = 1,	point = 5,	level = "9",	state = "9002",	name = "九重·涅槃",	unlock = "4"},
	{grade = 12,	pool = 3288000,	attr = {95,1,6850},	param = 1,	point = 5,	level = "9",	state = "9003",	name = "九重·渡地",	unlock = "4"},
	{grade = 13,	pool = 3955200,	attr = {95,1,8240},	param = 1,	point = 5,	level = "9",	state = "9004",	name = "九重·遮天",	unlock = "4"},
	{grade = 14,	pool = 5145600,	attr = {95,1,10720},	param = 1,	point = 5,	level = "9",	state = "9005",	name = "九重·玄极",	unlock = "4"},
	{grade = 15,	pool = 7200000,	attr = {95,1,15000},	param = 1,	point = 5,	level = "9",	state = "9006",	name = "九重·无衍",	unlock = "4"},
	{grade = 16,	pool = 14400000,	attr = {95,1,30000},	param = 1,	point = 5,	level = "9",	state = "9007",	name = "九重·帝宇",	unlock = "4"},
}

return neigong_grade