-- 此文件工具自动生成，不要修改
--id	int	11	实例id[sl:i][l]
--audio_id	int	11	模板id[sl:i][l]
--map	int	11	地图id[sl:i][l]
--position	char	1024	坐标[sl:v][l][DMH][Vector3]
--random	int	11	随机参数（万分之一，填10000就是不随机）[sl:v][l]
--range	char	1024	有效范围（1圆形：半径，2矩形：长：宽：高）[sl:v][l]
local map_audio =
{
	{id = 100001,	audio_id = 10012,	map = 1001,	position = {5282.45,236.04,4912.32},	random = 10000,	range = {{1,100}}},
}

return map_audio