-- 此文件工具自动生成，不要修改
--id	int	11	序号[l][#][sl:i]
--type	int	11	类型[l][sl:i]
--job	int	11	职业[l][sl:i]
--sex	int	11	性别(0男,1女,2通用)[l][sl:i]
--name	char	16	小节名[l]
--desc	char	128	描述[l]
--hint_area	char	16	执行任务区域[l]
--hint_pilot	char	256	追踪点(x:y:z:r|x:y:z:r，r半径，点为0）[l][float[][]]
--stage_event	char	1024	阶段行为配置[l][NoColor]
--npc_occupy_info	char	1024	npc占用配置[l]
--condition_info	char	128	任务进度描述[l][DMH]
--condition_special	char	64	任务完成特殊处理[l][sl:v]
--stage_special	char	64	阶段完成特殊处理[l][NTB]
--condition_list	char	1024	完成任务类型[l][sl:vv]
local task_yaoyue =
{
	{id = 900010,	type = 17,	job = 0,	sex = 2,	name = "花树遐思",	desc = "",	hint_area = "",	hint_pilot = "",	stage_event = {{2,"0#600010@6#900010@1#600010"}},	npc_occupy_info = "",	condition_info = "",	condition_special = "0",	stage_special = {},	condition_list = {{12,45000}}},
}

return task_yaoyue