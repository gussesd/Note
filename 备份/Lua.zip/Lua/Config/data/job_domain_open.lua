-- 此文件工具自动生成，不要修改
--id	int	11	对应宗门id[l]
--fog_open	char	64	对应开放区域，冒号分割[l][DMH]
local job_domain_open =
{
	{id = 1,	fog_open = {11}},
	{id = 2,	fog_open = {12}},
	{id = 3,	fog_open = {13}},
	{id = 4,	fog_open = {14}},
	{id = 5,	fog_open = {15}},
}

return job_domain_open