-- 此文件工具自动生成，不要修改
--id	int	11	序列[l]
--name	char	256	部位名称[l]
--count	char	16	样式显示数量[l][DMH]
--icon	char	256	部位icon[l]
--width	int	11	样式icon长[l]
--height	int	11	样式icon宽[l]
--style_effect	char	32	样式[l][DMH]
--lineCount	int	4	样式一行显示几个[l]
local make_face_zr =
{
	{id = 1,	name = "发型",	count = {8,8},	icon = "faxin",	width = 108,	height = 172,	style_effect = {1,4},	lineCount = 3},
	{id = 2,	name = "腮红",	count = {2,5},	icon = "saihong",	width = 180,	height = 116,	style_effect = {2,20,3},	lineCount = 2},
	{id = 3,	name = "纹饰",	count = {6,10},	icon = "wenshi",	width = 180,	height = 116,	style_effect = {2,30,20,10,3},	lineCount = 2},
	{id = 4,	name = "美瞳",	count = {13,13},	icon = "meitong",	width = 114,	height = 114,	style_effect = {1,4,43},	lineCount = 3},
	{id = 5,	name = "睫毛",	count = {2,6},	icon = "jiemao",	width = 172,	height = 108,	style_effect = {41,42},	lineCount = 2},
	{id = 6,	name = "眼妆",	count = {8,10},	icon = "yanzhuang",	width = 188,	height = 124,	style_effect = {1,4,2,10,3},	lineCount = 2},
	{id = 7,	name = "眉毛",	count = {6,10},	icon = "meimao",	width = 172,	height = 108,	style_effect = {1,4,3},	lineCount = 2},
	{id = 8,	name = "唇彩",	count = {8,10},	icon = "zuiba",	width = 172,	height = 108,	style_effect = {1,4,10,3,2},	lineCount = 2},
	{id = 9,	name = "胡子",	count = {2,2},	icon = "huzi",	width = 180,	height = 116,	style_effect = {1,4,2},	lineCount = 2},
	{id = 10,	name = "肤色",	count = {1,4},	icon = "fuse",	width = 172,	height = 108,	style_effect = {3},	lineCount = 3},
	{id = 11,	name = "眼型",	count = {6,9},	icon = "yanxin",	width = 188,	height = 124,	style_effect = {2,3},	lineCount = 2},
}

return make_face_zr