-- 此文件工具自动生成，不要修改
--grade	int	11	赛段[l][sl:i]
--hunshi_min	int	11	最低魂师称号[l][sl:i]
--hunshi_max	int	11	最高魂师称号[l][sl:i]
local arena_grade_7v7 =
{
	{grade = 1,	hunshi_min = 0,	hunshi_max = 6},
	{grade = 2,	hunshi_min = 7,	hunshi_max = 9},
	{grade = 3,	hunshi_min = 10,	hunshi_max = 15},
}

return arena_grade_7v7