-- 此文件工具自动生成，不要修改
--id	int	11	id[sl][l]
--name	char	16	名字[sl][l]
--fileName	char	16	资源名[sl][l]
--type	int	11	类型（0默认1月卡）[sl][l]
local chat_big_emoji =
{
	{id = 10101,	name = "欢笑",	fileName = "1",	type = 0},
	{id = 10102,	name = "微笑",	fileName = "2",	type = 0},
	{id = 10103,	name = "愤怒",	fileName = "3",	type = 0},
	{id = 10104,	name = "哭笑不得",	fileName = "4",	type = 0},
	{id = 10105,	name = "尴尬",	fileName = "5",	type = 0},
	{id = 10106,	name = "害羞",	fileName = "6",	type = 0},
	{id = 10107,	name = "得意",	fileName = "7",	type = 0},
	{id = 10108,	name = "不好意思",	fileName = "1",	type = 0},
	{id = 10109,	name = "纠结",	fileName = "9",	type = 0},
	{id = 10110,	name = "汗",	fileName = "10",	type = 0},
	{id = 10111,	name = "惊讶",	fileName = "11",	type = 0},
	{id = 10112,	name = "委屈",	fileName = "12",	type = 0},
	{id = 10113,	name = "欢乐",	fileName = "13",	type = 0},
	{id = 10114,	name = "晕",	fileName = "14",	type = 0},
	{id = 10115,	name = "调皮",	fileName = "15",	type = 0},
	{id = 10116,	name = "疑惑",	fileName = "16",	type = 0},
	{id = 10117,	name = "嘿嘿",	fileName = "17",	type = 0},
	{id = 10118,	name = "敲头",	fileName = "18",	type = 0},
	{id = 10119,	name = "睡觉",	fileName = "19",	type = 0},
	{id = 10120,	name = "难受",	fileName = "20",	type = 0},
	{id = 10201,	name = "哭泣",	fileName = "1",	type = 1},
	{id = 10202,	name = "大哭",	fileName = "2",	type = 1},
	{id = 10203,	name = "呆滞",	fileName = "3",	type = 1},
	{id = 10204,	name = "期待",	fileName = "4",	type = 1},
	{id = 10205,	name = "认错",	fileName = "5",	type = 1},
	{id = 10206,	name = "吃惊",	fileName = "6",	type = 1},
	{id = 10207,	name = "快乐",	fileName = "7",	type = 1},
	{id = 10208,	name = "耍赖",	fileName = "8",	type = 1},
	{id = 10209,	name = "害怕",	fileName = "9",	type = 1},
	{id = 10210,	name = "登场",	fileName = "10",	type = 1},
	{id = 10211,	name = "睡觉",	fileName = "11",	type = 1},
	{id = 10212,	name = "贴贴",	fileName = "12",	type = 1},
	{id = 10213,	name = "崇拜",	fileName = "13",	type = 1},
	{id = 10214,	name = "生气",	fileName = "14",	type = 1},
	{id = 10215,	name = "踢腿",	fileName = "15",	type = 1},
	{id = 10216,	name = "跳舞",	fileName = "16",	type = 1},
	{id = 10217,	name = "晕倒",	fileName = "17",	type = 1},
	{id = 10218,	name = "动动",	fileName = "18",	type = 1},
	{id = 10219,	name = "快来",	fileName = "19",	type = 1},
	{id = 10220,	name = "看剧",	fileName = "20",	type = 1},
}

return chat_big_emoji