-- 此文件工具自动生成，不要修改
--from	int	11	起始地图id[l]
--to	int	11	目标地图id[l]
--message	char	256	文字描述[l]
--time	int	11	最少显示时间(毫秒)[l]
local map_loading =
{
	{from = 1000,	to = 1000,	message = "",	time = 1000},
	{from = 10001,	to = 10002,	message = "",	time = 1000},
	{from = 10006,	to = 10002,	message = "",	time = 1000},
	{from = 10002,	to = 10007,	message = "",	time = 1000},
	{from = 10008,	to = 10003,	message = "",	time = 1000},
	{from = 10003,	to = 10005,	message = "",	time = 1000},
	{from = 10009,	to = 10003,	message = "",	time = 1000},
	{from = 10005,	to = 10003,	message = "",	time = 1000},
	{from = 10009,	to = 10007,	message = "",	time = 1000},
}

return map_loading