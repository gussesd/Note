-- 此文件工具自动生成，不要修改
--map	int	11	地图id(仅限常规地图)[l]
--force	int	11	阵营[l]
--desc	char	32	描述[l]
--enemy	int	11	敌对关系(可攻击，控制，减益等)[l]
--ally	int	11	联盟关系(可治疗，增益等)[l]
local map_force =
{
	{map = 90000,	force = 1,	desc = "A玩家",	enemy = 2,	ally = 1},
	{map = 90000,	force = 2,	desc = "B玩家",	enemy = 1,	ally = 2},
	{map = 90000,	force = 3,	desc = "A小兵",	enemy = 4192,	ally = 4},
	{map = 90000,	force = 4,	desc = "A水晶",	enemy = 34,	ally = 0},
	{map = 90000,	force = 5,	desc = "A泉水",	enemy = 2,	ally = 1},
	{map = 90000,	force = 6,	desc = "B小兵",	enemy = 2060,	ally = 32},
	{map = 90000,	force = 7,	desc = "B水晶",	enemy = 5,	ally = 0},
	{map = 90000,	force = 8,	desc = "B泉水",	enemy = 1,	ally = 2},
	{map = 90000,	force = 9,	desc = "空据点",	enemy = 0,	ally = 0},
	{map = 90000,	force = 10,	desc = "A据点",	enemy = 0,	ally = 5},
	{map = 90000,	force = 11,	desc = "B据点",	enemy = 0,	ally = 34},
	{map = 90000,	force = 12,	desc = "A防御塔",	enemy = 32,	ally = 0},
	{map = 90000,	force = 13,	desc = "B防御塔",	enemy = 4,	ally = 0},
}

return map_force