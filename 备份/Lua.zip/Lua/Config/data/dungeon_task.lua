-- 此文件工具自动生成，不要修改
--id	int	11	序号[l]
--scene_name	char	16	场景资源名[l]
--scene_index	int	11	场景索引id[l]
--shape	int	11	范围形状(0.圆形；1.矩形)[l]
--start_point	char	64	起始点[l][DMH]
--range_size	char	64	范围坐标(start_x,start_y,end_x,end_y)[l][DMH]
--voxel_path	char	256	体素模块[l]
--npc_list	char	64	npc列表[l]
--monster_list	char	64	怪物列表[l]
--trap_list	char	64	陷阱列表[l]
--treasure_list	char	64	宝箱列表[l]
--behavior_list	char	64	进度列表[l]
local dungeon_task =
{
	{id = 10001,	scene_name = "scene_qstm",	scene_index = 0,	shape = 0,	start_point = {0,0,50,50},	range_size = "",	voxel_path = "Scene/Voxel/scene_qstm/",	npc_list = "",	monster_list = "",	trap_list = "",	treasure_list = "",	behavior_list = ""},
}

return dungeon_task