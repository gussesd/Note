-- 此文件工具自动生成，不要修改
--desc	char	256	配置描述[l]
--value	char	1024	配置数值[l]
local global_params =
{
}

return global_params