-- 此文件工具自动生成，不要修改
--id	int	11	唯一ID[l][sl]
--type	int	11	类型(1头像框2气泡3背景4底纹)[l][sl]
--name	char	64	名称[l]
--desc	char	128	描述[l]
--sex	int	11	性别(-1无限制)[l][sl]
--job	int	11	职业(-1无限制1白虎2昊天3灵猫4凤凰5琉璃）[l][sl]
--level	int	11	等级[l][sl]
--condition_special	int	11	解锁条件特殊处理(0-全部完成,1任一完成)[l][sl]
--condition	char	128	解锁条件(1完成任务(id)|2消耗物品(id:type:count)3月卡4宗门5结婚6赞助7势力积分8探索度9完成xx个任务10斗魂积分)[l][sl:vv]
--time	int	11	限时(-1永久,>0持续时长(秒))[l][sl]
--icon	char	16	道具图标[l]
--sort	int	11	排序[l]
--display	int	11	是否显示(1显示0隐藏)[l]
--color	char	16	气泡字色[l]
local personal_set =
{
	{id = 1000,	type = 1,	name = "默认头像框",	desc = "默认头像框",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "1000",	sort = 1,	display = 1,	color = ""},
	{id = 1001,	type = 1,	name = "白虎宗",	desc = "成为白虎宗弟子获得",	sex = -1,	job = 1,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "1001",	sort = 2,	display = 1,	color = ""},
	{id = 1002,	type = 1,	name = "昊天宗",	desc = "成为昊天宗弟子获得",	sex = -1,	job = 2,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "1002",	sort = 3,	display = 1,	color = ""},
	{id = 1003,	type = 1,	name = "灵猫宗",	desc = "成为灵猫宗弟子获得",	sex = -1,	job = 3,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "1003",	sort = 4,	display = 1,	color = ""},
	{id = 1004,	type = 1,	name = "凤凰宗",	desc = "成为凤凰宗弟子获得",	sex = -1,	job = 4,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "1004",	sort = 5,	display = 1,	color = ""},
	{id = 1005,	type = 1,	name = "七宝琉璃宗",	desc = "成为七宝琉璃宗弟子获得",	sex = -1,	job = 5,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "1005",	sort = 6,	display = 1,	color = ""},
	{id = 1006,	type = 1,	name = "天斗帝国",	desc = "魂力等级达到20激活",	sex = -1,	job = -1,	level = 20,	condition_special = 0,	condition = "",	time = -1,	icon = "1006",	sort = 7,	display = 1,	color = ""},
	{id = 1007,	type = 1,	name = "星罗帝国",	desc = "魂力等级达到20激活",	sex = -1,	job = -1,	level = 20,	condition_special = 0,	condition = "",	time = -1,	icon = "1007",	sort = 8,	display = 1,	color = ""},
	{id = 1008,	type = 1,	name = "武魂殿",	desc = "魂力等级达到40激活",	sex = -1,	job = -1,	level = 40,	condition_special = 0,	condition = "",	time = -1,	icon = "1008",	sort = 14,	display = 1,	color = ""},
	{id = 1009,	type = 1,	name = "杀戮之都",	desc = "魂力等级达到50激活",	sex = -1,	job = -1,	level = 50,	condition_special = 0,	condition = "",	time = -1,	icon = "1009",	sort = 15,	display = 1,	color = ""},
	{id = 1010,	type = 1,	name = "海神岛",	desc = "魂力等级达到60激活",	sex = -1,	job = -1,	level = 60,	condition_special = 0,	condition = "",	time = -1,	icon = "1010",	sort = 16,	display = 1,	color = ""},
	{id = 1011,	type = 1,	name = "史莱克学院",	desc = "完成主线-奇遇疑云激活",	sex = -1,	job = -1,	level = 1,	condition_special = 1,	condition = {{1,1120335}},	time = -1,	icon = "1011",	sort = 9,	display = 1,	color = ""},
	{id = 1012,	type = 1,	name = "斗魂场",	desc = "竞技商店购买",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{2,15002,1,1}},	time = 259200,	icon = "1012",	sort = 10,	display = 1,	color = ""},
	{id = 1013,	type = 1,	name = "月卡",	desc = "购买月卡可激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = "3",	time = -1,	icon = "1013",	sort = 11,	display = 1,	color = ""},
	{id = 1014,	type = 1,	name = "宗门成员",	desc = "加入宗门可激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = "4",	time = -1,	icon = "1014",	sort = 12,	display = 1,	color = ""},
	{id = 1015,	type = 1,	name = "情缘",	desc = "拥有伴侣可激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = "5",	time = -1,	icon = "1015",	sort = 13,	display = 1,	color = ""},
	{id = 1016,	type = 1,	name = "冰火两仪眼",	desc = "魂力等级达到40激活",	sex = -1,	job = -1,	level = 40,	condition_special = 0,	condition = "",	time = -1,	icon = "1016",	sort = 24,	display = 1,	color = ""},
	{id = 1017,	type = 1,	name = "月轩",	desc = "魂力等级达到40激活",	sex = -1,	job = -1,	level = 40,	condition_special = 0,	condition = "",	time = -1,	icon = "1017",	sort = 23,	display = 1,	color = ""},
	{id = 1018,	type = 1,	name = "白银赞助",	desc = "购买白银赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,1}},	time = -1,	icon = "1018",	sort = 17,	display = 1,	color = ""},
	{id = 1019,	type = 1,	name = "黄金赞助",	desc = "购买黄金赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,2}},	time = -1,	icon = "1019",	sort = 18,	display = 1,	color = ""},
	{id = 1020,	type = 1,	name = "紫金赞助",	desc = "购买紫金赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,3}},	time = -1,	icon = "1020",	sort = 19,	display = 1,	color = ""},
	{id = 1021,	type = 1,	name = "蓝宝石赞助",	desc = "购买蓝宝石赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,4}},	time = -1,	icon = "1021",	sort = 20,	display = 1,	color = ""},
	{id = 1022,	type = 1,	name = "红宝石赞助",	desc = "购买红宝石赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,5}},	time = -1,	icon = "1022",	sort = 21,	display = 1,	color = ""},
	{id = 1023,	type = 1,	name = "钻石赞助",	desc = "购买钻石赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,6}},	time = -1,	icon = "1023",	sort = 22,	display = 1,	color = ""},
	{id = 1024,	type = 1,	name = "复古",	desc = "战令获得",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{2,15003,1,1}},	time = -1,	icon = "1028",	sort = 25,	display = 1,	color = ""},
	{id = 1025,	type = 1,	name = "唐门",	desc = "完成主线-梦回唐门激活",	sex = -1,	job = -1,	level = 1,	condition_special = 1,	condition = {{1,1140355}},	time = -1,	icon = "1024",	sort = 26,	display = 1,	color = ""},
	{id = 1026,	type = 1,	name = "星斗大森林",	desc = "完成主线-初入大星斗激活",	sex = -1,	job = -1,	level = 1,	condition_special = 1,	condition = {{1,1250085}},	time = -1,	icon = "1025",	sort = 27,	display = 1,	color = ""},
	{id = 2001,	type = 2,	name = "白虎宗",	desc = "白虎宗默认气泡",	sex = -1,	job = 1,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "001",	sort = 1,	display = 1,	color = "<color=#343333>"},
	{id = 2002,	type = 2,	name = "昊天宗",	desc = "昊天宗默认气泡",	sex = -1,	job = 2,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "002",	sort = 2,	display = 1,	color = "<color=#343333>"},
	{id = 2003,	type = 2,	name = "灵猫宗",	desc = "灵猫宗默认气泡",	sex = -1,	job = 3,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "003",	sort = 3,	display = 1,	color = "<color=#343333>"},
	{id = 2004,	type = 2,	name = "凤凰宗",	desc = "凤凰宗默认气泡",	sex = -1,	job = 4,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "004",	sort = 4,	display = 1,	color = "<color=#343333>"},
	{id = 2005,	type = 2,	name = "七宝琉璃宗",	desc = "七宝琉璃宗默认气泡",	sex = -1,	job = 5,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "005",	sort = 5,	display = 1,	color = "<color=#343333>"},
	{id = 2006,	type = 2,	name = "天斗帝国",	desc = "完成天斗势力悬赏10个",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{9,5,10}},	time = -1,	icon = "006",	sort = 6,	display = 1,	color = "<color=#343333>"},
	{id = 2007,	type = 2,	name = "星罗帝国",	desc = "完成星罗势力悬赏10个",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{9,6,10}},	time = -1,	icon = "007",	sort = 7,	display = 1,	color = "<color=#343333>"},
	{id = 2008,	type = 2,	name = "复古",	desc = "战令获得",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{2,15205,1,1}},	time = -1,	icon = "008",	sort = 8,	display = 1,	color = "<color=#343333>"},
	{id = 4001,	type = 4,	name = "初出茅庐",	desc = "默认底纹",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = "",	time = -1,	icon = "4001",	sort = 1,	display = 1,	color = ""},
	{id = 4002,	type = 4,	name = "白虎宗",	desc = "宗族任务奖励",	sex = -1,	job = 1,	level = 1,	condition_special = 0,	condition = {{2,15402,1,1}},	time = -1,	icon = "4002",	sort = 2,	display = 1,	color = ""},
	{id = 4003,	type = 4,	name = "昊天宗",	desc = "宗族任务奖励",	sex = -1,	job = 2,	level = 1,	condition_special = 0,	condition = {{2,15403,1,1}},	time = -1,	icon = "4003",	sort = 3,	display = 1,	color = ""},
	{id = 4004,	type = 4,	name = "灵猫宗",	desc = "宗族任务奖励",	sex = -1,	job = 3,	level = 1,	condition_special = 0,	condition = {{2,15404,1,1}},	time = -1,	icon = "4004",	sort = 4,	display = 1,	color = ""},
	{id = 4005,	type = 4,	name = "凤凰宗",	desc = "宗族任务奖励",	sex = -1,	job = 4,	level = 1,	condition_special = 0,	condition = {{2,15405,1,1}},	time = -1,	icon = "4005",	sort = 5,	display = 1,	color = ""},
	{id = 4006,	type = 4,	name = "七宝琉璃宗",	desc = "宗族任务奖励",	sex = -1,	job = 5,	level = 1,	condition_special = 0,	condition = {{2,15406,1,1}},	time = -1,	icon = "4006",	sort = 6,	display = 1,	color = ""},
	{id = 4007,	type = 4,	name = "天斗帝国",	desc = "天斗势力达到崇敬",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{7,1,1200}},	time = -1,	icon = "4007",	sort = 7,	display = 1,	color = ""},
	{id = 4008,	type = 4,	name = "星罗帝国",	desc = "星罗势力达到崇敬",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{7,2,1200}},	time = -1,	icon = "4008",	sort = 8,	display = 1,	color = ""},
	{id = 4009,	type = 4,	name = "武魂殿",	desc = "武魂殿势力达到崇敬",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{7,3,1200}},	time = -1,	icon = "4009",	sort = 9,	display = 1,	color = ""},
	{id = 4010,	type = 4,	name = "杀戮之都",	desc = "杀戮之都势力达到崇敬",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{7,4,1200}},	time = -1,	icon = "4010",	sort = 10,	display = 1,	color = ""},
	{id = 4011,	type = 4,	name = "海神岛",	desc = "海神岛势力达到崇敬",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{7,5,1200}},	time = -1,	icon = "4011",	sort = 11,	display = 1,	color = ""},
	{id = 4012,	type = 4,	name = "星斗大森林",	desc = "星斗大森林1线探索度10%",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{8,4,10}},	time = -1,	icon = "4012",	sort = 12,	display = 1,	color = ""},
	{id = 4013,	type = 4,	name = "史莱克学院",	desc = "完成学院历练20个",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{9,3,20}},	time = -1,	icon = "4013",	sort = 13,	display = 1,	color = ""},
	{id = 4014,	type = 4,	name = "斗魂场",	desc = "首次达到金斗魂段位",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{10,3000}},	time = -1,	icon = "4014",	sort = 14,	display = 1,	color = ""},
	{id = 4015,	type = 4,	name = "白银赞助",	desc = "购买白银赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,1}},	time = -1,	icon = "4015",	sort = 15,	display = 1,	color = ""},
	{id = 4016,	type = 4,	name = "黄金赞助",	desc = "购买黄金赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,2}},	time = -1,	icon = "4016",	sort = 16,	display = 1,	color = ""},
	{id = 4017,	type = 4,	name = "紫金赞助",	desc = "购买紫金赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,3}},	time = -1,	icon = "4017",	sort = 17,	display = 1,	color = ""},
	{id = 4018,	type = 4,	name = "蓝宝石赞助",	desc = "购买蓝宝石赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,4}},	time = -1,	icon = "4018",	sort = 18,	display = 1,	color = ""},
	{id = 4019,	type = 4,	name = "红宝石赞助",	desc = "购买红宝石赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,5}},	time = -1,	icon = "4019",	sort = 19,	display = 1,	color = ""},
	{id = 4020,	type = 4,	name = "钻石赞助",	desc = "购买钻石赞助激活",	sex = -1,	job = -1,	level = 1,	condition_special = 0,	condition = {{6,6}},	time = -1,	icon = "4020",	sort = 20,	display = 1,	color = ""},
	{id = 4021,	type = 4,	name = "冰火两仪眼",	desc = "魂力等级达到40激活",	sex = -1,	job = -1,	level = 40,	condition_special = 0,	condition = "",	time = -1,	icon = "4021",	sort = 21,	display = 1,	color = ""},
	{id = 4022,	type = 4,	name = "月轩",	desc = "魂力等级达到40激活",	sex = -1,	job = -1,	level = 40,	condition_special = 0,	condition = "",	time = -1,	icon = "4022",	sort = 22,	display = 1,	color = ""},
}

return personal_set