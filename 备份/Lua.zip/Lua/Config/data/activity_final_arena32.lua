-- 此文件工具自动生成，不要修改
--state_id	int	11	分组id（小组赛轮次分组id）[l]
--index	int	11	序号（每轮比赛包含的场次序号）[l]
--time	int	11	时间戳[l]
local activity_final_arena32 =
{
	{state_id = 2,	index = 1,	time = 1710507600},
	{state_id = 2,	index = 2,	time = 1710508200},
	{state_id = 2,	index = 3,	time = 1710508800},
	{state_id = 3,	index = 1,	time = 1710509400},
	{state_id = 3,	index = 2,	time = 1710510000},
	{state_id = 3,	index = 3,	time = 1710510600},
	{state_id = 4,	index = 1,	time = 1710511200},
	{state_id = 4,	index = 2,	time = 1710511800},
	{state_id = 4,	index = 3,	time = 1710512400},
}

return activity_final_arena32