-- 此文件工具自动生成，不要修改
--id	int	11	id[sl][l]
--zoom	int	11	缩放比（百分比）[sl][l]
--name	int	11	据点名称（0不显示1显示）[sl][l]
--icon_lv	int	11	据点等级icon[l]
--icon_area	int	11	据点icon[sl][l]
--attck_arrow	int	11	进攻指向[sl][l]
--belong	int	11	据点归属[sl][l]
--area_state	int	11	据点状态图标（竞价/对战等）[l]
--attack_info	int	11	对战详情（谁跟谁对战，对战进度比）[sl][l]
--map_show	int	11	进入界面后默认显示比例[sl][l]
local zone_map =
{
	{id = 1,	zoom = 18,	name = 1,	icon_lv = 1,	icon_area = 0,	attck_arrow = 0,	belong = 1,	area_state = 0,	attack_info = 0,	map_show = 0},
	{id = 2,	zoom = 5,	name = 1,	icon_lv = 1,	icon_area = 0,	attck_arrow = 1,	belong = 1,	area_state = 1,	attack_info = 0,	map_show = 1},
	{id = 3,	zoom = 100,	name = 1,	icon_lv = 1,	icon_area = 1,	attck_arrow = 1,	belong = 1,	area_state = 1,	attack_info = 1,	map_show = 0},
}

return zone_map