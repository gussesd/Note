-- 此文件工具自动生成，不要修改
--level	int	11	星级[sl][l]
--exp	int	11	升到本级需要经验[sl][l]
--rate	int	11	属性加成千分比（天赋属性）[sl][l]
local bone_star =
{
	{level = 1,	exp = 20,	rate = 40},
	{level = 2,	exp = 20,	rate = 80},
	{level = 3,	exp = 20,	rate = 120},
	{level = 4,	exp = 20,	rate = 160},
	{level = 5,	exp = 20,	rate = 200},
	{level = 6,	exp = 40,	rate = 280},
	{level = 7,	exp = 40,	rate = 360},
	{level = 8,	exp = 40,	rate = 440},
	{level = 9,	exp = 40,	rate = 520},
	{level = 10,	exp = 40,	rate = 600},
	{level = 11,	exp = 60,	rate = 720},
	{level = 12,	exp = 60,	rate = 840},
	{level = 13,	exp = 60,	rate = 960},
	{level = 14,	exp = 60,	rate = 1080},
	{level = 15,	exp = 60,	rate = 1200},
	{level = 16,	exp = 80,	rate = 1360},
	{level = 17,	exp = 80,	rate = 1520},
	{level = 18,	exp = 80,	rate = 1680},
	{level = 19,	exp = 80,	rate = 1840},
	{level = 20,	exp = 80,	rate = 2000},
	{level = 21,	exp = 100,	rate = 2200},
	{level = 22,	exp = 100,	rate = 2400},
	{level = 23,	exp = 100,	rate = 2600},
	{level = 24,	exp = 100,	rate = 2800},
	{level = 25,	exp = 100,	rate = 3000},
}

return bone_star