-- 此文件工具自动生成，不要修改
--id	int	11	怪物ID(monster表id)[l]
--list	char	1024	对话列表(显示条件（0靠近 1血量百分比）:数值:对话内容:显示时间  显示时间为整数秒)[l]
local boss_bubble_dialog =
{
}

return boss_bubble_dialog