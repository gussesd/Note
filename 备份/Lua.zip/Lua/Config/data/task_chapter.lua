-- 此文件工具自动生成，不要修改
--id	int	11	序号[l][#][sl:i]
--name	char	16	名称[l]
--type	int	11	类型[l][sl:i]
local task_chapter =
{
	{id = 1001,	name = "序章·前世唐门",	type = 1},
	{id = 1002,	name = "第一章·一朝乘风起",	type = 1},
}

return task_chapter