-- 此文件工具自动生成，不要修改
--id	int	11	序列[l]
--name	char	16	宗门名字[l]
--sex	int	11	性别（1男女都有2只有男3只有女）[l]
--zm_desc	char	256	宗门描述[l]
--wh_desc	char	256	武魂描述[l]
--ability	char	32	能力六维（攻击|控制|防御|治疗|机动|爆发，数值1-5）[l][DMH]
--video	char	64	技能视频[l]
--skill_id	char	64	技能id[l]
local newly_built =
{
	{id = 1,	name = "白虎宗",	sex = 2,	zm_desc = "星罗帝国皇室宗族，崇尚绝对实力，以武为尊。\n【近战·强攻】",	wh_desc = "武魂邪眸白虎，光明系。",	ability = {4,3,2,3,5,3},	video = {{"cjjn_bhm0","cjjn_bhm1","cjjn_bhm2","cjjn_bhm3","cjjn_bhm4"}},	skill_id = {{100101,100201,100301,100401,100501}}},
	{id = 2,	name = "昊天宗",	sex = 1,	zm_desc = "天斗帝国上三宗之首，拥有大陆第一强力器武魂。\n【近战·强攻】",	wh_desc = "武魂昊天锤，雷系。",	ability = {5,3,2,3,4,3},	video = {{"cjjn_htm0","cjjn_htm1","cjjn_htm2","cjjn_htm3","cjjn_htm4"},{"cjjn_htf0","cjjn_htf1","cjjn_htf2","cjjn_htf3","cjjn_htf4"}},	skill_id = {{200101,200201,200301,200401,200501},{200101,200201,200301,200401,200501}}},
	{id = 3,	name = "幽冥灵猫宗",	sex = 3,	zm_desc = "星罗帝国第一客卿宗族，与皇室世代联姻。\n【近战·敏攻】",	wh_desc = "武魂幽冥灵猫，黑暗系。",	ability = {4,5,4,2,2,3},	video = {{"cjjn_lmf0","cjjn_lmf1","cjjn_lmf2","cjjn_lmf3","cjjn_lmf4"}},	skill_id = {{300101,300201,300301,300401,300501}}},
	{id = 4,	name = "凤凰宗",	sex = 1,	zm_desc = "神秘的古老宗族，拥有大陆第二强力兽武魂。\n【远程·法攻】",	wh_desc = "武魂浴火凤凰，火系。",	ability = {5,4,3,2,3,3},	video = {{"cjjn_fhm0","cjjn_fhm1","cjjn_fhm2","cjjn_fhm3","cjjn_fhm4"},{"cjjn_fhf0","cjjn_fhf1","cjjn_fhf2","cjjn_fhf3","cjjn_fhf4"}},	skill_id = {{400101,400201,400301,400401,400501},{400101,400201,400301,400401,400501}}},
	{id = 5,	name = "七宝琉璃宗",	sex = 1,	zm_desc = "天斗帝国上三宗之一，大陆第一辅助系宗族。\n【远程·辅助】",	wh_desc = "武魂七宝琉璃塔，风系。",	ability = {3,4,3,5,3,2},	video = {{"cjjn_llm0","cjjn_llm1","cjjn_llm2","cjjn_llm3","cjjn_llm4"},{"cjjn_llf0","cjjn_llf1","cjjn_llf2","cjjn_llf3","cjjn_llf4"}},	skill_id = {{500101,500201,500301,500401,500501},{500101,500201,500301,500401,500501}}},
}

return newly_built