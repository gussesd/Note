-- 此文件工具自动生成，不要修改
--level	int	11	属性等级[sl][l]
--rate	int	11	天赋属性扣除比例，0表示不扣除(千分比)[sl][l]
local bone_level =
{
	{level = 0,	rate = 0},
	{level = 1,	rate = 250},
	{level = 2,	rate = 500},
	{level = 3,	rate = 750},
	{level = 4,	rate = 1000},
}

return bone_level