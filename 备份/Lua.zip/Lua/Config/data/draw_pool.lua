-- 此文件工具自动生成，不要修改
--id	int	11	id(1开始)[sl][l]
--pool_id	int	11	池id[sl][l]
--group	int	11	组id[sl][l]
--rate_func	int	11	概率函数[sl][l]
--fix_num	int	11	抽歪次数[sl][l]
--ext_item_id	int	11	赠送物品id[sl][l]
--ext_item_num	int	11	赠送物品数量[sl][l]
--num_max	int	11	保底次数[l]
--name	char	11	道具品质名称[l]
--rate	int	11	概率(显示精确到0.01%)[l]
--type	int	11	祈愿大类(0常规1魂骨2魂印)[sl][l]
local draw_pool =
{
	{id = 1,	pool_id = 0,	group = 1,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 0},
	{id = 2,	pool_id = 0,	group = 2,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 0},
	{id = 3,	pool_id = 0,	group = 3,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 0},
	{id = 4,	pool_id = 0,	group = 4,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 0},
	{id = 5,	pool_id = 0,	group = 5,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 0},
	{id = 1,	pool_id = 1,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 1,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 1,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 1,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 1,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 2,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 2,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 2,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 2,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 2,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 3,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 3,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 3,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 3,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 3,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 4,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 4,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 4,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 4,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 4,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 5,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 5,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 5,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 5,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 5,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 6,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 6,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 6,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 6,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 6,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 7,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 7,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 7,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 7,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 7,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 8,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 8,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 8,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 8,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 8,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 9,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 9,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 9,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 9,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 9,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 10,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 10,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 10,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 10,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 10,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 11,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 11,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 11,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 11,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 11,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
	{id = 1,	pool_id = 12,	group = 11,	rate_func = 1,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 20,	num_max = 100,	name = "传说",	rate = 130,	type = 1},
	{id = 2,	pool_id = 12,	group = 12,	rate_func = 2,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 10,	num_max = 60,	name = "史诗",	rate = 238,	type = 1},
	{id = 3,	pool_id = 12,	group = 13,	rate_func = 3,	fix_num = 2,	ext_item_id = 5,	ext_item_num = 5,	num_max = 10,	name = "稀有",	rate = 1300,	type = 1},
	{id = 4,	pool_id = 12,	group = 14,	rate_func = 4,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 10,	num_max = 0,	name = "珍贵",	rate = 800,	type = 1},
	{id = 5,	pool_id = 12,	group = 15,	rate_func = 5,	fix_num = 0,	ext_item_id = 4,	ext_item_num = 5,	num_max = 0,	name = "普通",	rate = 7532,	type = 1},
}

return draw_pool