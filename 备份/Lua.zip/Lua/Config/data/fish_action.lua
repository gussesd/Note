-- 此文件工具自动生成，不要修改
--id	int	11	鱼id[l]
--long	int	11	滑块长度（百分比）[l]
--speed	int	11	滑块速度[l]
--range	char	16	滑块范围（最小:最大 百分比）[l][DMH]
--up_progress	int	11	增加进度值（需要完全在条内的秒数）[l]
--down_progress	int	11	降低进度值（需要完全在条外的秒数）[l]
--step	int	11	步长（固定移动的秒数）[l]
--turn_rate	int	11	转向概率（移动一个步长后转向百分比）[l]
local fish_action =
{
	{id = 1401,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2701,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2702,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2703,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2704,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2705,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2706,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2707,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2708,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2709,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2710,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2711,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2712,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2713,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2714,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2715,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2716,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2717,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2718,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2719,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2720,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2721,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2722,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2723,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2724,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2725,	long = 120,	speed = 250,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 2,	turn_rate = 70},
	{id = 2726,	long = 120,	speed = 250,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 2,	turn_rate = 70},
	{id = 2727,	long = 120,	speed = 250,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 2,	turn_rate = 70},
	{id = 2728,	long = 120,	speed = 250,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 2,	turn_rate = 70},
	{id = 2729,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2730,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2731,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2732,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2733,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2734,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2735,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2736,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2737,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2738,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2801,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2802,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2803,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2804,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2805,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2806,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2807,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2808,	long = 200,	speed = 170,	range = {0,100},	up_progress = 6,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2809,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2810,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2811,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2812,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2813,	long = 150,	speed = 230,	range = {0,100},	up_progress = 7,	down_progress = 10,	step = 2,	turn_rate = 60},
	{id = 2814,	long = 120,	speed = 250,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 2,	turn_rate = 70},
	{id = 2815,	long = 120,	speed = 250,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 2,	turn_rate = 70},
	{id = 2816,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2817,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2818,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 2819,	long = 120,	speed = 270,	range = {0,100},	up_progress = 8,	down_progress = 10,	step = 1,	turn_rate = 50},
	{id = 88012,	long = 250,	speed = 150,	range = {0,100},	up_progress = 5,	down_progress = 10,	step = 1,	turn_rate = 50},
}

return fish_action