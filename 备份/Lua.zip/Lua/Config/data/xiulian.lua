-- 此文件工具自动生成，不要修改
--area_id	int	11	区域id（对应architecture表）[sl][l]
--way	int	11	修炼方式（1初级2中级3高级）[sl][l]
--cost_card	char	16	消耗修炼卡[sl:vv][l][DMH]
--cost_tl	int	11	消耗体力[sl][l]
--neili	int	11	增加的基础体力价值[sl][l]
local xiulian =
{
	{area_id = 60001,	way = 1,	cost_card = {261,1,1},	cost_tl = 20,	neili = 400},
	{area_id = 60001,	way = 2,	cost_card = {262,1,1},	cost_tl = 40,	neili = 1200},
	{area_id = 60001,	way = 3,	cost_card = {263,1,1},	cost_tl = 60,	neili = 2000},
}

return xiulian