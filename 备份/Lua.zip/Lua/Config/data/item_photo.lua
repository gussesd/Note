-- 此文件工具自动生成，不要修改
--id	int	11	itemid(关联item表)[l]
--desc	char	64	描述[l]
--photo	char	64	资源名[l]
local item_photo =
{
	{id = 80013,	desc = "蝴蝶结海报",	photo = "80013"},
}

return item_photo