-- 此文件工具自动生成，不要修改
--id	int	11	获得的id(取item表id)[sl][l]
--cost_type	int	11	消耗的id(取item表id)[sl][l]
--is_addition	int	11	是否需要读取别的表格或使用其他协议[sl][l]
--sell_value	int	11	价格[l][sl:i]
--count	int	11	买到的数量[sl][l]
--limit_count	int	11	限购数量[sl][l]
--shopId	int	11	商店id[l]
local quick_buy =
{
	{id = 23,	cost_type = 211,	is_addition = 0,	sell_value = 1,	count = 5000,	limit_count = 10,	shopId = 0},
	{id = 23,	cost_type = 221,	is_addition = 0,	sell_value = 1,	count = 4000,	limit_count = 10,	shopId = 0},
	{id = 23,	cost_type = 222,	is_addition = 0,	sell_value = 1,	count = 8000,	limit_count = 10,	shopId = 0},
	{id = 23,	cost_type = 223,	is_addition = 0,	sell_value = 1,	count = 16000,	limit_count = 10,	shopId = 0},
	{id = 23,	cost_type = 224,	is_addition = 0,	sell_value = 1,	count = 32000,	limit_count = 10,	shopId = 0},
	{id = 23,	cost_type = 225,	is_addition = 0,	sell_value = 1,	count = 64000,	limit_count = 10,	shopId = 0},
	{id = 22,	cost_type = 13,	is_addition = 1,	sell_value = 50,	count = 60,	limit_count = 10,	shopId = 0},
	{id = 22,	cost_type = 200,	is_addition = 0,	sell_value = 1,	count = 60,	limit_count = 10,	shopId = 0},
	{id = 22,	cost_type = 201,	is_addition = 0,	sell_value = 1,	count = 20,	limit_count = 10,	shopId = 0},
	{id = 202,	cost_type = 12,	is_addition = 0,	sell_value = 160,	count = 1,	limit_count = 9999,	shopId = 10001},
	{id = 203,	cost_type = 13,	is_addition = 0,	sell_value = 160,	count = 1,	limit_count = 9999,	shopId = 10002},
}

return quick_buy