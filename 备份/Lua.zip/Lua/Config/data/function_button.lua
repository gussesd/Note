-- 此文件工具自动生成，不要修改
--id	int	11	ID[l]
--name	char	16	名字[l]
--title	char	64	小标题[l]
--index	int	11	权重排序[l]
--icon	char	64	图标URL[l]
--uiRealId	int	11	pane_openId[l]
--type	int	11	类型[l]
local function_button =
{
	{id = 1,	name = "魂师",	title = "",	index = 1,	icon = "button_js",	uiRealId = 600,	type = 1},
	{id = 2,	name = "武魂",	title = "",	index = 2,	icon = "button_wh",	uiRealId = 900,	type = 1},
	{id = 3,	name = "成就",	title = "",	index = 3,	icon = "button_cj",	uiRealId = 2100,	type = 1},
	{id = 4,	name = "图鉴",	title = "",	index = 4,	icon = "button_tj",	uiRealId = 300,	type = 1},
	{id = 5,	name = "玄天功",	title = "",	index = 6,	icon = "button_xtg",	uiRealId = 2300,	type = 1},
	{id = 6,	name = "魂环",	title = "自选魂印",	index = 5,	icon = "button_hh",	uiRealId = 1600,	type = 2},
	{id = 7,	name = "仙草",	title = "",	index = 13,	icon = "button_xc",	uiRealId = 2000,	type = 1},
	{id = 8,	name = "魂骨",	title = "",	index = 8,	icon = "button_hg",	uiRealId = 1900,	type = 1},
	{id = 9,	name = "暗器",	title = "",	index = 9,	icon = "button_aq",	uiRealId = 1200,	type = 1},
	{id = 10,	name = "好友",	title = "",	index = 10,	icon = "button_hy",	uiRealId = 2402,	type = 1},
	{id = 11,	name = "宗门",	title = "",	index = 11,	icon = "button_zm",	uiRealId = 500,	type = 1},
	{id = 12,	name = "外附魂骨",	title = "",	index = 12,	icon = "button_wfhg",	uiRealId = 1000,	type = 1},
	{id = 13,	name = "神器",	title = "",	index = 14,	icon = "button_sqylg",	uiRealId = 1700,	type = 1},
	{id = 14,	name = "拍卖行",	title = "",	index = 15,	icon = "button_pmh",	uiRealId = 200,	type = 1},
	{id = 15,	name = "血脉",	title = "",	index = 7,	icon = "button_xm",	uiRealId = 450,	type = 1},
}

return function_button