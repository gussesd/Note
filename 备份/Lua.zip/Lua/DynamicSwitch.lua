--外部动态配置开关

--是否显示debugtools
SHOW_DEBUGTOOLS = true