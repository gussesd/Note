local TimerBase = {}
local this = TimerBase
local timers = {}
--缓存一次性定时器，降低队列的增删开销
local tempTimers = {}
local tempIndex = 0
local cache = {}
local updating = false

-- 希望每帧触发的函数，time写0
function TimerBase.Start(time, func, ...)
    return this.StartLoop(time, 1, func, ...)
end

function TimerBase.StartLoop(time, count, func, ...)
    local t = this.GetNewTimer(time, count, func, ...)

    if count > 1 or count <= -1 then
        table.insert(timers, t)
    else
        tempIndex = tempIndex + 1
        tempTimers[tempIndex] = t
    end
    return t
end

function TimerBase.StartLoopForever(time, func, ...)
    return this.StartLoop(time, -1, func, ...)
end

function TimerBase.Stop(t)
    if not t then
        return
    end

    t.count = 0
    --if not updating then
        --立刻执行后续逻辑
        if t.completed then
            t.completed()
            t.completed = nil
        end
    --end
end

function TimerBase.CheckUnStopTimer()
    -- 检测一下还没关闭的定时器,这个代码是故意保留，检测返回登陆界面时是否还有定时器没关闭
    -- 不强制关闭所有定时器，而是打日志，目的时找出可能存在内存泄漏
    if CS.UnityEngine.Debug.isDebugBuild then
        for k, v in pairs(timers) do
            local info = debug.getinfo(v.func)
            logError("未关闭的定时器", table.toString(info))
            this.Stop(v)
        end

        for k, v in pairs(tempTimers) do
            local info = debug.getinfo(v.func)
            logError("未关闭的定时器temp", table.toString(info))
            this.Stop(v)
        end
    end
end
function TimerBase.Restart(t)
    t.pauseTime = nil
    t.nextTime = this.GetTime() + t.time
end
function TimerBase.Pause(t)
    -- 说明这个计时器已经被回收了，则不处理
    if not t.nextTime then
        return
    end

    -- 防止被连续两次pause导致时间计算异常
    if not t.pauseTime then
        t.pauseTime = this.GetTime()
    end
end

function TimerBase.Resume(t)
    -- 说明这个计时器已经被回收了，则不处理
    if not t.nextTime then
        return
    end

    -- 处理计时器没被Pause就调用Resume的情况
    if t.pauseTime then
        t.nextTime = t.nextTime + (this.GetTime() - t.pauseTime)
        t.pauseTime = nil
    end
end

function TimerBase.SkipTime(t, skipTime)
    -- 说明这个计时器已经被回收了，则不处理
    if not t.nextTime then
        return
    end
    
    -- 处理计时器没被Pause就调用Resume的情况
    if t.pauseTime then
        t.nextTime = t.nextTime - skipTime + (this.GetTime() - t.pauseTime)
    else
        t.nextTime = t.nextTime - skipTime
    end
end
function TimerBase.Update()
    updating = true
    local now = this.GetTime()
    local count = #timers
    local i = 1
    while i <= count do
        local t = timers[i]
        local remove = false
        if t.count == 0 then
            remove = true
        elseif not t.pauseTime and t.nextTime <= now then
            if t.func then
                t.func(sunpack(t.args))
            end
            if t.count == 1 then
                remove = true
            else
                if t.count > 1 then
                    t.count = t.count - 1
                end
                t.nextTime = t.nextTime + t.time
            end
        end

        if remove then
            if t.completed then
                t.completed()
            end
            table.remove(timers, i)
            -- 暂时关闭回收流程
            --this.Recycle(t)
            count = count - 1
        else
            i = i + 1
        end
    end

    --处理临时的部分
    for k, t in pairs(tempTimers) do
        local remove = false
        if t.count == 0 then
            remove = true
        elseif not t.pauseTime and t.nextTime <= now then
            if t.func then
                t.func(sunpack(t.args))
            end
            remove = true
        end

        if remove then
            if t.completed then
                t.completed()
            end
            tempTimers[k] = nil
        end
    end

    updating = false
end

function TimerBase.GetTime()
    return 0
end

-- 添加定时器回收流程,这里只保留空table
function TimerBase.GetNewTimer(time, count, func, ...)
    if cache and #cache > 0 then
        local t = cache[#cache]
        cache[#cache] = nil

        t.time = time
        t.nextTime = this.GetTime() + time
        t.count = count
        t.func = func
        t.recycled = false;
        t.args = spack(...)

        return t
    end
    return {
        time = time,
        nextTime = this.GetTime() + time,
        count = count,
        func = func,
        recycled = false,
        args = spack(...)
    }
end

function TimerBase.Recycle(t)
    --t.recycled = true;
    --[[
    if t.owner then
        logError("Recycle Timer", t.owner)
    end
    table.quickClear(t)
    table.insert(cache, t)
    ]]
end

return TimerBase
