--常用的只读表
ConstValue = {}
local this = ConstValue

function ConstValue.Init()
    this.Vector3 = {
        up = Vector3.up,
        down = Vector3.down,
        left = Vector3.left,
        right = Vector3.right,
        forward = Vector3.forward,
        back = Vector3.back,
        zero = Vector3.zero,
        one = Vector3.one,
    }

    this.Vector2 = {
        up = Vector2.up,
        down = Vector2.down,
        left = Vector2.left,
        right = Vector2.right,
        zero = Vector2.zero,
        one = Vector2.one,
    }

    this.Color = {
        red 	= Color.red,
        green	= Color.green,
        blue	= Color.blue,
        white	= Color.white,
        black	= Color.black,
        yellow	= Color.yellow,
        cyan	= Color.cyan,
        magenta	= Color.magenta,
        gray	= Color.gray,
        clear   = Color.clear,
    }


    --不使用read_only功能，原因是修改了表结构会导致c#不认识这个类，不支持自动转换
    --使用时注意不要修改好了。
    --[[
    for k, v in pairs(this.Vector3) do
        this.Vector3[k] = read_only(v)
    end
    
    
    for k, v in pairs(this.Vector2) do
        this.Vector2[k] = read_only(v)
    end

    for k, v in pairs(this.Color) do
        this.Color[k] = read_only(v)
    end
    ]]
end

ConstValue.Init()