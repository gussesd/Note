
function table.contains(t, value)
    return table.getKey(t, value) ~= nil
end

function table.count(t)
    if not t then
        return 0
    end

    local n = 0
    for _, _ in pairs(t) do
        n = n + 1
    end
    return n
end

--获取表层级
function table.level(t)
    if not t then
        return 0
    end

    local level = 1
    while true do
        local key, child = next(t)
        if child and type(child) == "table" then
            t = child
            level = level + 1
        else
            break
        end
    end
    return level
end

--只获取数据长度
function table.length(t)
	if t.n ~= nil then
		return t.n
	end
	
	local count = 0
	for i,_ in pairs(t) do
		if count < i then
			count = i
		end		
	end
	return count
end

--设置数组长度
function table.setlen(t, n)
    t.n = n
end

function table.sub(tab, startindex, endindex)
    local newtab = {}
    for i = startindex, endindex do
        newtab[i] = tab[i]
    end
    return newtab
end

function table.copy(t)
    local nt = {}
    for k, v in pairs(t) do
        nt[k] = v
    end
    return nt
end

function table.getKey(t, value)
    for k, v in pairs(t) do
        if v == value then
            return k
        end
    end
end

function table.isArray(t)
    for i = 1, table.count(t) do
        if not t[i] then
            return false
        end
    end
    return true
end

function table.isNullOrEmpty(t)
    return t == nil or next(t) == nil
end

function table.pop(t)
    if #t == 0 then
        return
    end
    return table.remove(t)
end

function table.quickPop(t)
    if #t == 0 then
        return
    end
    local value = t[#t]
    t[#t] = nil
    return value
end

function table.keys(t)
    local keys = {}
    for k, v in pairs(t) do
        table.insert(keys, k)
    end
    return keys
end

-- 将t2合并到t1
function table.merge(t1, t2)
    if t2 == nil then
        return t1
    end
    for k, v in pairs(t2) do
        t1[k] = v
    end
end

-- 合并数组：将t2数组从begin位置开始插入到t1数组
-- 注意：begin <= 0被认为没有指定起始位置，则将两个数组执行拼接
function table.insertto(t1, t2, begin)
	assert(begin == nil or type(begin) == "number")
	if begin == nil or begin <= 0 then
		begin = #t1 + 1
	end

	local src_len = #t2
	for i = 0, src_len - 1 do
		t1[i + begin] = t2[i + 1]
	end
end

-- 从数组中查找指定值，返回其索引，没找到返回false
function table.indexof(t, value, begin)
    for i = begin or 1, #t do
        if t[i] == value then 
			return i 
		end
    end
	return false
end

-- 从哈希表查找指定值，返回其键，没找到返回nil
-- 注意：
-- 1、containskey用t[key] ~= nil快速判断
-- 2、containsvalue由本函数返回结果是否为nil判断
function table.keyof(t, value)
    for k, v in pairs(t) do
        if v == value then 
			return k 
		end
    end
    return nil
end

-- 遍历写：用函数返回值更新表格内容
function table.map(t, func)
    for k, v in pairs(t) do
        t[k] = func(k, v)
    end
end

-- 遍历读：不修改表格
function table.walk(t, func)
    for k,v in pairs(t) do
        func(k, v)
    end
end

-- 按指定的排序方式遍历：不修改表格
function table.walksort(t, sort_func, walk_func)
	local keys = table.keys(t)
	table.sort(keys, function(lkey, rkey)
		return sort_func(lkey, rkey)
	end)
	for i = 1, table.length(keys) do
		walk_func(keys[i], t[keys[i]])
	end
end

-- 过滤掉不符合条件的项：不对原表执行操作
function table.filter(t, func)
	local filter = {}
    for k, v in pairs(t) do
        if not func(k, v) then 
			filter[k] = v
		end
    end
	return filter
end

-- 筛选出符合条件的项：不对原表执行操作
function table.choose(t, func)
	local choose = {}
    for k, v in pairs(t) do
        if func(k, v) then 
			choose[k] = v
		end
    end
	return choose
end

-- 获取数据循环器：用于循环数组遍历，每次调用走一步，到数组末尾从新从头开始
function table.circulator(array)
	local i = 1
	local iter = function()
		i = i >= #array and 1 or i + 1
		return array[i]
	end
	return iter
end

local function tableToString(t, processed, sortKey, deep)
    if deep <= 0 then
        return ""
    end

    if type(t) ~= "table" or processed and table.contains(processed, t) then
        return tostring(t)
    end

    if processed then
        table.insert(processed, t)
    end

    --local str
    local tab
    if table.isArray(t) then
        for _, v in ipairs(t) do
            local item = processed and table.toString(v, processed, sortKey, deep - 1) or tostring(v)
            --str = str and (str .. ", " .. item) or item
            if tab then
                table.insert(tab, ", ")
                table.insert(tab, item)
            else
                tab = {item}
            end    
        end
    else
        if sortKey then
            local key = table.keys(t)
            table.sort(key)
            for k, v in ipairs(key) do
                local item = (processed and table.toString(v, processed, sortKey, deep - 1) or tostring(v)) .. ":" .. 
                    (processed and table.toString(t[v], processed, sortKey, deep - 1) or tostring(t[v]))
                --str = str and (str .. ", " .. item) or item
                if tab then
                    table.insert(tab, ", ")
                    table.insert(tab, item)
                else
                    tab = {item}
                end
            end
        else
            for k, v in pairs(t) do
                local item = (processed and table.toString(k, processed, sortKey, deep - 1) or tostring(k)) .. ":" .. 
                    (processed and table.toString(v, processed, sortKey, deep - 1) or tostring(v))
                --str = str and (str .. ", " .. item) or item
                if tab then
                    table.insert(tab, ", ")
                    table.insert(tab, item)
                else
                    tab = {item}
                end
            end
        end
    end
    return tab and "{" .. table.concat(tab, "") .. "}" or "{}"
end

--添加表遍历深度设置，防止遇到环出不来
function table.toString(t, recursive, sortKey, deep)
    return tableToString(t, recursive and {}, sortKey, deep or 3)
end

--另一种table打印,格式好很多，但效率很低，建议只在调试时查看数据使用
local serpent = require "ProtoBuf/serpent"
function table.block(t)
    return serpent.block(t)
end

function table.values(t)
    local values = {}
    for k, v in pairs(t) do
        table.insert(values, v)
    end
    return values
end

--快速清表函数主要目的是节省gc开销
--实际上清理后的表比新表的写入流程要快2-3倍，但计算上清表开销，总耗时是更高的，极端情况时间开销可能会多2-10倍
function table.quickClear(t, bRelease)
    if t == nil then
        return
    end
    for k, v in pairs(t) do
        if bRelease then
            PoolManager.Release(v)
        end
        t[k] = nil
    end
end

--交换表的key和value值
function table.swichKeyValue(t)
    local values = {}
    for k, v in pairs(t) do
        values[v] = k
    end
    return values
end

--随机获取一个值
--remove=false表示quick remove, 只把key置nil(table大小不变，没有可能的resize开销，适合长期持有的复用table和非连续table)
--remove=nil表示获取值，不删除
--remove=true表示调用table.remove删除(适合连续表，有额外尾部资源向前移动和可能出现的resize开销)
function table.randomGetValue(t, remove)
    local count = table.count(t)
    if count == 0 then
        return
    end

    local k, v
    if count == #t then
        k = math.random(#t)
        v = t[k]
    else
        local keys = table.keys(t)
        k = keys[math.random(#keys)]
        v = t[k]
    end

    if remove == false then
        t[k] = nil
    elseif remove == true then
        table.remove(t, k)
    end

    return v
end

-- 从数组中删除指定值，返回删除的值的个数
function table.removebyvalue(t, value, removeall)
    local remove_count = 0
	for i = #t, 1, -1 do
		if t[i] == value then
			table.remove(t, i)
			remove_count = remove_count + 1
            if not removeall then 
				break 
			end
		end
	end
	return remove_count
end

--根据函数条件删除内容
function table.removebyfunction(array, f, removeall, data)
    local c, i, max = 0, 1, #array
    while i <= max do
        if data then
            if f(array[i], data) then
                table.remove(array, i)
                c = c + 1
                i = i - 1
                max = max - 1
                if not removeall then break end
            end
        else
            if f(array[i]) then
                table.remove(array, i)
                c = c + 1
                i = i - 1
                max = max - 1
                if not removeall then break end
            end
        end

        i = i + 1
    end
    return c
end
-- 根据包含要删除下标的组成的table删除
function table.removebypostable(originalTable, indexesToRemove)
    if (type(originalTable) ~= 'table' or table.count(originalTable) == 0) or
        (type(indexesToRemove) ~= 'table' or table.count(indexesToRemove) == 0) then
        return
    end
    table.sort(indexesToRemove, function(a, b)
        return a > b
    end)

    for _, index in ipairs(indexesToRemove) do
        table.remove(originalTable, index)
    end
end

function table.trim(list)
    local result={}
    for k,v in pairs(list) do
        if v then
            result[k]=v
        end
    end
    return result
end
function table.equal(a, b)
    if #a ~= #b then
        return false
    end
    for i = 1, #a do
        if a[i] ~= b[i] then
            return false
        end
    end
    return true
end
-- local function Partition(array,compare,low,high,isReverse)
--     local pivot=array[low]
--     local arg=(isReverse and -1 or 1)
--     while low<high do
--         while low<high and (compare(pivot,array[high])*arg>=0) do
--             high=high-1
--         end
--         array[low]=array[high]
--         while low<high and (compare(array[low],pivot)*arg>=0) do
--             low=low+1
--         end
--         array[high]=array[low]
--     end
--     array[low]=pivot
--     return low
-- end
-- --compare返回-1则交换
-- function table.quickSort(array,compare,low,high,isReverse)
--     if(low>=high)then
--         return
--     end
--     local pivot=Partition(array,compare,low,high,isReverse)
--     table.quickSort(array,compare,low,pivot-1,isReverse)
--     table.quickSort(array,compare,pivot+1,high,isReverse)
-- end