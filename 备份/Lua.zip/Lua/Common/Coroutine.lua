local util = require 'Common/util'
local coroutineRunner = CS.Main.instance

Coroutine = {list = {}}

function Coroutine.Start(...)
    return coroutineRunner:StartCoroutine(util.cs_generator(...))
end

function Coroutine.Stop(c)
    coroutineRunner:StopCoroutine(c)
end

function Coroutine.StopAll()
    coroutineRunner:StopAllCoroutines()
end

function Coroutine.Yield(enumerator)
    coroutine.yield(enumerator)
end

function Coroutine.Wait(time)
    coroutine.yield(Coroutine.GetWaitForSeconds(time))
end

function Coroutine.GetWaitForSeconds(time)
    if not Coroutine.list[time] then
        Coroutine.list[time] = CS.UnityEngine.WaitForSeconds(time)
    end
    return Coroutine.list[time]
end

function Coroutine.Break()
    coroutine.yield(util.move_end)
end