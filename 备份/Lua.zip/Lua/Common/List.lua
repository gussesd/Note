--比较高效的双向链表实现方式，可以用来模拟队列或者堆栈
--缺点是遍历比较不方便，也不能删除中间值
List = {}

function List.new()
    return {first = 0, last = -1}
end

function List.pushFront(list, value)
    local first = list.first - 1
    list.first = first
    list[first] = value
end

function List.pushBack(list, value)
    local last = list.last + 1
    list.last = last
    list[last] = value
end

function List.popFront(list,release)
    local first = list.first
    if first > list.last then
        return nil
    end
    local value = list[first]
    if release then PoolManager.Release(value) end
    list[first] = nil
    list.first = first + 1
    return value
end

function List.popBack(list,release)
    local last = list.last
    if list.first > last then
        return nil
    end
    local value = list[last]
    if release then PoolManager.Release(value) end
    list[last] = nil
    list.last = last - 1
    return value
end

function List.clear(list,release)
    for k, v in pairs(list) do
        if release then PoolManager.Release(v) end
        list[k] = nil
    end
    list.first = 0
    list.last = -1
end

function List.empty(list)
    return list.first > list.last
end

function List.count(list)
    return list.last - list.first + 1
end

function List.get(list, index)
    return list[list.first + index - 1]
end

--遍历
function List.walk(list, func, ...)
    for i=list.first, list.last do
        if func(i, list[i], ...) then
            return true
        end
    end
end