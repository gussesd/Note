--异常捕获接口
-- traceback
function _traceback(errors)

    -- no diagnosis info?
    if not option.get("diagnosis") then
        if errors then
            -- remove the prefix info
            local _, pos = errors:find(":%d+: ")
            if pos then
                errors = errors:sub(pos + 1)
            end
        end
        return errors
    end

    -- traceback exists?
    if errors and errors:find("stack traceback:", 1, true) then
        return errors
    end

    -- init results
    local results = ""
    if errors then
        results = errors .. "\n"
    end
    results = results .. "stack traceback:\n"

    -- make results
    local level = 2
    while true do

        -- get debug info
        local info = debug.getinfo(level, "Sln")

        -- end?
        if not info or (info.name and info.name == "xpcall") then
            break
        end

        -- function?
        if info.what == "C" then
            results = results .. string.format("    [C]: in function '%s'\n", info.name)
        elseif info.name then
            results = results .. string.format("    [%s:%d]: in function '%s'\n", info.short_src, info.currentline, info.name)
        elseif info.what == "main" then
            results = results .. string.format("    [%s:%d]: in main chunk\n", info.short_src, info.currentline)
            break
        else
            results = results .. string.format("    [%s:%d]:\n", info.short_src, info.currentline)
        end

        -- next
        level = level + 1
    end

    -- ok?
    return results
end

function try(block)

    -- get the try function
    local try = block[1]
    assert(try)

    -- get catch and finally functions
    local funcs = table.join(block[2] or {}, block[3] or {})

    -- try to call it
    local results = table.pack(utils.trycall(try, sandbox_try._traceback))
    local ok = results[1]
    if not ok then

        -- run the catch function
        if funcs and funcs.catch then
            funcs.catch(results[2])
        end
    end

    -- run the finally function
    if funcs and funcs.finally then
        funcs.finally(ok, table.unpack(results, 2, results.n))
    end

    -- ok?
    if ok then
        return table.unpack(results, 2, results.n)
    end
end

function finally(block)

    -- get the finally block function
    return {finally = block[1]}
end

function catch(block)

    -- get the catch block function
    return {catch = block[1]}
end