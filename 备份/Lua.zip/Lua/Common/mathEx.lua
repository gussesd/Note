--[[
    游戏相关的一些数学函数
]]

mathEx = {}
local sqrt = math.sqrt
local clamp = Mathf.Clamp

function mathEx.GetInt(num)--四舍五入取整
    return math.floor(num + 0.5)
end

--将dir转换成Quaternion
function mathEx.GetQuaternionByDir(dir)
    return Quaternion.Euler(0, dir, 0)
end

--根据纵坐标差计算角度
function mathEx.GetAngle(y, x)
    return math.atan(y, x) / math.pi * 180
end

function mathEx.GetAngle2(v1, v2)
    return math.atan(v2.y - v1.y, v2.x - v1.x) / math.pi * 180
end

function mathEx.GetAngle3(v1, v2)
    return math.atan(v2.z - v1.z, v2.x - v1.x) / math.pi * 180
end

--把角度限制在目标区域,clamp为true表示越界时直接获取边界
function mathEx.LimitAngle(angle, min, max, clamp)
    while angle < min do
        if clamp then
            return min
        end
        angle = angle + 360
    end

    while angle >= max do
        if clamp then
            return max - 1
        end
        angle = angle - 360
    end
    return angle
end

--根据两点间的方向和限定角度，求360度范围内的夹角
function mathEx.GetAngleRangeByAngle(angle, angleLimit)
    local loAngle = 0
    local hiAngle = 0

    if angleLimit <= 0 or angleLimit >= 360 then
        loAngle = 0
        hiAngle = 360
        
    else
        hiAngle = mathEx.LimitAngle(angle + (angleLimit / 2), 0, 360)
        loAngle = mathEx.LimitAngle(angle + (angleLimit / 2), 0, 360)
    end

    return loAngle, hiAngle
end

--根据中心点，半径和角度获取对应点
function mathEx.GetAPointInCircle(center, r, ao)
    ao = mathEx.LimitAngle(ao, -180, 180)

    return Vector2(center.x + r * math.sin(ao * math.pi / 180), center.y + r * math.cos(ao * math.pi / 180))
end

--判定角度是否在某个角度范围内
function mathEx.InAngleRange(angle, loAngle, hiAngle)
    if loAngle > hiAngle then
        return angle >= loAngle and angle <= hiAngle
    end

    return (angle >= loAngle and angle < 360) or (angle > 0 and angle < hiAngle)
end

--判定点是否在圆内
function mathEx.InCircle2(target, center, radius)
    if (target.x - center.x) ^ 2 + (target.y - center.y) ^ 2 <= radius ^ 2 then
        return true
    end
    return false
end

function mathEx.InCircle3(target, center, radius)
    if (target.x - center.x) ^ 2 + (target.y - center.y) ^ 2 + (target.z - center.z) ^ 2 <= radius ^ 2 then
        return true
    end
    return false
end

--判定点是否在扇形范围内
function mathEx.InCircleByAngle2(target, center, radius, loAngle, hiAngle)
    if mathEx.InCircle2(target, center, radius) then
        local angle = mathEx.GetAngle2(center, target)
        if mathEx.InAngleRange(angle, loAngle, hiAngle) then
            return true
        end
    end
    return false
end

function mathEx.InCircleByAngle(target, center, radius, loAngle, hiAngle, u)
    if (target.x - center.x) ^ 2 + (target.z - center.z) ^ 2 <= radius ^ 2 then
        -- local angle = 90 - math.abs(mathEx.GetAngle3(center, target))
        local angle = Vector3.Angle(u, Vector3.GetTemp(target.x - center.x, u.y, target.z - center.z)) + 90;
        if loAngle < 0 then
            loAngle = 360 + loAngle
        end
        if mathEx.InAngleRange(angle, loAngle, hiAngle) then
            return true
        end
    end
    return false
end

--根据余弦定理求两个线段夹角
function mathEx.GetTwoLineAngle(o, s, e, isAngle)
    local dsx = s.x - o.x
    local dsy = s.y - o.y
    local dex = e.x - o.x
    local dey = e.y - o.y

    local norm = (dsx * dsx + dsy * dsy) * (dex * dex + dey * dey)
    local cosfi = (dsx * dex + dsy * dey) / math.sqrt(norm)

    if cosfi >= 1 then
        return 0
    end
    if cosfi <= -1 then
        return math.pi
    end

    local fi = math.acos(cosfi)

    if 180 * fi / math.pi < 180 then
        if isAngle then
            return 180 * fi / math.pi
        end
        return fi
    else
        if isAngle then
            return 360 - 180 * fi / math.pi
        end
        return 2 * math.pi - fi
    end

    return 0
end

function mathEx.GetTwoLineAngleV3(o, s, e, isAngle)
    local dsx = s.x - o.x
    local dsz = s.z - o.z
    local dex = e.x - o.x
    local dez = e.z - o.z

    local norm = (dsx * dsx + dsz * dsz) * (dex * dex + dez * dez)
    local cosfi = (dsx * dex + dsz * dez) / math.sqrt(norm)

    if cosfi >= 1 then
        return 0
    end
    if cosfi <= -1 then
        return math.pi
    end

    local fi = math.acos(cosfi)

    if 180 * fi / math.pi < 180 then
        if isAngle then
            return 180 * fi / math.pi
        end
        return fi
    else
        if isAngle then
            return 360 - 180 * fi / math.pi
        end
        return 2 * math.pi - fi
    end

    return 0
end

function mathEx.Lerp(from, to, t)
	t = clamp(t, 0, 1)
	return from + (to - from) * t
end

--判定对象是否在矩形内
--center中心点 target检测点 length矩形长度 width矩形宽度 
function mathEx.InSquare(from, to, target, length, width)
    if Vector3.Equals(from, to) then
        return false
    end
    --先获取中点
    local center = Vector3.Lerp(from, to, length / 2 / Vector3.Distance(from, to))

    local disLength = mathEx.GetDistance(center.x, center.z, target.x, target.z)

    local angle = mathEx.GetTwoLineAngleV3(center, target, from)
    if Mathf.IsNan(angle) then
        angle = 0
    end

    local distance1 = math.abs(math.cos(angle) * disLength)
    local distance2 = math.abs(math.sin(angle) * disLength)

    if length / 2 >= distance1 and width / 2 >= distance2 then
        return true
    end

    return false
end

--判定对象是否在矩形内
--start起点 dir角度 target检测点 length矩形长度 width矩形宽度 
function mathEx.InSquare2(start, dir, target, length, width)
    local disLength = mathEx.GetDistance(start.x, start.z, target.x, target.z)

    --先获取中点
    local offsetX = length * math.cos(dir * math.pi / 180)
    local offsetZ = length * math.sin(dir * math.pi / 180)
    local center = Vector3.Lerp(start, start + Vector3(offsetX, start.y, offsetZ), 0.5)

    local angle = mathEx.GetTwoLineAngleV3(center, target, start)
    if Mathf.IsNan(angle) then
        angle = 0
    end

    local distance1 = math.abs(math.cos(angle) * disLength)
    local distance2 = math.abs(math.sin(angle) * disLength)

    if length >= distance1 and width >= distance2 then
        return true
    end

    return false
end

--获取A点绕B点旋转P度后的新坐标
function mathEx.GetNewPoint(angle, cirPoint, startPoint, reverse)
    local sign = 1
    if reverse then
        sign = -1
    end
    --角度转换为弧度
    local rage2 = angle / 180 * math.pi
    --计算新坐标x
    local x = ((startPoint.x - cirPoint.x) * math.cos(rage2 * sign) - (startPoint.y - cirPoint.y) * math.sin(rage2 * sign))
    --计算新坐标y
    local y = ((startPoint.y - cirPoint.y) * math.cos(rage2 * sign) + (startPoint.x - cirPoint.x) * math.sin(rage2 * sign))
    --返回新坐标
    return Vector2(x + cirPoint.x, y + cirPoint.y)
end

function mathEx.GetNewPointV3(angle, cirPoint, startPoint, reverse)
    local sign = 1
    if reverse then
        sign = -1
    end
    --角度转换为弧度
    local rage2 = angle / 180 * math.pi
    --计算新坐标x
    local x = ((startPoint.x - cirPoint.x) * math.cos(rage2 * sign) - (startPoint.z - cirPoint.z) * math.sin(rage2 * sign))
    --计算新坐标y
    local z = ((startPoint.z - cirPoint.z) * math.cos(rage2 * sign) + (startPoint.x - cirPoint.x) * math.sin(rage2 * sign))
    --返回新坐标
    return cirPoint.x + x, cirPoint.y, cirPoint.z + z
end



function mathEx.GetDistance(x1, z1, x2, z2)
    return sqrt((x1 - x2) ^ 2 + (z1 - z2) ^ 2)
end

function mathEx.GetSqrDistance(x1, z1, x2, z2)
    return (x1 - x2) ^ 2 + (z1 - z2) ^ 2
end

function mathEx.CornersContainsPoint(corners, x, y)
    local left = math.min(corners[0].x, corners[2].x)
    local right = math.max(corners[0].x, corners[2].x)
    local top = math.min(corners[0].y, corners[2].y)
    local bottom = math.max(corners[0].y, corners[2].y)

    if left >= right or top >= bottom then
        return false
    end

    if x >= left and x <= right and y >= top and y <= bottom then
        return true, (x - left) / (right - left), (y - top) / (bottom - top)
    end

    return false
end

function mathEx.RectContainsPoint(rect, x, y)
    local left = rect.left
    local right = rect.right
    local top = rect.top
    local bottom = rect.bottom

    if left >= right or top >= bottom then
        return false
    end

    if x >= left and x <= right and y >= top and y <= bottom then
        return true, (x - left) / (right - left), (y - top) / (bottom - top)
    end

    return false
end

--[[
    获取点到线段的距离平方
    checkLine判定是到线段的距离还是直线的距离
]]
function mathEx.SqrDistancePtToLine(p, q, pt, checkLine)
    local pqx = q.x - p.x
    local pqy = q.y - p.y
    local pqz = q.z - p.z
    local dx = pt.x - p.x
    local dy = pt.y - p.y
    local dz = pt.z - p.z
    local d = pqx * pqx + pqy * pqy + pqz * pqz     --qp线段长度的平方
    local t = pqx * dx + pqy * dy + pqz * dz        --p pt向量 点积 pq 向量（p相当于A点，q相当于B点，pt相当于P点）
    if d > 0 then   --除数不能为0; 如果为零 t应该也为零。下面计算结果仍然成立。
        t = t / d   --此时t 相当于 上述推导中的 r。
    end

    local out_range = false

    if not checkLine then --false表示获取线段距离，true表示获取直线距离
        if t < 0 then   --当t（r）< 0时，最短距离即为 pt点 和 p点（A点和P点）之间的距离。
            t = 0
            out_range = true
        elseif t > 1 then   --当t（r）> 1时，最短距离即为 pt点 和 q点（B点和P点）之间的距离。
            t = 1
            out_range = true
        end
    end

    --t = 0，计算 pt点 和 p点的距离; t = 1, 计算 pt点 和 q点 的距离; 否则计算 pt点 和 投影点 的距离。
    dx = p.x + t * pqx - pt.x
    dy = p.y + t * pqy - pt.y
    dz = p.z + t * pqz - pt.z

    return dx * dx + dy * dy + dz * dz, out_range
end

--[[
    获取点到线段的距离
    checkLine判定是到线段的距离还是直线的距离
]]
function mathEx.DistancePtToLine(p, q, pt, checkLine)
    local sqrDis, out_range = mathEx.SqrDistancePtToLine(p, q, pt, checkLine)
    return math.sqrt(sqrDis), out_range
end

--[[
    判定点是否在圆柱范围内
]]
local target_pos = Vector3()
function mathEx.IsPtInCylinder(pt, start_pos, end_pos, r, h)
    local dis = Vector3.Distance(start_pos, end_pos)
    if dis == 0 then
        return false
    end
    target_pos:CopyFrom(end_pos)
    Vector3.LerpWithFrom(target_pos, start_pos, (dis - h) / dis)
    local range, out_range = mathEx.DistancePtToLine(start_pos, target_pos, pt, false)
    if out_range then
        return false
    end
    return range <= r
end

--[[
    旋转方向
]]
function mathEx.RotateDir(dir, angle)
    local r = math.angle2radian(angle)
    local x = dir.x * math.cos(r) + dir.y * math.sin(r)
    local y = -dir.x * math.sin(r) + dir.y * math.cos(r)
    return Vector2(x, y)
end

-- 圆和线段相交
function mathEx.CheckCircleWithLineSegment(cCenter, cRadius, q1, q2)

    local cRadiusSqr = cRadius * cRadius;

    local A = (q2.x - q1.x) * (q2.x - q1.x) + (q2.y - q1.y) * (q2.y - q1.y)
    local B = 2 * ((q2.x - q1.x) * (q1.x - cCenter.x) + (q2.y - q1.y) * (q1.y - cCenter.y))
    local C = cCenter.x * cCenter.x
        + cCenter.y * cCenter.y
        + q1.x * q1.x + q1.y * q1.y
        - 2 * (cCenter.x * q1.x + cCenter.y * q1.y)
        - cRadiusSqr
    local b2_4ac = B * B - 4 * A * C
    local u = 100

    -- 不相交
    if b2_4ac < 0 then
        return false

    -- 一个交点
    elseif b2_4ac == 0 then 
        u = -B / (2 * A)

    -- 两个交点    
    else
        local sqrt_b2_4ac = Mathf.Sqrt(b2_4ac)
        local u1 = (-B + sqrt_b2_4ac) / (2 * A)
        local u2 = (-B - sqrt_b2_4ac) / (2 * A)
        -- 取小的u
        if 0 <= u1 and u1 < 1 then
            u = u1
        end
        if 0 <= u2 and u2 < 1 and u2 < u then
            u = u2
        end
    end
  
    if 0 <= u and u <= 1 then
    
        --length = length * u
        -- q2.x = q1.x + dir.x * length
        -- q2.y = q1.y + dir.y * length
        return true, u;
    end
    return false;
end