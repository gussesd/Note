UnscaledTimer = rrequire("Common/TimerBase")

function UnscaledTimer.GetTime()
    return Time.unscaledTime
end