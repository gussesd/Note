Timer = rrequire("Common/TimerBase")

function Timer.GetTime()
    return Time.time
end