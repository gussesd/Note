StringPool = {}
local str2id = {}
local id2str = {}
local pool = CS.TCFramework.StringPool

function StringPool.ToID(str)
    local id = str2id[str]
    if not id then
        id = pool.Add(str)
        str2id[str] = id
        id2str[id] = str
    end
    return id
end

function StringPool.ToStr(id)
    if id2str[id] == nil then
        return pool.Get(id)
    end
    return id2str[id]
end