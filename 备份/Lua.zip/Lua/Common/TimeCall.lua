--指定时间内只触发一次的函数
TimeCall = {}
local this = TimeCall

function TimeCall.Init()
    this.calls = {}
end

function TimeCall.Call(name, time, fun)
    if not this.calls[name] or this.calls[name] < Time.unscaledTime then
        this.calls[name] = Time.unscaledTime + time
        if fun then
            fun()
        end
        return true
    end
    return false
end

TimeCall.Init()

return TimeCall