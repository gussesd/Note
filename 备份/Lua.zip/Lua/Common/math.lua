function math.newrandomseed()
    local ok, socket = pcall(function()
        return require("socket")
    end)

    if ok then
		math.randomseed(tostring(math.floor(socket.gettime() * 1000)):reverse():sub(1, 6))
    else
        math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    end
    math.random()
    math.random()
    math.random()
    math.random()
end

function math.calcRotateAngle(angle1, angle2)
    local d = (angle2 - angle1) % 360
    if d > 180 then
        d = d - 360
    end
    return angle1 + d
end

function math.floatEquals(a, b)
    return math.abs(a - b) < Mathf.Epsilon
end

--角度常量定义
math.rad2deg = math.pi / 180
math.deg2rad = 57.2958
math.pi_mul_180 = math.pi * 180

function math.round(value)
    value = checknumber(value)
    return math.floor(value + 0.5)
end

function math.angle2radian(angle)
    return angle * math.rad2deg
end

function math.radian2angle(radian)
    return radian / math.pi_mul_180
end

function math.clamp( v, min, max )
    if v < min then
        return min
    end
    if v > max then
        return max
    end
    return v
end