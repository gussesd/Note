--一些通用函数

--记录函数的输入输出结果
function memoize(f)
    local mem = {} -- memoizing table
    setmetatable(mem, {__mode = "kv"}) -- make it weak
    return function (x) -- new version of ’f’, with memoizing
        local r = mem[x]
        if r == nil then -- no previous result?
            r = f(x) -- calls original function
            mem[x] = r -- store result for reuse
        end
        return r
    end
end

--返回值为复数形式的memoize
function memoizes(f)
    local mem = {} -- memoizing table
    setmetatable(mem, {__mode = "kv"}) -- make it weak
    return function (x) -- new version of ’f’, with memoizing
        local r = mem[x]
        if r == nil then -- no previous result?
            r = spack(f(x)) -- calls original function
            mem[x] = r -- store result for reuse
        end
        return sunpack(r)
    end
end
--复数输入函数由于涉及到表构建，性能不一定会好，所以就不实现了

-- 深拷贝对象
function DeepCopy(object)
	local lookup_table = {}
	
	local function _copy(object)
		if type(object) ~= "table" then
			return object
		elseif lookup_table[object] then
			return lookup_table[object]
		end

		local new_table = {}
		lookup_table[object] = new_table
		for index, value in pairs(object) do
			new_table[_copy(index)] = _copy(value)
		end

		return setmetatable(new_table, getmetatable(object))
	end

	return _copy(object)
end

--简单变量相等检测函数，不做元表检测
function SimpleEquals(value1, value2)
    local type1 = type(value1)
    if type1 ~= type(value2) then
        return false
    end

    if type1 == "table" then
        if table.count(value1) ~= table.count(value2) then
            return false
        end

        for k, v in pairs(value1) do
            if not SimpleEquals(v, value2[k]) then
                return false
            end
        end
        return true
    else
        return value1 == value2
    end
end

function checknumber(value, base)
    return tonumber(value, base) or 0
end

function limitnumber(value, min, max)
    if not value or value < min then
        value = min
    elseif value > max then
        value = max
    end
    return value
end

function checkint(value)
    return math.round(checknumber(value))
end

function checkbool(value)
    return (value ~= nil and value ~= false)
end

function checktable(value)
    if type(value) ~= "table" then value = {} end
    return value
end

function toboolean(value)
    if type(value) == "string" then
        value = string.lower( value )
        return (value == "true" and true) or false
    else
        return (value ~= nil and true) or false
    end
end

--[[------------------------------------------------------------------------------
-** 设置table只读 
-- 出现改写会抛出lua error
-- 用法 local cfg_proxy = read_only(cfg) retur cfg_proxy
-- 增加了防重置设置read_only的机制
-- lua5.3支持 1）table库支持调用元方法，所以table.remove table.insert 也会抛出错误，
--  2）不用定义__ipairs 5.3 ipairs迭代器支持访问元方法__index，pairs迭代器next不支持故需要元方法__pairs
-- 低版本lua此函数不能完全按照预期工作
*]]

local Debug = CS.UnityEngine.Debug
local isDebugBuild = Debug.isDebugBuild

function read_only(inputTable)
    --为了运行效率，该功能只在调试状态下触发
    if not isDebugBuild then
        return inputTable
    end
    local travelled_tables = {}

    local function __read_only(tbl)
        if not travelled_tables[tbl] then
            local tbl_mt = getmetatable(tbl)
            if not tbl_mt then
                tbl_mt = {}
                setmetatable(tbl, tbl_mt)
            end
    
            local proxy = tbl_mt.__read_only_proxy
            if not proxy then
                proxy = {}
                tbl_mt.__read_only_proxy = proxy
                local proxy_mt = {
                    __index = tbl,
                    __newindex = function (t, k, v) logError("error write to a read-only table with key = " .. tostring(k)) end,
                    __pairs = function (t) return pairs(tbl) end,
                    -- __ipairs = function (t) return ipairs(tbl) end, 5.3版本不需要此方法
                    __len = function (t) return #tbl end,
                    __read_only_proxy = proxy
                }
                setmetatable(proxy, proxy_mt)
            end

            travelled_tables[tbl] = proxy
            for k, v in pairs(tbl) do

                if type(v) == "table" then
                    tbl[k] = __read_only(v)
                end
            end
        end
        return travelled_tables[tbl]

    end
    return __read_only(inputTable)
end


--拿上面的函数仿写一个writeLog
function write_log(inputTable)
    --为了运行效率，该功能只在调试状态下触发
    if not isDebugBuild then
        return inputTable
    end
    local travelled_tables = {}

    local function __write_log(tbl)
        if not travelled_tables[tbl] then
            local tbl_mt = getmetatable(tbl)
            if not tbl_mt then
                tbl_mt = {}
                setmetatable(tbl, tbl_mt)
            end
    
            local proxy = tbl_mt.__write_log_proxy
            if not proxy then
                proxy = {}
                tbl_mt.__write_log_proxy = proxy
                local proxy_mt = {
                    __index = tbl,
                    __newindex = function (t, k, v) 
                            if tbl[k] ~= v then
                                tbl[k] = v
                                logError(k, v)
                            end
                        end,
                    __pairs = function (t) return pairs(tbl) end,
                    -- __ipairs = function (t) return ipairs(tbl) end, 5.3版本不需要此方法
                    __len = function (t) return #tbl end,
                    __write_log_proxy = proxy
                }
                setmetatable(proxy, proxy_mt)
            end

            travelled_tables[tbl] = proxy
            for k, v in pairs(tbl) do

                if type(v) == "table" then
                    tbl[k] = __write_log(v)
                end
            end
        end
        return travelled_tables[tbl]

    end
    return __write_log(inputTable)
end

local hookLogFunList = 
{
    --{"os", "date"},
}

function HookFun()
    for k, v in pairs(hookLogFunList) do
        if #v == 1 then
            local _f = _G[v[1]]
            _G[v[1]] = function(...)
                logError(...)
                return _f(...)
            end
        elseif #v == 2 then
            local _f = _G[v[1]][v[2]]
            _G[v[1]][v[2]] = function(...)
                logError(...)
                return _f(...)
            end
        elseif #v == 3 then
            local _f = _G[v[1]][v[2]][v[3]]
            _G[v[1]][v[2]][v[3]] = function(...)
                logError(...)
                return _f(...)
            end
        end
    end
end

HookFun()