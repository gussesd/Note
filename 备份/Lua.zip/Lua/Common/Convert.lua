--Convert.lua
--数据类型转换扩展
local Convert = {}

-- <summary>
 -- 将字符串数组转换为double类型数组
 -- </summary>
 -- <param name="ss">字符串数组</param>
 -- <returns></returns>
function Convert.StringArray2DoubleArray(strArray)
	local  numArray = {}
	for i=1, #strArray do
		if strArray[i] ~= "" then
			numArray[i] = tonumber(strArray[i])--暂时这么转换
		end	
	end
	return numArray
end

function Convert.StringArray2StringArray(strArray)
	-- body
	local  Array = {}
		for i=1,#strArray do
			if strArray[i] ~= "" then
				Array[i] = tostring(strArray[i])
			end	
		end
	return Array
end

function Convert.StringArray2ListArray(strArray)
	-- body
	local Array = {}
	for i,v in ipairs(strArray) do
		local tempArray = string.split(v,",")
		local Arraylist = {}
		for j,k in ipairs(tempArray) do
			Arraylist[j] = tonumber(k)
		end
		table.insert(Array, Arraylist)
	end
	return Array
end

function Convert.StringArray2BlendArray(strArray)
	-- body
	local BlendArray = {}
	local ArrayAnim = {}
	local Array = {}
	ArrayAnim[1] = tostring(strArray[1])
	BlendArray[1] = ArrayAnim
	for i,v in ipairs(strArray) do	
		if i > 1 and i < #strArray then
			local exist1 = string.find(v, "{")
			local exist2 = string.find(v, "}")

			if exist1 ~= nil and exist2 == nil then
				v = string.sub(v, 2)
			end

			if exist2 ~= nil and exist1 == nil then
				v = string.sub(v, 1, -2)
			end

			if exist1 ~= nil and exist2 ~= nil then
				v = string.sub(v, 2, -2)
			end

			Array[i-1] = tonumber(v)
		end
	end
	BlendArray[2] = Array
	BlendArray[3] = tonumber(strArray[#strArray])
	return BlendArray
end

-- <summary>
 -- 安全的字符串到浮点的转换
 -- </summary>
 -- <param name="str">字符串</param>
 -- <returns></returns>
function Convert:SafeConvertToDouble(str)
	return tonumber(str)
end

return Convert