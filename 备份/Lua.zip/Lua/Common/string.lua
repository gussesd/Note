function string.contains(str, subStr)
	return string.find(str, subStr) ~= nil
end

function string.endsWith(str, subStr)
	local len1 = #str
	local len2 = #subStr
	if len1 < len2 then
		return false
	end

	return string.find(str, subStr, len1 - len2 + 1) ~= nil
end

function string.isNullOrEmpty(str)
	return str == nil or str == ""
end

function string.replace(str, oldStr, newStr)
    local i, j = string.find(str, oldStr, 1, true)
    if i and j then
        local ret = {}
        local start = 1
        while i and j do
            table.insert(ret, string.sub(str, start, i - 1))
            table.insert(ret, newStr)
            start = j + 1
            i, j = string.find(str, oldStr, start, true)
        end
        table.insert(ret, string.sub(str, start))
        return table.concat(ret)
    end
    return str
end

function string.split(str, sep)
	sep = sep or " "
	local items = {}
    local pattern = string.format("([^%s]+)", sep)
    string.gsub(str, pattern, function (c) table.insert(items, c) end)  
    return items
end

--split2和split的区别是2会保留空字符串
function string.split2(str, sep) 
	sep = sep or '%s' 
	local t = {}  
	for field, s in string.gmatch(str, "([^"..sep.."]*)("..sep.."?)") do 
		table.insert(t,field)  
		if s == "" then 
			return t 
		end 
	end 
end

-- 字符串分割
-- @split_string：被分割的字符串
-- @pattern：分隔符，可以为模式匹配
-- @init：起始位置
-- @plain：为true禁用pattern模式匹配；为false则开启模式匹配
function string.splitEx(split_string, pattern, search_pos_begin, plain)
	assert(type(split_string) == "string")
	assert(type(pattern) == "string" and #pattern > 0)
	search_pos_begin = search_pos_begin or 1
	plain = plain or true
	local split_result = {}

	while true do
		local find_pos_begin, find_pos_end = string.find(split_string, pattern, search_pos_begin, plain)
		if not find_pos_begin then
			break
		end
		local cur_str = ""
		if find_pos_begin > search_pos_begin then
			cur_str = string.sub(split_string, search_pos_begin, find_pos_begin - 1)
		end
		split_result[#split_result + 1] = cur_str
		search_pos_begin = find_pos_end + 1
	end

	if search_pos_begin < string.len(split_string) then
		split_result[#split_result + 1] = string.sub(split_string, search_pos_begin)
	else
		split_result[#split_result + 1] = ""
	end

	return split_result
end

function string.startsWith(str, subStr)
	return string.find(str, subStr) == 1
end

local EMPTY_CHARS = " \t\n\r"

function string.trim(str, chars)
	chars = chars or EMPTY_CHARS
	return str:match(string.format("^[%s]*(.-)[%s]*$", chars, chars))
end

function string.trimLeft(str, chars)
	chars = chars or EMPTY_CHARS
	return str:match(string.format("^[%s]*(.*)", chars))
end

function string.trimRight(str, chars)
	chars = chars or EMPTY_CHARS
	return str:match(string.format("(.-)[%s]*$", chars))
end

function string.splitToNumber(str, step)
    local arr = string.split(str, step) or {}
    if arr then
        for i=1,#arr do
            arr[i] = tonumber(arr[i])
        end
    end
    return arr
end
    
function string.formatc(fmt,...)
    assert(fmt ~= nil,"Format error:Invalid Format String")
    local parms = {...}
	--解决传入空对象，导致后面参数丢失的问题
	parms.n = select('#', ...)
    
    local function search(k)
      --从 C# 数组习惯转到 Lua
      k = k + 1
      assert(k <= #parms and k >=0 ,"Format error:IndexOutOfRange")
      return tostring(parms[k])
    end
    
    return (string.gsub(fmt,"{(%d)}",search))
end

function string.formati(fmt,paramtab,numbertab)
    assert(fmt ~= nil,"Format error:Invalid Format String")
	--解决传入空对象，导致后面参数丢失的问题

    local function search(k)
	  local x=tonumber(k)
	  if x==nil then
		  return tostring(paramtab[k])
	  else
		  x = x + 1
		  assert(x <= #numbertab and x >=0 ,"Format error:IndexOutOfRange")
		  return tostring(numbertab[x])
	  end
      --从 C# 数组习惯转到 Lua
	end
    
    return (string.gsub(fmt,"{(%w+)}",search))
end

-- 字符串连接
function string.join(t, joiner)
	if #t == 0 then
		return ""
	end

    joiner = joiner or ""

	local fmt = "%s"
	for i = 2, #t do
		fmt = fmt .. joiner .. "%s"
	end

	return string.format(fmt, unpack(t))
end

-- 是否包含
-- 注意：plain为true时，关闭模式匹配机制，此时函数仅做直接的 “查找子串”的操作
function string.contains(str, pattern, plain)
	plain = plain or true
	local find_pos_begin, find_pos_end = string.find(str, pattern, 1, plain)
	return find_pos_begin ~= nil
end

-- 以某个字符串开始
function string.startswith(str, start_pattern, plain)
	plain = plain or true
	local find_pos_begin, find_pos_end = string.find(str, start_pattern, 1, plain)
	return find_pos_begin == 1
end

-- 以某个字符串结尾
function string.endswith(str, start_pattern, plain)
	plain = plain or true
	local find_pos_begin, find_pos_end = string.find(str, start_pattern, -#start_pattern, plain)
	return find_pos_end == #str
end

--- @ 从{} 中获取数据
---@ return table
function string.findData(str)
	assert(str ~= nil,"Format error:Invalid Format String")
	local _start = 0
	local _end =0
	local index = 0
	local data = {}

	while _start ~= nil do
		_start , _end = string.find(str,"{(%w+)}",_start)
		if _start ~= nil then
			local sub = string.sub(str,_start + 1 ,_end - 1)
			str =  string.replace(str,sub,tostring(index))
			if string.isNullOrEmpty(sub) == false then
				table.insert(data,sub)
			end
			_start = _start + 1
		end
	end
	return str,data
end

--[[
    @desc: 获取字符串的哈希值
    author:{author}
    time:2022-06-01 15:31:21
    --@str: 
    @return: number
]]
function string.getHashCode(str)
    local l = string.len(str)
    local h = l
    local step = bit.rshift(l, 5) + 1

    for i=l,step,-step do
        h = bit.bxor(h, (bit.lshift(h, 5) + string.byte(string.sub(str, i, i)) + bit.rshift(h, 2)))
    end

    return h
end

function string.GetBytes(char)
	if not char then
		return 0
	end
	local code = string.byte(char)
	if code < 127 then
		return 1
	elseif code <= 223  then
		return 2
	elseif code <= 239  then
		return 3
	elseif code <= 247  then
		return 4
	else
		return 0
	end
end

function string.SubChar(str,startIndex,endIndex) --截取汉字符串
	local tempStr = str
	local byteStart = 1 --起始位置
	local byteEnd = -1  --结束位置
	local index = 0 --字符计数
	local bytes = 0 --字符字计数
	startIndex = math.max(startIndex,1)
	endIndex = endIndex or -1
	while string.len(tempStr) > 0 do
		if index == startIndex -1 then
			byteStart = bytes + 1
		elseif index == endIndex then
			byteEnd = bytes
			break
		end
		bytes = bytes + string.GetBytes(tempStr)
		tempStr = string.sub(str,bytes + 1)
		index  = index + 1
	end
	return string.sub(str, byteStart, byteEnd)
end

function string.GetStringLength(inputstr)
    if not inputstr or type(inputstr) ~= "string" or #inputstr <= 0 then  --inputstr不为nil、类型为字符串、且长度不为0
        return nil
    end
    local length = 0  -- 字符的个数
    local i = 1       --累计的每个字符的字节数，如果 i = 0，那么跳出while条件就是  i >= #intutstr 或 i == #inputstr
    while true do     --这里我们是通过获取一个字符的头字节来判断是几字节的，如汉字的头字节ASCII是大于223的，所以直接跳过后面2个字节的判断，byteCount = 3
        local curByte = string.byte(inputstr, i)  --获取单个字节的ASCII码
        local byteCount = 1                       --单个字符的字节数，根据ASCII判断字节数
        if curByte > 239 then
            byteCount = 4  -- 4字节字符
        elseif curByte > 223 then
            byteCount = 3  -- 汉字，3字节
        elseif curByte > 128 then
            byteCount = 2  -- 双字节字符
        else
            byteCount = 1  -- 单字节字符
        end
        -- local char = string.sub(inputstr, i, i + byteCount - 1)
        -- print(char)  -- 打印单个字符
        i = i + byteCount
        length = length + 1
        if i > #inputstr then
            break
        end
    end
    return length          --返回字符个数
end

function string.getAllStringsBetweenMarkers(str,marker1,marker2)

	local results = {}
	local pattern = string.format("%s(.-)%s",marker1,marker2)

	for match in string.gmatch(str,pattern) do
		table.insert(results,match)
	end

	return results
end

function string.lastIndexOf(str, subStr, start)
    local index = nil
    while true do
        local i, j = string.find(str, subStr, index and index + 1, true)
        if not i then
            return index
        end

        index = i
    end
end

---@ 判断字符串是否能转换为int
function string.IsStringConvertibleToInt(str)
	local num = tonumber(str)
	if num ~= nil and math.type(num) == "integer" then
		return true , num
	else
		return false
	end
end

