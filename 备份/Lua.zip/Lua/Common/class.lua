function class(base)
    local c = {}
    local m = {}

    -- 构造函数
    m.__call = function (t, ...)
        local o = {}
        setmetatable(o, t)
        if o.ctor then
            o:ctor(...)
        end
        return o
    end

    -- 继承
    c.__base = base
    m.__index = base

    setgetters(c, nil)
    setmetatable(c, m)
    return c
end

local tempGetters = {}
function setgetters(cls, getters)
    local base = cls.__base
    if base and base.__getters then
        for k, v in pairs(base.__getters) do
            tempGetters[k] = v
        end
    end

    if getters then
        for k, v in pairs(getters) do
            tempGetters[k] = v
        end
    end

    if next(tempGetters) then
        cls.__getters = tempGetters
        tempGetters = {}

        cls.__index = function(t, k)
            local v = cls[k]
            if v then
                return v
            end

            local getters = cls.__getters
            if not getters then
                return nil
            end
    
            local getter = getters[k]
            return getter and getter(t)
        end
    else
        cls.__getters = nil
        cls.__index = cls
    end
end

function pairclass(cls, callback)
    for k, v in pairs(cls) do
        if callback(k, v) then
            return true
        end
    end
    if cls.__base then
        if pairclass(cls.__base, callback) then
            return true
        end
    end
end