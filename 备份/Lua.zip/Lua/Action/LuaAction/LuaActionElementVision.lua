local LuaActionElementVision = class(LuaActionBase)
local SetElementVisionScale = CS.CustomPipeline.DL.ElementVisionRenderer.SetElementVisionScale

function LuaActionElementVision:ctor(cfg, actionPlayer, event)
    LuaActionBase.ctor(self, cfg, actionPlayer, event)
end

function LuaActionElementVision:Init()
    LuaActionBase.Init(self)

    if self.event then
        self.timeCfg = self.event._time
    else
        self.timeCfg = tonumber(self.cfg.actiondataTable[1])
    end
end

function LuaActionElementVision:GetDuration()
    if self.event then
        return self.timeCfg
    end
    return LuaActionBase.GetDuration(self)
end

function LuaActionElementVision:OnStart()
    SetElementVisionScale(MainCamera.camera, 1, UnitManager.hero.pos)
    self.timer = nil
    local timeCount = 0
    local timeFull = self.timeCfg
    for k, v in pairs(UnitManager.monsters) do
        v:EnterElementVision(true)
    end
    for k, v in pairs(UnitManager.jiguans) do
        v:EnterElementVision(true)
    end
    for k, v in pairs(UnitManager.roles) do
        if v.isPlayer or v.isHero then
            v:EnterElementVision(true)
        end
    end
    TaskDecorationManager.EnterElementVision()
    self.timer = UnscaledTimer.StartLoop(0, -1, function()
        timeCount = timeCount + Time.unscaledDeltaTime
        if timeCount >= timeFull then
            self:EndElement()
            return        
        end
    end)
end

function LuaActionElementVision:EndElement()
    if self.timer then
        UnscaledTimer.Stop(self.timer)
    end

    SetElementVisionScale(MainCamera.camera, 0)
    for k, v in pairs(UnitManager.monsters) do
        v:LeaveElementVision()
    end
    for k, v in pairs(UnitManager.jiguans) do
        v:LeaveElementVision()
    end
    for k, v in pairs(UnitManager.roles) do
        if v.isPlayer or v.isHero then
            v:LeaveElementVision(true)
        end
    end
    TaskDecorationManager.LeaveElementVision()
end

function LuaActionElementVision:OnComplete()
    self:EndElement()
end

return LuaActionElementVision