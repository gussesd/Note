local LuaActionForbid = class(LuaActionBase)

function LuaActionForbid:ctor(cfg, actionPlayer)
    LuaActionBase.ctor(self, cfg, actionPlayer)
end

function LuaActionForbid:Init()
    LuaActionBase.Init(self)
    self.forbidTypes = tonumber(self.cfg.actiondataTable[1])

    self.table = Action.CreateAction("ForbidInput", self.forbidTypes, self.actionPlayer)
    self.onStart = self.table.OnStart
    self.onComplete = self.table.OnComplete
end

function LuaActionForbid:OnStart()
    if self.onStart then
        self.onStart(self.table)
    end
end

function LuaActionForbid:OnComplete()
    if self.onComplete then
        self.onComplete(self.table)
    end
end

return LuaActionForbid