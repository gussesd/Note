local LuaActionShake = class(LuaActionBase)

function LuaActionShake:ctor(cfg, actionPlayer, event)
    LuaActionBase.ctor(self, cfg, actionPlayer, event)
end

function LuaActionShake:OnStart()
    --logError("LuaActionShake:OnStart", Time.time)
    if self.event then
        MainCamera.StartShake(self.event._x, self.event._y, self.event._z, self.event._pow, self.event._time)
    else
        MainCamera.StartShake(unpack(self.cfg.actiondataTable))
    end
end

return LuaActionShake