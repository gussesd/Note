local LuaActionLookAt = class(LuaActionBase)

function LuaActionLookAt:ctor(cfg, actionPlayer)
    LuaActionBase.ctor(self, cfg, actionPlayer)
end

function LuaActionLookAt:Init()
    LuaActionBase.Init(self)

    --解析
    self.lookatType = tonumber(self.cfg.actiondataTable[1] or 0)
end

function LuaActionLookAt:OnStart()
    --logError("LuaActionLookAt:OnStart()", self.animationName)
    local owners = self.actionPlayer:GetTargets(ActionTargetType.Self)
    if owners then
        for k, v in pairs(owners) do
            if UnitManager.IsRoleAlive(v) then
                if self.lookatType == 0 then
                    local target = self.actionPlayer:GetTargets(ActionTargetType.Targets)
                    if target and #target > 0 then
                        v:LookAtTarget(target[1])
                    end
                else
                    local targetPoss = self.actionPlayer:GetTargetPoses(ActionTargetType.Targets)
                    if targetPoss and #targetPoss > 0 then
                        v:LookAt(targetPoss[1].x, targetPoss[1].z)
                    end
                end
            end
        end
    end
end

function LuaActionLookAt:GetDuration()
    return self.fadeOutLength > 0 and (self.cfg.duration - self.fadeOutLength) or self.cfg.duration
end

function LuaActionLookAt:OnStop()
    local owners = self.actionPlayer:GetTargets(ActionTargetType.Self)
    if owners then
        for k, v in pairs(owners) do
            if UnitManager.IsRoleAlive(v) then
                if self.lookatType == 0 then
                    v:LookAtTarget()
                end
            end
        end
    end
end

function LuaActionLookAt:OnComplete(bStop)
    --logError("LuaActionLookAt:OnComplete()", self.animationName, bStop)
    --如果是正常完成，并且配置了停止融合时间，测触发停止融合
    if not bStop and self.fadeOutLength >= 0 then
        local targets = self.actionPlayer:GetTargets(self.target)
        if targets then
            for k, v in pairs(targets) do
                if UnitManager.IsRoleAlive(v) and v.moving then
                    v:StopAnimation(self.animationName, self.fadeOutLength)
                end
                --logError("OnComplete", self.animationName)
            end
        end
    end
end


return LuaActionLookAt