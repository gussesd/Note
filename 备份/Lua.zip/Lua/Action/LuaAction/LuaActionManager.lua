--技能事件管理器
LuaActionData = require "Action/LuaAction/LuaActionData"
LuaActionPlayer = require "Action/LuaAction/LuaActionPlayer"
LuaActionBase = require "Action/LuaAction/LuaActionBase"
LuaActionAnimation = require "Action/LuaAction/LuaActionAnimation"
LuaActionBroken = require "Action/LuaAction/LuaActionBroken"
LuaActionDoBroken = require "Action/LuaAction/LuaActionDoBroken"
LuaActionDecoration = require "Action/LuaAction/LuaActionDecoration"
LuaActionForbid = require "Action/LuaAction/LuaActionForbid"
LuaActionGhostShadow = require "Action/LuaAction/LuaActionGhostShadow"
LuaActionOther = require "Action/LuaAction/LuaActionOther"
LuaActionShake = require "Action/LuaAction/LuaActionShake"
LuaActionTimeScale = require "Action/LuaAction/LuaActionTimeScale"
LuaActionMoveRotate = require "Action/LuaAction/LuaActionMoveRotate"
LuaActionElementVision = require "Action/LuaAction/LuaActionElementVision"

local LuaActionManager = {}
local this = LuaActionManager

function LuaActionManager.Init()
    this.dic = {}
end

function LuaActionManager.Play(id, args, bHero, bMultiple, level, avatar)
    local cfg = ConfigManager.GetMultiConfig(ConfigName.SkillAction, id)
    if cfg then
        local player = PoolManager.Get("LuaActionPlayer", {id = id, cfg = cfg, args = args, bHero = bHero, bMultiple = bMultiple, level = level, avatar = avatar})
        table.insert(this.dic, player)
        return player
    end
end

function LuaActionManager.PlayByEvent(avatar, event, bHero)
    local player = PoolManager.Get("LuaActionPlayer", {avatar = avatar, event = event, bHero = bHero})
    table.insert(this.dic, player)
    return player
end

--单纯获得一个action的时长
function LuaActionManager.GetActionLife(id, bHero, bMultiple, level, avatar, bSkipDecoration)
    local cfg = ConfigManager.GetMultiConfig(ConfigName.SkillAction, id)
    if cfg then
        local player = PoolManager.Get("LuaActionPlayer", {id = id, cfg = cfg, args = {}, bHero = bHero, bMultiple = bMultiple, level = level, avatar = avatar})
        local life = player.data:CalcMaxTime(bSkipDecoration)
        player:Destroy()
        return life
    end
end

function LuaActionManager.Update()
    for k, v in pairs(this.dic) do
        if v:Update() then
            v:Destroy()
            this.dic[k] = nil
        end
    end
end

function LuaActionManager.Clear()
    for k, v in pairs(this.dic) do
        v:Destroy()
        this.dic[k] = nil
    end
end

LuaActionManager.Init()

return LuaActionManager
