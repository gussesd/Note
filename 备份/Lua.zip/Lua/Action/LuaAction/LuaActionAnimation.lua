local LuaActionAnimation = class(LuaActionBase)

function LuaActionAnimation:ctor(cfg, actionPlayer)
    LuaActionBase.ctor(self, cfg, actionPlayer)
end

function LuaActionAnimation:Init()
    LuaActionBase.Init(self)

    --解析
    self.animationName = self.cfg.actiondataTable[1]
    self.target = tonumber(self.cfg.actiondataTable[2])
    self.speed = tonumber(self.cfg.actiondataTable[3])
    self.fadeLength = tonumber(self.cfg.actiondataTable[4])

    self.fadeOutLength = tonumber(self.cfg.actiondataTable[5] or -1)
    self.checkPlaying = (self.cfg.actiondataTable[6] == 1)
    self.UnStopWhenComplete = (self.cfg.actiondataTable[6] == 2)

    --logError("LuaActionAnimation:Init()", self.animationName)
end

function LuaActionAnimation:OnStart()
    --logError("LuaActionAnimation:OnStart()", self.animationName)
    local targets = self.actionPlayer:GetTargets(self.target)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                --logError("play", self.animationName)
                if not self.checkPlaying or not v:IsPlayingAnimation(self.animationName) then
                    v:PlayAnimation(self.animationName, self:GetPlayerSpeed() * self.speed, self.fadeLength, nil, true)
                end
            end
        end
    end
end

function LuaActionAnimation:GetDuration()
    local value = self.fadeOutLength > 0 and (self.cfg.duration - self.fadeOutLength) or self.cfg.duration
    if value <= 0 then
        if not self.log then
            self.log = true
            logError("LuaActionAnimation:GetDuration <= 0", self.animationName)
        end
    end
    return value
end

function LuaActionAnimation:OnStop()
    --logError("LuaActionAnimation:OnStop()", self.animationName, bStop)
    local targets = self.actionPlayer:GetTargets(self.target)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                --v:StopAnimation(self.animationName)
            end
        end
    end
end

function LuaActionAnimation:OnComplete(bStop)
    --logError("LuaActionAnimation:OnComplete()", self.animationName, bStop)
    --如果是正常完成，并且配置了停止融合时间，则触发停止融合
    if not bStop and self.fadeOutLength >= 0 then
        local targets = self.actionPlayer:GetTargets(self.target)
        if targets then
            for k, v in pairs(targets) do
                if UnitManager.IsRoleAlive(v) and v.moving then
                    v:StopAnimation(self.animationName, self.fadeOutLength)
                end
                --logError("OnComplete", self.animationName)
            end
        end
    elseif bStop and not self.UnStopWhenComplete then
        local targets = self.actionPlayer:GetTargets(self.target)
        if targets then
            for k, v in pairs(targets) do
                if UnitManager.IsRoleAlive(v) then
                    v:StopAnimation(self.animationName, self.fadeLength)
                end
            end
        end
    end
end


return LuaActionAnimation