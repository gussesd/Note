local LuaActionDoBroken = class(LuaActionBase)

function LuaActionDoBroken:ctor(cfg, actionPlayer)
    LuaActionBase.ctor(self, cfg, actionPlayer)
end

function LuaActionDoBroken:Init()
    LuaActionBase.Init(self)
    local brokenTypes = tonumber(self.cfg.actiondataTable[1])

    self.brokenList = {}
    for k, v in pairs(BROKEN_TYPE) do
        if (brokenTypes & v) > 0 then
            table.insert(self.brokenList, v)
        end
    end
end

function LuaActionDoBroken:OnStart()
    local targets = self.actionPlayer:GetTargets(self.target)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                for _, b in pairs(self.brokenList) do
                    v:DoBroken(b)
                end
            end
        end
    end
end

function LuaActionDoBroken:OnComplete()

end

return LuaActionDoBroken