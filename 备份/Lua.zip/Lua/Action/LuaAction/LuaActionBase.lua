local LuaActionBase = class()

function LuaActionBase:ctor(cfg, actionPlayer, event)
    self:PoolCtor(cfg, actionPlayer, event)
end

function LuaActionBase:PoolCtor(cfg, actionPlayer, event)
    self.cfg = cfg
    self.actionPlayer = actionPlayer
    self.event = event
    self.isRunning = false
    self.isStopped = false
    self.isComplete = false
    self.deltaTime = 0
    self:Init()
end

function LuaActionBase:PoolReset()
    self.cfg = nil
    self.actionPlayer = nil
end

function LuaActionBase:Init()
    if self.cfg and not self.cfg.actiondataTable then
        self.cfg.actiondataTable = string.split(self.cfg.actiondata, " ")
    end
end

function LuaActionBase:Update(time, lastTime)
    if self.isStopped then
        return
    end

    local st = self.cfg and self.cfg.startTime or 0
    local t1 = lastTime - st
    local t2 = time - st

    t1 = t1 * self:GetPlayerSpeed()
    t2 = t2 * self:GetPlayerSpeed()

    local running = t2 >= 0 and t2 < self:GetDuration()
    if running then
        self.deltaTime = t2 - math.clamp(t1, 0, self:GetDuration())

        if not self.isRunning then
            self:OnStart()
            self.isRunning = true
        end
        self:OnUpdate(t2)
    elseif t2 >= 0 then
        self:Complete()
    end
end

--获取当前进度
function LuaActionBase:GetProcess()
    if not self.isRunning then
        if self.isComplete then
            return 1
        else
            return 0
        end
    else
        return math.clamp(self.curTime / self:GetDuration(), 0, 1)
    end
end

function LuaActionBase:GetDuration()
    if self.cfg then
        return self.cfg.duration
    end
    return 0
end

function LuaActionBase:Complete(bStop)
    if self.isRunning then
        self.isRunning = false
        self:OnComplete(bStop)
    end
    self.isComplete = true
end

function LuaActionBase:GetPlayerSpeed()
    if self.cfg and self.cfg.usespeed == 1 then
        return self.actionPlayer:GetSpeed()
    end
    return 1
end

function LuaActionBase:Stop()
    if self.isStopped or self.isComplete then
        return
    end

    self.isStopped = true
    if self.isRunning then
        self:OnStop()
    end
    self:Complete(true)
end

-------------------------------------------------------------------------------
--override
function LuaActionBase:OnStart()

end

function LuaActionBase:OnUpdate(time)
    self.curTime = time
end

function LuaActionBase:OnComplete()

end

function LuaActionBase:OnStop()

end

function LuaActionBase:OnEvent(eventID, args)

end

return LuaActionBase