local LuaActionMoveRotate = class(LuaActionBase)

function LuaActionMoveRotate:ctor(cfg, actionPlayer)
    LuaActionBase.ctor(self, cfg, actionPlayer)
end

function LuaActionMoveRotate:Init()
    LuaActionBase.Init(self)
    self.angle = tonumber(self.cfg.actiondataTable[1])
end

function LuaActionMoveRotate:OnStart()
    local targets = self.actionPlayer:GetTargets(ActionTargetType.Self)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                v.moveRotate = self.angle
            end
        end
    end
end

function LuaActionMoveRotate:OnComplete()
    local targets = self.actionPlayer:GetTargets(ActionTargetType.Self)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                v.moveRotate = nil
            end
        end
    end
end

return LuaActionMoveRotate