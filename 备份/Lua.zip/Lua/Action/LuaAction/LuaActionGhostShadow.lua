local LuaActionGhostShadow = class(LuaActionBase)

function LuaActionGhostShadow:ctor(cfg, actionPlayer, event)
    LuaActionBase.ctor(self, cfg, actionPlayer, event)
end

function LuaActionGhostShadow:Init()
    LuaActionBase.Init(self)

    if self.event then
        self.timeCfg = self.event._value._time
    else
        self.timeCfg = tonumber(self.cfg.actiondataTable[1])
    end
end

function LuaActionGhostShadow:GetDuration()
    if self.event then
        return self.timeCfg
    end
    return LuaActionBase.GetDuration(self)
end

function LuaActionGhostShadow:OnStart()
    local targets = self.actionPlayer:GetTargets(ActionTargetType.Self)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                v:ShowGhostShadow(self.timeCfg)
            end
        end
    end
end

function LuaActionGhostShadow:OnComplete()
 
end

return LuaActionGhostShadow