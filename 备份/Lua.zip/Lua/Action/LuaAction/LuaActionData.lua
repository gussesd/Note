--技能事件数据
local LuaActionData = class()
local LuaActionType = {
    RoleAnimation = enum(0), --播放动作
    Decoration = enum(1), --播放特效
    ForbidInput = enum(3), --禁止操作
    Broken = enum(4), --打断操作
    Shake = enum(5), --震屏
    TimeScale = enum(6), --慢镜
    MoveRotate = enum(7),    --移动的相对朝向
    ElementVision = enum(8),    --元素视野
    GhostShadow = enum(9),  --残影
    DoBroken = enum(10),  --触发打断
    Other = enum(255) --特殊
}
function LuaActionData:ctor(params)
    self.cfg = {}
    self:PoolCtor(params)
end

function LuaActionData:PoolCtor(params)
    self.params = params
    self.unscaledTime = false
    self.bHero = params.bHero
    self.bMultiple = params.bMultiple
    self.level = params.level
    self.args = params.args
    self.avatar = params.avatar
    self.event = params.event
    if params.cfg then
        self:InitConfig(params.cfg)
    end
end

function LuaActionData:PoolReset()
    self.args = nil
    self.avatar = nil
    self.event = nil
    self.params = nil
    table.quickClear(self.cfg)
end

function LuaActionData:InitConfig(cfg)
    --根据输入参数，决定哪些是不触发的
    for k, v in pairs(cfg) do
        if self.bMultiple then
            --暂时只添加特效
            if v.actiontype == LuaActionType.Decoration then
                table.insert(self.cfg, v)
            end
        elseif not ((v.actiontype == LuaActionType.Shake
        or v.actiontype == LuaActionType.TimeScale
        or v.actiontype == LuaActionType.ElementVision
        or v.action == LuaActionType.GhostShadow ) and not self.bHero) then
            table.insert(self.cfg, v)
        end
    end
end

function LuaActionData:CalcMaxTime(bSkipDecoration)
    local maxTime = 0
    for k, v in pairs(self.cfg) do
        --特效不统计时长(除非是特效是唯一一个选项)
        if not bSkipDecoration or (v.actiontype ~= LuaActionType.Decoration or #self.cfg == 1) then
            local time = v.startTime + v.duration
            if maxTime < time then
                maxTime = time
            end
        end
    end
    return maxTime
end

function LuaActionData:CreateActions(index, actionPlayer)
    local config = self.cfg[index]
    if config then
        if config.actiontype == LuaActionType.RoleAnimation then
            return PoolManager.Get("LuaActionAnimation", config, actionPlayer)
        elseif config.actiontype == LuaActionType.Decoration then
            return PoolManager.Get("LuaActionDecoration", config, actionPlayer, self.args.element)
        elseif config.actiontype == LuaActionType.ForbidInput then
            return PoolManager.Get("LuaActionForbid", config, actionPlayer)
        elseif config.actiontype == LuaActionType.Broken then
            return PoolManager.Get("LuaActionBroken", config, actionPlayer)
        elseif config.actiontype == LuaActionType.Shake then
            return PoolManager.Get("LuaActionShake", config, actionPlayer)
        elseif config.actiontype == LuaActionType.TimeScale then
            return PoolManager.Get("LuaActionTimeScale", config, actionPlayer)
        elseif config.actiontype == LuaActionType.MoveRotate then
            return PoolManager.Get("LuaActionMoveRotate", config, actionPlayer)
        elseif config.actiontype == LuaActionType.ElementVision then
            return PoolManager.Get("LuaActionElementVision", config, actionPlayer)
        elseif config.actiontype == LuaActionType.GhostShadow then
            return PoolManager.Get("LuaActionGhostShadow", config, actionPlayer)
        elseif config.actiontype == LuaActionType.DoBroken then
            return PoolManager.Get("LuaActionDoBroken", config, actionPlayer)
        elseif config.actiontype == LuaActionType.Other then
            return PoolManager.Get("LuaActionOther", config, actionPlayer)
        end
    end
end

--根据事件创建对象
function LuaActionData:CreateEventAction(actionPlayer)
    if self.event._effecttype == SpecialEffectType.ElementeVision then
        return PoolManager.Get("LuaActionElementVision", nil, actionPlayer, self.event)
    elseif self.event._effecttype == SpecialEffectType.GhostShadow then
        return PoolManager.Get("LuaActionGhostShadow", nil, actionPlayer, self.event)
    elseif self.event._effecttype == SpecialEffectType.CameraShake then
        return PoolManager.Get("LuaActionShake", nil, actionPlayer, self.event)
    elseif self.event._effecttype == SpecialEffectType.CameraAlign then
        MainCamera.AlignCamera(true)
    elseif self.event._effecttype == SpecialEffectType.TimeScale then
        return PoolManager.Get("LuaActionTimeScale", nil, actionPlayer, self.event)
    elseif self.event._effecttype == SpecialEffectType.HideUI then
        if self.event._state == 0 then
            UIManager.Hide(self.ui)
        else
            UIManager.Show(self.ui)
        end
    end
end

return LuaActionData