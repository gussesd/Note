local LuaActionTimeScale = class(LuaActionBase)

function LuaActionTimeScale:ctor(cfg, actionPlayer, event)
    LuaActionBase.ctor(self, cfg, actionPlayer, event)
end

function LuaActionTimeScale:Init()
    LuaActionBase.Init(self)

    if self.event then
        self.timeScale = self.event._scale
        if self.timeScale < 0 then
            self.timeScale = 0
        elseif self.timeScale > 1 then
            --不准加速
            self.timeScale = 1
        end
    else
        self.timeScale = tonumber(self.cfg.actiondataTable[1])
        if self.timeScale < 0 then
            self.timeScale = 0
        elseif self.timeScale > 1 then
            --不准加速
            self.timeScale = 1
        end
    end
end

function LuaActionTimeScale:GetDuration()
    if self.event then
        return self.event._time
    end
    return LuaActionBase.GetDuration(self)
end

function LuaActionTimeScale:OnStart()
    self.startTime = 0
    --开定时器来做
    self.timer = UnscaledTimer.StartLoop(0, -1, function()
        self.startTime = self.startTime + Time.unscaledDeltaTime * self:GetPlayerSpeed()
        if self.startTime >= self:GetDuration() then
            self:StopTimer()
            Time.timeScale = 1
            return
        end
        Time.timeScale = self.timeScale
    end)
end

function LuaActionTimeScale:StopTimer()
    if self.timer then
        UnscaledTimer.Stop(self.timer)
        self.timer = nil
    end
end

function LuaActionTimeScale:OnComplete()
    self:StopTimer()
    Time.timeScale = 1
end

return LuaActionTimeScale