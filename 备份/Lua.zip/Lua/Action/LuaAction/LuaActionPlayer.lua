local LuaActionPlayer = class()

function LuaActionPlayer:ctor(params)
    self.actions = {}
    self:PoolCtor(params)
end

function LuaActionPlayer:PoolCtor(params)
    self.params = params
    self.avatar = params.avatar
    self.id = params.id
    self.args = params.args
    self.bHero = params.bHero
    self.bMultiple = params.bMultiple
    self.level = params.level
    self.cfg = params.cfg
    self.event = params.event
    self.speed = 1
    
    self.bDestroy = false
    self.bLaterDestroy = false
    
    self.breakType = self.args and self.args.breakType or LuaActionBreakType.All
    --self.co = Coroutine.Start(self.LoadActionData, self)
    self:LoadActionData()
    --logError("new luaactionplayer")
end

function LuaActionPlayer:PoolReset()
    self.args = nil
    self.cfg = nil
    self.data = nil
    self.selfs = nil
    self.co = nil
    self.avatar = nil
    self.event = nil
    self.params = nil
    table.quickClear(self.actions)
end

function LuaActionPlayer:LoadActionData()
    if self.event then
        self.data = PoolManager.Get("LuaActionData", {bHero = self.bHero, event = self.event, avatar = self.avatar})
    else
        self.data = PoolManager.Get("LuaActionData", {cfg = self.cfg, bHero = self.bHero, bMultiple = self.bMultiple, level = self.level, args = self.args, avatar = self.avatar})
    end
    self:Start()
    self.co = nil
end

function LuaActionPlayer:CurrentTime()
    return math.min(self.currentTime, self.maxTime)
end

function LuaActionPlayer:GetTime()
    return self.data.unscaledTime and Time.unscaledTime or Time.time
end

function LuaActionPlayer:Start()
    --logError("LuaActionPlayer:Start", self.id, Time.time)
    self.speed = self.args and self.args.speed or 1
    self.time = self:GetTime()
    self.maxTime = self.data:CalcMaxTime()
    self.currentTime = 0

    if #self.data.cfg > 0 then
        for k, v in pairs(self.data.cfg) do
            local action = self.data:CreateActions(k, self)
            if action then
                table.insert(self.actions, action)
            end
        end
    elseif self.data.event then
        local action = self.data:CreateEventAction(self)
        if action then
            table.insert(self.actions, action)
        end
    end
end

function LuaActionPlayer:Update()
    if not self.data or not self.actions then
        return true
    end

    local time = self:GetTime()
    local dt = (time - self.time) * self:GetSpeed()
    self.time = time

    return self:OnUpdate(self.currentTime + dt)
end

function LuaActionPlayer:GetSpeed()
    if self.avatar then
        return self.speed * self.avatar.animationSpeed
    end
    return self.speed
end

function LuaActionPlayer:OnUpdate(time)
    --强制销毁
    if self.bLaterDestroy then
        return true
    end
    --logError("OnUpdate", time)
    local isComplete = false
    for k, v in pairs(self.actions) do
        v:Update(time, self.currentTime)
        isComplete = isComplete and v.isComplete
    end
    self.currentTime = time

    --超时或者全部完成都算完成
    return (time > self.maxTime) or isComplete
end

--下一帧销毁
function LuaActionPlayer:LaterDestroy()
    self.bLaterDestroy = true
end

function LuaActionPlayer:Destroy()
    --logError("LuaActionPlayer:Destroy", self.id, Time.time)
    if self.bDestroy then
        return
    end
    if self.actions then
        for k, v in pairs(self.actions) do
            v:Complete(true)
            self.actions[k] = PoolManager.Release(v)
        end
    end

    if self.co then
        Coroutine.Stop(self.co)
        self.co = nil
    end

    self.data = PoolManager.Release(self.data)

    --触发回调
    if self.args and self.args.callback then
        self.args.callback()
        self.args.callback = nil
    end

    PoolManager.Release(self)
    self.bDestroy = true
end

function LuaActionPlayer:Stop()
    if self.actions == nil then
        return
    end

    if self.breakType == LuaActionBreakType.None then
        return
    end

    for k, v in pairs(self.actions) do
        if not v.isStopped then
            if self.breakType == LuaActionBreakType.All then
                v:Stop()
            end
        end
    end
end

function LuaActionPlayer:GetTargets(targetType)
    if targetType == ActionTargetType.Self or not targetType then
        if not self.selfs then
            if self.args and self.args.self then
                self.selfs = {self.args.self}
            elseif self.data then
                self.selfs = {self.avatar}
            end
        end
        return self.selfs
    elseif targetType == ActionTargetType.Targets then
        return self.args.targets
    end
end

function LuaActionPlayer:GetTargetPoses(targetType)
    if targetType == ActionTargetType.Self or not targetType then
        if not self.selfs and self.args.selPos then
            self.selfs = {self.args.selfPos}
        end
        return self.selfs
    elseif targetType == ActionTargetType.Targets then
        return self.args.targetPoses
    end
end

return LuaActionPlayer