local LuaActionDecoration = class(LuaActionBase)
local CSActionUtil = CS.TCFramework.ActionUtil

function LuaActionDecoration:ctor(cfg, actionPlayer, element)
    self:PoolCtor(cfg, actionPlayer, element)
    self.effects = {}
end

function LuaActionDecoration:PoolCtor(cfg, actionPlayer, element)
    LuaActionBase.PoolCtor(self, cfg, actionPlayer)
    self.element = element
end

function LuaActionDecoration:PoolReset()
    table.quickClear(self.effects)
    self.lookatTargetPos = nil
end

function LuaActionDecoration:Init()
    LuaActionBase.Init(self)
    self.id = tonumber(self.cfg.actiondataTable[1])
    self.target = tonumber(self.cfg.actiondataTable[2])
    if #self.cfg.actiondataTable > 2 and self.cfg.actiondataTable[3] == "1" then
        self.lookatTargetPos = tonumber(self.cfg.actiondataTable[3])
    end
    self.speed = 1
    if #self.cfg.actiondataTable > 3 then
        self.speed = tonumber(self.cfg.actiondataTable[4])
    end
end

function LuaActionDecoration:OnStart()
    self:CreateEffects()
end

function LuaActionDecoration:CreateEffects()
    local targets = self.actionPlayer:GetTargets(self.target)
    if targets and #targets > 0 then
        local pos = nil
        if self.lookatTargetPos then
            local poses = self.actionPlayer:GetTargetPoses(ActionTargetType.Targets)
            if poses and #poses > 0 then
                pos = poses[1]
            end
        end
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                local dec = Decoration({id = self.id, parent = v.model.transform, element = self.element, speed = self:GetPlayerSpeed() * self.speed, avatar = ((self.cfg.usespeed == 1) and self.actionPlayer.avatar), lookat = pos})
                table.insert(self.effects, dec)
            end
        end
    else
        local targetPoses = self.actionPlayer:GetTargetPoses(self.target)
        if targetPoses then
            for k, v in pairs(targetPoses) do
                local dec = Decoration({id = self.id, pos = v, element = self.element, speed = self:GetPlayerSpeed() * self.speed, avatar = ((self.cfg.usespeed == 1) and self.actionPlayer.avatar)})
                table.insert(self.effects, dec)
            end
        end
    end
end

function LuaActionDecoration:SetEffectSpeed(effect)
    if self.cfg.usespeed == 0 or self.actionPlayer.speed == 1 then
        return
    end

    CSActionUtil.SetEffectSpeed(effect.gameObject, self:GetPlayerSpeed())
end

function LuaActionDecoration:OnComplete()
    if not self.effects then
        return
    end

    for k, v in pairs(self.effects) do
        v:Destroy(v)
        self.effects[k] = v
    end
end

return LuaActionDecoration