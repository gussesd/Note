local LuaActionBroken = class(LuaActionBase)

local BROKEN_ACTION = {
    BREAKSKILL = enum(1),   --中断当前技能
    BREAKACTION = enum(2),  --中断当前action,带id的话，则执行新action
    ANIMATION = enum(3),    --执行新动作
}
function LuaActionBroken:ctor(cfg, actionPlayer)
    LuaActionBase.ctor(self, cfg, actionPlayer)
end

function LuaActionBroken:Init()
    LuaActionBase.Init(self)
    local brokenTypes = tonumber(self.cfg.actiondataTable[1])
    self.brokenAction = tonumber(self.cfg.actiondataTable[2] or -1)
    self.brokenActionData = self.cfg.actiondataTable[3]
    

    self.brokenList = {}
    for k, v in pairs(BROKEN_TYPE) do
        if (brokenTypes & v) > 0 then
            table.insert(self.brokenList, v)
        end
    end
end

function LuaActionBroken:OnStart()
    local targets = self.actionPlayer:GetTargets(self.target)
    if targets then
        for k, v in pairs(targets) do
            --if UnitManager.IsRoleAlive(v) then
                v:AddBroken(self)
            --end
        end
    end
end

function LuaActionBroken:OnComplete()
    local targets = self.actionPlayer:GetTargets(self.target)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                v:RemoveBroken(self)
            end
        end
    end
end

--触发打断时，检测打断逻辑
function LuaActionBroken:DoBroken(type)
    --结束的action不再处理
    if self.isComplete or self.isStopped then
        return
    end
    for k, v in pairs(self.brokenList) do
        if v == type then
            self:OnBroken(type)
        end
    end
end

--触发打断流程
function LuaActionBroken:OnBroken(type)
    --根据类型触发打断
    local targets = self.actionPlayer:GetTargets(self.target)
    if targets then
        for k, v in pairs(targets) do
            if UnitManager.IsRoleAlive(v) then
                self:BrokenAction(v, type)
            end
        end
    end
end

--具体的打断逻辑
function LuaActionBroken:BrokenAction(avatar, type)
    if self.brokenAction == BROKEN_ACTION.BREAKSKILL then
        avatar.skillCtrl:DoBroken(type)
    elseif self.brokenAction == BROKEN_ACTION.BREAKACTION then
        self.actionPlayer:LaterDestroy()
        if self.brokenActionData then
            avatar:PlayNetAction(tonumber(self.brokenActionData))
        end
    elseif self.brokenAction == BROKEN_ACTION.ANIMATION then
        if self.brokenActionData then
            avatar:PlayAnimation(self.brokenActionData, nil, nil, nil, true)
        end
    end
end

return LuaActionBroken