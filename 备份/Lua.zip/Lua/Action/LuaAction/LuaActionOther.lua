local LuaActionOther = class(LuaActionBase)

function LuaActionOther:ctor(cfg, actionPlayer, event, luaClass, data)
    self.luaClass = luaClass
    self.data = data
    LuaActionBase.ctor(self, cfg, actionPlayer, event)
end

function LuaActionOther:Init()
    LuaActionBase.Init(self)

    if not self.event then
        self.luaClass = self.cfg.actiondataTable[1]
        self.data = self.cfg.actiondataTable[2]
    end

    self.table = Action.CreateAction(self.luaClass, self.data, self.actionPlayer, self.cfg, self.event)
    if not self.table then
        return
    end
    self.onStart = self.table.OnStart
    self.onUpdate = self.table.OnUpdate
    self.onComplete = self.table.OnComplete
end

function LuaActionOther:GetDuration()
    if self.event then
        --安全点，保证不会立刻释放
        return 0.1
    end
    return LuaActionBase.GetDuration(self)
end

function LuaActionOther:OnStart()
    if self.onStart and self.table then
        self.onStart(self.table)
    else
        if self.luaClass == "AutoStopAnimation" then
            local targets = self.actionPlayer:GetTargets(ActionTargetType.Self)
            if targets then
                for k, v in pairs(targets) do
                    if UnitManager.IsRoleAlive(v) then
                        v:AutoStopAnimation(true)
                    end
                end
            end
        end
    end
end

function LuaActionOther:OnUpdate()
    if self.onUpdate and self.table then
        self.onUpdate(self.table)
    end
end

function LuaActionOther:OnComplete()
    if self.onComplete and self.table then
        self.onComplete(self.table)
    else
        if self.luaClass == "AutoStopAnimation" then
            local targets = self.actionPlayer:GetTargets(ActionTargetType.Self)
            if targets then
                for k, v in pairs(targets) do
                    if UnitManager.IsRoleAlive(v) then
                        v:AutoStopAnimation(false)
                    end
                end
            end
        end
    end
end

return LuaActionOther