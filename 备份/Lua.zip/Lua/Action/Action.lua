ActionHideUI = require "Action/ActionHideUI"
ActionMoveUnit = require "Action/ActionMoveUnit"
ActionRotateUnit = require "Action/ActionRotateUnit"
--ActionBroken = require "Action/ActionBroken"
ActionForbidInput = require "Action/ActionForbidInput"
ActionShakeCamera = require "Action/ActionShakeCamera"
ActionUseShader = require "Action/ActionUseShader"
LuaActionManager = require "Action/LuaAction/LuaActionManager"

local Action = {}

function Action.CreateAction(name, data, player, cfg, event)
    if not name or name == "" then
        return nil
    end

    --TODO 整个流程已经改成lua实现了，可以改为使用对象池
    ----action的lua类都不用缓存池，原因是每个类都会有回调函数被c#持有，维护这个监控太麻烦了。
    local type = _G["Action" .. name]
    if not type then
        return nil
    end

    return type(data, player, cfg, event)
end

function Action.RoleGetGameObject(id)
    return UnitManager.UnitGetGameObject(nil, id)
end

function Action.RoleGetUnitIDByName(name)
    --logError("Action.RoleGetUnitIDByName", name)
    local unit = UnitManager.GetUnitByName(nil, name)
    if unit then
        return unit.id
    end
end

function Action.RoleGetGameObjectByName(name)
    local unit = UnitManager.GetUnitByName(nil, name)
    if unit then
        return unit.gameObject
    end
end

function Action.GetPlayableAnimationByName(name)
    local unit = UnitManager.GetUnitByName(nil, name)
    if unit and unit.model and unit.model.roleAnimation then
        return unit.model.roleAnimation.animation
    end
end

function Action.RolePlayAnimation(id, name, speed)
    --logError("Action.RolePlayAnimation", id, name)
    --判定是否配置了多个动作
    if string.find(name, ",") then
        Action.RolePlayRandomAnimation(id, string.split(name, ","), speed)
    else
        UnitManager.UnitPlayAnimation(nil, id, name, speed, nil, nil, true)
    end
end

function Action.RoleStopAnimation(id, name)
    --logError("Action.RoleStopAnimation", id, name)
    UnitManager.UnitStopPlayAnimation(nil, id, name, 0)
end

function Action.RoleBlendAnimation(id, name, targetWeight, fadeLength)
    UnitManager.UnitBlendAnimation(nil, id, name, targetWeight, fadeLength)
end

function Action.RoleRewindAnimation(id, name)
    UnitManager.UnitRewindAnimation(nil, id, name)
end

function Action.RoleSampleAnimation(id, name, time)
    UnitManager.UnitSampleAnimation(nil, id, name, time)
end

--随机播放一个动作
function Action.RolePlayRandomAnimation(id, list)
    local name = table.randomGetValue(list)
    if name then
        UnitManager.UnitPlayAnimation(nil, id, name)
    end
end

function Action.RoleLookAt(id, x, z, bLocal, bAnimation)
    local unit = UnitManager.GetUnit(nil, id)
    if unit then
        if bLocal then
            unit:LookAt(unit.pos.x + x, unit.pos.z + z, bAnimation)
        else
            unit:LookAt(x, z, bAnimation)
        end
    end
end

return Action