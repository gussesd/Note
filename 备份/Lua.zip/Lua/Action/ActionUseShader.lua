local ActionUseShader = class()

function ActionUseShader:ctor(data, player, cfg)
    self.data = string.splitToNumber(data,',')
    self.player = player
    self.args = player.args
    self.cfg = cfg
end

function ActionUseShader:OnStart()
    if self.data and #self.data >= 1 then
        local targets = self.player:GetTargets(self.target)
        if targets then
            for k, v in pairs(targets) do
                if UnitManager.IsRoleAlive(v) then
                    if v.shaderCtrl then
                        v.shaderCtrl:AddShader(tonumber(self.data[1]), tonumber(self.data[2]))
                    end
                end
            end
        end
    end
end

--这里会从C#调用Lua，尽量少用
--function ActionUseShader:OnUpdate(time)
--    LuaActionBase.OnUpdate(self, time)
--end


function ActionUseShader:OnComplete()
    --TODO 取消shader的逻辑
end

return ActionUseShader