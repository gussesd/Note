local ActionRotateUnit = class()

function ActionRotateUnit:ctor(data, player, cfg)
    self.data = string.splitToNumber(data,',')
    self.player = player
    self.args = player.args
    self.cfg = cfg
end

function ActionRotateUnit:OnStart()
    if self.data and #self.data >= 2 then
        local target
        if self.data[1] == 1 then
            target = {self.args.self}
        elseif self.data[1] == 2 then
            target = self.args.target
        end

        if target then
            for _,v in pairs(target) do
                local role = UnitManager.GetUnit("role", v)
                if role then
                    role.rotateCtrl:StartRotate(self.data[2], self.data[3])
                end
            end
        end
    end
end

--这里会从C#调用Lua，尽量少用
--function ActionRotateUnit:OnUpdate(time)
--    LuaActionBase.OnUpdate(self, time)    
--end


function ActionRotateUnit:OnComplete()
   
end

return ActionRotateUnit