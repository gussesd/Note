local ActionBroken = class()

function ActionBroken:ctor(data, player, cfg)
    self.data = data
    self.player = player
    self.args = player.args
    self.cfg = cfg
end

function ActionBroken:InitData()
    local value = tonumber(self.data)
    self.brokenList = {}
    for k, v in pairs(BROKEN_TYPE) do
        if (value & v) > 0 then
            table.insert(self.brokenList, v)
        end
    end
end

function ActionBroken:OnStart()
    --logError("ActionForbidInput.OnStart")
    self:InitData()
    --添加到unit上
    if self.args.self and self.args.self then
        if self.args.self.m_RoleID then
            self.avatar = UnitManager.GetUnit("role", self.args.self.m_RoleID)
        else
            self.avatar = self.args.self
        end
    end
    if self.avatar then
        self.avatar:AddBroken(self)
    end
end

function ActionBroken:OnComplete()
    --logError("ActionForbidInput.OnComplete")
    if self.avatar then
        self.avatar:RemoveBroken(self)
    end
end

function ActionBroken:DoBroken()
    
end

return ActionBroken