local ActionShakeCamera = class()

function ActionShakeCamera:ctor(data)
    self.data = string.splitToNumber(data, ",")
end

function ActionShakeCamera:OnStart()
    --logError("shake", Time.time)
    MainCamera.StartShake(unpack(self.data))
end

--这里会从C#调用Lua，尽量少用
--function ActionHideUI:OnUpdate(time)
--    LuaActionBase.OnUpdate(self, time)
--end

function ActionShakeCamera:OnComplete()
    
end

return ActionShakeCamera