local ActionForbidInput = class()

function ActionForbidInput:ctor(data, player, cfg)
    self.data = data
    self.player = player
    self.args = player.args
    self.cfg = cfg
end

function ActionForbidInput:InitData()
    --logError("ActionForbidInput.InitData", self.data)
    local value = tonumber(self.data)
    --self.forbidList = string.splitToNumber(self.data, ",")
    self.forbidList = {}
    for k, v in pairs(INPUT_TYPE) do
        if (value & v) > 0 then
            table.insert(self.forbidList, v)
        end
    end
end

function ActionForbidInput:OnStart()
    --logError("ActionForbidInput.OnStart")
    self:InitData()
    --添加到unit上
    if self.args.self and self.args.self then
        if self.args.self.m_RoleID then
            self.avatar = UnitManager.GetUnit("role", self.args.self.m_RoleID)
        else
            self.avatar = self.args.self
        end
    end
    if self.avatar and self.avatar.skillCtrl then
        self.avatar.skillCtrl:AddForbidInput(self.forbidList)
    end
end

function ActionForbidInput:OnComplete()
    --logError("ActionForbidInput.OnComplete")
    if self.avatar and self.avatar.skillCtrl then
        self.avatar.skillCtrl:RemoveForbidInput(self.forbidList)
    end
end

return ActionForbidInput