local ActionMoveUnit = class()

function ActionMoveUnit:ctor(data, player, cfg)
    self.data = string.splitToNumber(data,',')
    self.player = player
    self.args = player.args
    self.cfg = cfg
end

function ActionMoveUnit:OnStart()
    if self.data and #self.data >= 2 then
        local targets = self.player:GetTargets(self.target)
        if targets then
            for k, v in pairs(targets) do
                if UnitManager.IsRoleAlive(v) then
                    --logError(v.dir)
                    --v.moveCtrl:NetSkillMove(Vector3(mathEx.GetNewPointV3(v.dir, v.pos, Vector3(v.pos.x + self.data[1], v.pos.y, v.pos.z + self.data[2]), true)), self.cfg.duration)
                end
            end
        end
    end
end

--function ActionMoveUnit:Update()

--end

--这里会从C#调用Lua，尽量少用
--function ActionMoveUnit:OnUpdate(time)
--    LuaActionBase.OnUpdate(self, time)    
--end


function ActionMoveUnit:OnComplete()
   if self.actionKey then
        ActionManager.RemoveAction(self.actionKey)
   end
end

return ActionMoveUnit