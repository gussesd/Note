local ActionHideUI = class()

function ActionHideUI:ctor(data)
    self.ui = data
end

function ActionHideUI:OnStart()
    UIManager.Hide(self.ui)
end

--这里会从C#调用Lua，尽量少用
--function ActionHideUI:OnUpdate(time)
--    LuaActionBase.OnUpdate(self, time)    
--end

function ActionHideUI:OnComplete()
    UIManager.Show(self.ui)
end

return ActionHideUI