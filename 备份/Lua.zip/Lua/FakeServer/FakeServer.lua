--[[
    模拟服务器，方便客户端调试用
]]
local PlayerPrefs = CS.UnityEngine.PlayerPrefs
local FakeServer = {}
local this = FakeServer

function FakeServer.Init()
    this.delayCall = {}
    this.checkTime = Time.unscaledTime
end

function FakeServer.Close()
    this.bClosed = true
end

function FakeServer.Update()
    --模拟真实环境，50毫秒处理一次
    if Time.unscaledTime > this.checkTime + 0.05 then
        this.checkTime = Time.unscaledTime
        if not table.isNullOrEmpty(this.delayCall) then
            for k, v in pairs(this.delayCall) do
                v[1]  = v[1] - 0.05
                if v[1] <= 0 then
                    v[2](table.unpack(v[3]))
                    this.delayCall[k] = nil
                end
            end
        end
    end
end

function FakeServer.AddDelayCall(delay, callback, ...)
    table.insert(this.delayCall, {delay, callback, {...}})
end

function FakeServer.Connect(callback)
    this.bClosed = false
    this.AddDelayCall(0, callback, true)
end

function FakeServer.Recv(id, data)
    this.AddDelayCall(0, FakeServer.DelayRecv, id, data)
end


local function serialize(obj)
    local lua = ""  
    local t = type(obj)  
    if t == "number" then  
        lua = lua .. obj  
    elseif t == "boolean" then  
        lua = lua .. tostring(obj)  
    elseif t == "string" then  
        lua = lua .. string.format("%q", obj)  
    elseif t == "table" then  
        lua = lua .. "{"  
        for k, v in pairs(obj) do  
            lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ","  
        end  
        local metatable = getmetatable(obj)  
        if metatable ~= nil and type(metatable.__index) == "table" then  
            for k, v in pairs(metatable.__index) do  
                lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ","  
            end  
        end  
        lua = lua .. "}"  
    elseif t == "nil" then  
        return nil  
    else  
        error("can not serialize a " .. t .. " type.")  
    end  
    return lua  
end

local function unserialize(lua)
    local t = type(lua)
    if t == "nil" or lua == "" then
        return nil
    end
    lua = "return " .. lua
    local func = load(lua)
    if func == nil then
        return nil
    end
    return func()
end


function FakeServer.DelayRecv(id, data)
    if id == ClientMsgMessage.CM_USER_LOGIN then    --登陆
        this.uid = data.uid
    --    print(PlayerPrefs.GetString(data.uid))
    --    local str=unserialize(PlayerPrefs.GetString(data.uid))==nil and 1 or 2
    --    LPrint.log(ColorCode.Yellow, str)
    
        this.roleList = unserialize(PlayerPrefs.GetString(data.uid)) or {uid = data.uid, sid = data.sid, serverTime = Time.unscaledTime, chrs = {}}
        for k, v in pairs(this.roleList.chrs) do
            v.logout_time = 0
        end
        this.cidInitial = PlayerPrefs.GetInt("cidInitial") or  0
       
        -- this.roleList = {uid = data.uid, sid = data.sid, serverTime = Time.unscaledTime, chrs = {}}
        -- local r = math.random(1, 100)
        -- if r > 66 then
            -- table.insert(this.roleList.chrs, {cid = 1, name = "白虎宗男", delete_time = 0, sex = 0, job = JOB_TYPE.Paladin, guideProcess = 0, level = 1, hunshi = 0})
            -- table.insert(this.roleList.chrs, {cid = 2, name = "昊天宗男", delete_time = 0, sex = 0, job = JOB_TYPE.Warrior, guideProcess = 0, level = 1, hunshi = 0})
            -- table.insert(this.roleList.chrs, {cid = 3, name = "灵猫宗女", delete_time = 0, sex = 1, job = JOB_TYPE.Hunter, guideProcess = 0, level = 1, hunshi = 0})
        -- elseif r > 33 then
            -- table.insert(this.roleList.chrs, {cid = 2, name = "昊天宗女", delete_time = 0, sex = 1, job = JOB_TYPE.Warrior, guideProcess = 0, level = 1, hunshi = 0})
            -- table.insert(this.roleList.chrs, {cid = 6, name = "琉璃宗女", delete_time = 0, sex = 1, job = JOB_TYPE.Priest, guideProcess = 0, level = 1, hunshi = 0})
            -- table.insert(this.roleList.chrs, {cid = 1, name = "白虎宗男", delete_time = 0, sex = 0, job = JOB_TYPE.Paladin, guideProcess = 0, level = 1, hunshi = 0})
        -- else
            -- table.insert(this.roleList.chrs, {cid = 4, name = "凤凰宗男", delete_time = 0, sex = 0, job = JOB_TYPE.Sorcerer, guideProcess = 0, level = 1, hunshi = 0})
            -- table.insert(this.roleList.chrs, {cid = 5, name = "凤凰宗女", delete_time = 0, sex = 1, job = JOB_TYPE.Sorcerer, guideProcess = 0, level = 1, hunshi = 0})
            -- table.insert(this.roleList.chrs, {cid = 6, name = "琉璃宗男", delete_time = 0, sex = 0, job = JOB_TYPE.Priest, guideProcess = 0, level = 1, hunshi = 0})
        -- end
        -- table.insert(retTable.chrs, {cid = 3, name = "test3", delete_time = 0, sex = 1, guideProcess = 0})
        this.Send(ServerMsgMessage.SM_CHARACTOR_LIST, this.roleList)
    elseif id == ClientMsgMessage.CM_NEW_CHARACTER then
        this.cidInitial = this.cidInitial+1
       
        table.insert(this.roleList.chrs, {cid = this.cidInitial, name = "", delete_time = 0,logout_time=0, sex = data.sex, job = data.job, guideProcess = 0, level = 1, hunshi = 0})
        local listString= serialize( this.roleList)
        PlayerPrefs.SetInt("cidInitial",this.cidInitial)
        PlayerPrefs.SetString(this.uid, listString)
        PlayerPrefs.Save()
        this.Send(ServerMsgMessage.SM_CHARACTOR_LIST, this.roleList)
    elseif id == ClientMsgMessage.CM_DELETE_CHARACTER then
        for i, v in ipairs(this.roleList.chrs) do
            if v.cid == data.cid then
                table.remove(this.roleList.chrs,i)
                break
            end
        end
        local listString= serialize( this.roleList)
        PlayerPrefs.SetString(this.uid, listString)
        PlayerPrefs.DeleteKey(data.cid)
        PlayerPrefs.Save()
        this.Send(ServerMsgMessage.SM_CHARACTOR_LIST, this.roleList)
    elseif id == ClientMsgMessage.CM_RECOVER_CHARACTER then
    elseif id == ClientMsgMessage.CM_ENTER_GAME then
        --local tabs = {
        --    --{left_atk_speed=1, pos={x=1600, z=3100, y=0.0}, map=1000, entity_id=data.cid, right_atk_speed=1},
        --    --{left_atk_speed=1, pos={x=-30, z=-40, y=110}, map=1001, entity_id=data.cid, right_atk_speed=1},
        --    {left_atk_speed=1, pos={x=-21, z=8, y=1}, map=1002, entity_id=data.cid, right_atk_speed=1},
        --    }
        --local retTable = tabs[math.random(#tabs)]
        this.propertyList =unserialize(PlayerPrefs.GetString(tostring(data.cid))) or
        {
            [NetManager.IsUsingFakeServer().id]=
            {
            left_atk_speed=1, 
            entity_id=data.cid, 
            right_atk_speed=1, 
            map=NetManager.IsUsingFakeServer().id,
            pos=Vector3(unpack(NetManager.IsUsingFakeServer().pos)),
            dir=0,
            }
        }

        this.rolePropertyList=this.propertyList[NetManager.IsUsingFakeServer().id] or   {
            left_atk_speed=1, 
            entity_id=data.cid, 
            right_atk_speed=1, 
            map=NetManager.IsUsingFakeServer().id,
            pos=Vector3(unpack(NetManager.IsUsingFakeServer().pos)),
            dir=0,
            }
        this.rolePropertyList.dir = 0
        -- local retTable = {left_atk_speed=1, 
        --                 entity_id=data.cid, 
        --                 right_atk_speed=1, 
        --                 map=NetManager.IsUsingFakeServer().id,
        --                 pos=Vector3(unpack(NetManager.IsUsingFakeServer().pos))}
        --, pos={x=-21, z=8, y=1}, map=1002

        --记录玩家信息
        this.map = this.rolePropertyList.map
        this.pos = this.rolePropertyList.pos
        this.cid = data.cid

        this.roleInfo = nil
        for k, v in pairs(this.roleList.chrs) do
            if v.cid == data.cid then
                this.roleInfo = v
                break
            end
        end

        --角色信息包
        if this.roleInfo then
            this.Send(ServerMsgMessage.SM_PLAYER_INFO, {cid = this.roleInfo.cid, 
                                                        sid = this.roleInfo.sid,
                                                        uid = this.roleInfo.uid,
                                                        name = " ",--this.roleInfo.name,
                                                        sex = this.roleInfo.sex,
                                                        job = this.roleInfo.job,
                                                        level = 1,
                                                        coin = 0,
                                                        model = 1,
                                                        map = this.rolePropertyList.map,
                                                        exp = 0,
                                                        x = this.rolePropertyList.pos.x,
                                                        y = this.rolePropertyList.pos.y,
                                                        z = this.rolePropertyList.pos.z,
                                                        create_time = 0,
                                                        })
            this.Send(ServerMsgMessage.SM_LEVEL_INFO, {xuantian2 = 0,
                                                        xuantian1 = 0,
                                                        xuantian3 = 0,
                                                        hunshi = 0,
                                                        level = 10,
                                                        attr_level = 80,
        
        })
        end

        this.Send(ServerMsgMessage.SM_ENTER_MAP, this.rolePropertyList)

        this.Send(ServerMsgMessage.SM_ATTRS, {unit_type = 1, unit_id = this.roleInfo.cid, 
                                                attr = {{value = 100, index = 1}, 
                                                {value = 100, index = 1001}, 
                                                {value = 10000, index = 1002},
                                                {value = 1400, index = ATTR_TYPE.ATTR_MAX_NEILI},
                                                {value = 1400, index = ATTR_TYPE.ATTR_NEILI},
                                            }
        })

        --技能包
        if this.roleInfo then
            local hitlist = {}
            local skillList = SkillConfig.GetJobSkills(this.roleInfo.job)
            -- if not this.rolePropertyList.skills then
            --     this.rolePropertyList.skills =  {}
            -- end
            local retTable = {skills = {}}
 
           
            for k, v in pairs(skillList) do
                hitlist[v.id] = true
                table.insert(retTable.skills, {id = v.id, level = 1, hunyin = {}})
            end
            skillList = RoleAttrConfig.GetJobSkill(this.roleInfo.job)
            for k, v in pairs(skillList) do
                --已存在的就不添加
                if not hitlist[v] then
                    table.insert(retTable.skills, {id = v, level = 1, hunyin = {}})
                    hitlist[v] = true
                end
            end
            this.Send(ServerMsgMessage.SM_SKILL_LIST, retTable)
        end

        --视野包
        this.RandomHeroView()

        --初始化任务
        this.Send(ServerMsgMessage.SM_TASK_INFO, {taskid = 1000001, state = TaskState.TSTATE_UNKNOWN, process = {[1] = 0}, ttype = 1})

        --heroTest
        --this.HeroTest()
    elseif id == ClientMsgMessage.CM_EXIT_GAME then

    elseif id == ClientMsgMessage.CM_SERVER_TIME then --心跳
        local retTable = {client_time = data.client_time, server_time = math.floor(Time.unscaledTime)}
        this.Send(ServerMsgMessage.SM_SERVER_TIME, retTable)
    elseif id == ClientMsgMessage.CM_RECEIVE_TASK then -- 接任务
        this.Send(ServerMsgMessage.SM_TASK_INFO, {taskid = data.nID, state = TaskState.TSTATE_DOING, process = {[1] = 0}, ttype = 1})
    elseif id == ClientMsgMessage.CM_SUBMIT_TASK then -- 提交任务
        this.Send(ServerMsgMessage.SM_TASK_INFO, {taskid = data.nID, state = TaskState.TSTATE_DONE, process = {[1] = 0}, ttype = 1})
    elseif id == ClientMsgMessage.CM_CHECK_TASK_PROGRESS then --刷新任务状态
        this.Send(ServerMsgMessage.SM_TASK_INFO, {taskid = data.i32[1], state = TaskState.TSTATE_CAN_SUBMIT, process = {[1] = 0}, ttype = 1})
    elseif id == ClientMsgMessage.CM_DO_SKILL then
        if data.group then
            --没有目标则不回包
            if data.target or data.pos then
                --先回一个技能开始包
                --this.Send(ServerMsgMessage.SM_SKILL_START, {id = data.id, target = data.target, pos = data.pos, from_unit = {id = this.roleInfo.cid, type = UNITTYPE.UT_PLAYER}})

            
                local hp_changes = {}
                local skillInfo = LocalData.hero.skillManager:GetSkillInfo(data.group)
                --for i=1, skillInfo.cfg.calc_num do
                --    table.insert(hp_changes, {val = math.random(1,200), state = 2})
                    --table.insert(hp_changes, {val = 0, state = 0})
                --end
                --延时0.5秒回一个受伤包
                local msg = {
                    id = data.group,
                    launcher = {id = this.roleInfo.cid, type = UnitType.UT_PLAYER},
                    results = {
                        {
                        unit = {id = data.target and data.target.id or nil, type = UnitType.UT_MONSTER},
                        hp_changes = hp_changes}
                    }
                }
                this.Send(ServerMsgMessage.SM_SKILL_RESULT, msg, 0.5)
            end
        end
    elseif id == ClientMsgMessage.CM_MOVE_STOP then
        -- this.rolePropertyList.pos=data.pos
        -- this.propertyList[NetManager.IsUsingFakeServer().id]=this.rolePropertyList
        -- local listString= serialize( this.propertyList)
        -- PlayerPrefs.SetString(this.cid, listString)
        -- PlayerPrefs.Save()
    elseif id == ClientMsgMessage.CM_DEBUG then
        --支持地图传送
        if data.i32 and data.i32[1] == GM_TYPE.GM_TELEPORT then
            local cfg = ConfigManager.GetConfig(ConfigName.MapTeleport, data.i32[2])
            if cfg then
                this.rolePropertyList.map = cfg.map
                this.rolePropertyList.pos = {x = cfg.x, y = cfg.y, z = cfg.z}
                this.rolePropertyList.dir = 0
                this.Send(ServerMsgMessage.SM_ENTER_MAP, this.rolePropertyList)
            end
        end
    end
end

function FakeServer.Send(id, data, delayTime)
    this.AddDelayCall(delayTime or 0, NetManager.RecvFromFakeServer, id, data)
end


function FakeServer.RandomHeroView()
    local retTable = {collections={}, monsters={}, players={},articles={}}
    
    --加怪物
    for i=1, 0 do
        table.insert(retTable.monsters, 
            {
                unit_info = {
                    entity_info = {
                        --pos={z=this.pos.z + math.random(-100,100), y=0.0, x=this.pos.x + math.random(-100,100)}, 
                        pos = {x = -66.936599731445, y = 108.20746612549, z = -50.80980682373},
                        entity_id = 10000 + i,
                    },
                
                max_hp = 100,
                hp = 100,
                move_speed = 4000,
                attack_speed = 1000,
                
                buff_show_state = 0,
                },
                monster_id = i % 2 == 0 and 1002 or 1001,
                first_enter = true,
            })
        end
    --加玩家
    for i=1, 0 do
        local sex = 0
        local job = math.random(1,5)
        if job == 3 then
            sex = 1
        end
        local skillList = SkillConfig.GetJobSkills(job)
        local skills = {}
        for k, v in pairs(skillList) do
            if v and #v > 0 then
                table.insert(skills, {id = v[1].id, extend = {}})
            end
        end
        table.insert(retTable.players, 
            {
            unit_info =
             {
                entity_info =
                 {
                    entity_id = 20000 + i,
                    pos=
                       {
                         z=this.pos.z + math.random(-30,30), y=0.0, x=this.pos.x + math.random(-30,30)
                       }, 
                },
                max_hp = 100,
                hp = 100,
                move_speed = 4000,
                attack_speed = 1000,
                
                buff_show_state = 0,
            },
            name=112344, 
            sex = sex,
            job = job,   
            skills = skills, 
        })
        end
         --加物件
    -- for i=1, 4 do
    --     table.insert(retTable.articles,
    --         {
    --            unit_info = {
    --             entity_info = {
    --                 pos={z=this.pos.z + math.random(-100,100), y=0.0, x=this.pos.x + math.random(-100,100)}, 
    --                 entity_id = 30000 + i,
    --             },
            
    --             max_hp = 100,
    --             hp = 100,
    --             move_speed = 4000,
    --             attack_speed = 1000,
    --             buff_show_state = 0,
    --            },
    --            article_id = 3000+i,
    --            first_enter = true,
    --         })
    -- end


    --[[
    for i=1, 100 do
        if math.random(100) > 50 then
            table.insert(retTable.players, 
            {yifu=0, 
            state=0, 
            hp=100, 
            buffs={}, 
            zhushou=0, 
            maxhp=100, 
            pos={z=this.pos.z + math.random(-50,50), y=0.0, x=this.pos.x + math.random(-50,50)}, 
            sex=1, 
            fushou=0, 
            name=112344, 
            entity_state=0, 
            move_speed=4000, 
            entity_id=10000 + i})
        else
            table.insert(retTable.monsters, 
            {
                entity_id=10000 + i,
                monster_id=1000, 
                pos={z=this.pos.z + math.random(-50,50), y=0.0, x=this.pos.x + math.random(-50,50)}, 
                dest={x=0, y=0, z=0},
                maxhp=100,
                hp=100,
                atkSpeed=1,
                move_speed=4000,
                quility=1,
                camp=0,
                cizhui={},
                buffs={}, 
                state=0, 
                entity_state=0, 
                atk_entity_id=0,
            })
        end
    end
    ]]

    this.Send(ServerMsgMessage.SM_ENTER_VIEW, retTable)
    this.Send(ServerMsgMessage.SM_DRESS_INFO, {data = {}})
end

--这里做一些网络包无关的测试功能
function FakeServer.HeroTest()
    if this.testTimer then
        this.testTimer:Stop()
        this.testTimer = nil
    end

    this.testTimer = Timer.StartLoop(10, -1, function()
        if UnitManager.hero then
            UnitManager.hero:UpdateBuffState(this.testTimer.index % 2)
            this.testTimer.index = this.testTimer.index + 1
        end
    end)
    this.testTimer.index = 1
end

FakeServer.Init()

return FakeServer