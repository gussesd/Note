local MapAudioCtrl = {}
local this = MapAudioCtrl
function MapAudioCtrl.Init()
    this.currentSounds = {} -- 用于存储当前正在播放的音效
    this.eventContainer = EventContainer(EventManager)
    this.eventContainer:Regist(Event.MapAudioOnEnter, this.EventHandle)
    this.eventContainer:Regist(Event.MapAudioOnExit, this.EventHandle)
end

-- 外部消息处理函数，接收消息并处理音效播放逻辑
function MapAudioCtrl.EventHandle(event, args)
    if event == Event.MapAudioOnEnter then
        this.PlaySound(args)
    elseif event == Event.MapAudioOnExit then
        this.StopSound(args)
    end
end
local function Play(id, pos,key)
    return FModAudioManager.PlaySoundwithPos(id, Vector3.New(pos[1], pos[2], pos[3]),key*1000)
end

local function Stop(key)
    CS.FmodAudioManager.Instance:StopSound(key*1000)
end
-- 停止播放背景音乐
local function StopBgm(cfg)
    if cfg.currentPlay and cfg.currentPlay.cover == 1 and FModAudioManager.GetBgmVolume() > 0 then
        cfg.currentPlay.bgmVolume = FModAudioManager.GetBgmVolume()
        FModAudioManager.SetBgmVolume(0)
    end
end
-- 随机逻辑
local function ChooseRandomElement(elements, weights)
    local randomValue = math.random(0, 10000)
    if randomValue > weights then
        return nil
    end
    local cumulativeWeights = {}
    local cumulativeWeight = 0;
    -- 随机权重相等
    for k, v in pairs(elements) do
        cumulativeWeight = cumulativeWeight + 1;
        table.insert(cumulativeWeights, cumulativeWeight)
    end

    --  生成随机数
    local randomValue = math.random(0, cumulativeWeight)
    -- 根据随机数和累积概率选择元素
    local selectedElement = nil;
    for i = 1, table.count(cumulativeWeights), 1 do
        if randomValue <= cumulativeWeights[i] then
            selectedElement = elements[i];
            return selectedElement;
        end
    end
    return selectedElement;
end

-- 随机播放逻辑
local function RandomPlay(cfg)
    local selectedElement = ChooseRandomElement(cfg.inst_ids, cfg.random);
    local inst = ConfigManager.GetConfig(ConfigName.Audio_Inst, selectedElement)
    if inst then
        if cfg.currentPlay then
            Stop(cfg.currentPlay.id)
        end
        cfg.currentPlay = inst
        Play(inst.resource_id, inst.position,inst.id)
        LPrint.log(ColorCode.Yellow, "当前随机到的音效id:" .. inst.resource_id)
        StopBgm(cfg)
    else
        LPrint.log(ColorCode.Yellow, "当前随机到的音效id:无")
    end

end
-- 随机播放逻辑
local function Loop(cfg)
    local count = table.count(cfg.inst_ids)
    cfg.index = cfg.index + 1
    if cfg.index > count then
        cfg.index = 1
    end
    local inst = ConfigManager.GetConfig(ConfigName.Audio_Inst, cfg.inst_ids[cfg.index])
    if cfg.currentPlay then
        Stop(cfg.currentPlay.id)
    end
    cfg.currentPlay = inst
    Play(inst.resource_id, inst.position,inst.id)
    cfg.audioLenght = LPrint.log(ColorCode.Yellow, "当前随机到的音效id:" .. inst.resource_id)
    StopBgm(cfg)
    if cfg.timer then
        Timer.Stop(cfg.timer)
        cfg.timer = Timer.Start(tonumber(cfg.audioLenght), Loop, cfg)
    end
end
-- 开始音效逻辑处理
local function OnSoundStarted(cfg)
    LPrint.log(ColorCode.Yellow, cfg)
    local inst = ConfigManager.GetConfig(ConfigName.Audio_Inst, cfg.inst_ids[1])
    if not inst then
        logError("Audio_Inst没有对应配置:" .. cfg.inst_ids[1])
        return
    end
    cfg.currentPlay = inst
    
    local audioLenght = Play(inst.resource_id, inst.position,inst.id)
    LPrint.log(ColorCode.Yellow, "第一次音效id:" .. inst.resource_id)
    StopBgm(cfg)
    if cfg.interval > 0 then
        cfg.timer = Timer.StartLoopForever(tonumber(cfg.interval), RandomPlay, cfg)
    else
        LPrint.log(ColorCode.Yellow, "当前音效时长:" .. audioLenght)
        cfg.audioLenght = audioLenght
        cfg.index = 1
        if cfg.audioLenght > 0 then
            cfg.timer = Timer.Start(cfg.audioLenght, Loop, cfg)
        end 
    end

    return cfg
end
-- 停止音效逻辑处理
local function OnSoundStopped(cfg)
    Stop(cfg.currentPlay.id)
    if cfg.currentPlay.cover == 1 and cfg.currentPlay.bgmVolume then
        FModAudioManager.SetBgmVolume(cfg.currentPlay.bgmVolume)
    end
    if cfg.timer then
        Timer.Stop(cfg.timer)
        cfg.timer = nil
    end
end
-- 播放音效
function MapAudioCtrl.PlaySound(soundID)
    LPrint.log(ColorCode.Yellow, "进入音效播放区域" .. soundID)
    local soundKey = soundID
    local groupCfg = ConfigManager.GetConfig(ConfigName.Audio_Group, soundID)
    -- 播放音效
    if groupCfg and not this.currentSounds[soundKey] then
        log("Playing sound effect: " .. soundKey)
        this.currentSounds[soundKey] = OnSoundStarted(groupCfg)
    end
end

-- 停止音效
function MapAudioCtrl.StopSound(soundID)
    local soundKey = soundID
    LPrint.log(ColorCode.Yellow, "离开音效播放区域" .. soundID)
    -- 停止音效
    if this.currentSounds[soundKey] then
        log("Stopping sound effect: " .. this.currentSounds[soundKey].currentPlay.id)
        OnSoundStopped(this.currentSounds[soundKey])
        this.currentSounds[soundKey] = nil
    end
end

MapAudioCtrl.Init()
return MapAudioCtrl
