--先尝试获取实时服务器数据
if CS.UnityEngine.Application.isMobilePlatform then
    local loadList = {"DynamicSwitch.lua"}
    for k, v in pairs(loadList) do
        local data = CS.Main.instance:GetOtherFileData(v)
        if not string.isNullOrEmpty(data) then
            load(data)()
        else
            require(v)
        end
    end

    local function Init()
        if SHOW_DEBUGTOOLS then
            --打开gm界面
            CS.TCFramework.DebugTool.instance.show = 1
            CS.TCFramework.DebugTool.instance.enabled = true
            --打开日志
            setlogEnable(true)
            LocalData.SetShowForce(true)
        end
    end

    Init()
end