--是否使用luaide调试
UsingLuaIdeDebug = false

--调试死循环日志使用,日志文件存在assets上一层目录的loop.log和loop_bk.log里
--该功能开启时，自动关闭luaide的调试功能，因为会抢debug.sethook
DebugEndlessLoop = false

local file
local index = 1
function WriteLogToFile(str)
    index = index + 1
    --只保留最后1千行
    if index % 100000 == 0 then
        file:close()
        os.remove(CS.UnityEngine.Application.dataPath .. "/../loop_bk.log")
        os.rename(CS.UnityEngine.Application.dataPath .. "/../loop.log", CS.UnityEngine.Application.dataPath .. "/../loop_bk.log", true)
        file = nil
    end
    -- 以只读方式打开文件
    if not file then
        file = io.open(CS.UnityEngine.Application.dataPath .. "/../loop.log", "w")
    end

    -- 输出文件第一行
    file:write(str .. "\n")
    --file:close()
end

local function SetHook(co)
    if not co then
        debug.sethook(
            function (event, line)
                if line then
                    if Time and Time.time then
                        WriteLogToFile(Time.time .. " " .. debug.getinfo(2).short_src .. ":" .. line)
                    else
                        WriteLogToFile(debug.getinfo(2).short_src .. ":" .. line)
                    end
                end
            end
            , "l")
    else
        debug.sethook(co, 
            function (event, line)
                if line then
                    if Time and Time.time then
                        WriteLogToFile(Time.time .. " " .. debug.getinfo(2).short_src .. ":" .. line)
                    else
                        WriteLogToFile(debug.getinfo(2).short_src .. ":" .. line)
                    end
                end
            end
            , "l")
    end
end

function TrackDebugLog()
    UsingLuaIdeDebug = false
    SetHook()
    local _resume = coroutine.resume
    coroutine.resume = function(co, ...)
        if coroutine.status(co) ~= "dead" then
            SetHook(co)
        end
        return _resume(co, ...)
    end
    local _wrap = coroutine.wrap
    coroutine.wrap = function(fun,dd)
        local newFun =_wrap(function() 
            SetHook()
        return fun();
        end)
    return newFun
    end
end

if DebugEndlessLoop then
    TrackDebugLog()
end

