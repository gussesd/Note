EventManager = rrequire("Event/EventManagerBase")
local this = EventManager

--添加c#消息处理接口
function EventManager.DispatchMsgStrParam(nameID, strID)
    --logError(StringPool.ToStr(nameID),StringPool.ToStr(strID))
    this.Dispatch(Event[StringPool.ToStr(nameID)], StringPool.ToStr(strID))
end

function EventManager.DispatchMsgParam(nameID, param)
    --logError(StringPool.ToStr(nameID),param)
    this.Dispatch(Event[StringPool.ToStr(nameID)], param)
end

function EventManager.DispatchMsgMultiParam(nameID, ...)
    --logError(StringPool.ToStr(nameID),...)
    this.Dispatch(Event[StringPool.ToStr(nameID)], {...})
end

--只支持string参数
function EventManager.DelayDispatchMsg(nameID, strID)
    this.DelayDispatch(Event[StringPool.ToStr(nameID)], StringPool.ToStr(strID))
end