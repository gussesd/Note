require "Event/EventManager"
EventContainer = require "Event/EventContainer"

Event = {
    Game_LowMemory = enum(1),
    Game_SceneLoaded = enum(),
    Game_ApplicationFocus = enum(),
    Game_ApplicationPause = enum(),
    Game_ApplicationQuit = enum(),
    Game_MainDestroy = enum(),
    UI_Create = enum(),
    UI_Show = enum(),
    UI_Hide = enum(),
    UI_Destroy = enum(),
    Net_ConnectSuccess = enum(),
    Net_ConnectFailed = enum(),
    Net_Disconnect = enum(),
    GM_Message = enum(),
    GM_NATIVE_Message = enum(),
    GamePlay_Enter = enum(), -- 进入游戏
    GamePlay_Leave = enum(), -- 离开游戏
    GamePlay_ChangeScene = enum(), -- 切换地图
    RouteInfo_Refresh = enum(), -- 线路信息刷新

    Chat_ServerQuit = enum(), -- 聊天服断开
    GamePlay_EnterMap = enum(), -- 进入地图 （同场景进入不触发）
    GamePlay_TELEPORTMap = enum(), -- 传送到地图
    GamePlay_Task_Dungeon_Refresh_Map = enum(), -- 任务副本重置地图
    GamePlay_TempShow = enum(), -- 临时显示UI内容改变通知
    GamePlay_MapLoadFinish = enum(),    --地图资源加载完成
    GamePlay_HeroRoleLoadFinish = enum(),    --主角模型加载完成
    GamePlay_SyncMCPositionByVC = enum(),    --同步主相机位置到虚拟相机
    GamePlay_UpdateTriggerArea = enum(),
    GamePlay_Task_End = enum(), -- 任务完成（通知模块）
    GamePlay_ServerLv_Refresh = enum(), -- 世界等级更新
    -----------------------------------------------------------------------------------------------------------
    --ui逻辑事件
    UI_Login_Reset = enum(1000), --登陆界面ui重置
    UI_Open_MessageBoxPanel = enum(), --打开MessagePanel
    --UI_Open_TooltipPanel = enum(), --打开TooltipPanel
    UI_RefreshMainUIShowType = enum(), -- 刷新ui显示格式
    UI_HideLoadingUI = enum(), -- loading界面隐藏
    --UI_LoadingUI_Hide=enum(),
    UI_Open_NPCDialogPanel = enum(), --打开Npc对话Panel
    UI_Close_NPCDialogPanel = enum(), --npc对话流程结束
    UI_Open_SkillSpell = enum(), --打开技能吟唱界面
    UI_Open_CollectProgress = enum(), --打开采集进度条界面
    UI_Open_HeightEquipTipPanel = enum(), --打开更好装备提示框
    UI_Open_NPCDialogButton = enum(), --打开对话提示按钮
    UI_Open_ReliveUI    = enum(),   --打开死亡复活界面
    UI_PassAntiAddiction = enum(),--通过实名认证
    UI_NotPassAntiAddiction = enum(),--未通过实名认证
    UI_RoleSelect_Update = enum(1100), --刷新角色选择界面
    UI_RoleSelect_Sel = enum(), --选中角色
    UI_Game_Skill_PublicTime = enum(1200), --技能释放后公Cd
    UI_Game_Skill_CoolDown = enum(), --技能进cd
    UI_Chat_Switch = enum(1300), --切换聊天频道
    UI_Chat_Public = enum(), --聊天
    UI_Chat_Private = enum(), --私聊
    UI_Chat_Private2NPC = enum(), -- 伙伴聊天
    UI_Chat_Refresh = enum(), --刷新聊天框
    UI_Mail_Refresh = enum(), --刷新邮件
    UI_Mail_RefreshState = enum(), --刷新邮件状态
    UI_Mail_DeleteMail = enum(), --邮件删除
    UI_Sect_SM_FAMILY_LIST = enum(1400), --宗门列表刷新
    UI_Sect_SM_FAMILY_INFO = enum(), --宗门信息刷新

    UI_Sect_SM_FAMILY_MEMBER = enum(), --宗门成员刷新
    UI_Sect_SM_FAMILY_DELETE= enum(), --退出宗门
    UI_Sect_SM_FAMILY_EVENT= enum(), --宗门事件更新
    UI_Sect_SM_FAMILY_APPLY= enum(), --宗门申请列表更新
    UI_Sect_SM_REPLY_RES= enum(), --宗门申请列表更新
    UI_Sect_SM_FAMILY_PlAYER_INFO= enum(), --宗门活跃更新
    UI_Sect_SM_FAMILY_SEND_INFO= enum(), -- 派遣信息
    UI_Sect_SM_RED_PACKET_INFO= enum(), --宗门红包信息更新
    UI_Sect_SM_RED_PACKET_LIST= enum(), --宗门红包信息更新2

    UI_Sect_SM_FRIEND_RECOMMEND= enum(), --宗门查找好友拉人
    UI_Sect_FAMILY_UNLOCK_TEAM=enum(), --宗门战团解锁
    UI_FAMILY_MEMBER_TEAM_INFO=enum(), --宗门战团信息

    UI_FAMILY_PLACE_INFO = enum(),--宗门驻地消息更新

    UI_FAMILY_SKILL_INFO=enum(), --宗门技能信息
    UI_Click_Hero = enum(), -- 点击角色模型

    UI_Get_RedPack_RTHead = enum(), -- 红包头像
    UI_Get_Rank_PlayerInfo = enum(), --获取排名
    UI_Get_PreRank_PlayerInfo = enum(),--获取之前排名
    UI_FuncTips_Refresh = enum(), -- 功能推送

    UI_Bag_Refresh = enum(1500),--背包刷新
    UI_Bag_SlotT_HUNYIN = enum(),--背包中魂印格子刷新
    UI_Bag_SlotT_CORE = enum(),--背包中魂核格子刷新
    UI_Bag_UpdateAllMoney = enum(1510),--更新货币1510-1560货币刷新 加 CurrencyType 类型的值
    UI_Bag_UpdateJinHunBi = enum(1511),--更新金魂币 +1
    UI_Bag_UpdateYinHunBi = enum(1512),--更新银魂币 +2
    UI_Bag_UpdateTili = enum(1532),--更新体力+22
    UI_Bag_UpdateDIAMOND = enum(1561),--更新充值砖石+51
    UI_Bag_UpdateBindDIAMOND = enum(1562),--更新绑定砖石+52
    UI_Bag_TOOLITEM_BREAK = enum(), --道具损毁通知
    UI_Game_Refresh_TaskItem = enum(), -- 任务道具更新
    UI_Game_Task_Refresh = enum(1600), --刷新任务
    UI_Game_Task_Init = enum(), -- 任务模块数据初始化
    UI_Game_Task_Guide_Init = enum(), -- 支线模块初始化
    UI_Game_Task_Refresh_UnderwayTask = enum(), -- 刷新当前进行中的任务
    UI_Game_MainTask_Refresh = enum(), -- 主线任务刷新
    UI_Game_MainTask_End = enum() , --主线任务完成
    UI_Game_Task_Guide_Refresh = enum(), -- 引导任务刷新
    UI_Game_Task_Branch_Refresh = enum(), -- 支线任务刷新
    UI_Game_Task_Memoirist_Refresh = enum(), --传记任务刷新
    UI_Game_Task_Week_Refresh = enum(), -- 悬赏任务刷新
    UI_Game_Task_Move = enum(), --任务寻路
    UI_Game_Task_Kid_End = enum(), -- 通知ui任务小节完成
    UI_Game_Task_End = enum(), -- 通知ui任务完成
    UI_Game_Task_Invite_End = enum(), -- 情缘任务完成
    UI_Game_Task_NewTask = enum(), -- 接取到新任务
    UI_Game_Task_FixedLogicStart = enum(), -- 特殊逻辑任务开始
    UI_Game_Task_FixedLogicPause = enum(), -- 特殊逻辑暂停
    UI_Game_Task_FixedLogicRefresh = enum(), --特殊逻辑重置
    UI_Game_Task_FixedLogicEnd = enum(), -- 特殊逻辑任务结束
    UI_Game_Ref_TraceTarget = enum(), --添加任务追踪显示
    UI_Game_AddDef_TraceTarget =enum() , --添加被动追踪显示
    UI_Game_Refresh_DungeonTarget = enum(), -- 副本追踪显示刷新
    UI_Game_AddPass_TraceTarget = enum() , -- 添加通用追踪显示
    UI_Game_AddTimerTask_Refresh = enum(), -- 添加倒计时任务
    UI_Game_FailedTask = enum(), -- 倒计时任务失败
    UI_Game_HiedWind_ByTask = enum(), -- 关闭ui相关的任务行为监听
    UI_Game_FailedPlayingMethod = enum(), -- 客户端玩法失败
    UI_Read_Book = enum(), -- 通过物品阅读信件

    UI_Game_Joystick_Changed = enum(2000), --摇杆变化
    UI_Game_SkillBtn_Clicked = enum(), --点击技能按钮
    UI_Game_SkillBtn_Prepare = enum(), --点击技能按钮
    UI_Game_SkillBtn_Cancel = enum(), --取消点击技能按钮
    UI_Game_FloatBtn_Input = enum(), --上下浮按钮输入
    UI_Game_FloatBtn_UpInput = enum(), --上浮按钮输入
    UI_Game_FloatBtn_DownInput = enum(), --下浮按钮输入
    UI_Game_Gravity_Input = enum(), -- 不同重力状态输入行为切换通知
    UI_Game_SkillBtn_CheckAim = enum(), --检测技能瞄准
    UI_Game_SkillBtn_StartAim = enum(), --开启技能瞄准
    UI_Game_SkillBtn_CloseAim = enum(), --关闭技能瞄准
    UI_Game_SkillBtn_OperatorEffect = enum(), --技能操作特效事件
    UI_Game_Up_Mount =enum(), -- 上坐骑
    UI_Game_Down_Mount = enum(), -- 下坐骑
    UI_Game_Hero_CanFly = enum(), -- 是否可以飞行状态变化

    UI_Game_QTEBtn_Show = enum(), --qte技能显示
    UI_Game_QTEBtn_Hide = enum(), --qte技能隐藏

    UI_Game_Show_Decoration = enum(), --显示ui特效

    UI_Game_Show_Cutsceneplot = enum(3100), --打开剧情对话界面
    UI_Game_Show_PlotDialogue = enum(), --剧情对话
    UI_Game_Show_QTEPanel = enum(),      --剧情QTE
    UI_Game_Show_VideoPanel = enum(),      --剧情显示视频
    UI_Game_Show_ScreenFadePanel = enum(),     --剧情屏幕过度
    UI_Game_Show_SubtitlePanel = enum(),     --剧情字幕
    UI_Game_Show_SwitchSubtitlePanel = enum(),     --剧情切换字幕
    UI_Game_Show_RoleCaptionText = enum(),     --剧情介绍角色
    UI_Game_Show_DialogueSkip = enum(),     --剧情对话跳过
    UI_Game_Show_GiveNamePanel = enum(),     --打开起名界面
    UI_Game_Show_ScrrenEffectPanel = enum(),     --剧情屏幕特效
    UI_Game_Show_ShowImage = enum(),     --剧情打开图片
    UI_Game_Hide_ShowImage = enum(),     --剧情隐藏图片
    UI_Game_Show_ShowImageFadeTime = enum(),     --剧情图片的淡出
    UI_Game_ShowOrHide_BlackCurtain = enum(),     --打开或关闭黑幕专场
    UI_Game_Trigger_AnqiShoot = enum(),     --触发暗器射击事件
    UI_Show_Anqi = enum(),     --显示暗器射击界面
    UI_Plot_AutoEvent= enum(),  --剧情对话自动播放
    UI_QTE_Click= enum(),  --点击QTE
    UI_QTE_Fail= enum(),  --点击QTE
    UI_QTE_End= enum(),  --点击QTE
    UI_GiveName_Succeed= enum(),  --取名成功
    UI_SkillPanel_Refresh = enum(4000),
    UI_SkillHunHuan_Refresh = enum(),
    UI_SkillBreakLevel = enum(),
    UI_SkillHunYin = enum(),
    UI_SkillHunYinSetSkill = enum(),
    UI_UpSkillHunYinLv = enum(),
    UI_HunHuanAudio = enum(),
     --辅助魂印格子刷新
    UI_PlayerPanel_TalentPoint = enum(),
     --角色界面天赋点
    UI_PlayerPanel_Attr = enum(),
    UI_PlayerPF_Attr = enum(),
    UI_PlayerPFValue_Attr = enum(),
     --角色界面天赋点-基础属性
    UI_PlayerPanel_EquipPanel = enum(),
    UI_PlayerPanel_EatFood = enum(),
     --角色
    UI_PlayerPanel_DanYao = enum(),
    UI_PlayerPanel_Detail = enum(),
    UI_PlayerPanel_FangAn = enum(),
    UI_PlayerPanel_SchemeFangAn = enum(),
    UI_PlayerPanel_SchemeDetail = enum(),
    UI_NHHY_BUY_NUM_Refresh = enum(),--
    UI_USE_ITEM = enum(),
    UI_ItemChange_Dress = enum(),
    UI_XianCaoPanel_Refresh = enum(),
    UI_XianCaoAudio = enum(),
     --仙草数据刷新
    UI_ShenQiPanel_Refresh = enum(),--神器（元素弓）数据刷新
    UI_HuoYueDuPanel_Refresh = enum(),--活跃度 数据刷新
    UI_HuoYueZhang_Refresh = enum(),
    UI_HuoYueZhang_ItemRefresh = enum(),
    --时装
    UI_DressPanel_Refresh = enum(),
    UI_RefreshDressModel = enum(),
    UI_Game_Show_PopUp = enum(), -- 游戏弹窗提示
    UI_Game_Hide_PopUp = enum(), -- 弹窗消失通知
    UI_DouLuoRoad_Refresh = enum(),--刷新魂师手札
    UI_ZZTask_Refresh = enum(),--刷新宗族任务
    UI_WuHu_Refresh = enum(), --武魂刷新
    UI_WuHu_Qh = enum(), --武魂强化
    UI_WuHu_Jh = enum(), --武魂进化
    UI_WuHu_Jx = enum(), --武魂觉醒
    UI_WuHu_Fl = enum(), --武魂附灵
    UI_HunqI_FM=enum(), --魂器附魔
    UI_HunqI_TKClose=enum(), -- 神赐属性 弹窗关闭 后显示特效
    UI_WuHu_HqUpdate = enum(), --魂器的穿戴信息更新
    UI_WUHu_HunQiUpdate = enum(), -- 魂器拥有信息更新
    Ui_WuHu_UpdateExpend = enum(), -- 更新魂器消耗选择列表
    UI_WuHu_UpdateSelect_Celerity = enum(), -- 魂器强化快速选择
    UI_Equip_Refresh = enum(), --装备刷新
    --UI_EQUIPJL_SM_REPLY_RES = enum(),--精炼刷新
    UI_Core_Refresh = enum(),     --魔核刷新
    UI_Core_Lock_Update = enum(), --魔核绑定更改
    UI_Core_Exp_Update = enum(),--魔核经验更改
    UI_Core_Level_Update = enum(),--魔核等级更改
    UI_Core_Mat_Select = enum(),     --魔核升级选中刷新
    UI_Core_Job_Select = enum(), --魔核职业属性修改
    UI_PopPush_Bubble = enum(), --添加气泡
    UI_PopClear_Bubble = enum(), --清除所有气泡显示
    UI_PopNow_Bubble = enum(), --停止当前冒泡，然后立刻显示传入提示
    UI_PopNow_Bubble2 = enum(), --停止当前冒泡，然后立刻显示传入提示
    UI_PopArea_Show = enum(),   -- 显示区域名
    UI_PopPush_Tips = enum(), --显示当前获得物品Tips
    UI_PopUp_BeLeave = enum(), -- 即将脱离副本
    UI_PopUp_Leave = enum(), -- 脱离副本导致任务失败
    UI_PopUp_Emergency = enum(), -- 触发突发事件
    UI_PopUp_TOOLITEM_BREAK = enum(), --道具损坏
    UI_PopUp_Announcement = enum(), -- 公告
    UI_PopUp_WaveTip = enum(), --波次提示
    UI_MainUI_Show = enum(),
    UI_MainUI_Hide = enum(),
    UI_ChatPanel2Main_Show = enum(), -- 聊天显示主界面隐藏
    UI_ChatPanel2Main_Hide = enum(), -- 聊天隐藏主界面显示
    UI_PopupTips_Stop = enum(), --暂停左侧Tips弹窗
    UI_PopupTips_Start = enum(), --重新开始左侧Tips弹窗
    UI_MainAnimation_Hide =enum(), -- 主界面隐藏动画
    UI_MapUI_Icon = enum(),--刷新保存标记汇总
    UI_MapUI_IconFresh = enum(),--刷新地图上的标记
    UI_MapUI_ClickOneIcon = enum(),--选中地图上的点
    UI_MapUI_SetVisibleIconAround = enum(),--设置选中地图上选中区域的显隐
    UI_MapUI_ExploreGift = enum(), -- 区域探索奖励
    UI_MapUI_TaskArrowItemOnClick = enum(),--选中地图上的任务点
    UI_MapUI_MapColItemOnClick = enum(),--选中地图上的采集物
    UI_MainUI_SetRaycastMask = enum(),--设置主界面射线遮罩
    
    UI_Show_Guide = enum(), --显示引导
    UI_Show_SliderBtn = enum(), --显示进入倒计时进度条
    UI_Close_SliderBtn = enum(), --关闭进入倒计时进度条
    UI_Target_SetMutualBtn = enum(), --采集拾取 主界面目标层 一般交互按钮 通知ui刷新
    Game_Collection_ShowMutualBtn = enum(),--采集拾取 通知数据层
    Game_Collection_InteractionBtn = enum(), --拾取交互
    Game_Collection_HideMutualBtn = enum(), -- 隐藏采集
    Game_Self_Collection_Open_End = enum(), -- 私有采集物采集完毕
    Game_Single_Self_Collection_Open_End = enum(), -- 永久采集物采集完毕
    Game_Interaction_Animation_On = enum(), -- 通过交互点进行了交互
    Game_Collection_TopView_MutualBtn = enum(), -- 全屏俯视角度沉浸交互
    UI_SetInteractionBtn = enum(), -- 主界面技能层 动作等待交互
    UI_PlayInteractionEx = enum(), -- 继续交互按钮逻辑执行
    UI_CloseInteractionEx = enum(), -- 清除交互按钮逻辑执行
    UI_Show_MHQM = enum(),-- 梦回前面显示通知
    UI_Bone_Refresh = enum(), --魂骨刷新
    Ui_Bone_UpdateExpend = enum(), -- 更新魂器消耗选择列表
    UI_Spirit_Refresh = enum(), --神祗刷新
    UI_ShenQi_Refresh = enum(), --神器刷新
    UI_WaiFuBone_Refresh = enum(), --外附魂骨
    UI_LIfeSkill_Success = enum(), --生活技能信息
    UI_LifeSkill_Update_Level = enum(),
    UI_LifeSkill_ComposeReward_Refresh = enum(),
    UI_LifeSkill_PeiFang_Refresh = enum(),
    UI_LifeSkill_SelMaterial_Refresh = enum(),
    --UI_FenJieBase_Refresh = enum(),
    UI_FenJieInst_Refresh = enum(),--分解实例
    UI_Fishing_Refresh = enum(),
    UI_FishingItem_Refresh = enum(),
    UI_Fishing_State = enum(),--钓鱼状态返回
    UI_PeiFang_Refresh = enum(),
    UI_Shop_SM_REPLY_RES = enum(),--商店购买回应
    UI_Introduction_REPLY_RES = enum(), --签名回应
    UI_Show_LianHun = enum(),--炼魂
    UI_Game_AcquireZuoQi = enum(),--获得坐骑
    ---情缘相关
    UI_QYRingNum_Refresh=enum(),
    UI_QYMarryInfo_Refresh=enum(),
    UI_QYWeddingInfo_Refresh=enum(),
    UI_QYAppointmentInfo_Refresh=enum(),
    UI_QingYuan_GuestInfo=enum(),
    UI_QingYuan_MarryDel=enum(),

    ---
    UI_ZoneMap_RefreshPos = enum(),
    UI_ZoneMap_RefreshLeaderSkill = enum(),
    UI_ZoneMap_STATISTICS = enum(),
    UI_BackHouseEnd = enum(),
    UI_BATTLE_REPORT = enum(),--城战战报
    UI_SetNearPlayerMutualBtn = enum(), -- 更新附近玩家列表显示
    UI_ZoneMap_PlayerDie = enum(),
    UI_ShowJumpBtn = enum(), --展示跳转按钮
    UI_ZONE_REFRESHWIN = enum(),
    UI_Refresh_PlayerHead = enum(), --刷新玩家头像

    -----事件id  5000-6000空出来留给服务端协议，因为协议也是走EventManagerBase.Dispatch，方便查看服务端UI事件
    UI_CollegeSupport_Refresh = enum(6000),--学院赞助
    UI_AnQi_Refresh = enum(),
    UI_AnQi_Update_Order = enum(),
    UI_AnQi_Update_Star = enum(),
    UI_AnQiSkill_Refresh = enum(),
    UI_ChengJiuPanel_Update=enum(),
    UI_ChengJiuPop_Info = enum(),
    ui_JueWei_Info=enum(),
    ui_JueWeiGift_Info =enum(),
    UI_NeiLiUpDate=enum(),--刷新内力
    UI_XuanTianGong_Refresh=enum(),--刷新玄天功
    UI_XuanTianGong_GetNeiLi=enum(),--刷新玄天功
    UI_XuanTianGong_UpLvFail=enum(),--刷新玄天功
    UI_Illustration_Refresh = enum(), --刷新图鉴
    UI_Illustration_Refresh_Map = enum(), --刷新图鉴
    UI_Illustration_OpenRewardPanel = enum(), --打开图鉴奖励页签
    UI_Illustration_PlayAffinity = enum(), --播放亲密度动画
    UI_RefreshInviteNode = enum(), --邀约界面刷新
    UI_Illustration_SM_REPLY_RES = enum(),--图鉴展示
    UI_Team_Action = enum(), --组队事件
    UI_Team_Info = enum(), --组队信息
    UI_Team_DungeonInfo = enum(), --组队副本匹配信息
    UI_Team_DungeonSucess = enum(),-- 副本匹配成功
    UI_Team_Dungeon_Rest = enum(),-- 副本重新匹配
    UI_Team_Dungeon_BMCancel = enum(),--取消报名
    UI_Team_Dungeon_BMSucess = enum(),--报名成功
    UI_Team_RefreshApply = enum(), --刷新队伍是否允许申请
    UI_Team_RefreshCaptainApply = enum(), --队长申请的组队列表
    UIModelRotationCompleted= enum(), --ui模型转动结束
    --UI_Team_AcceptInvitation = enum(), --收到了邀请
    UI_Team_GoDungeon = enum(), --队伍界面前往目标副本
    UI_Team_ShowHunhuan = enum(), --队友显示魂环
    UI_Team_MateMapIcon = enum(),--刷新地图上的队友位置
    UI_FriendTJ_Info=enum(),-- 好友推荐信息
    UI_Friend_Info = enum(),
    UI_Friend_Del = enum(),

    --大师
    -- UI_Master_Success = enum(),--大师成功
    -- UI_Master_Failed = enum(),--大师失败
    -- UI_NormalDungeon_Failed  = enum(),--普通副本失败
   -- UI_Dungeon_Finish = enum(),--副本结束
    UI_Dungeon_Win  = enum(),---副本胜利
    UI_Dungeon_Fail = enum(), --副本失败
    UI_Dungeon_Win_Hide = enum(),--副本结果副本隐藏

    UI_Arena_Response=enum(6100),--操作返回信息
    UI_Arena_Info=enum(),--竞技场信息
    UI_Arena_Request=enum(),--竞技场队友请求
    UI_Arena_Result=enum(),--竞技场结果
    UI_Arena_RefreshRankInfo = enum(),--竞技场段位信息
    UI_Arena_RefreshScoreRewardInfo = enum(),
    UI_Arena_GetScoreRewardSuccess = enum(),--竞技场分数奖励领取成功

    UI_Arena_7v7_RefreshTeamNum = enum(), --竞技场登记队伍数量刷新
    UI_Arena_7v7_RefreshSelfTeam = enum(), --刷新自己战队信息
    UI_Arena_7v7_CreateReponse = enum(),
    UI_Arena_7v7_CreateSuccess = enum(), --竞技场创建队伍成功
    UI_Arena_7v7_CreateFail = enum(),--竞技场创建队伍失败
     UI_Arena_7v7_SignRequest= enum(), --竞技场匹配队友请求
    UI_Arena_7v7_SignReponse = enum(),--竞技场匹配队友响应
    UI_Arena_7v7_Center_SignReponse = enum(),--竞技场中心服响应
    UI_Arena_7v7_SignResult  =  enum(),--竞技场匹配返回
    UI_Arena_7v7_RefreshIndex = enum(),--竞技场页签解锁
    UI_Arena_7v7_RefreshEventType = enum(),--竞技场刷新事件
    UI_Arena_7v7_RefreshBattleState = enum(),--竞技场战斗场次刷新
    UI_Arena_7v7_RefreshTeamBattle = enum(),--竞技场对战图刷新
    UI_Arena_7v7_DrawLots = enum(),--竞技场抽完签
    UI_Arena_7v7_RefreshGuess = enum(),--竞技场个人竞猜刷新
    UI_Arena_7v7_RefreshBattleGuess = enum(),--竞技场竞猜刷新
    UI_Arena_7v7_RefreshGroupGuess = enum(),--竞技场组竞猜刷新
    UI_Arena_7v7_RefreshChampionGuess = enum(),--竞技场冠军竞猜刷新
    UI_Arena_7v7_EnterMapSuccess = enum(),--进入地图修改
    UI_Arena_7v7_GetRewardSuccess = enum(),--7v7奖励领取成功

    UI_XuanTianBaoLu_RefreshUI=enum(),--刷新玄天宝录UI
    UI_XuanTianBaoLu_RefreshPoints=enum(),--刷新玄天宝录点数
    UI_Welfare_Recharge = enum(),--福利充值刷新
    UI_Welfare_RefreshBuyNum = enum(),--刷新购买次数
    UI_FreshMysteryShop = enum(),--刷新神秘商店
    UI_FreshSellShop = enum(),--刷新回购商店
    UI_Welfare_GetMonthCard = enum(),--领取月卡奖励
    UI_Welfare_GetSignUp = enum(),--领取每日奖励
    UI_Welfare_FirstPay = enum(), --首充
    UI_Welfare_RefreshWarToken = enum(),--刷新战令
    UI_Welfare_Refresh_WarToken_Buy =  enum(),--刷新战令购买
    UI_Welfare_Refresh_WarToken_LevelExp = enum(),--更新战令经验
    UI_Welfare_Refresh_WarToken_Reward = enum(),--刷新奖励
    UI_Welfare_RefreshTaskWarToken = enum(),--刷新战令任务
    UI_Welfare_DoneTaskWarToken = enum(),--战令任务完成
    UI_IsTodayOver_Refresh = enum(), --跨天消息
    UI_IsTodayOver_FiveRefresh = enum(), --五点数据刷新

    UI_ShowDrawCard = enum(), --抽卡结果展示
    UI_DrawCardCount = enum(), --抽卡次数

    UI_FamilyBanChat = enum(),--帮会禁言
    UI_FriendApply = enum(),--好友申请

    UI_Game_NewOpen_Init = enum(), -- 功能开启
    UI_Game_NewOpen_TaskInit = enum(),--功能任务开启
    UI_Game_NewOpen_TaskRefresh = enum(),--功能任务刷新
    UI_Game_GongNeng_Open = enum(), --打开新功能弹窗

    UI_Game_JiGuan_Event = enum(),   --机关事件 由机关触发器内部发起，其他地方不建议调用
    UI_Game_JiGuan_Signed = enum(),  --机关新标记
    UI_Game_JiGuan_Reset = enum(),  --机关结点触发重置
    UI_Game_JiGuan_State_Update = enum(), -- 机关状态更新
    UI_Game_JiGuan_RwdGet = enum(),  --机关标记数据就位

    UI_Game_Animal_Kill = enum(),   --动物击杀
    UI_Game_Animal_Oper = enum(),   --动物交互

    UI_ZONE_PLAYER_RANK = enum(), --获取指定战区个人排行
    UI_ZONE_FAMILY_RANK = enum(), --获取指定战区宗门排行
    UI_ZONE_AREA_INFO = enum(), --更新区块信息
    UI_ZONE_TIME_Refresh = enum(), --时间点刷新
    UI_ZONE_JINGJIA_Refresh = enum(),
    UI_ZONE_ZHANTUAN_Refresh = enum(), --获取战团数据刷新界面
    UI_ZONE_Daily_Reward = enum(),
    UI_ZONE_GiveUp = enum(), --放弃竞价
    UI_ZONE_ACHIEVEMENT = enum(), --个人赛季成就

    UI_SomeValue_Update = enum(), -- 人气值

    UI_SoulBone_JingLian = enum(), --刷新精炼等级
    UI_SoulBone_RongHe = enum(), --刷新融合等级
    UI_SoulBone_ShengJie = enum(), --刷新升阶等级

    UI_WaiFu_JinHua = enum(), --外附魂骨进化

    UI_WaiFu_JueXing = enum(), --外附魂骨觉醒

    UI_SmallMap_ColIcon = enum(),--小地图追踪采集物icon刷新
    UI_SmallMap_Icon = enum(),--小地图icon刷新

    UI_Hide_BlackMask = enum(),

    UI_Open_WuPinGetPanel = enum(),

    --寄售
    TradingSuccess = enum(),--寄售成功
    TradingRefresh = enum(),--商品新增，改变，下架刷新
    ShowInstTips = enum(), --请求成功展示实例数据
    --FreshMineLikeGoods = enum(), --添加关注
    AddMineLikeGoods = enum(), --添加关注
    DelMineLikeGoods = enum(), --删除关注

    ---交易锁
    LockRefrsh = enum(), --锁状态刷新
    
    FreshMyGoods = enum(), --自己的上架改变
    FreshRecordGoods = enum(), --记录数据刷新
    PkPriceFail = enum(),--竞价失败
    ShowPriceBox = enum(),--弹出竞价框

    --个性设置
    UI_UpPersonalSet = enum(),--更新设置
    UI_UnlockPersonalSet = enum(),--解锁设置

    UI_UpBasicSet = enum(),--基础设置更新

    UI_Match_Cancel = enum(),--取消匹配

    UI_NiTaiXunLian_Success=enum(),--拟态训练成功消息
    
    UI_HunliPk_Fail = enum(),--魂力pk邀请失败
    UI_HunliPK_Start = enum(), --魂力pk准备开始
    UI_HunliPK_Updata = enum(), --魂力波动
    UI_HunliPK_End = enum(), --魂力pk结束
    
    UI_Player_Dying = enum(),--濒死
    UI_Player_Cure = enum(),--救人
    UI_Player_BrokeCure = enum(),--打断救人

    UI_BloodAwake_Fresh = enum(),--血脉觉醒

    
    UI_AddNewTransmitPoint = enum(),--固定传送
    UI_TransmitEnd = enum(),--传送结束
    
    ----------------------------------------------------------------------------------------
    --RedPoint
    --菜单
    RegisterRed_Menu = enum(50000),
    SendRed_Menu = enum(),
    --挂机
    RegisterRed_Automation = enum(),
    SendRed_Automation = enum(),
    --背包
    RegisterRed_Bag = enum(),
    SendRed_Bag = enum(),
    --头像
    RegisterRed_Head = enum(),
    SendRed_Head = enum(),
    --好友
    RegisterRed_Friend = enum(),
    SendRed_Friend = enum(),
    --聊天
    RegisterRed_Chat = enum(),
    SendRed_Chat = enum(),
    --top收缩按钮
    RegisterRed_TopShrink = enum(),
    SendRed_TopShrink = enum(),
    --商店
    RegisterRed_Shop = enum(),
    SendRed_Shop = enum(),
    --福利
    RegisterRed_Weal = enum(),
    SendRed_Weal = enum(),
    --活动
    RegisterRed_Activity = enum(),
    SendRed_Activity = enum(),
    --竞技场7v7
    RegisterRed_Arena7v7 = enum(),
    SendRed_Arena7v7 = enum(),

    --排行榜
    RegisterRed_Ranking = enum(),
    SendRed_Ranking = enum(),
    --组队
    RegisterRed_Team = enum(),
    SendRed_Team = enum(),
    --图鉴
    RegisterRed_Illustration = enum(),
    SendRed_Illustration = enum(),
    --成就
    RegisterRed_ChengJiu = enum(),
    SendRed_ChengJiu = enum(),
    --血脉
    RegisterRed_BloodAwake = enum(),
    SendRed_BloodAwake = enum(),

    RegisterRed_DouLuoRoad = enum(),
    SendRed_DouLuoRoad = enum(),
    --玄天功
    RegisterRed_XuanTianGong = enum(),
    SendRed_XuanTianGong = enum(),

    --战令
    RegisterRed_ZhanLing = enum(),
    SendRed_ZhanLing = enum(),
    RegisterRed_ZhanLingReward = enum(),
    SendRed_ZhanLingReward = enum(),
    RegisterRed_ZhanLingTask = enum(),
    SendRed_ZhanLingTask = enum(),
    --角色
    RegisterRed_Player = enum(),
    SendRed_Player = enum(),
    RegisterRed_Player_DanYao = enum(),
    SendRed_Player_DanYao = enum(),
    RegisterRed_Player_TalentPoint = enum(),
    SendRed_Player_TalentPoint = enum(),
    RegisterRed_Player_AddEquip = enum(),--是否有没有装装备的位置可以装备
    SendRed_Player_AddEquip = enum(),
    RegisterRed_Player_AddHunQi = enum(),--是否有没有装魂器的位置可以装备
    SendRed_Player_AddHunQi = enum(),
    RegisterRed_Player_AddBone = enum(),--是否有没有装魂骨的位置可以装备
    SendRed_Player_AddBone = enum(),
    RegisterRed_Player_ShiZhuang = enum(),--时装红点
    SendRed_Player_ShiZhuang = enum(),
    --活跃度
    RegisterRed_Vitality = enum(),--活跃度总
    SendRed_Vitality = enum(),
    RegisterRed_Vitality_1 = enum(),--活跃度组1
    SendRed_Vitality_1 = enum(),
    RegisterRed_Vitality_2 = enum(),--活跃度组2
    SendRed_Vitality_2 = enum(),
    RegisterRed_Vitality_3 = enum(),--活跃度组3
    SendRed_Vitality_3 = enum(),
    RegisterRed_Vitality_Gift = enum(),
    SendRed_Vitality_Gift = enum(),
    RegisterRed_Vitality_Medal = enum(),
    SendRed_Vitality_Medal = enum(),
    --仙草
    RegisterRed_XianCao = enum(),
    SendRed_XianCao = enum(),
    RegisterRed_XianCao_PY = enum(),--仙草培养
    SendRed_XianCao_PY = enum(),

    -- 宗门
    RegisterRed_Sect = enum(),
    SendRed_Sect = enum(),
    -- 武魂
    RegisterRed_WuHun =enum(),
    SendRed_WuHun = enum(),
    -- 武魂属性
    RegisterRed_WuHun_SX = enum(),
    SendRed_WuHun_SX = enum(),
    RegisterRed_HunQi = enum(), -- 魂器穿戴
    SendRed_HunQi = enum(),

    RegisterRed_WuHun_JH = enum(),  -- 武魂进化
    SendRed_WuHun_JH = enum(),

    RegisterRed_WuHun_JX = enum(),  -- 武魂进化
    SendRed_WuHun_JX = enum(),

    --魂骨
    RegisterRed_SoulBone = enum(),
    SendRed_SoulBone = enum(),
    --神器
    RegisterRed_ShenQi = enum(),
    SendRed_ShenQi = enum(),

    --这里最大值 红点消息往上面加
    RegisterRed_Max  = enum(),
    -----------------------------------------------------------------------------------------------
    --游戏逻辑
    Game_Role_Move_From = enum(100000),
    Game_Role_Move_Stop = enum(),
    Game_Role_Instant = enum(), --拉回
    Game_Role_JumpStart = enum(),
    Game_Role_JumpEnd = enum(),
    Game_Role_FallGround = enum(),
    Game_Role_Create = enum(), --场景切换后角色重新生成
     --角色移动
    Game_Hero_Resurgence =enum(), -- 玩家复活
    --Game_Role_Move_Mode = enum(), --移动模式
    Game_Role_Open_Wings = enum(),  --开关翅膀
    Game_Role_Move_To = enum(), --移动到
    Game_Role_Tran_To = enum(), --传送门移动到
    Game_Role_Move_Path = enum(),   --移动队列
    Game_Role_UpdateEquip = enum(100100), --刷新装备
    Game_Role_Update_AttrSpeed = enum(), --同步移动速度倍率
    Game_Role_Update_BuffShow = enum(), --同步buff显示状态
    Game_Role_Update_BuffList = enum(), --同步buff列表
    Game_Role_Update_Shield = enum(), -- 护盾刷新
    Game_Role_Update_HP = enum(), --同步血量变化
    Game_Trap_Update_Time = enum(), --更新城战机关占领时间刷新

    Game_Trap_Update_Side = enum(), --更新城战机关归属

    Game_Role_HaoPointUpdata = enum(),

    Game_Role_Update_Dress = enum(), --同步时装
    Game_Role_Update_Wing = enum(), --同步玩家翅膀
    Game_Hero_GravityType_Change = enum(), --主角重力状态切换
    Game_Hero_Loaded = enum(), --主角模型加载完成
    Game_Monster_PlayAnim = enum(), --怪物播放动画
    Game_Player_Fast_Move = enum(), --玩家疾行
    Game_Player_ChangeForce = enum(), --玩家改变阵营
    Game_HunliPK_OtherView = enum(), --魂力比拼路人视角
    Game_Role_Update_Level = enum(), --刷新等级
    Game_Role_Update_HunShi = enum(), --刷新魂师等级
    Game_Role_GrowUp = enum(), --模型切换为成人
    Game_Hero_Init_HunHuan = enum(),    --初始化魂环状态
    Game_Monster_Lost_KeyDecoration = enum(),   --怪物宝箱特效
    Game_Monster_Update_KeyDecoration = enum(), --刷新怪物宝箱特效
    Game_Monster_Start_Dig = enum(),--挖尸开始
    Game_Monster_Finish_Dig = enum(), --挖尸结束
    Game_Collection_Update_KeyDecoration = enum(),  --刷新宝箱特效
    Game_Unit_Host_Change = enum(), --对象宿主状态变更
    Game_Unit_Net_Play_Action = enum(),  --播放动作
    Game_Unit_Net_Update_Pos = enum(),  --更新坐标
    Game_Unit_Set_Dir = enum(), --设置朝向
    Game_Unit_TerrainMaterial_Change = enum(),  -- 对象运动状态切换
    Game_Unit_MotionState_Change = enum(),  -- 对象运动状态切换
    UI_ReliveOK_CloseGrounState = enum(),  -- 复活按钮点击 关闭地表状态

    Game_Monster_EventNotify = enum(), --怪物警戒
    --自动打怪
    Game_AutoController = enum(100200),
    Game_AutoWalk = enum(),
    Game_AutoPlaySkill = enum(),
    Game_AutoResultSkill = enum(),
    --技能
    Game_RefreshSkill = enum(100300),
    Game_SmSkillMissile = enum(),
    Game_GudResetSkill = enum(),
    Game_ResetSkill = enum(),
    Game_RefreshTangMenSkill = enum(),
    --设置更新
    Game_RefreshBasicSet = enum(),
    --剧情
    Game_Cutscene_Pause = enum(100400), --暂停动画
    Game_Cutscene_ResumePause = enum(), --恢复动画
    Game_Cutscene_Time = enum(), --播放时间
    Game_Cutscene_ChangeTime = enum(), --改变时间了
    Game_Cutscene_PausedExceptAnimation = enum(), --暂停剧情除了动画
    Game_Cutscene_End = enum(), --剧情动画结束
    Game_Cutscene_HideGameObject= enum(),  --隐藏指定游戏对象
    Game_Cutscene_ShowHunhuan= enum(),  --显示魂环
    Game_Cutscene_HideHunhuan= enum(),  --隐藏魂环
    Game_Cutscene_ShowCameraEffect= enum(),  --显示相机特效
    Game_Cutscene_Photograph = enum(),     --拍照
    Game_Cutscene_CameraPostion= enum(),     --相机位置
    --玩家
    Game_Player_Update_HP = enum(100500), --玩家血量更新
    Game_Player_Update_MP = enum(), --玩家魂力更新
    Game_Player_Update_NEILI = enum(), --玩家内力更新
    Game_Player_Update_EXP = enum(), --玩家经验更新
    Game_Player_Update_Level = enum(), --玩家等级更新
    Game_Player_Update_HeadIcon = enum(), --玩家头像变更
    Game_Target_Change = enum(100600), --目标更换
    Game_Target_Hp = enum(), --目标属性变化
    Game_Target_Buff = enum(), --目标buff变化
    Game_Collection_Update = enum(100700), --陷阱状态刷新
    Game_LocalCollection_Update = enum(), --宝箱状态刷新
    Game_Role_Buff = enum(), -- 单位buff变化刷新
    Game_Role_Buff_Special = enum(),    --buff的特殊状态变化
    Game_Role_Buff_Element = enum(),    --元素护盾buff状态变化
    Game_Near_Player = enum(),    --附近玩家
    Game_FollowCap = enum(), -- 跟随队长
    
    --领主
    Game_Boss_Show_Target = enum(), -- boss 目标显示
    Game_Boss_Hide_Target = enum(), -- boss 目标隐藏
    Game_Boss_Hp_Update = enum(), -- boss 血量更新
    Game_Boss_Buff_Update = enum(), -- boss buff 更新
    Game_Boss_Distance_Update = enum(), -- boss 距离 更新

    Game_AddElementBall = enum(),    --添加元素球
    Game_Team_SelfInfo = enum(), --自己队伍信息
    Game_Team_InviteListChange = enum(), --邀请列表变化
    Game_Team_ByInviteListChange = enum(), --被邀请者列表变化
    Game_Team_RefreshSelfMemberHPAndMp = enum(),

    --副本
    Game_Dungeon_State_Change = enum(100800),--副本进程改变
    Game_Dungeon_Init= enum(),--副本信息初始化
    Game_Dungeon_Enter = enum(),--副本进入
    Game_Dungeon_Leave = enum(),--副本退出
    Game_Dungeon_Target_Refresh = enum(),--目标刷新
    Game_Dungeon_PlayerNum_Change = enum(),--副本角色数量改变
    Game_DungeonZoneArea_Target_Refresh = enum(),--目标刷新
    Game_Dungeon_Detail_Refresh = enum(),--副本详细信息
    Game_Dungeon_Battle_Refresh = enum(),--副本战斗信息
    Game_Dungeon_Leader_Change = enum(),--副本队长信息
    Game_Dungeon_Restart_Info = enum(),--重新开始副本
    Game_Dungeon_Zan_Refresh = enum(),--副本点赞信息
    Game_Dungeon_Hp_Refresh = enum(),--副本血量信息
    Game_Dungeon_Hero_Die = enum(),--副本英雄死亡
    Game_Dungeon_LimitTime_Change = enum(),--副本结束时间变化

    Game_Dungeon_Arena_Detail_Refresh = enum(),
    Game_Dungeon_Arena_Pos_Refresh = enum(),
    Game_Dungeon_Arena_Battle_Report = enum(),
    Game_Dungeon_First_Reward_Info = enum(),
    Game_Master_Damage_Info = enum(),
    --Unit
    Game_Unit_Npc_Show = enum(101000), -- npc模型显示
    Game_Unit_Npc_Hide = enum(), -- npc 模型隐藏

    Game_Unit_Npc_OpenBubble = enum(), -- npc开始自动对话
    Game_Unit_Npc_BreakBubble = enum(), -- 打断npc自动对话

    Game_Refresh_Guard_List = enum(), -- 刷新躲避追中的箭头列表
    Game_Refresh_Threat_List = enum(), -- 刷新仇恨列表箭头
    --Model加载完毕
    Role_Load_Success = enum(),
    --Audio
    MapAudioOnEnter = enum(),
    MapAudioOnExit = enum()
}

CSharpEvent = {
    "Game_Cutscene_HideGameObject","Game_Cutscene_HideHunhuan","Game_Cutscene_PausedExceptAnimation",
    "Game_Cutscene_Photograph","Game_Cutscene_ShowCameraEffect","Game_Cutscene_ShowHunhuan",
    "UI_Game_Show_DialogueSkip","UI_Game_Show_GiveNamePanel","UI_Game_Show_SwitchSubtitlePanel",
    "UI_Game_Trigger_AnqiShoot","UIModelRotationCompleted","UI_Game_ShowOrHide_BlackCurtain",
    "UI_Game_Hide_ShowImage","UI_Game_Show_PlotDialogue","UI_Game_Show_QTEPanel",
    "UI_Game_Show_RoleCaptionText","UI_Game_Show_ScreenFadePanel","UI_Game_Show_ScrrenEffectPanel",
    "UI_Game_Show_ShowImage","UI_Game_Show_ShowImageFadeTime","UI_Game_Show_SubtitlePanel","Game_Cutscene_CameraPostion"
}
