local EventManagerBase = {}
local this = EventManagerBase
local events = {}
local dispatchCount = 0
local savedActions = {}
local delayList = {}
local newDelayList = {}

local ACTION_TYPE_REGIST<const> = 1
local ACTION_TYPE_UNREGIST<const> = 2

function EventManagerBase.Regist(id, func, owner, priority)
    if not id then
        return
    end

    if this.IsDispatching() then
        table.insert(savedActions, {ACTION_TYPE_REGIST, id, func, owner})
        return
    end

    local items = events[id]
    if not items then
        items = {}
        events[id] = items
    end

    priority = priority or 0
    local index
    for k, v in ipairs(items) do
        if priority < v[3] then
            index = k
            break
        end
    end

    table.insert(items, index or #items + 1, {func, owner, priority})
end

function EventManagerBase.UnRegist(id, func, owner)
    local items = events[id]
    if not items then
        return false
    end

    if this.IsDispatching() then
        table.insert(savedActions, {ACTION_TYPE_UNREGIST, id, func, owner})
        return
    end

    for k, v in ipairs(items) do
        if v[1] == func and v[2] == owner then
            table.remove(items, k)
            return true
        end
    end

    return false
end

function EventManagerBase.Dispatch(id, ...)
    local items = events[id]
    if not items then
        return false
    end

    this.BeginDispatch()
    for k, v in ipairs(items) do
        if v[2] then
            scall(v[1], v[2], id, ...)
        else
            scall(v[1], id, ...)
        end
    end
    this.EndDispatch()
end

-- 延时消息，会在下一帧触发，自动覆盖id，所以message内容不一致的话，不要使用这个函数
-- 主要作用是延时和合并同类消息，避免同一帧同一事件触发多次
function EventManagerBase.DelayDispatch(id, ...)
    if not this.lockDelay then
        -- 如果当前没有定时器，则开启定时器
        if not this.timer then
            this.timer = Timer.StartLoop(0, -1, this.HandlerDelay)
        end
        Timer.Resume(this.timer)

        delayList[id] = {...}
    else
        newDelayList[id] = {...}
    end
end

function EventManagerBase.HandlerDelay()
    this.lockDelay = true
    for k, v in pairs(delayList) do
        this.Dispatch(k, v[1], v[2])
        delayList[k] = nil
    end
    this.lockDelay = false

    if table.isNullOrEmpty(newDelayList) then
        if this.timer then
            Timer.Pause(this.timer)
        end
    else
        for k, v in pairs(newDelayList) do
            delayList[k] = v
            newDelayList[k] = nil
        end
    end
end

function EventManagerBase.HasCallback(id)
    local items = events[id]
    return items and #items > 0
end

function EventManagerBase.BeginDispatch()
    dispatchCount = dispatchCount + 1
end

function EventManagerBase.EndDispatch()
    dispatchCount = dispatchCount - 1
    if dispatchCount > 0 then
        return
    end

    if #savedActions > 0 then
        for k, v in ipairs(savedActions) do
            if v[1] == ACTION_TYPE_REGIST then
                this.Regist(v[2], v[3], v[4], v[5])
            else
                this.UnRegist(v[2], v[3], v[4])
            end
        end
        savedActions = {}
    end
end

function EventManagerBase.IsDispatching()
    return dispatchCount > 0
end

-- --添加一个消息死锁时的解控机制，目前认为所有跨帧的锁定都是异常的。
function EventManagerBase.HandleDispatching()
    if dispatchCount > 0 then
        dispatchCount = 0
        if CS.UnityEngine.Debug.isDebugBuild then
            logError(
                "发现消息模块的异常死锁，需要检查下之前的错误日志或者检查处理消息的逻辑代码有没有开协程")
        end
    end
end

function EventManagerBase.Reset()
    if this.timer then
        Timer.Stop(this.timer)
        this.timer = nil
    end
end

return EventManagerBase
